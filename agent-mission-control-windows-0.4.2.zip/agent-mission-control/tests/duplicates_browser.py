"""Live HTTP/SSE and DOM duplicate checks in Chromium/Linux, NOT a Windows/VS Code test."""
import json, os, tempfile, subprocess, time, urllib.request, urllib.error
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
checks=[]
with tempfile.TemporaryDirectory() as temp:
    env={**os.environ,'MC_DATA_DIR':temp,'MC_PORT':'14320'}
    proc=subprocess.Popen(['node',str(ROOT/'src/server.mjs')],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    url='http://127.0.0.1:14320'
    try:
        for _ in range(100):
            try:
                with urllib.request.urlopen(url+'/healthz',timeout=.2):break
            except Exception:time.sleep(.05)
        token=(Path(temp)/'token').read_text().strip()
        with sync_playwright() as p:
            b=p.chromium.launch(executable_path=os.environ.get('CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
            context=b.new_context(viewport={'width':1500,'height':1000});page=context.new_page();errors=[]
            page.on('pageerror',lambda e:errors.append(str(e)))
            assert context.request.post(url+'/api/login',data={'token':token}).status==200
            page.goto(url+'/');page.wait_for_function("document.querySelector('#hubStatus').textContent.includes('Lokální hub připojen')")
            h={'Authorization':'Bearer '+token};now=int(time.time()*1000)
            s={'id':'chat-unique','agent':'zoo','host':'test-linux','environment':'Linux','workspace':'/repo','project':'Original project','state':'needs_input','evidence':'api','activity':'Choose one','activityAt':now,'stateSince':now,'events':[],'messages':[],'capabilities':['open']}
            e={'version':1,'sourceId':'window-original','epoch':'epoch-one','seq':1,'label':'Original window','sessions':[s]}
            assert context.request.post(url+'/api/claim',headers=h,data=e).status==200
            assert context.request.post(url+'/api/ingest',headers=h,data=e).status==200
            page.wait_for_function("document.querySelectorAll('.session-row').length===1")
            key=page.locator('.session-row').first.get_attribute('data-select')
            page.locator('.session-row').first.click()
            checks.append('One connected session is rendered from the real hub through SSE')
            other={**e,'sourceId':'random-second','epoch':'epoch-two','sessions':[{**s,'project':'Must not replace original'}]}
            conflict=context.request.post(url+'/api/ingest',headers=h,data=other)
            assert conflict.status==409 and conflict.json()['code']=='SESSION_IN_USE'
            page.wait_for_timeout(350)
            assert page.locator('.session-row').count()==1
            assert 'Original project' in page.locator('.session-row').inner_text()
            assert page.locator('.session-row').first.get_attribute('data-select')==key
            checks.append('Conflicting second window returns HTTP 409 and does not add/replace a dashboard row')
            page.reload();page.wait_for_function("document.querySelectorAll('.session-row').length===1")
            assert page.locator('.session-row').first.get_attribute('data-select')==key
            checks.append('Reloading the dashboard is read-only and keeps the same single session key')
            assert context.request.post(url+'/api/release',headers=h,data=e).status==200
            other['sessions']=[s]
            assert context.request.post(url+'/api/claim',headers=h,data=other).status==200
            assert context.request.post(url+'/api/ingest',headers=h,data=other).status==200
            page.wait_for_timeout(500)
            assert page.locator('.session-row').count()==1
            assert page.locator('.session-row').first.get_attribute('data-select')==key
            checks.append('Explicit release and new owner update the existing row, not a second session')
            independent={**other,'seq':2,'sessions':[s,{**s,'id':'truly-another-task','project':'Independent task'}]}
            assert context.request.post(url+'/api/ingest',headers=h,data=independent).status==200
            page.wait_for_function("document.querySelectorAll('.session-row').length===2")
            checks.append('A genuinely different task in the same workspace remains separate')
            assert not errors,errors
            checks.append('No uncaught browser JavaScript errors')
            b.close()
    finally:
        proc.terminate();proc.communicate(timeout=5)
print(json.dumps({'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2))
