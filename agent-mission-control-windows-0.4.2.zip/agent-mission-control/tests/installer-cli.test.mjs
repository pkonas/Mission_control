import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdtemp,rm,readFile,writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const {capture,succeeded,listedVersions,manage}=require('../windows/vscode-cli.cjs');
const fixture=fileURLToPath(new URL('./fixtures/fake-vscode.cjs',import.meta.url));
async function fake(scenario,fn){
 const dir=await mkdtemp(path.join(tmpdir(),'mc-cli-'));
 const state=path.join(dir,'state'),argsLog=path.join(dir,'args.jsonl');
 const run=(file,args,opts)=>capture(file,args,{...opts,env:{...opts.env,FAKE_CODE_STATE:state,FAKE_CODE_SCENARIO:scenario,FAKE_CODE_ARGS:argsLog}});
 const config={executable:process.execPath,cli:fixture,vsix:path.join(dir,'bridge & 100% ! žluťoučký.vsix'),version:'0.4.2'};
 try{await fn({dir,state,argsLog,run,config});}finally{await rm(dir,{recursive:true,force:true});}
}
test('CLI regression: the reported DEP0169 warning does not turn exit 0 into a failure',()=>fake('warning',async({config,run})=>{
 const r=await manage(config,run);assert.equal(r.ok,true);assert.equal(r.hasWarnings,true);assert.match(r.commands[0].result.stderr,/DEP0169/);assert.equal(r.commands.length,2);assert.deepEqual(r.versions,['0.4.2']);
}));
test('CLI regression: genuine nonzero exit is a failure',()=>fake('failure',async({config,run})=>{
 const r=await manage(config,run);assert.equal(r.ok,false);assert.equal(r.commands.length,1);assert.match(r.message,/7/);assert.match(r.commands[0].result.stderr,/incompatible/);
}));
test('CLI regression: exit 0 without an installed bridge is NOT success',()=>fake('missing',async({config,run})=>{
 const r=await manage(config,run);assert.equal(r.ok,false);assert.match(r.message,/nepotvrdil/);
}));
test('CLI regression: wrong installed version is NOT success',()=>fake('wrong',async({config,run})=>{
 const r=await manage(config,run);assert.equal(r.ok,false);assert.deepEqual(r.versions,['0.2.0']);
}));
test('CLI regression: list failure after successful installation is surfaced',()=>fake('list-failure',async({config,run})=>{
 const r=await manage(config,run);assert.equal(r.ok,false);assert.match(r.message,/9/);
}));
test('CLI repair: reinstalling same version is idempotent and verified',()=>fake('warning',async({config,run})=>{
 assert.equal((await manage(config,run)).ok,true);assert.equal((await manage(config,run)).ok,true);
}));
test('CLI update: 0.2.0 is replaced by verified 0.4.2',()=>fake('warning',async({config,run,state})=>{
 await writeFile(state,'0.2.0');assert.equal((await manage(config,run)).ok,true);assert.equal(await readFile(state,'utf8'),'0.4.2');
}));
test('CLI uninstall: removes only bridge ID and verifies absence',()=>fake('warning',async({config,run,state,argsLog})=>{
 await writeFile(state,'0.4.2');const r=await manage({...config,action:'uninstall'},run);assert.equal(r.ok,true);const calls=(await readFile(argsLog,'utf8')).trim().split('\n').map(JSON.parse);assert.deepEqual(calls[1],['--uninstall-extension','local-mission-control.bridge']);
}));
test('CLI uninstall: already absent is idempotent',()=>fake('warning',async({config,run})=>{
 const r=await manage({...config,action:'uninstall'},run);assert.equal(r.ok,true);assert.equal(r.alreadyAbsent,true);assert.equal(r.commands.length,1);
}));
test('CLI uninstall: false success with remaining extension is detected',()=>fake('retain',async({config,run,state})=>{
 await writeFile(state,'0.4.2');const r=await manage({...config,action:'uninstall'},run);assert.equal(r.ok,false);assert.match(r.message,/stále/);
}));
test('CLI arguments: spaces, Czech names and shell metacharacters remain literal',()=>fake('warning',async({config,run,argsLog})=>{
 const profile='Vývoj & remote %PATH% !';const r=await manage({...config,profile},run);assert.equal(r.ok,true);const calls=(await readFile(argsLog,'utf8')).trim().split('\n').map(JSON.parse);assert.deepEqual(calls[0],['--profile',profile,'--install-extension',config.vsix,'--force']);assert.deepEqual(calls[1],['--profile',profile,'--list-extensions','--show-versions']);
}));
test('CLI environment: child-only Electron mode; remote routing and VSCODE_DEV removed',async()=>{
 let seen;const r=await manage({executable:'unused',cli:'cli.js',action:'verify'},async(_file,_args,opts)=>{seen=opts.env;return {exitCode:0,stdout:'local-mission-control.bridge@0.4.2\n',stderr:'',timedOut:false,overflow:false,spawnError:''};});assert.equal(r.ok,true);assert.equal(seen.ELECTRON_RUN_AS_NODE,'1');assert(!('VSCODE_DEV' in seen));assert(!('VSCODE_IPC_HOOK_CLI' in seen));assert(!('NODE_OPTIONS' in seen));
});
test('CLI parser: exact extension ID, BOM, CRLF and case-insensitive publisher',()=>{
 assert.deepEqual(listedVersions('\uFEFFother@1\r\n Local-Mission-Control.Bridge@0.4.2 \r\nlocal-mission-control.bridge-extra@9\n'),['0.4.2']);
});
test('Process capture: large stdout AND stderr do not deadlock',async()=>{
 const r=await capture(process.execPath,['-e',"process.stdout.write('a'.repeat(150000));process.stderr.write('b'.repeat(150000))"]);assert(succeeded(r));assert.equal(r.stdout.length,150000);assert.equal(r.stderr.length,150000);
});
test('Process capture: timeout is not success',async()=>{
 const r=await capture(process.execPath,['-e','setTimeout(()=>{},10000)'],{timeoutMs:50});assert(!succeeded(r));assert.equal(r.timedOut,true);
});
test('Process capture: missing executable is a structured failure',async()=>{
 const r=await capture(path.join(tmpdir(),'mc-never-an-executable-497571'),[]);assert(!succeeded(r));assert.match(r.spawnError,/ENOENT/);
});
test('Process capture: excessive output is bounded and fails visibly',async()=>{
 const r=await capture(process.execPath,['-e',"process.stdout.write('a'.repeat(500000))"],{maxOutput:10000});assert.equal(r.overflow,true);assert(!succeeded(r));assert(r.stdout.length<=10000);
});
test('Helper CLI: structured UTF-8 result survives deprecation output',()=>fake('warning',async({config,dir,state,argsLog})=>{
 const c=path.join(dir,'config.json'),out=path.join(dir,'result.json');await writeFile(c,'\uFEFF'+JSON.stringify(config));
 const helper=fileURLToPath(new URL('../windows/vscode-cli.cjs',import.meta.url));const r=await capture(process.execPath,[helper,c,out],{env:{...process.env,FAKE_CODE_STATE:state,FAKE_CODE_SCENARIO:'warning',FAKE_CODE_ARGS:argsLog}});
 assert.equal(r.exitCode,0);const result=JSON.parse(await readFile(out,'utf8'));assert.equal(result.ok,true);assert.equal(result.hasWarnings,true);
}));
test('Helper CLI: true error has a nonzero helper result',()=>fake('failure',async({config,dir,state})=>{
 const c=path.join(dir,'config.json'),out=path.join(dir,'result.json');await writeFile(c,JSON.stringify(config));
 const helper=fileURLToPath(new URL('../windows/vscode-cli.cjs',import.meta.url));const r=await capture(process.execPath,[helper,c,out],{env:{...process.env,FAKE_CODE_STATE:state,FAKE_CODE_SCENARIO:'failure'}});
 assert.equal(r.exitCode,2);assert.equal(JSON.parse(await readFile(out,'utf8')).ok,false);
}));
test('Helper rejects unknown operations',async()=>{
 await assert.rejects(manage({action:'delete-all'}),/Unsupported/);
});
