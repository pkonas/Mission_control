import {pathToFileURL} from 'node:url';
import {readFile} from 'node:fs/promises';
const sourceRoot=process.argv[2]||new URL('..',import.meta.url).pathname;
const {createHub}=await import(pathToFileURL(sourceRoot+'/src/server.mjs'));
const version=JSON.parse(await readFile(sourceRoot+'/package.json','utf8')).version;
import {bridgeHarness,until,pause,TOKEN,browser} from './helpers/live-bridge.mjs';
import {mkdtemp,rm,writeFile} from 'node:fs/promises';
import os from 'node:os';import path from 'node:path';
const folder=await mkdtemp(path.join(os.tmpdir(),'mc-038-race-'));
const hub=await createHub({port:0,persist:false,token:TOKEN});
const h=bridgeHarness({hub,folder,sourceRoot});
try {
 await h.activation;await until(()=>hub.store.sessions.size===1);
 const old=await h.freeze(),ui=await browser(hub);
 await ui('/api/disconnect',{sourceId:old.sourceId,epoch:old.epoch});
 await old.tick();await until(async()=>(await h.status()).paused);
 const get=h.secrets.get.bind(h.secrets);let fired=false;
 h.secrets.get=key=>{if(key==='hubToken'&&!fired){fired=true;h.fireWorkspaceFolders();}return get(key);};
 await h.command('missionControl.reconnect');await pause(100);
 const status=await h.status();if(status.connected)await until(()=>hub.store.sessions.size===1);
 const result={version,realHub:true,realBridge:true,vscodeApi:'test double',scenario:'Workspace-change auto-start races explicit Reconnect while token lookup resolves',eventFired:fired,connected:status.connected,paused:status.paused,liveSessions:hub.store.sessions.size,producers:h.instances.length,logs:h.logs};
 console.log(JSON.stringify(result,null,2));
 await writeFile(new URL('../docs/reconnect-race-'+version+'.json',import.meta.url),JSON.stringify(result,null,2));
} finally {await h.close();await hub.close();await rm(folder,{recursive:true,force:true});}
