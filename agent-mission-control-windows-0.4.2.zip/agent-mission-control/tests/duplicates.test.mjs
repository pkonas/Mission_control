import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm,symlink} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {Store} from '../src/store.mjs';
import {createHub} from '../src/server.mjs';
import tools from '../bridge/src/identity.cjs';
import transport from '../bridge/src/producer.cjs';
import single from '../bridge/src/single-flight.cjs';
import desktop from '../bridge/src/desktop.cjs';
import {startCodexClient} from '../src/codex-client.mjs';
import {fileURLToPath} from 'node:url';
const token='a'.repeat(64),headers={Authorization:`Bearer ${token}`,'Content-Type':'application/json'};
const session=(extra={})=>({id:'task-1',agent:'zoo',project:'P',workspace:'/home/petr/repo',host:'linux-1',environment:'Linux',state:'working',evidence:'api',activityAt:10000,stateSince:10000,events:[],messages:[],pending:[],capabilities:['open'],...extra});
const envelope=(sourceId='window-1',epoch='epoch-one',sessions=[session()],seq=1)=>({version:1,sourceId,epoch,seq,label:sourceId,sessions});
function code(expected){return e=>e.status===409&&e.code===expected;}
async function withHub(fn,options={}){const h=await createHub({port:0,token,persist:false,...options});try{return await fn(h);}finally{await h.close();}}
const post=(h,p,b)=>fetch(h.url+p,{method:'POST',headers,body:JSON.stringify(b)});
async function temporary(fn){const dir=await mkdtemp(path.join(os.tmpdir(),'mc-unique-'));try{return await fn(dir);}finally{await rm(dir,{force:true,recursive:true});}}
async function until(fn){for(let n=0;n<80;n++){const value=fn();if(value)return value;await new Promise(r=>setTimeout(r,25));}throw new Error('Condition timed out');}
test('Duplicate guard: active source cannot be replaced by a different epoch',()=>{
 const s=new Store({now:()=>10000});s.claim(envelope());assert.throws(()=>s.claim(envelope('window-1','epoch-two')),code('CONNECTION_IN_USE'));assert.equal(s.sources.get('window-1').epoch,'epoch-one');
});
test('Duplicate guard: repeated claim by the owner is idempotent',()=>{const s=new Store({now:()=>10000});s.claim(envelope());s.ingest(envelope());for(let n=0;n<20;n++)s.claim(envelope());assert.equal(s.sources.size,1);assert.equal(s.sources.get('window-1').seq,1);assert.equal(s.sessions.size,1);});
test('Duplicate guard: same agent task from random source ids is rejected atomically',()=>{
 const s=new Store({now:()=>10000});s.ingest(envelope());const before=JSON.stringify(s.snapshot());
 assert.throws(()=>s.ingest(envelope('random-2','epoch-two',[session({id:'new-legitimate-task'}),session({state:'review',focusUri:'vscode://different-window'})])),code('SESSION_IN_USE'));
 assert.equal(JSON.stringify(s.snapshot()),before);
});
test('Duplicate guard: same id in Zoo and Codex remains two different tasks',()=>{const s=new Store({now:()=>10000});s.ingest(envelope('w','epoch-one',[session(),session({agent:'codex'})]));assert.equal(s.sessions.size,2);});
test('Duplicate guard: distinct chats in one workspace are permitted',()=>{const s=new Store({now:()=>10000});s.ingest(envelope('w','epoch-one',[session(),session({id:'task-2'})]));assert.equal(s.sessions.size,2);});
test('Duplicate guard: identical ids on different physical hosts are distinct',()=>{const s=new Store({now:()=>10000});s.ingest(envelope('w','epoch-one',[session({hostId:'host-a'}),session({hostId:'host-b'})]));assert.equal(s.sessions.size,2);});
test('Duplicate guard: independent workspace/worktree remains distinct',()=>{const s=new Store({now:()=>10000});s.ingest(envelope('w','epoch-one',[session(),session({workspace:'/home/petr/other-worktree'})]));assert.equal(s.sessions.size,2);});
test('Duplicate guard: duplicate within one batch is rejected with no mutation',()=>{const s=new Store({now:()=>10000});assert.throws(()=>s.ingest(envelope('w','epoch-one',[session(),session()])),code('DUPLICATE_SESSION'));assert.equal(s.sources.size,0);assert.equal(s.sessions.size,0);});
test('Identity: Windows slash/case aliases compare equal; Linux case does not',()=>{
 assert(tools.sameSession(session({workspace:'C:\\Repo\\.\\src\\..',environment:'Windows'}),session({workspace:'c:/repo/',environment:'Windows'})));
 assert(!tools.sameSession(session({workspace:'/Repo'}),session({workspace:'/repo'})));
 assert(!tools.sameSession(session({environment:'WSL'}),session({environment:'Windows'})));
});
test('Identity: physical Linux and SSH aliases with shared host identity are equal',()=>{assert(tools.sameSession(session({hostId:'one',environment:'Remote SSH'}),session({hostId:'one',environment:'Linux',host:'an-alias'})));});
test('Identity: concurrently created host id and canonical symlink roots are stable',()=>temporary(async dir=>{
 const repo=path.join(dir,'repo');await mkdir(repo);await symlink(repo,path.join(dir,'alias'),'dir');
 const all=await Promise.all(Array.from({length:12},(_,i)=>tools.workspaceIdentity([i%2?repo:path.join(dir,'alias')],{home:dir,hostname:'test-host'})));
 assert.equal(new Set(all.map(x=>x.hostId)).size,1);assert.equal(new Set(all.map(x=>x.sourceId)).size,1);
 const again=await tools.workspaceIdentity([repo],{home:dir,hostname:'test-host'});assert.equal(again.sourceId,all[0].sourceId);
}));
test('Identity: multi-root order and repetition cannot create a second source',()=>temporary(async dir=>{
 const a=path.join(dir,'a'),b=path.join(dir,'b');await mkdir(a);await mkdir(b);
 const x=await tools.workspaceIdentity([a,b],{home:dir}),y=await tools.workspaceIdentity([b,a,a],{home:dir});assert.equal(x.sourceId,y.sourceId);
}));
test('Identity: inaccessible/missing workspace is not silently guessed',()=>temporary(async dir=>{await assert.rejects(tools.workspaceIdentity([path.join(dir,'missing')],{home:dir}),{code:'ENOENT'});}));
test('Lease: foreign or delayed release cannot disconnect the owner',()=>{const s=new Store({now:()=>10000});s.claim(envelope());assert.equal(s.release(envelope('window-1','epoch-two')).released,false);assert(s.sourceAlive(s.sources.get('window-1')));});
test('Lease: explicit release permits immediate reconnect without another record',()=>{
 const s=new Store({now:()=>10000});s.claim(envelope());s.ingest(envelope());const key=s.snapshot().sessions[0].key;s.annotate(key,{acknowledge:true,snoozeMinutes:15});
 assert(s.release(envelope()).released);assert(!s.snapshot().sessions[0].connected);
 s.claim(envelope('window-1','epoch-two'));s.ingest(envelope('window-1','epoch-two'));
 assert.equal(s.sessions.size,1);assert.equal(s.snapshot().sessions[0].key,key);assert(s.snapshot().sessions[0].acknowledged);assert(s.snapshot().sessions[0].snoozed);
 assert.throws(()=>s.ingest(envelope('window-1','epoch-one',undefined,10)),code('RETIRED_EPOCH'));
});
test('Lease: expired owner can be replaced, and late old messages cannot steal back',()=>{
 let now=10000;const s=new Store({now:()=>now});s.claim(envelope());s.ingest(envelope());const key=s.snapshot().sessions[0].key;
 now+=29999;assert.throws(()=>s.claim(envelope('window-1','epoch-two')),code('CONNECTION_IN_USE'));
 now+=1;s.claim(envelope('window-1','epoch-two'));s.ingest(envelope('window-1','epoch-two'));assert.equal(s.sessions.size,1);assert.equal(s.snapshot().sessions[0].key,key);
 assert.throws(()=>s.claim(envelope()),code('RETIRED_EPOCH'));
});
test('Lease: released epoch cannot resurrect itself with a late heartbeat',()=>{const s=new Store({now:()=>10000});s.ingest(envelope());s.release(envelope());assert.throws(()=>s.ingest(envelope('window-1','epoch-one',undefined,2)),code('RELEASED_CONNECTION'));});
test('Migration: historical duplicates merge offline, preserving bounded history and snooze',()=>{
 const s=new Store({now:()=>20000});s.restore({version:1,sessions:[
  {...session({messages:[{id:'old',at:10000,kind:'user',text:'Old'}]}),sourceId:'random-1',snoozeUntil:900000,key:'1'.repeat(24)},
  {...session({activityAt:15000,state:'review',messages:[{id:'new',at:15000,kind:'agent',text:'New'}]}),sourceId:'random-2',key:'2'.repeat(24)}]});
 assert.equal(s.sessions.size,1);const x=s.snapshot().sessions[0];assert(!x.connected);assert.equal(x.state,'review');assert.deepEqual(x.messages.map(x=>x.text),['Old','New']);assert.equal(x.snoozeUntil,900000);
 const copy=new Store();copy.restore(s.serialize());assert.equal(copy.sessions.size,1);assert.equal(copy.snapshot().sessions[0].key,x.key);
});
test('Migration: current host identity adopts a legacy record instead of duplicating it',()=>{
 const s=new Store({now:()=>10000});s.restore({version:1,sessions:[{...session(),sourceId:'random-old'}]});const key=s.snapshot().sessions[0].key;
 s.claim(envelope());s.ingest(envelope('window-1','epoch-one',[session({hostId:'new-shared-host-id'})]));assert.equal(s.sessions.size,1);assert.equal(s.snapshot().sessions[0].key,key);
});
test('Migration: live old bridge also cannot duplicate a newly identified session',()=>{const s=new Store({now:()=>10000});s.ingest(envelope('new','epoch-new',[session({hostId:'host-id'})]));assert.throws(()=>s.ingest(envelope('old','epoch-old')),code('SESSION_IN_USE'));});
test('Migration: backup preserves original bytes and is not overwritten on restart',()=>temporary(async dir=>{
 const state=JSON.stringify({version:1,sessions:[{...session(),sourceId:'a'},{...session(),sourceId:'b'}]});await writeFile(path.join(dir,'state.json'),state);
 await withHub(async h=>{assert.equal(h.store.sessions.size,1);h.store.changed();},{persist:true,dataDir:dir});
 assert.equal(await readFile(path.join(dir,'state.before-0.4.0.json'),'utf8'),state);
 const stored=JSON.parse(await readFile(path.join(dir,'state.json'),'utf8'));assert.equal(stored.identityVersion,2);assert.equal(stored.sessions.length,1);
 await withHub(async h=>{assert(!h.store.snapshot().sessions[0].connected);},{persist:true,dataDir:dir});
 assert.equal(await readFile(path.join(dir,'state.before-0.4.0.json'),'utf8'),state);
}));
test('HTTP: 20 simultaneous different owners yield one lease and 19 conflicts',()=>withHub(async h=>{
 const responses=await Promise.all(Array.from({length:20},(_,i)=>post(h,'/api/claim',envelope('one-source',`epoch-${i}-id`))));
 assert.equal(responses.filter(r=>r.status===200).length,1);assert.equal(responses.filter(r=>r.status===409).length,19);assert.equal(h.store.sources.size,1);
 const loser=await responses.find(r=>r.status===409).json();assert.equal(loser.code,'CONNECTION_IN_USE');assert(loser.ownerLabel);assert(!JSON.stringify(loser).includes(token));
}));
test('HTTP: random source ids cannot bypass session uniqueness in parallel',()=>withHub(async h=>{
 const responses=await Promise.all(Array.from({length:15},(_,i)=>post(h,'/api/ingest',envelope(`random-${i}`,`epoch-${i}-id`))));
 assert.equal(responses.filter(r=>r.status===200).length,1);assert.equal(responses.filter(r=>r.status===409).length,14);assert.equal(h.store.sessions.size,1);
}));
test('HTTP: ownership APIs require producer auth, not just an open dashboard',()=>withHub(async h=>{
 const login=await post(h,'/api/login',{token});const cookie=login.headers.get('set-cookie').split(';')[0];
 for(const p of ['/api/claim','/api/release'])assert.equal((await fetch(h.url+p,{method:'POST',headers:{Cookie:cookie},body:JSON.stringify(envelope())})).status,401);
}));
test('HTTP: another epoch cannot poll, consume or confirm owner approvals',()=>withHub(async h=>{
 await post(h,'/api/claim',envelope());await post(h,'/api/ingest',envelope('window-1','epoch-one',[session({agent:'codex',state:'needs_approval',capabilities:['approve'],pending:[{id:9,method:'item/commandExecution/requestApproval'}]})]));
 const login=await post(h,'/api/login',{token});const cookie=login.headers.get('set-cookie').split(';')[0],s=h.store.snapshot().sessions[0];
 const response=await fetch(h.url+'/api/action',{method:'POST',headers:{Cookie:cookie},body:JSON.stringify({key:s.key,stateRevision:s.stateRevision,action:'approve',requestId:9,decision:'accept'})});assert.equal(response.status,202);const {id}=await response.json();
 for(const q of ['','&epoch=epoch-two'])assert.equal((await fetch(h.url+'/api/commands?sourceId=window-1'+q,{headers})).status,409);
 const list=await(await fetch(h.url+'/api/commands?sourceId=window-1&epoch=epoch-one',{headers})).json();assert.equal(list.commands.length,1);
 assert.equal((await post(h,'/api/result',{id,sourceId:'window-1',epoch:'epoch-two',ok:true})).status,409);
 assert.equal((await post(h,'/api/result',{id,sourceId:'window-1',epoch:'epoch-one',ok:true})).status,200);
 assert.equal((await post(h,'/api/result',{id,sourceId:'window-1',epoch:'epoch-one',ok:true})).status,409);
}));
test('HTTP: queued approval is not delivered to a replacement owner',()=>withHub(async h=>{
 const e=envelope('owner','epoch-one',[session({agent:'codex',state:'needs_approval',capabilities:['approve'],pending:[{id:9,method:'item/commandExecution/requestApproval'}]})]);
 await post(h,'/api/claim',e);await post(h,'/api/ingest',e);
 const login=await post(h,'/api/login',{token});const cookie=login.headers.get('set-cookie').split(';')[0],s=h.store.snapshot().sessions[0];
 const r=await fetch(h.url+'/api/action',{method:'POST',headers:{Cookie:cookie},body:JSON.stringify({key:s.key,stateRevision:s.stateRevision,action:'approve',requestId:9,decision:'accept'})});const {id}=await r.json();
 await post(h,'/api/release',e);await post(h,'/api/claim',{...e,epoch:'epoch-two'});await post(h,'/api/ingest',{...e,epoch:'epoch-two'});
 const list=await(await fetch(h.url+'/api/commands?sourceId=owner&epoch=epoch-two',{headers})).json();assert.equal(list.commands.length,0);
 const result=await(await fetch(h.url+'/api/action/'+id,{headers:{Cookie:cookie}})).json();assert.equal(result.status,'failed');
}));
test('Producer: repeated start is idempotent; second producer cannot replace first',()=>withHub(async h=>{
 const statuses=[];const a=new transport.Producer({hub:h.url,token,sourceId:'stable',label:'original',getSessions:()=>[session()]});
 const b=new transport.Producer({hub:h.url,token,sourceId:'stable',label:'duplicate',getSessions:()=>[session()],onStatus:(ok,msg,e)=>statuses.push({ok,e})});
 try{a.start();a.start();await until(()=>h.store.sessions.size);const key=h.store.snapshot().sessions[0].key;b.start();await until(()=>b.conflict);assert.equal(b.conflict.code,'CONNECTION_IN_USE');assert(b.stopped);assert(!a.stopped);assert.equal(h.store.sessions.size,1);assert.equal(h.store.snapshot().sessions[0].key,key);assert(statuses.every(s=>!s.ok));}
 finally{await b.stop();await a.stop();}
}));
test('Producer: graceful stop allows immediate reconnect and same session key',()=>withHub(async h=>{
 const cfg={hub:h.url,token,sourceId:'stable',label:'one',getSessions:()=>[session()]};const a=new transport.Producer(cfg).start();let b;
 try{await until(()=>h.store.sessions.size);const key=h.store.snapshot().sessions[0].key;await a.stop();assert(!h.store.snapshot().sessions[0].connected);b=new transport.Producer(cfg).start();await until(()=>h.store.snapshot().sessions[0]?.connected);assert.equal(h.store.sessions.size,1);assert.equal(h.store.snapshot().sessions[0].key,key);}
 finally{await a.stop();await b?.stop();}
}));
test('Producer: stop during in-flight claim releases it after the request settles',async()=>{
 let resolveClaim,releases=0;const p=new transport.Producer({hub:'http://127.0.0.1:4317',token,sourceId:'p',label:'p',getSessions:()=>[],transport:{request:async(_h,_t,url)=>{if(url==='/api/claim')return new Promise(r=>{resolveClaim=r;});if(url==='/api/release'){releases++;return {released:true};}throw new Error('Unexpected request');},stop(){}}});
 p.start();await until(()=>resolveClaim);const stop=p.stop();resolveClaim({accepted:true});await stop;assert.equal(releases,1);assert(!p.timer);assert(!p.claimed);
});
test('WSL relay: claim, structured conflict and release survive stdio transport',()=>withHub(async h=>{
 const r=new desktop.RelayTransport({command:process.execPath,args:[fileURLToPath(new URL('../windows/wsl-relay.cjs',import.meta.url))]});
 try{await r.request(h.url,token,'/api/claim','POST',envelope());await assert.rejects(r.request(h.url,token,'/api/claim','POST',envelope('window-1','epoch-two')),code('CONNECTION_IN_USE'));assert((await r.request(h.url,token,'/api/release','POST',envelope())).released);}
 finally{r.stop();}
}));
test('Single-flight: mixed rapid clicks execute one async operation; cancellation unlocks retry',async()=>{
 let resolve,count=0;const f=single.singleFlight(async()=>{count++;return new Promise(r=>{resolve=r;});});
 const first=f('desktop'),second=f('manual');assert.equal(first,second);await until(()=>resolve);resolve('cancelled');assert.equal(await first,'cancelled');assert(!f.busy);assert.equal(count,1);
 const third=f();await until(()=>count===2);resolve('ok');assert.equal(await third,'ok');
});
test('Managed Codex: repeated connection is rejected BEFORE trying to spawn its command',()=>withHub(async h=>{
 const e=envelope('managed-config');await post(h,'/api/claim',e);
 await assert.rejects(startCodexClient({hub:h.url,sourceId:'managed-config',cwd:os.tmpdir(),command:['/definitely-must-not-be-executed']},{token}),code('CONNECTION_IN_USE'));
 assert.equal(h.store.sources.get('managed-config').epoch,'epoch-one');assert.equal(h.store.sessions.size,0);
}));

test('Producer: an old hub without claim support cannot silently bypass uniqueness',async()=>{
 const requests=[],statuses=[];const p=new transport.Producer({hub:'http://127.0.0.1:4317',token,sourceId:'p',label:'p',getSessions:()=>[session()],onStatus:(ok,_m,e)=>statuses.push({ok,code:e?.code}),transport:{request:async(_h,_t,endpoint)=>{requests.push(endpoint);throw Object.assign(new Error('Unknown API endpoint'),{status:404});},stop(){}}});
 p.start();await until(()=>statuses.length);assert(p.stopped);assert.deepEqual(requests,['/api/claim']);assert.equal(statuses[0].code,'HUB_UPGRADE_REQUIRED');assert(!statuses[0].ok);await p.stop();
});
