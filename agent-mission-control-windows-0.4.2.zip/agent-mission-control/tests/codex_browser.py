"""Production DOM + real HTTP hub, Bridge and executable PermissionRequest hook.
The Codex input producer and browser network transport are test replacements.
No actual Codex/VS Code/Windows UI is used or claimed.
"""
from pathlib import Path
import subprocess,json,urllib.request,urllib.error,http.cookiejar,sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'docs';OUT.mkdir(parents=True,exist_ok=True)
checks=[]
def check(name,value):
    assert value,name
    checks.append(name);print('PASS '+name,file=sys.stderr,flush=True)
proc=subprocess.Popen(['node',str(ROOT/'tests/fixtures/codex-browser-hub.mjs')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
try:
    f=json.loads(proc.stdout.readline());url=f['url']
    def ctl(**x):
        proc.stdin.write(json.dumps(x)+'\n');proc.stdin.flush();r=json.loads(proc.stdout.readline());assert 'error' not in r,r;return r
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium');ctx=browser.new_context(viewport={'width':1536,'height':1000});page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        jar=http.cookiejar.CookieJar();opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
        def bridge_fetch(_source,route,options):
            req=urllib.request.Request(url+route,method=options.get('method','GET'),data=options.get('body').encode() if options.get('body') else None,headers={'Origin':url,**(options.get('headers') or {})})
            try:
                with opener.open(req,timeout=5) as res:return {'status':res.status,'body':res.read().decode()}
            except urllib.error.HTTPError as e:return {'status':e.code,'body':e.read().decode()}
        page.expose_binding('__mcTestFetch',bridge_fetch)
        transport='''<script>
        window.fetch=async(route,options={})=>{const r=await window.__mcTestFetch(route,options);return new Response(r.body,{status:r.status,headers:{'Content-Type':'application/json'}});};
        window.EventSource=class {constructor(){this.handlers={};window.testEvents=this;this.timer=setInterval(async()=>{const r=await fetch('/api/state');if(r.ok&&this.handlers.snapshot)this.handlers.snapshot({data:await r.text()});},120);} addEventListener(k,f){this.handlers[k]=f;}close(){clearInterval(this.timer);}};
        </script>'''
        html=(ROOT/'dashboard-demo.html').read_text().replace('window.MC_OFFLINE=true;','window.MC_OFFLINE=false;').replace('<script>window.MC_OFFLINE=',transport+'<script>window.MC_OFFLINE=')
        page.set_content(html,wait_until='load');page.locator('#loginForm').wait_for();page.locator('#pairToken').fill(f['token']);page.locator('#loginForm button').click()
        page.wait_for_function("document.querySelectorAll('.project-shell').length===2")
        page.locator('.project-main').filter(has_text='monografie').click();page.locator('[data-codex-decision="run"]').wait_for()
        check('One project row despite Zoo + Codex in same folder',page.locator('.project-shell').count()==2)
        check('Codex offers Run, Deny and fallback to native approval',page.locator('[data-codex-decision]').count()==3)
        page.evaluate("()=>{const b=document.createElement('div');b.id='screenLabel';b.textContent='TESTOVACÍ DATA · skutečný dashboard a hook / simulovaný zdroj Codex událostí';b.style='background:#253443;color:white;padding:8px;text-align:center';document.body.prepend(b)}")
        page.screenshot(path=str(OUT/'codex-dashboard-0.4.2.png'),full_page=True);page.locator('#screenLabel').evaluate('(e)=>e.remove()')
        page.locator('[data-codex-decision="run"]').click()
        check('Run dialog contains complete original tool input and thread/turn/cwd',all(x in page.locator('#dialog .approval-body').inner_text() for x in ['npm test -- --runInBand','original-vscode-codex-thread','original-turn','monografie']))
        check('Opening Run dialog makes no decision',len(ctl(op='status')['calls'])==0)
        page.locator('#dialog [data-close]').click();check('Closing confirmation cannot approve',len(ctl(op='status')['calls'])==0)
        page.locator('#notifications').click();page.locator('[data-notice-open]').first.wait_for();nid=page.locator('[data-notice-open]').first.get_attribute('data-notice-open');page.locator('[data-notice-open]').first.click()
        page.locator('[data-notice]').wait_for();check('Click opens captured Codex event without approving',page.locator('[data-notice]').get_attribute('data-notice')==nid and len(ctl(op='status')['calls'])==0)
        page.locator('[data-codex-decision="run"]').click();page.locator('#confirmCodexDecision').click();page.wait_for_function("document.querySelector('#notice').textContent.includes('Run předáno')",timeout=15000)
        check('Actual hook stdout returns allow only after explicit confirmation',ctl(op='status')['calls']==[{'n':1,'decision':'allow'}])
        check('Feedback does not pretend the tool succeeded','Není to potvrzení' in page.locator('#notice').inner_text())
        page.wait_for_function("document.querySelectorAll('[data-codex-decision]').length===0")
        check('Resolved request loses buttons and original notice is marked resolved','vyřízený' in page.locator('[data-notice]').inner_text())
        payload='node tool.js --note="<img src=x onerror=window.injected=true>"\n'+'úplný příkaz ' * 80
        ctl(op='ask',text=payload,description='Citlivý požadavek — rozhodni pouze o této akci');page.locator('[data-codex-decision="deny"]').wait_for();page.locator('[data-codex-decision="deny"]').click()
        check('Long command is preserved instead of preview-only approval',json.loads(page.locator('#dialog .approval-body').inner_text())['input']['command']==payload)
        check('Codex tool input HTML is rendered inertly',page.locator('#dialog img').count()==0 and not page.evaluate('window.injected===true'))
        page.evaluate("()=>{const b=document.createElement('div');b.id='label';b.textContent='TESTOVACÍ DATA · neodesílá se skutečnému Codexu';b.style='position:fixed;top:0;left:0;right:0;padding:6px;background:#253443;color:white;z-index:10000;text-align:center';document.body.appendChild(b)}")
        page.screenshot(path=str(OUT/'codex-deny-0.4.2.png'),full_page=True);page.locator('#label').evaluate('(e)=>e.remove()')
        page.locator('#confirmCodexDecision').click();page.wait_for_function("document.querySelector('#notice').textContent.includes('Deny předáno')",timeout=15000)
        check('Deny returns official single-request deny output',ctl(op='status')['calls'][-1]['decision']=='deny')
        ctl(op='ask',description='Vrátit do Codexu');page.locator('[data-codex-decision="delegate"]').wait_for();page.locator('[data-codex-decision="delegate"]').click()
        check('Fallback explains original policy, not guaranteed rejection','původní schvalovací politika' in page.locator('#dialogContent').inner_text())
        page.locator('#confirmCodexDecision').click();page.wait_for_function("document.querySelector('#notice').textContent.includes('Předáno standardnímu')",timeout=15000)
        check('Fallback returns no hook decision',ctl(op='status')['calls'][-1]['decision']=='delegate')
        ctl(op='ask',description='První souběžný dotaz');ctl(op='ask',description='Druhý souběžný dotaz',extra={'agent_id':'subagent-2'});page.wait_for_function("document.querySelectorAll('[data-codex-decision]').length===6")
        check('Multiple approvals have separate controls, still one project row',page.locator('.project-shell').count()==2 and page.locator('.codex-request').count()==2)
        page.locator('[data-codex-decision="run"]').first.click();ctl(op='cancel');page.wait_for_timeout(350);page.locator('#confirmCodexDecision').click();page.wait_for_timeout(1400)
        check('Cancelled hook rejects open confirmation without a second allow',sum(c['decision']=='allow' for c in ctl(op='status')['calls'])==1)
        page.locator('#search').fill('backend');page.locator('#notifications').click();page.locator('[data-notice-open="'+nid+'"]').click();page.wait_for_function("document.querySelector('#search').value==='' && !document.querySelector('#dialog').open")
        check('Old event deep link restores correct project/filter',page.locator('#detail h2').inner_text()=='monografie' and 'Spustit testy' in page.locator('[data-notice]').inner_text())
        ticket=urllib.request.urlopen(urllib.request.Request(url+'/api/desktop/ticket',data=b'',headers={'Authorization':'Bearer '+f['desktopSecret']})).read().decode()
        jar.clear();page.close();page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.expose_binding('__mcTestFetch',bridge_fetch);page.goto('about:blank#desktop-ticket='+ticket+'&notice='+nid);page.set_content(html,wait_until='load');page.locator('[data-notice="'+nid+'"]').wait_for(timeout=15000)
        check('Native-style one-time login lands on original Codex event',page.url.endswith('#notice='+nid) and 'desktop-ticket' not in page.url and page.locator('#detail h2').inner_text()=='monografie')
        check('Notification login never issues Run',sum(c['decision']=='allow' for c in ctl(op='status')['calls'])==1)
        ctl(op='ask',description='Responzivní dotaz');page.locator('[data-codex-decision="run"]').wait_for();page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(150)
        check('Phone-width page does not overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
        check('No JavaScript runtime errors',not errors)
        browser.close()
    print(json.dumps({'passed':len(checks),'checks':checks,'limits':'Real executable hook/Bridge/hub/DOM; synthetic Codex events, mocked VS Code and injected browser transport. No native Windows test.'},ensure_ascii=False,indent=2))
finally:
    proc.terminate()
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:proc.kill()
