// Production bridge/Producer/controller with an in-memory VS Code API only.
// HTTP and stdio relay are real. This is NOT a real Windows Extension Host.
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
import {EventEmitter} from 'node:events';
import path from 'node:path';
export const TOKEN='a'.repeat(64);
export const pause=ms=>new Promise(r=>setTimeout(r,ms));
export async function until(check,message='condition',ms=5000){
 const end=Date.now()+ms;while(Date.now()<end){if(await check())return;await pause(10);}throw new Error('Timeout: '+message);
}
export function bridgeHarness({hub,folder,folders=null,workspaceStore=new Map(),settings={},secrets=new Map([['hubToken',TOKEN]]),remoteName=null,relay=false,intentGate=null,sourceRoot=fileURLToPath(new URL('../..',import.meta.url))}={}){
 const requireBridge=createRequire(path.join(sourceRoot,'bridge/src/extension.cjs'));
 const {Producer}=requireBridge('./producer.cjs');const {RelayTransport}=requireBridge('./desktop.cjs');
 const commands=new Map(),instances=[],messages=[],logs=[],contextValues=new Map(),timers=new Set();
 const effects={subprocesses:0,zooStops:0,desktopReads:0};
 const folderListeners=new Set();
 const version=JSON.parse(readFileSync(path.join(sourceRoot,'package.json'),'utf8')).version;
 const noOp={dispose(){}};const zoo=new EventEmitter();zoo.getCurrentTaskStack=()=>['test-zoo-task'];zoo.abortTask=()=>{effects.zooStops++;throw new Error('Unexpected agent control');};
 const cfg={hubUrl:hub.url,gitStatus:false,windowsDesktopConnection:relay,...settings};
 const api={
  version:'test-api-with-real-http',StatusBarAlignment:{Left:1},ConfigurationTarget:{Global:1,Workspace:2},
  env:{remoteName,uriScheme:'vscode',asExternalUri:async uri=>uri},
  Uri:{parse:value=>({toString:()=>value}),joinPath:(_uri,...parts)=>({fsPath:path.join(sourceRoot,'connector',...parts)})},
  extensions:{getExtension:id=>id==='ZooCodeOrganization.zoo-code'?{packageJSON:{version:'fixture'},activate:async()=>zoo}:undefined},
  workspace:{isTrusted:true,onDidChangeWorkspaceFolders:fn=>{folderListeners.add(fn);return {dispose:()=>folderListeners.delete(fn)};},workspaceFolders:(folders||[folder]).map(folder=>({name:path.basename(folder),uri:{fsPath:folder,scheme:remoteName?'vscode-remote':'file'}})),getConfiguration:()=>({get:(k,d)=>cfg[k]??d,update:async(k,v)=>{cfg[k]=v;}})},
  window:{createOutputChannel:()=>({appendLine:s=>logs.push(s),show(){},dispose(){}}),createStatusBarItem:()=>({show(){},dispose(){}}),registerUriHandler:()=>noOp,
   showInformationMessage:async(m,...opts)=>{messages.push({kind:'info',m});return opts.includes('Připojit')?'Připojit':opts.includes('Nainstalovat')?'Nainstalovat':undefined;},
   showWarningMessage:async(m,...opts)=>{messages.push({kind:'warning',m});return opts.includes('Odpojit a odebrat')?'Odpojit a odebrat':undefined;},
   showErrorMessage:async m=>{messages.push({kind:'error',m});},showInputBox:async o=>o.password?TOKEN:hub.url},
  commands:{registerCommand:(id,fn)=>{commands.set(id,fn);return {dispose:()=>commands.delete(id)};},getCommands:async()=>[...commands.keys()],
   executeCommand:async(id,...args)=>{if(id==='setContext'){contextValues.set(args[0],args[1]);return;}if(!commands.has(id))throw new Error('Unknown command '+id);return commands.get(id)(...args);}}
 };
 const context={subscriptions:[],extension:{extensionKind:2,packageJSON:{version}},
  secrets:{get:async k=>secrets.get(k),store:async(k,v)=>{secrets.set(k,v);},delete:async k=>{secrets.delete(k);}},
  workspaceState:{get:(k,d)=>workspaceStore.has(k)?workspaceStore.get(k):d,update:async(k,v)=>{if(intentGate&&k==='missionControl.disconnectIntent.v1')await intentGate(v);if(v===undefined)workspaceStore.delete(k);else workspaceStore.set(k,v);}}
 };
 class ObservedProducer extends Producer {constructor(opts){super(opts);instances.push(this);}}
 const dependencies={vscode:api,'./producer.cjs':{Producer:ObservedProducer},
  './desktop.cjs':{RelayTransport,readDesktop:async()=>{effects.desktopReads++;return {hub:hub.url,token:TOKEN,linuxNode:process.execPath,relay:path.join(sourceRoot,'windows/wsl-relay.cjs')};}},
  'node:child_process':{execFile(){effects.subprocesses++;throw new Error('Unexpected process from bridge (Git disabled)');}}
 };
 const box={module:{exports:{}},exports:{},require:id=>dependencies[id]||requireBridge(id),process,URLSearchParams,
  setInterval:(fn,ms)=>{const timer=setInterval(fn,ms);timers.add(timer);return timer;},clearInterval:t=>{clearInterval(t);timers.delete(t);}};
 vm.runInNewContext(readFileSync(path.join(sourceRoot,'bridge/src/extension.cjs'),'utf8'),box,{filename:'production-bridge.cjs'});
 const activation=box.module.exports.activate(context);
 const requireConnector=createRequire(path.join(sourceRoot,'connector/src/controller.cjs'));
 const {createController}=requireConnector('./controller.cjs');
 const controller=createController(api,{extension:{packageJSON:{version}},extensionUri:{fsPath:path.join(sourceRoot,'connector')}},{log:s=>logs.push(s)});
 return {api,commands,instances,messages,logs,effects,activation,workspaceStore,secrets,contextValues,zoo,controller,
  fireWorkspaceFolders:()=>{for(const fn of folderListeners)fn({added:[],removed:[]});},
  status:()=>commands.get('missionControl.getStatus')(),command:id=>api.commands.executeCommand(id),
  async freeze(){const p=instances.at(-1);await p.inFlight;clearTimeout(p.timer);return p;},
  async close(){await box.module.exports.deactivate();for(const t of timers)clearInterval(t);for(const p of instances)await p.stop();}
 };
}
export async function native(hub,endpoint,data){
 const r=await fetch(hub.url+endpoint,{method:data?'POST':'GET',headers:{Authorization:'Bearer '+TOKEN,...(data?{'Content-Type':'application/json'}:{})},body:data?JSON.stringify(data):undefined});
 return {status:r.status,body:await r.json()};
}
export async function browser(hub){
 const login=await fetch(hub.url+'/api/login',{method:'POST',headers:{'Content-Type':'application/json',Origin:hub.url},body:JSON.stringify({token:TOKEN})});
 const cookie=login.headers.get('set-cookie').split(';')[0];
 return async(endpoint,data)=>{const r=await fetch(hub.url+endpoint,{method:data?'POST':'GET',headers:{Cookie:cookie,Origin:hub.url,...(data?{'Content-Type':'application/json'}:{})},body:data?JSON.stringify(data):undefined});return {status:r.status,body:await r.json()};};
}
