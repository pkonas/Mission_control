import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,rm} from 'node:fs/promises';
import {readFileSync} from 'node:fs';
import os from 'node:os';import path from 'node:path';
import {createHub} from '../src/server.mjs';
import {Store} from '../src/store.mjs';
import producer from '../bridge/src/producer.cjs';
import {bridgeHarness,until,pause,TOKEN,native,browser} from './helpers/live-bridge.mjs';
const intentKey='missionControl.disconnectIntent.v1';
const env=(sourceId='source-one',epoch='epoch-one')=>({version:1,sourceId,epoch,label:'Test fixture'});
async function fixture(fn,{persist=false,relay=false}={}){
 const dir=await mkdtemp(path.join(os.tmpdir(),'mc-reconnect-'));const folder=path.join(dir,'project');await mkdir(folder);
 const hub=await createHub({port:0,persist,dataDir:path.join(dir,'data'),token:TOKEN});
 const h=bridgeHarness({hub,folder,remoteName:relay?'wsl':null,relay});const extra=[];
 try{await h.activation;await until(()=>hub.store.sessions.size===1,'initial session');return await fn({hub,h,folder,dir,extra,ui:await browser(hub)});}
 finally{for(const x of extra)await x.close();await h.close();await hub.close();await rm(dir,{recursive:true,force:true});}
}
async function remove(ui,p){const r=await ui('/api/disconnect',{sourceId:p.sourceId,epoch:p.epoch});assert.equal(r.status,200,JSON.stringify(r));assert(r.body.removed);}
async function expectReconnected(h,hub,previous){
 await until(()=>hub.store.sessions.size===1,'session after reconnect');
 const s=await h.status();assert(s.connected);assert(!s.paused);assert(!s.pendingRemoval);
 assert.equal(h.instances.length,2);assert.notEqual(h.instances[1].epoch,previous.epoch);
 assert.equal(h.instances[1].sourceId,previous.sourceId);assert.equal(hub.store.snapshot().sources.length,1);
 assert(h.messages.some(x=>x.m.includes('připojení k hubu bylo potvrzeno')));
 assert.equal(h.effects.subprocesses,0);assert.equal(h.effects.zooStops,0);assert.equal(h.secrets.get('hubToken'),TOKEN);
}
// These run the ACTUAL bridge, producer, controller, Zoo event normalization,
// and HTTP hub. Only the VS Code API/Zoo provider are test doubles.
for(const action of ['missionControl.connect','missionControl.connectDesktop','missionControl.reconnect','controller.setup','controller.reconnect']){
 test('Reconnect live HTTP: removal before heartbeat, '+action,()=>fixture(async({hub,h,ui})=>{
  const old=await h.freeze();await remove(ui,old);assert.equal(hub.store.sessions.size,0);
  assert((await h.status()).connected,'force the original stale-UI condition');
  if(action.startsWith('controller.'))await h.controller[action.split('.')[1]]();else await h.command(action);
  await expectReconnected(h,hub,old);assert(h.logs.some(s=>s.includes('MC_RECONNECT_CHECK')));
 }));
}
test('Reconnect live HTTP: removal already detected restores paused workspace',()=>fixture(async({hub,h,ui})=>{
 const old=await h.freeze();await remove(ui,old);await old.tick();await until(async()=>(await h.status()).paused);
 assert(old.removed);assert(!old.conflict);await h.command('missionControl.reconnect');await expectReconnected(h,hub,old);
}));
test('Reconnect live HTTP: local Disconnect -> Connect uses saved credential and a fresh epoch',()=>fixture(async({hub,h})=>{
 const old=await h.freeze();await h.command('missionControl.disconnect');assert.equal(hub.store.sessions.size,0);assert((await h.status()).paused);
 await h.command('missionControl.connect');await until(()=>hub.store.sessions.size===1);
 assert((await h.status()).connected);assert(!(await h.status()).paused);
 // The removal-only Producer is never started; there is one new live producer.
 assert.equal(h.instances.filter(p=>p.started&&!p.stopped).length,1);assert.notEqual(h.instances.at(-1).epoch,old.epoch);
 assert.equal(h.secrets.get('hubToken'),TOKEN);assert.equal(h.effects.zooStops,0);
}));
test('Reconnect live HTTP: 20 rapid mixed clicks still create one replacement',()=>fixture(async({hub,h,ui})=>{
 const old=await h.freeze();await remove(ui,old);
 await Promise.all(Array.from({length:20},(_,i)=>h.command(i%2?'missionControl.connect':'missionControl.reconnect')));
 await expectReconnected(h,hub,old);
}));
test('Reconnect live HTTP: already connected uses same owner and does not re-pair',()=>fixture(async({hub,h})=>{
 const old=await h.freeze();await h.command('missionControl.reconnect');await h.controller.setup();
 assert.equal(h.instances.length,1);assert.equal(hub.store.sessions.size,1);assert.equal(hub.store.sources.get(old.sourceId).epoch,old.epoch);
 assert(h.messages.every(m=>m.m.includes('již připojena')));assert.equal(h.effects.desktopReads,0);assert(!old.stopped);
}));
test('Reconnect live HTTP: other project remains connected',()=>fixture(async({hub,h,folder,extra,ui})=>{
 const otherFolder=folder+'-other';await mkdir(otherFolder);const other=bridgeHarness({hub,folder:otherFolder});extra.push(other);await other.activation;await until(()=>hub.store.sessions.size===2);
 const winner=await other.freeze(),old=await h.freeze();await remove(ui,old);assert.equal(hub.store.sessions.size,1);
 await h.command('missionControl.reconnect');await until(()=>hub.store.sessions.size===2);
 assert.equal(hub.store.sources.get(winner.sourceId).epoch,winner.epoch);assert(!winner.stopped);
 assert.equal(h.instances.filter(p=>p.started&&!p.stopped).length,1);
}));
test('Reconnect live HTTP: second window cannot replace a live owner of same workspace',()=>fixture(async({hub,h,folder,extra})=>{
 const first=await h.freeze(),other=bridgeHarness({hub,folder});extra.push(other);await other.activation;
 await until(async()=>(await other.status()).connectionState==='duplicate');
 await other.command('missionControl.reconnect');assert.equal(hub.store.sessions.size,1);
 assert.equal(hub.store.sources.get(first.sourceId).epoch,first.epoch);assert(!first.stopped);assert(!(await other.status()).connected);
 assert(!other.messages.some(x=>x.m.includes('připojení k hubu bylo potvrzeno')));
}));
test('Reconnect live HTTP: stale ingest and removal cannot affect new connection',()=>fixture(async({hub,h,ui})=>{
 const old=await h.freeze(),envelope=old.envelope();await remove(ui,old);await h.command('missionControl.reconnect');await until(()=>hub.store.sessions.size===1);
 let r=await native(hub,'/api/ingest',{...envelope,seq:999,sessions:[]});assert.equal(r.status,409);assert.equal(r.body.code,'CONNECTION_REMOVED');
 r=await native(hub,'/api/disconnect-source',envelope);assert.equal(r.status,409);assert.equal(r.body.code,'NOT_OWNER');
 assert.equal(hub.store.sessions.size,1);assert((await h.status()).connected);
}));
test('Reconnect live HTTP: restart with saved pause requires explicit action',()=>fixture(async({hub,h,folder,extra,ui})=>{
 const old=await h.freeze();await remove(ui,old);await old.tick();await until(async()=>(await h.status()).paused);await h.close();
 const next=bridgeHarness({hub,folder,workspaceStore:h.workspaceStore,secrets:h.secrets});extra.push(next);await next.activation;assert.equal(next.instances.length,0);
 await next.command('missionControl.reconnect');await until(()=>hub.store.sessions.size===1);
 assert((await next.status()).connected);assert(!(await next.status()).paused);assert.equal(next.instances.length,1);
}));
test('Reconnect live HTTP: queued local pause write cannot overwrite explicit resume',()=>fixture(async({hub,h,folder,extra,ui})=>{
 const old=await h.freeze();await remove(ui,old);await h.close();
 let allow;const gate=new Promise(r=>{allow=r;});const storage=new Map();
 const next=bridgeHarness({hub,folder,workspaceStore:storage,intentGate:v=>v.paused?gate:Promise.resolve()});extra.push(next);await next.activation;
 await until(()=>next.instances[0]?.removed,'removed response received');
 const reconnect=next.command('missionControl.reconnect');await pause(20);allow();await reconnect;await until(()=>hub.store.sessions.size===1);
 assert((await next.status()).connected);assert.equal(storage.get(intentKey).paused,false);
}));
test('Reconnect live stdio: WSL relay path removes, verifies, resumes and rejects old reports',()=>fixture(async({hub,h,ui})=>{
 const old=await h.freeze();await remove(ui,old);await h.command('missionControl.reconnect');await expectReconnected(h,hub,old);
 assert(h.effects.desktopReads>=2);
},{relay:true}));
test('Reconnect live HTTP: unavailable hub returns feedback and never creates a duplicate',()=>fixture(async({hub,h})=>{
 const old=await h.freeze();const original=old.inspect.bind(old);old.inspect=async()=>{throw new Error('Connection refused (injected fault)');};
 await h.command('missionControl.reconnect');old.inspect=original;
 assert.equal(h.instances.length,1);assert.equal(hub.store.sessions.size,1);assert(h.messages.some(x=>x.kind==='warning'&&x.m.includes('hub nyní nelze ověřit')));
}));
test('Reconnect command manifests: Connect and recovery stay callable when status is stale',()=>{
 const bridge=JSON.parse(readFileSync(new URL('../bridge/package.json',import.meta.url))),connector=JSON.parse(readFileSync(new URL('../connector/package.json',import.meta.url)));
 for(const id of ['missionControl.connect','missionControl.connectDesktop','missionControl.reconnect']){
  const command=bridge.contributes.commands.find(c=>c.command===id);assert(command);assert(!command.enablement);assert(bridge.activationEvents.includes('onCommand:'+id));
 }
 assert(connector.contributes.commands.some(c=>c.command==='missionControl.reconnectHere'));assert(connector.activationEvents.includes('onCommand:missionControl.reconnectHere'));
});
test('Reconnect Producer: missing machine code on HTTP 409 cannot leave an endless retry loop',async()=>{
 let calls=0;const statuses=[];const p=new producer.Producer({hub:'http://127.0.0.1:4317',token:TOKEN,sourceId:'old-relay',getSessions:()=>[],onStatus:(ok,m,e)=>statuses.push(e),transport:{request:async()=>{calls++;throw Object.assign(new Error('Připojení bylo odpojeno a odebráno z dashboardu.'),{status:409});},stop(){}}});
 try{await p.tick();assert(p.stopped);assert.equal(calls,1);assert.equal(statuses[0].code,'HUB_CONFLICT');assert(!p.timer);}finally{await p.stop();}
});
test('Reconnect Store: status verification is read-only and never extends ownership',()=>{
 let now=100000;const s=new Store({now:()=>now});s.claim(env());const before=JSON.stringify([...s.sources]),revision=s.revision;
 now+=1000;assert(s.connectionStatus(env()).owned);assert.equal(JSON.stringify([...s.sources]),before);assert.equal(s.revision,revision);
 assert.equal(s.connectionStatus(env('source-one','epoch-two')).code,'CONNECTION_IN_USE');s.disconnectSource('source-one',{epoch:'epoch-one'});assert.equal(s.connectionStatus(env()).code,'CONNECTION_REMOVED');
});
test('Reconnect HTTP: connection-status requires bearer, rejects missing epoch and does not claim',async()=>{
 const h=await createHub({port:0,persist:false,token:TOKEN});try{
  assert.equal((await fetch(h.url+'/api/connection-status?sourceId=a&epoch=epoch-one')).status,401);
  const ui=await browser(h);assert.equal((await ui('/api/connection-status?sourceId=a&epoch=epoch-one')).status,401);
  assert.equal((await native(h,'/api/connection-status?sourceId=a')).status,400);
  const r=await native(h,'/api/connection-status?sourceId=a&epoch=epoch-one');assert.equal(r.status,200);assert.equal(r.body.state,'missing');assert.equal(h.store.sources.size,0);
 }finally{await h.close();}
});
test('Reconnect HTTP: explicit resume is saved before success; old epoch stays retired after restart',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'mc-reconnect-save-'));let h;
 try{
  h=await createHub({port:0,persist:true,dataDir:dir,token:TOKEN});await native(h,'/api/claim',env());await native(h,'/api/disconnect-source',env());
  assert(JSON.parse(await readFile(path.join(dir,'state.json'),'utf8')).detachedSources.length);
  const r=await native(h,'/api/claim',{...env('source-one','epoch-new'),resume:true});assert.equal(r.status,200);
  const saved=JSON.parse(await readFile(path.join(dir,'state.json'),'utf8'));assert.equal(saved.detachedSources.length,0);assert(saved.retiredEpochs[0][1].includes('epoch-one'));
  await h.close();h=await createHub({port:0,persist:true,dataDir:dir,token:TOKEN});assert.equal(h.store.detachedSources.size,0);
  assert.equal((await native(h,'/api/claim',env())).status,409);assert.equal((await native(h,'/api/claim',env('source-one','epoch-after-restart'))).status,200);
 }finally{await h?.close();await rm(dir,{recursive:true,force:true});}
});
test('Reconnect HTTP: failed resume persistence is an error, not false success',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'mc-reconnect-disk-'));let h;
 try{
  h=await createHub({port:0,persist:true,dataDir:dir,token:TOKEN});await native(h,'/api/claim',env());await native(h,'/api/disconnect-source',env());await mkdir(path.join(dir,'state.json.tmp'));
  const r=await native(h,'/api/claim',{...env('source-one','epoch-new'),resume:true});assert.equal(r.status,400);assert.match(r.body.error,/nepodařilo uložit/);
  await rm(path.join(dir,'state.json.tmp'),{recursive:true});assert.equal((await native(h,'/api/claim',{...env('source-one','epoch-new'),resume:true})).status,200);
 }finally{await h?.close();await rm(dir,{recursive:true,force:true});}
});
test('Reconnect live HTTP: undismissed information toasts cannot hold Connect or Disconnect busy',()=>fixture(async({hub,h})=>{
 const original=h.api.window.showInformationMessage;
 // Real VS Code may keep this Thenable pending until the notification closes.
 h.api.window.showInformationMessage=(m,...options)=>options.length?original(m,...options):new Promise(()=>{});
 const bounded=p=>Promise.race([p,pause(2500).then(()=>{throw new Error('Command incorrectly awaited notification dismissal');})]);
 await bounded(h.command('missionControl.disconnect'));assert.equal(hub.store.sessions.size,0);assert(!(await h.status()).disconnecting);
 await bounded(h.command('missionControl.reconnect'));await until(()=>hub.store.sessions.size===1);assert(!(await h.status()).connecting);
 await bounded(h.command('missionControl.connect'));assert.equal(h.instances.filter(p=>p.started&&!p.stopped).length,1);
}));
test('Reconnect HTTP: ownership inspection never consumes a pending approval command',async()=>{
 const h=await createHub({port:0,persist:false,token:TOKEN});
 try{
  const e=env();await native(h,'/api/claim',e);
  const session={id:'approval-task',agent:'codex',workspace:'/synthetic',host:'fixture',environment:'Linux',project:'Fixture',state:'needs_approval',evidence:'api',activity:'Fixture approval',capabilities:['approve'],pending:[{id:31,method:'item/commandExecution/requestApproval',summary:'Synthetic approval only'}]};
  await native(h,'/api/ingest',{...e,seq:1,sessions:[session]});const s=h.store.snapshot().sessions[0],ui=await browser(h);
  const action=await ui('/api/action',{key:s.key,stateRevision:s.stateRevision,action:'approve',requestId:31,decision:'decline'});assert.equal(action.status,202);
  const before=h.store.revision,r=await native(h,'/api/connection-status?sourceId=source-one&epoch=epoch-one');assert(r.body.owned);assert.equal(h.store.revision,before);
  const status=await ui('/api/action/'+action.body.id);assert.equal(status.body.status,'queued');
  const poll=await native(h,'/api/commands?sourceId=source-one&epoch=epoch-one');assert.equal(poll.body.commands.length,1);assert.equal(poll.body.commands[0].id,action.body.id);
 }finally{await h.close();}
});
