import test from 'node:test';import assert from 'node:assert/strict';import {spawn} from 'node:child_process';import {mkdtemp,readFile,rm,writeFile} from 'node:fs/promises';import {tmpdir} from 'node:os';import path from 'node:path';import {fileURLToPath} from 'node:url';
const server=fileURLToPath(new URL('../src/server.mjs',import.meta.url));
test('Installed desktop identity: descriptor matches live hub and preserves the existing token',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'mc-desktop-update-'));const token='b'.repeat(64),instance='c'.repeat(32);await writeFile(path.join(dir,'token'),token+'\n');
 const child=spawn(process.execPath,[server],{stdio:['ignore','pipe','pipe'],env:{...process.env,MC_DATA_DIR:dir,MC_PORT:'0',MC_DESKTOP_SECRET:'a'.repeat(64),MC_INSTANCE_ID:instance}});let diagnostic='';child.stdout.on('data',()=>{});child.stderr.on('data',b=>diagnostic+=b);
 try{
  let descriptor;for(let i=0;i<100;i++){try{descriptor=JSON.parse(await readFile(path.join(dir,'connection.json'),'utf8'));break;}catch{await new Promise(r=>setTimeout(r,25));}}
  assert(descriptor,diagnostic);assert.equal(descriptor.instanceId,instance);assert.equal(descriptor.node,process.execPath);
  const health=await(await fetch(descriptor.hub+'/healthz')).json();assert.equal(health.version,'0.4.2');assert.equal(health.instanceId,descriptor.instanceId);assert.equal((await readFile(path.join(dir,'token'),'utf8')).trim(),token);
 } finally {const exited=new Promise(resolve=>child.once('exit',resolve));child.kill('SIGTERM');await exited;await rm(dir,{recursive:true,force:true});}
});
