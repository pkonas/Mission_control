import test from 'node:test';import assert from 'node:assert/strict';import {mkdtemp,mkdir,writeFile,appendFile,stat,rm} from 'node:fs/promises';import path from 'node:path';import os from 'node:os';import {fileURLToPath} from 'node:url';
import observer from '../bridge/src/codex-observer.cjs';import transport from '../bridge/src/producer.cjs';import {createHub} from '../src/server.mjs';import {startCodexClient} from '../src/codex-client.mjs';
const {CodexObserver,matchWorkspace}=observer;const token='y'.repeat(64);
const wait=async fn=>{const start=Date.now();while(Date.now()-start<12000){const value=fn();if(value)return value;await new Promise(r=>setTimeout(r,80));}throw new Error('Condition timed out');};
test('Hub URL validation rejects credentials and unencrypted LAN addresses',()=>{assert.equal(transport.validateHub('http://127.0.0.1:4317/'),'http://127.0.0.1:4317');assert.throws(()=>transport.validateHub('http://10.0.0.1:4317'));assert.throws(()=>transport.validateHub('https://user:pass@example.org'));});
test('Observer only matches declared workspace roots, not similarly named siblings',()=>{const root=path.resolve('/tmp/project');const f=[{path:root,name:'P'}];assert.ok(matchWorkspace(path.join(root,'src'),f));assert.equal(matchWorkspace(root+'-private',f),undefined);});
test('Observer consumes partial UTF-8/JSONL lines without inventing states',async()=>{const dir=await mkdtemp(path.join(os.tmpdir(),'mc-log-'));try{const workspace=path.join(dir,'repo');await mkdir(workspace);const file=path.join(dir,'rollout.jsonl');const now=new Date().toISOString();const head=JSON.stringify({type:'session_meta',payload:{id:'t',cwd:workspace,timestamp:now}})+'\n';await writeFile(file,head+JSON.stringify({type:'event_msg',timestamp:now,payload:{type:'task_started'}})+'\n');let result;
 const obs=new CodexObserver({home:dir,folders:[{name:'repo',path:workspace}],sessionFactory:m=>({id:m.id,state:'unknown',events:[],messages:[]}),onSession:s=>{result=s;}});
 await obs.processFile(file,await stat(file));assert.equal(result.state,'working');
 const msg=Buffer.from(JSON.stringify({type:'event_msg',timestamp:now,payload:{type:'agent_message',message:'Příliš žluťoučký kůň?'}})+'\n');const cut=msg.indexOf(Buffer.from('ř'))+1;await appendFile(file,msg.subarray(0,cut));await obs.processFile(file,await stat(file));assert.equal(result.messages.length,0);await appendFile(file,msg.subarray(cut));await obs.processFile(file,await stat(file));assert.equal(result.messages[0].text,'Příliš žluťoučký kůň?');assert.equal(result.state,'working');obs.stop();
 }finally{await rm(dir,{recursive:true,force:true});}});
test('Full Codex fixture flow: client → hub → explicit approval → completion',async()=>{
 const hub=await createHub({port:0,token,persist:false});let client;
 try{
   client=await startCodexClient({hub:hub.url,cwd:os.tmpdir(),project:'Protocol fixture',sourceId:'fixture-client',command:[process.execPath,fileURLToPath(new URL('./fixtures/mock-codex.mjs',import.meta.url))],sandbox:'read-only'},{token});
   const first=await wait(()=>hub.store.snapshot().sessions[0]);assert.equal(first.state,'idle');
   const lr=await fetch(hub.url+'/api/login',{method:'POST',body:JSON.stringify({token})});const cookie=lr.headers.get('set-cookie').split(';')[0];
   const act=async(s,b)=>{const r=await fetch(hub.url+'/api/action',{method:'POST',headers:{Cookie:cookie},body:JSON.stringify({key:s.key,stateRevision:s.stateRevision,...b})});assert.equal(r.status,202,await r.clone().text());return r.json();};
   await act(first,{action:'prompt',text:'fixture task'});
   const need=await wait(()=>{const s=hub.store.snapshot().sessions[0];return s?.state==='needs_approval'&&s;});assert.equal(need.pending[0].id,91);assert.equal(need.messages.at(-1).text,'Testovací odpověď');
   await act(need,{action:'approve',requestId:91,decision:'accept'});
   const done=await wait(()=>{const s=hub.store.snapshot().sessions[0];return s?.state==='review'&&s;});assert.match(done.diff,/fixture/);assert.equal(done.pending.length,0);
 }finally{client?.close();await hub.close();}
});
