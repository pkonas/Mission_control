import test from 'node:test';import assert from 'node:assert/strict';import controls from '../bridge/src/zoo-control.cjs';
const {ZooControl}=controls;
export function taskFixture(text='npm test'){
 const task={taskId:'zoo-one',lastMessageTs:1000,askResponse:undefined,interactiveAsk:{ts:1000,type:'ask',ask:'command',text},idleAsk:undefined,abort:false,abandoned:false,calls:[],
  handleWebviewAskResponse(value){this.calls.push(value);this.askResponse=value;}};
 const api={sidebarProvider:{getCurrentTask:()=>task},pressPrimaryButton(){throw new Error('Unsafe global API must not be called');},pressSecondaryButton(){throw new Error('Unsafe global API must not be called');}};
 const s={id:'zoo-one',agent:'zoo',state:'working',capabilities:['open'],events:[],pending:[]};
 const adapter=new ZooControl(api,{now:()=>2000});adapter.sync(s);
 return {api,task,s,adapter,command:decision=>({action:'zooDecision',sessionId:s.id,requestId:s.pending[0]?.id,deadline:3000,decision})};
}
test('Zoo: a waiting ask is hydrated even without a new event',()=>{const {s}=taskFixture();assert.equal(s.state,'needs_approval');assert.equal(s.pending[0].command,'npm test');assert(s.capabilities.includes('zooDecision'));});
for(const [decision,expected] of [['run','yesButtonClicked'],['deny','noButtonClicked']])test('Zoo: '+decision+' addresses captured Task directly, not a webview button',()=>{const f=taskFixture();const c=f.command(decision);assert.match(f.adapter.decide(f.s,c),/předáno Zoo Code/);assert.deepEqual(f.task.calls,[expected]);assert.equal(f.s.pending.length,0);assert.throws(()=>f.adapter.decide(f.s,c));assert.equal(f.task.calls.length,1);});
test('Zoo: heartbeat keeps the same request id and state timestamp',()=>{const f=taskFixture(),id=f.s.pending[0].id,at=f.s.stateSince;for(let i=0;i<10;i++)f.adapter.sync(f.s);assert.equal(f.s.pending[0].id,id);assert.equal(f.s.stateSince,at);});
for(const [name,change] of [
 ['task changed',f=>f.api.sidebarProvider.getCurrentTask=()=>({...f.task,taskId:'different'})],
 ['same ID different object',f=>f.api.sidebarProvider.getCurrentTask=()=>({...f.task})],
 ['different ask object with identical timestamp and text',f=>f.task.interactiveAsk={...f.task.interactiveAsk}],
 ['ask timestamp changed',f=>f.task.lastMessageTs=1001],
 ['command edited',f=>f.task.interactiveAsk.text='different command'],
 ['already answered in VS Code',f=>f.task.askResponse='noButtonClicked'],
 ['aborted task',f=>f.task.abort=true],
 ['abandoned task',f=>f.task.abandoned=true],
 ['partial text',f=>f.task.interactiveAsk.partial=true],
 ['auto approved',f=>f.task.interactiveAsk.autoApprovalDecision='approve'],
 ['answered flag',f=>f.task.interactiveAsk.isAnswered=true],
 ['protected flag changed',f=>f.task.interactiveAsk.isProtected=true],
 ])test('Zoo rejects stale control: '+name,()=>{const f=taskFixture(),c=f.command('run');change(f);assert.throws(()=>f.adapter.decide(f.s,c));assert.equal(f.task.calls.length,0);});
for(const type of ['command_output','followup','completion_result','resume_task','unknown'])test('Zoo: '+type+' does not masquerade as Run/Deny',()=>{const f=taskFixture();f.task.interactiveAsk.ask=type;f.adapter.sync(f.s);assert.equal(f.s.pending.length,0);assert(!f.s.capabilities.includes('zooDecision'));});
for(const type of ['tool','use_mcp_server'])test('Zoo: full '+type+' payload is bound and displayed',()=>{const f=taskFixture('{"tool":"write","path":"file.txt","content":"český text"}');f.task.interactiveAsk.ask=type;f.adapter.sync(f.s);assert.equal(f.s.pending[0].ask,type);assert.match(f.s.pending[0].command,/content/);f.adapter.decide(f.s,f.command('deny'));assert.equal(f.task.calls[0],'noButtonClicked');});
test('Zoo: unsupported API fails closed without global click fallback',()=>{const f=taskFixture();delete f.api.sidebarProvider;f.adapter.sync(f.s);assert.equal(f.s.pending.length,0);assert.match(f.s.controlNote,/neposkytuje/);});
test('Zoo: oversized text is not silently truncated and then approved',()=>{const f=taskFixture('x'.repeat(24001));assert.equal(f.s.pending.length,0);assert.match(f.s.controlNote,/úplně/);});
test('Zoo: images require review in VS Code',()=>{const f=taskFixture();f.task.interactiveAsk.images=['data:x'];f.adapter.sync(f.s);assert.equal(f.s.pending.length,0);});
test('Zoo: exception after delivery is never automatically retried',()=>{const f=taskFixture(),c=f.command('run');f.task.handleWebviewAskResponse=()=>{throw new Error('Unknown result');};assert.throws(()=>f.adapter.decide(f.s,c));f.adapter.sync(f.s);assert.equal(f.s.pending.length,0);assert.throws(()=>f.adapter.decide(f.s,c));});
test('Zoo: disabled controls cannot be used even with saved request',()=>{const f=taskFixture(),c=f.command('run');f.adapter.enabled=()=>false;assert.throws(()=>f.adapter.decide(f.s,c));assert.equal(f.task.calls.length,0);});
test('Zoo: wrong request id, wrong session and expired decision reject',()=>{for(const change of [c=>c.requestId='different',c=>c.sessionId='different',c=>c.deadline=1000,c=>c.decision='acceptForSession']){const f=taskFixture(),c=f.command('run');change(c);assert.throws(()=>f.adapter.decide(f.s,c));assert.equal(f.task.calls.length,0);}});
test('Zoo: synchronous check and delivery are not split by another event-loop task',async()=>{const f=taskFixture();queueMicrotask(()=>{f.task.lastMessageTs=9000;});f.adapter.decide(f.s,f.command('run'));assert.equal(f.task.askResponse,'yesButtonClicked');await Promise.resolve();assert.equal(f.task.lastMessageTs,9000);});
