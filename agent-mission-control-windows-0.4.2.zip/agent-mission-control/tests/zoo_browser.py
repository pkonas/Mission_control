"""Production DOM/JS + actual HTTP hub/bridge, synthetic Zoo Task, injected browser transport. Not a Windows test."""
from pathlib import Path
import subprocess,json,urllib.request,urllib.error,http.cookiejar,sys,time
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]; OUT=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'docs';OUT.mkdir(parents=True,exist_ok=True)
checks=[]
def check(name,value):
    assert value,name
    checks.append(name);print("PASS "+name,file=sys.stderr,flush=True)
proc=subprocess.Popen(['node',str(ROOT/'tests/fixtures/zoo-browser-hub.mjs')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
try:
    f=json.loads(proc.stdout.readline());url=f['url']
    def ctl(**x):
        proc.stdin.write(json.dumps(x)+'\n');proc.stdin.flush();r=json.loads(proc.stdout.readline());assert 'error' not in r,r;return r
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium');ctx=browser.new_context(viewport={'width':1536,'height':1000});page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        jar=http.cookiejar.CookieJar();opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
        def bridge_fetch(_source,route,options):
            headers={'Origin':url,**(options.get('headers') or {})};req=urllib.request.Request(url+route,method=options.get('method','GET'),data=options.get('body').encode() if options.get('body') else None,headers=headers)
            try:
                with opener.open(req,timeout=5) as res:return {'status':res.status,'body':res.read().decode()}
            except urllib.error.HTTPError as e:return {'status':e.code,'body':e.read().decode()}
        page.expose_binding('__mcTestFetch',bridge_fetch)
        transport='''<script>
        window.fetch=async(route,options={})=>{const r=await window.__mcTestFetch(route,options);return new Response(r.body,{status:r.status,headers:{'Content-Type':'application/json'}});};
        window.EventSource=class {constructor(){this.handlers={};window.testEvents=this;this.timer=setInterval(async()=>{const r=await fetch('/api/state');if(r.ok&&this.handlers.snapshot)this.handlers.snapshot({data:await r.text()});},120);} addEventListener(k,f){this.handlers[k]=f;}close(){clearInterval(this.timer);}};
        </script>'''
        html=(ROOT/'dashboard-demo.html').read_text().replace('window.MC_OFFLINE=true;','window.MC_OFFLINE=false;').replace('<script>window.MC_OFFLINE=',transport+'<script>window.MC_OFFLINE=')
        # Container policy blocks even route-fulfilled HTTP navigation; actual page loaded with set_content.
        page.set_content(html,wait_until='load');page.locator('#loginForm').wait_for();page.locator('#pairToken').fill(f['token']);page.locator('#loginForm button').click()
        page.wait_for_function("document.querySelectorAll('.project-shell').length===2")
        page.locator('.project-main').filter(has_text='eshop').click();page.locator('[data-zoo-decision="run"]').wait_for()
        check('Zoo and another running project remain exactly two rows',page.locator('.project-shell').count()==2)
        check('Verified Zoo ask offers Run and Deny',page.locator('[data-zoo-decision]').count()==2)
        page.evaluate("()=>{const b=document.createElement('div');b.id='screenLabel';b.textContent='TESTOVACÍ DATA · skutečný dashboard, simulovaný Zoo Task';b.style='background:#253443;color:white;padding:8px;text-align:center';document.body.prepend(b)}");page.screenshot(path=str(OUT/'zoo-dashboard-0.4.2.png'),full_page=True);page.locator('#screenLabel').evaluate('(e)=>e.remove()')
        page.locator('[data-zoo-decision="run"]').click();check('Run confirmation shows exact full command',page.locator('.approval-body').inner_text()=='npm test -- --runInBand')
        check('Opening confirmation alone does not approve',len(ctl(op='status')['calls'])==0)
        page.locator('#dialog [data-close]').click();check('Cancel never sends a Zoo response',len(ctl(op='status')['calls'])==0)
        page.locator('#notifications').click();page.locator('[data-notice-open]').first.wait_for();nid=page.locator('[data-notice-open]').first.get_attribute('data-notice-open');page.locator('[data-notice-open]').first.click()
        page.locator('[data-notice]').wait_for();check('Notification opens exact original event',page.locator('[data-notice]').get_attribute('data-notice')==nid and 'npm test' in page.locator('[data-notice]').inner_text())
        check('Clicking notification never approves command',len(ctl(op='status')['calls'])==0)
        page.locator('[data-zoo-decision="run"]').click();page.locator('#confirmZooDecision').click()
        page.wait_for_function("document.querySelector('#notice').textContent.includes('Run předáno')",timeout=15000)
        check('Run reaches task-scoped Zoo response through real hub and producer',ctl(op='status')['calls']==['yesButtonClicked'])
        check('Action feedback is actually visible, not hidden by legacy CSS',page.locator('#notice').is_visible())
        page.wait_for_function("document.querySelectorAll('[data-zoo-decision]').length===0")
        check('Answered ask no longer offers approval buttons',page.locator('[data-zoo-decision]').count()==0)
        check('Previously opened event is marked resolved instead of retargeting','vyřízený' in page.locator('[data-notice]').inner_text())
        danger='node tools/prepare.js --path="<img src=x onerror=window.injected=true>"\n'+'--note='+('úplný obsah ' * 90)
        ctl(op='ask',text=danger,protected=True);page.locator('[data-zoo-decision="deny"]').wait_for();page.locator('[data-zoo-decision="deny"]').click()
        check('Protected request is explicitly labeled', 'chráněnou' in page.locator('#dialog').inner_text())
        check('Approval content is complete, not just summary',page.locator('.approval-body').inner_text()==danger)
        check('Agent HTML is inert in command body',page.locator('#dialog img').count()==0 and not page.evaluate('window.injected===true'))
        page.evaluate("()=>{const b=document.createElement('div');b.textContent='TESTOVACÍ DATA · skutečné rozhraní / simulovaný Zoo Task';b.style='position:fixed;top:0;left:0;right:0;background:#253443;color:white;padding:6px;text-align:center;z-index:10000';b.id='fixtureLabel';document.body.appendChild(b)}")
        page.screenshot(path=str(OUT/'zoo-deny-confirmation-0.4.2.png'),full_page=True);page.locator('#fixtureLabel').evaluate('(e)=>e.remove()')
        page.locator('#confirmZooDecision').click();page.wait_for_function("document.querySelector('#notice').textContent.includes('Deny předáno')",timeout=15000)
        check('Deny sends only noButtonClicked for that ask',ctl(op='status')['calls']==['yesButtonClicked','noButtonClicked'])
        ctl(op='ask',text='npm run build');page.locator('[data-zoo-decision="run"]').wait_for();page.locator('[data-zoo-decision="run"]').click()
        ctl(op='ask',text='npm run different-command');page.wait_for_timeout(300);page.locator('#confirmZooDecision').click();page.wait_for_timeout(1500)
        check('Changed ask rejects already-open confirmation with zero extra decisions',len(ctl(op='status')['calls'])==2)
        page.locator('#search').fill('backend');page.locator('#notifications').click();page.locator('[data-notice-open="'+nid+'"]').click();page.wait_for_function("document.querySelector('#search').value==='' && !document.querySelector('#dialog').open");page.locator('[data-notice="'+nid+'"]').wait_for()
        check('Notice navigation clears a filter hiding the target project',page.locator('#search').input_value()=='' and page.locator('#detail h2').inner_text()=='eshop')
        check('Old notice preserves original command after newer asks exist','npm test -- --runInBand' in page.locator('[data-notice]').inner_text() and 'different-command' not in page.locator('[data-notice]').inner_text())
        check('Navigation uses immutable notice fragment',page.url.endswith('#notice='+nid))
        # Simulate a native click in a fresh document with real one-use ticket login.
        ticket=urllib.request.urlopen(urllib.request.Request(url+'/api/desktop/ticket',data=b'',headers={'Authorization':'Bearer '+f['desktopSecret']})).read().decode()
        jar.clear();page.close();page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.expose_binding('__mcTestFetch',bridge_fetch);page.goto('about:blank#desktop-ticket='+ticket+'&notice='+nid);page.set_content(html,wait_until='load')
        page.locator('[data-notice="'+nid+'"]').wait_for(timeout=15000)
        check('Desktop one-use login preserves exact event target',page.url.endswith('#notice='+nid) and 'desktop-ticket' not in page.url)
        check('Opening authenticated desktop link performs no approval',len(ctl(op='status')['calls'])==2)
        page.evaluate("()=>{const b=document.createElement('div');b.textContent='TESTOVACÍ DATA · skutečné rozhraní / simulovaný Zoo Task';b.style='background:#253443;color:white;padding:8px;text-align:center';document.body.prepend(b)}")
        page.screenshot(path=str(OUT/'zoo-event-navigation-0.4.2.png'),full_page=True)
        page.locator('[data-disconnect]').click();page.locator('#confirmDisconnect').click();page.wait_for_function("!document.querySelector('#rows').textContent.includes('eshop')")
        page.locator('#notifications').click();page.locator('[data-notice-open="'+nid+'"]').click();page.wait_for_function("document.querySelector('#dialogTitle').textContent.includes('již není')")
        check('Removed-project notice shows original event, never another project', 'npm test -- --runInBand' in page.locator('#dialogContent').inner_text() and 'Žádný jiný' in page.locator('#dialogContent').inner_text())
        page.locator('#dialog [data-close]').click();page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(150)
        check('Narrow screen has no page overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
        check('No JavaScript page errors',not errors)
        browser.close()
    print(json.dumps({'passed':len(checks),'checks':checks,'backend':'Real HTTP hub, bridge/producer, test Zoo object; cookie-aware injected browser transport; no actual Windows/VS Code host.'},ensure_ascii=False,indent=2))
finally:
    proc.terminate()
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:proc.kill()
