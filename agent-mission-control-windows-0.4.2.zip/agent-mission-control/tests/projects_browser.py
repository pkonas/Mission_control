"""Production browser DOM + actual HTTP hub, test transport shim (direct loopback navigation is blocked). Not a Windows/VS Code test."""
from pathlib import Path
import subprocess,json,urllib.request,urllib.error,http.cookiejar,time,sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'docs'
OUT.mkdir(parents=True,exist_ok=True)
checks=[]
def check(name, value):
    assert value,name
    checks.append(name)
proc=subprocess.Popen(['node',str(ROOT/'tests/fixtures/project-browser-hub.mjs')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
try:
    fixture=json.loads(proc.stdout.readline());url=fixture['url'];token=fixture['token']
    def post(route,data):
        req=urllib.request.Request(url+route,data=json.dumps(data).encode(),headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
        return json.load(urllib.request.urlopen(req))
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium')
        ctx=browser.new_context(viewport={'width':1536,'height':1100})
        page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        # Container Chromium policy blocks loopback. Only the browser transport is injected;
        # requests execute against the actual hub via Python; authentication/cookies/routes are real.
        jar=http.cookiejar.CookieJar();opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
        def bridge_fetch(_source,route,options):
            headers={'Origin':url,**(options.get('headers') or {})}
            req=urllib.request.Request(url+route,method=options.get('method','GET'),data=options.get('body').encode() if options.get('body') else None,headers=headers)
            try:
                with opener.open(req,timeout=5) as res:return {'status':res.status,'body':res.read().decode()}
            except urllib.error.HTTPError as err:return {'status':err.code,'body':err.read().decode()}
        page.expose_binding('__mcTestFetch',bridge_fetch)
        transport="""<script>
        window.fetch=async(route,options={})=>{const r=await window.__mcTestFetch(route,options);return new Response(r.body,{status:r.status,headers:{'Content-Type':'application/json'}});};
        window.EventSource=class {constructor(){this.handlers={};window.testEvents=this;this.timer=setInterval(async()=>{const r=await fetch('/api/state');if(r.ok&&this.handlers.snapshot)this.handlers.snapshot({data:await r.text()});},120);} addEventListener(k,f){this.handlers[k]=f;}close(){clearInterval(this.timer);}};
        </script>"""
        html=(ROOT/'dashboard-demo.html').read_text().replace('window.MC_OFFLINE=true;','window.MC_OFFLINE=false;').replace('<script>window.MC_OFFLINE=',transport+'<script>window.MC_OFFLINE=')
        page.set_content(html,wait_until='load');page.locator('#loginForm').wait_for();page.locator('#pairToken').fill(token);page.locator('#loginForm button').click()
        page.wait_for_function("document.querySelector('#hubStatus').textContent.includes('připojen')")
        page.wait_for_function("document.querySelectorAll('.project-shell').length===6")
        check('Actual HTTP login and state snapshots through test transport initialize six projects',page.locator('.project-shell').count()==6)
        check('Four Codex records produce exactly one monografie row',page.locator('.project-shell').filter(has_text='monografie').count()==1)
        page.locator('.project-main').filter(has_text='monografie').click()
        check('Selected project shows current main work, not internal completion',page.locator('#detail .callout').inner_text().find('Pracuje')>=0)
        check('Internal approval JSON is absent from main view','risk_level' not in page.locator('body').inner_text())
        check('One selected project title',page.locator('#detail h2').inner_text()=='monografie')
        page.locator('[data-tab="history"]').click();check('Auxiliary history is collapsed metadata',page.locator('[data-expand="diagnostics"]').count()==1 and not page.locator('[data-expand="diagnostics"]').evaluate('(e)=>e.open'))
        page.locator('[data-expand="diagnostics"] summary').click();check('Internal records do not expose their message body','Interní posouzení' not in page.locator('#detail').inner_text())
        page.locator('[data-tab="changes"]').click();check('Changes use unique file snapshot',page.locator('#detail').inner_text().find('Počet se nesčítá')>=0)
        page.locator('#search').fill('monografie');check('Search filters projects, not chats',page.locator('.project-shell').count()==1)
        page.locator('#search').fill('');page.locator('#environment').select_option('Windows');check('Environment filter matches root rows',page.locator('.project-shell').count()>=1 and 'WSL' not in page.locator('#rows').inner_text())
        page.locator('#environment').select_option('all');page.locator('#agent').select_option('zoo');check('Tool filter excludes Codex-only project','monografie' not in page.locator('#rows').inner_text());page.locator('#agent').select_option('all')
        page.locator('.project-main').filter(has_text='monografie').click();page.locator('[data-pin]').click();check('Pin keeps a project at top',page.locator('.project-shell').first.inner_text().find('monografie')>=0)
        page.locator('#density').click();check('Compact mode toggles without losing selection',page.locator('body').evaluate("e=>e.classList.contains('compact')") and page.locator('#detail h2').inner_text()=='monografie');page.locator('#density').click()
        page.locator('[data-ack]').click();page.wait_for_timeout(100);check('Acknowledge does not send an agent command','schváleno' in page.locator('#notice').inner_text())
        # Add main Zoo pending request to SAME root using the actual producer API.
        sessions=fixture['sessions'];mono=next(s for s in sessions if s['project']=='monografie' and s.get('role')=='main')
        both={**mono,'id':'zoo-browser-question','agent':'zoo','evidence':'api','role':'main','state':'needs_input','activity':'Kterou kapitolu zpracovat? <img src=x onerror=window.injected=true>','activityAt':int(time.time()*1000),'stateSince':int(time.time()*1000),'runStartedAt':int(time.time()*1000)}
        # Use a sequence beyond fixture; subsequent smaller heartbeat is correctly rejected.
        post('/api/ingest',{**fixture['envelope'],'seq':10000,'sessions':[s for s in sessions if s['state']!='disconnected']+[both]})
        page.wait_for_function("document.querySelector('#detail .callout').textContent.includes('Kterou kapitolu')")
        check('Two different tools still yield one row for same project',page.locator('.project-shell').filter(has_text='monografie').count()==1)
        check('Human question takes priority while Codex continues', 'Čeká na tebe' in page.locator('#detail .callout').inner_text() and 'další běh pracuje' in page.locator('#detail .callout').inner_text())
        check('Both tools remain visible inside selected project',page.locator('#detail .run').count()==2)
        check('Agent-controlled HTML stays inert text',page.locator('#detail img').count()==0 and not page.evaluate('window.injected===true'))
        stale_snapshot=page.evaluate("async()=>await (await fetch('/api/state')).json()")
        page.locator('[data-disconnect]').click();check('Project removal dialog captures project scope','Ostatní kořeny' in page.locator('#dialog').inner_text());page.locator('#confirmDisconnect').click()
        page.wait_for_function("!document.querySelector('#rows').textContent.includes('monografie')")
        check('Real dashboard removal deletes only selected project',page.locator('.project-shell').count()==5)
        reappeared=page.evaluate("s=>{window.testEvents.handlers.snapshot({data:JSON.stringify(s)});return document.querySelector('#rows').textContent.includes('monografie');}",stale_snapshot)
        check('Out-of-order browser snapshot cannot resurrect a removed project',not reappeared)
        # A late root/task with old epoch must be rejected by project tombstones.
        post('/api/ingest',{**fixture['envelope'],'seq':10001,'sessions':[s for s in sessions if s['state']!='disconnected']+[both]})
        page.wait_for_timeout(300);check('Late producer update does not restore removed row','monografie' not in page.locator('#rows').inner_text())
        # Actual reload: HTTP state remains detached, no front-end-only hiding.
        page.goto('about:blank');page.set_content(html,wait_until='load');page.wait_for_function("document.querySelector('#hubStatus').textContent.includes('připojen')");check('Removal survives a new dashboard document and authenticated HTTP read','monografie' not in page.locator('#rows').inner_text())
        page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(100);check('Narrow 390px view has no horizontal page overflow',page.evaluate('document.documentElement.scrollWidth <= innerWidth+1'))
        check('No JavaScript page errors in actual hub workflow',not errors)
        ctx.close()
        # Offline release demo: synthetic label remains in all screenshots.
        ctx=browser.new_context(viewport={'width':1536,'height':1100});page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content((ROOT/'dashboard-demo.html').read_text(),wait_until='load');page.wait_for_function("document.querySelectorAll('.project-shell').length===7")
        check('Standalone bundle loads seven synthetic projects',page.locator('.project-shell').count()==7)
        check('Standalone preview is explicitly marked synthetic',page.locator('#demoBanner').is_visible() and 'UKÁZKOVÁ DATA' in page.locator('#demoBanner').inner_text())
        page.locator('.project-main').filter(has_text='monografie').click();page.screenshot(path=str(OUT/'mission-control-projekty-0.4.2.png'),full_page=True)
        page.locator('#demoStep').click();check('New demo activity does not increase project count',page.locator('.project-shell').count()==7)
        page.locator('[data-disconnect]').click();page.screenshot(path=str(OUT/'project-disconnect-0.4.2.png'),full_page=True);page.locator('#confirmDisconnect').click();check('Standalone removal uses project unit',page.locator('.project-shell').count()==6)
        check('Standalone demo has no JavaScript errors',not errors)
        browser.close()
    print(json.dumps({'passed':len(checks),'checks':checks,'browser':'Chromium / Linux','backend':'Actual HTTP hub via injected browser transport and cookie jar; EventSource snapshots polled by shim. Direct loopback Chromium navigation blocked. Synthetic tasks, no VS Code host.'},ensure_ascii=False,indent=2))
finally:
    proc.terminate()
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:proc.kill()
