import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,rm,mkdir,writeFile} from 'node:fs/promises';
import os from 'node:os';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {Store} from '../src/store.mjs';import {createHub} from '../src/server.mjs';
import transport from '../bridge/src/producer.cjs';import desktop from '../bridge/src/desktop.cjs';
import {startCodexClient} from '../src/codex-client.mjs';
const token='d'.repeat(64),headers={Authorization:`Bearer ${token}`};
const session=(id='task-one',overrides={})=>({id,agent:'zoo',workspace:'/repo',host:'test-host',environment:'Linux',project:'Project A',state:'working',evidence:'api',activity:'Test event',activityAt:Date.now(),stateSince:Date.now(),...overrides});
const envelope=(id='source-a',epoch='epoch-one',sessions=[session()],seq=1)=>({version:1,sourceId:id,epoch,label:id,sessions,seq});
const expectCode=code=>e=>e.code===code;
const until=async fn=>{const start=Date.now();while(Date.now()-start<10000){if(fn())return;await new Promise(r=>setTimeout(r,15));}throw new Error('Condition timeout');};
const native=(hub,route,data)=>fetch(hub.url+route,{method:data?'POST':'GET',headers,body:data?JSON.stringify(data):undefined});
async function browser(hub){const r=await native(hub,'/api/login',{token});const cookie=r.headers.get('set-cookie').split(';')[0];return (route,data)=>fetch(hub.url+route,{method:data?'POST':'GET',headers:{Cookie:cookie},body:data?JSON.stringify(data):undefined});}
async function withHub(fn,opts={}){const hub=await createHub({port:0,token,persist:false,...opts});try{return await fn(hub);}finally{await hub.close();}}
function seeded(){const store=new Store();store.claim(envelope());store.ingest(envelope('source-a','epoch-one',[session(),session('task-two',{agent:'codex'})]));store.claim(envelope('source-b','epoch-two'));store.ingest(envelope('source-b','epoch-two',[session('other',{workspace:'/other',project:'Project B'})]));return store;}

test('Disconnect store: removes all sessions of one source, not other sources or agents',()=>{
 const s=seeded(),r=s.disconnectSource('source-a',{epoch:'epoch-one'});assert.equal(r.count,2);
 const snap=s.snapshot();assert.equal(snap.sessions.length,1);assert.equal(snap.sessions[0].project,'Project B');assert(snap.sessions[0].connected);
 assert.deepEqual(snap.sources.map(x=>x.id),['source-b']);assert(s.detachedSources.has('source-a'));
});
test('Disconnect store: late ingest and automatic reclaims cannot resurrect records',()=>{
 const s=seeded();s.disconnectSource('source-a',{epoch:'epoch-one'});
 for(let n=2;n<22;n++)assert.throws(()=>s.ingest(envelope('source-a','epoch-one',[session()],n)),expectCode('CONNECTION_REMOVED'));
 assert.throws(()=>s.claim(envelope('source-a','epoch-new')),expectCode('CONNECTION_REMOVED'));assert.equal(s.sessions.size,1);
});
test('Disconnect store: explicit new owner can resume; old owner stays permanently fenced',()=>{
 const s=seeded();s.disconnectSource('source-a',{epoch:'epoch-one'});
 assert.throws(()=>s.claim({...envelope(),resume:true}),expectCode('CONNECTION_REMOVED'));
 s.claim({...envelope('source-a','epoch-new'),resume:true});s.ingest(envelope('source-a','epoch-new'));
 assert.equal(s.snapshot().sessions.length,2);assert(!s.detachedSources.has('source-a'));
 assert.throws(()=>s.ingest(envelope('source-a','epoch-one',undefined,50)),expectCode('CONNECTION_REMOVED'));
});
test('Disconnect store: a normal stop or lease timeout preserves history; only removal hides it',()=>{
 const s=seeded();s.release(envelope());assert.equal(s.snapshot().sessions.length,3);assert.equal(s.snapshot().sessions.filter(x=>!x.connected).length,2);assert(!s.detachedSources.size);
});
test('Disconnect store: stale dashboard and losing duplicate cannot remove active owner',()=>{
 const s=seeded();for(const epoch of ['wrong-epoch',null])assert.throws(()=>s.disconnectSource('source-a',{epoch}),expectCode('NOT_OWNER'));
 assert.throws(()=>s.disconnectSource('source-a',{epoch:'wrong-epoch',producer:true}),expectCode('NOT_OWNER'));assert(s.snapshot().sessions.every(x=>x.connected));
});
test('Disconnect store: repeated same request is idempotent including empty connections',()=>{
 const s=new Store();s.claim(envelope('empty-source','epoch-empty',[]));assert(s.disconnectSource('empty-source',{epoch:'epoch-empty'}).removed);assert(s.disconnectSource('empty-source',{epoch:'epoch-empty'}).removed);assert.equal(s.snapshot().sources.length,0);
});
test('Disconnect store: offline persisted source with no live epoch can be removed',()=>{
 const s=new Store();s.restore(seeded().serialize());assert.equal(s.sessions.size,3);assert.equal(s.sources.size,0);
 assert.equal(s.disconnectSource('source-a').count,2);assert.equal(s.sessions.size,1);assert(s.detachedSources.has('source-a'));
});
test('Disconnect store: serialized pause and retired epochs survive restore and explicit resume',()=>{
 const s=seeded();s.disconnectSource('source-a',{epoch:'epoch-one'});const restored=new Store();restored.restore(s.serialize());
 assert.equal(restored.sessions.size,1);assert.throws(()=>restored.claim(envelope('source-a','epoch-fresh')),expectCode('CONNECTION_REMOVED'));
 restored.claim({...envelope('source-a','epoch-fresh'),resume:true});restored.ingest(envelope('source-a','epoch-fresh'));
 const r=new Store();r.restore(restored.serialize());assert.throws(()=>r.claim({...envelope(),resume:true}),expectCode('CONNECTION_REMOVED'));
 r.claim(envelope('source-a','epoch-third'));assert(r.sources.has('source-a'));
});
test('Disconnect store: corrupt saved controls do not execute or resurrect removed rows',()=>{
 const r=new Store();const data=seeded().serialize();data.detachedSources=[null,{id:'source-a',label:'A'}, {id:'../../bad'}];data.retiredEpochs=[null,['source-a',['epoch-one',null,42]],['?bad',{}]];
 r.restore(data);assert.equal(r.sessions.size,1);assert(r.detachedSources.has('source-a'));assert.deepEqual(r.retiredEpochs.get('source-a'),['epoch-one']);
});
test('Disconnect HTTP: endpoint separates cookie UI auth from producer bearer auth',()=>withHub(async h=>{
 await native(h,'/api/claim',envelope());await native(h,'/api/ingest',envelope());const ui=await browser(h);
 assert.equal((await fetch(h.url+'/api/disconnect',{method:'POST',body:JSON.stringify({sourceId:'source-a',epoch:'epoch-one'})})).status,401);
 assert.equal((await native(h,'/api/disconnect',{sourceId:'source-a',epoch:'epoch-one'})).status,401);
 assert.equal((await ui('/api/disconnect-source',envelope())).status,401);assert.equal(h.store.sessions.size,1);
 assert.equal((await ui('/api/disconnect',{sourceId:'source-a',epoch:'epoch-one'})).status,200);assert.equal(h.store.sessions.size,0);
}));
test('Disconnect HTTP: cross-origin write is rejected, connection remains intact',()=>withHub(async h=>{
 await native(h,'/api/claim',envelope());await native(h,'/api/ingest',envelope());
 const r=await fetch(h.url+'/api/disconnect-source',{method:'POST',headers:{...headers,Origin:'https://untrusted.example'},body:JSON.stringify(envelope())});assert.equal(r.status,403);assert.equal(h.store.sessions.size,1);
}));
test('Disconnect HTTP: saved intent is on disk before success and blocks reports after full hub restart',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'mc-disconnect-'));let h;
 try{h=await createHub({port:0,token,persist:true,dataDir:dir});await native(h,'/api/claim',envelope());await native(h,'/api/ingest',envelope());
 const ui=await browser(h);const r=await ui('/api/disconnect',{sourceId:'source-a',epoch:'epoch-one'});assert.equal(r.status,200);
 const state=JSON.parse(await readFile(path.join(dir,'state.json'),'utf8'));assert.equal(state.sessions.length,0);assert.equal(state.detachedSources[0].id,'source-a');
 await h.close();h=await createHub({port:0,token,persist:true,dataDir:dir});assert.equal((await native(h,'/api/ingest',envelope())).status,409);assert.equal((await native(h,'/api/claim',envelope('source-a','epoch-new'))).status,409);
 assert.equal((await native(h,'/api/claim',{...envelope('source-a','epoch-new'),resume:true})).status,200);assert.equal((await native(h,'/api/ingest',envelope('source-a','epoch-new'))).status,200);
 }finally{await h?.close();await rm(dir,{recursive:true,force:true});}
});
test('Disconnect HTTP: late removal after reconnect is rejected, even following hub restart',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'mc-fence-'));let h;
 try{h=await createHub({port:0,token,persist:true,dataDir:dir});await native(h,'/api/claim',envelope());await native(h,'/api/disconnect-source',envelope());await native(h,'/api/claim',{...envelope('source-a','epoch-new'),resume:true});await h.close();
 h=await createHub({port:0,token,persist:true,dataDir:dir});const r=await native(h,'/api/disconnect-source',envelope());assert.equal(r.status,409);assert.equal((await r.json()).code,'NOT_OWNER');
 assert.equal((await native(h,'/api/claim',envelope('source-a','epoch-other'))).status,200);
 }finally{await h?.close();await rm(dir,{recursive:true,force:true});}
});
test('Disconnect HTTP: a failed durable write is reported, not claimed as successful',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'mc-save-error-'));let h;
 try{h=await createHub({port:0,token,persist:true,dataDir:dir});await native(h,'/api/claim',envelope());await native(h,'/api/ingest',envelope());await mkdir(path.join(dir,'state.json.tmp'));
 const r=await native(h,'/api/disconnect-source',envelope());assert.equal(r.status,400);assert.match((await r.json()).error,/nepodařilo uložit/);assert.equal(h.store.sessions.size,0);assert(h.store.detachedSources.has('source-a'));
 await rm(path.join(dir,'state.json.tmp'),{recursive:true});
 }finally{await h?.close();await rm(dir,{recursive:true,force:true});}
});
async function approvalReady(h){
 const e=envelope('source-a','epoch-one',[session('codex-one',{agent:'codex',state:'needs_approval',capabilities:['approve'],pending:[{id:91,method:'item/commandExecution/requestApproval',summary:'Synthetic request'}]})]);
 await native(h,'/api/claim',e);await native(h,'/api/ingest',e);const ui=await browser(h),s=h.store.snapshot().sessions[0];const r=await ui('/api/action',{key:s.key,stateRevision:s.stateRevision,action:'approve',requestId:91,decision:'accept'});assert.equal(r.status,202);return {ui,id:(await r.json()).id};
}
test('Disconnect HTTP: undelivered approval is cancelled, never dispatched to replacement',()=>withHub(async h=>{
 const {ui,id}=await approvalReady(h);await ui('/api/disconnect',{sourceId:'source-a',epoch:'epoch-one'});
 assert.equal((await (await ui('/api/action/'+id)).json()).status,'failed');
 assert.equal((await native(h,'/api/commands?sourceId=source-a&epoch=epoch-one')).status,409);
 await native(h,'/api/claim',{...envelope('source-a','epoch-new'),resume:true});const poll=await native(h,'/api/commands?sourceId=source-a&epoch=epoch-new');assert.deepEqual((await poll.json()).commands,[]);
}));
test('Disconnect HTTP: already-delivered action is unknown, not falsely cancelled or repeated',()=>withHub(async h=>{
 const {ui,id}=await approvalReady(h);const commands=await(await native(h,'/api/commands?sourceId=source-a&epoch=epoch-one')).json();assert.equal(commands.commands.length,1);
 await ui('/api/disconnect',{sourceId:'source-a',epoch:'epoch-one'});const r=await(await ui('/api/action/'+id)).json();assert.equal(r.status,'unknown');assert.match(r.message,/již byl předán/);
 assert.equal((await native(h,'/api/result',{sourceId:'source-a',epoch:'epoch-one',id,ok:true})).status,409);
}));
test('Disconnect Producer: dashboard removal stops reporting without agent command or conflict',()=>withHub(async h=>{
 const commands=[],states=[];const p=new transport.Producer({hub:h.url,token,sourceId:'source-a',label:'A',getSessions:()=>[session()],onCommand:async c=>commands.push(c),onStatus:(ok,msg,e)=>states.push({ok,e})}).start();
 try{await until(()=>h.store.sessions.size===1);const ui=await browser(h);await ui('/api/disconnect',{sourceId:p.sourceId,epoch:p.epoch});await until(()=>p.stopped);
 assert(p.removed);assert.equal(p.removed.code,'CONNECTION_REMOVED');assert(!p.conflict);assert.equal(commands.length,0);assert.equal(h.store.sessions.size,0);assert(states.some(x=>x.e?.code==='CONNECTION_REMOVED'));
 }finally{await p.stop();}
}));
test('Disconnect Producer: own disconnect drains in-flight ingest before removal',()=>withHub(async h=>{
 let allow,started=false;const gate=new Promise(r=>{allow=r;});const p=new transport.Producer({hub:h.url,token,sourceId:'source-a',label:'A',getSessions:async()=>{started=true;await gate;return [session()];}}).start();
 try{await until(()=>started);const removing=p.disconnect();allow();assert((await removing).removed);assert(p.stopped);assert(!p.claimed);assert.equal(h.store.sessions.size,0);assert(h.store.detachedSources.has('source-a'));
 }finally{await p.stop();}
}));
test('Disconnect Producer: resume flag is one-shot; another remove cannot auto-reenable it',()=>withHub(async h=>{
 await native(h,'/api/claim',envelope());await native(h,'/api/disconnect-source',envelope());const p=new transport.Producer({hub:h.url,token,sourceId:'source-a',label:'A',resume:true,getSessions:()=>[session()]});
 try{await p.connect();assert.equal(p.resume,false);h.store.disconnectSource(p.sourceId,{epoch:p.epoch});await assert.rejects(p.connect(),expectCode('CONNECTION_REMOVED'));assert.equal(h.store.sessions.size,0);}
 finally{await p.stop();}
}));
test('Disconnect WSL: stdio relay permits only the dedicated producer endpoint with ownership checks',()=>withHub(async h=>{
 const r=new desktop.RelayTransport({command:process.execPath,args:[fileURLToPath(new URL('../windows/wsl-relay.cjs',import.meta.url))]});
 try{await r.request(h.url,token,'/api/claim','POST',envelope());await r.request(h.url,token,'/api/ingest','POST',envelope());assert((await r.request(h.url,token,'/api/disconnect-source','POST',envelope())).removed);assert.equal(h.store.sessions.size,0);
 await assert.rejects(r.request(h.url,token,'/api/desktop/shutdown','POST',{}),/Unsupported/);await assert.rejects(r.request(h.url,token,'/api/disconnect','POST',{sourceId:'source-a'}),/Unsupported/);
 }finally{r.stop();}
}));
test('Disconnect managed Codex fixture: remove and reconnect preserves the running RPC and same pending task',()=>withHub(async h=>{
 let c;try{
 c=await startCodexClient({hub:h.url,cwd:os.tmpdir(),sourceId:'managed-disconnect',command:[process.execPath,fileURLToPath(new URL('./fixtures/mock-codex.mjs',import.meta.url))]},{token});await until(()=>h.store.sessions.size===1);
 const ui=await browser(h),s=h.store.snapshot().sessions[0],thread=c.session.id,pid=c.rpc.child.pid;
 assert.equal((await ui('/api/action',{key:s.key,stateRevision:s.stateRevision,action:'prompt',text:'test fixture'})).status,202);await until(()=>h.store.snapshot().sessions[0]?.state==='needs_approval');
 await ui('/api/disconnect',{sourceId:c.producer.sourceId,epoch:c.producer.epoch});await until(()=>c.producer.stopped);
 assert(!c.rpc.closed);assert(!c.rpc.child.killed);assert.equal(c.session.pending[0].id,91);assert.equal(h.store.sessions.size,0);
 const back=await c.reconnect();assert.equal(back.threadId,thread);assert.equal(c.rpc.child.pid,pid);await until(()=>h.store.sessions.size===1);assert.equal(h.store.snapshot().sessions[0].pending[0].id,91);
 const need=h.store.snapshot().sessions[0];assert.equal((await ui('/api/action',{key:need.key,stateRevision:need.stateRevision,action:'approve',requestId:91,decision:'decline'})).status,202);await until(()=>h.store.snapshot().sessions[0]?.state==='review');
 }finally{await c?.close();}
}));
