import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
const require=createRequire(import.meta.url);
const {resolveInstallation,parseLauncher}=require('../windows/vscode-layout.cjs');
const {manage,isolatedEnvironment}=require('../windows/vscode-cli.cjs');
const HASH='a123456789',FULL_HASH=HASH+'0'.repeat(30);
function fixture(t,{hash='',insiders=false,launcher=true,target,portable=false,executableName}={}) {
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mc Code & 100% ! žluťoučký '));
 t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 const exe=path.join(root,executableName||(insiders?'Code - Insiders.exe':'Code.exe'));
 fs.writeFileSync(exe,'test executable placeholder');
 const app=path.join(root,hash,'resources','app'),cli=path.join(app,'out','cli.js');
 fs.mkdirSync(path.dirname(cli),{recursive:true});fs.writeFileSync(cli,'// fixture, not Microsoft Code');
 const product={applicationName:insiders?'code-insiders':'code'};if(target)product.target=target;
 fs.writeFileSync(path.join(app,'product.json'),JSON.stringify(product));
 if(portable)fs.mkdirSync(path.join(root,'data'));
 const cmd=path.join(root,'bin',insiders?'code-insiders.cmd':'code.cmd');
 fs.mkdirSync(path.dirname(cmd));
 if(launcher)fs.writeFileSync(cmd,`@echo off\r\nsetlocal\r\nset VSCODE_DEV=\r\nset ELECTRON_RUN_AS_NODE=1\r\n"%~dp0..\\${path.basename(exe)}" "%~dp0..\\${hash?hash+'\\':''}resources\\app\\out\\cli.js" %*\r\nIF %ERRORLEVEL% NEQ 0 EXIT /b %ERRORLEVEL%\r\nendlocal\r\n`);
 return {root,exe,app,cli,cmd};
}
const success=(stdout='')=>({exitCode:0,stdout,stderr:'',timedOut:false,overflow:false,spawnError:''});
test('VS Code layout: legacy executable + official launcher',(t)=>{
 const f=fixture(t);const r=resolveInstallation(f.exe);assert.equal(r.cli,f.cli);assert.equal(r.method,'active-launcher');
});
test('VS Code layout REGRESSION: versioned resources with no root resources folder',(t)=>{
 const f=fixture(t,{hash:HASH});assert(!fs.existsSync(path.join(f.root,'resources')));const r=resolveInstallation(f.exe);assert.equal(r.cli,f.cli);assert.equal(r.resourceVersion,HASH);
});
test('VS Code layout: active launcher wins over newer/staged resources',(t)=>{
 const f=fixture(t,{hash:HASH});const other=path.join(f.root,'ffffffff00','resources','app','out');fs.mkdirSync(other,{recursive:true});fs.writeFileSync(path.join(other,'cli.js'),'other');
 fs.writeFileSync(path.join(f.root,'bin','new_code.cmd'),'staged update');assert.equal(resolveInstallation(f.exe).cli,f.cli);
});
test('VS Code layout: Stable and Insiders paths remain distinct',(t)=>{
 const f=fixture(t,{hash:HASH,insiders:true});const r=resolveInstallation(f.exe);assert.equal(r.cli,f.cli);assert.equal(r.product,'VS Code Insiders');
});
test('VS Code layout: absent cmd is allowed for the legacy layout',(t)=>{
 const f=fixture(t,{launcher:false});assert.equal(resolveInstallation(f.exe).method,'legacy-layout');
});
test('VS Code layout: absent cmd can use the exact executable resource version',(t)=>{
 const f=fixture(t,{launcher:false,hash:HASH});assert.equal(resolveInstallation(f.exe,{resourceVersion:HASH}).cli,f.cli);
});
test('VS Code layout: no arbitrary hash-directory guessing',(t)=>{
 const f=fixture(t,{launcher:false,hash:HASH});assert.throws(()=>resolveInstallation(f.exe),/nevybírám odhadem/);
});
test('VS Code layout: stale launcher does not fall back to a leftover CLI',(t)=>{
 const f=fixture(t,{hash:HASH});fs.rmSync(f.cli);const legacy=path.join(f.root,'resources','app','out');fs.mkdirSync(legacy,{recursive:true});fs.writeFileSync(path.join(legacy,'cli.js'),'stale');
 assert.throws(()=>resolveInstallation(f.exe),/chybějící CLI/);
});
test('VS Code layout: modified launcher targeting a different executable is rejected',(t)=>{
 const f=fixture(t);fs.writeFileSync(f.cmd,fs.readFileSync(f.cmd,'utf8').replace('..\\Code.exe','..\\Other.exe'));assert.throws(()=>resolveInstallation(f.exe),/jiné Code/);
});
test('VS Code layout: malformed script is never executed as a fallback',(t)=>{
 const f=fixture(t);fs.writeFileSync(f.cmd,'@echo off\r\nstart Code.exe\r\n');assert.throws(()=>resolveInstallation(f.exe),/Spouštěč nebyl proveden/);
});
test('VS Code layout: launcher must not escape the selected installation',(t)=>{
 const f=fixture(t);const bad=`"%~dp0..\\Code.exe" "%~dp0..\\..\\resources\\app\\out\\cli.js" %*`;
 assert.throws(()=>parseLauncher(bad,f.cmd,f.exe),/mimo/);
});
test('VS Code layout: dynamic environment expansion in launcher is rejected',(t)=>{
 const f=fixture(t);const bad=`"%~dp0..\\Code.exe" "%~dp0..\\%OTHER%\\resources\\app\\out\\cli.js" %*`;
 assert.throws(()=>parseLauncher(bad,f.cmd,f.exe),/Dynamické/);
});
test('VS Code layout: reject ambiguous duplicated launch statements',(t)=>{
 const f=fixture(t);const text=fs.readFileSync(f.cmd,'utf8');fs.writeFileSync(f.cmd,text+text);assert.throws(()=>resolveInstallation(f.exe),/jednoznačně/);
});
test('VS Code layout: reject wrong product/edition metadata',(t)=>{
 const f=fixture(t);fs.writeFileSync(path.join(f.app,'product.json'),JSON.stringify({applicationName:'code-insiders'}));assert.throws(()=>resolveInstallation(f.exe),/edici/);
});
test('VS Code layout: corrupt metadata is a visible error',(t)=>{
 const f=fixture(t);fs.writeFileSync(path.join(f.app,'product.json'),'{');assert.throws(()=>resolveInstallation(f.exe),/poškozený/);
});
test('VS Code layout: portable root/data is detected',(t)=>{
 const f=fixture(t,{portable:true,hash:HASH});assert.equal(resolveInstallation(f.exe).portable,true);
});
test('VS Code layout: installed target is not labelled portable merely by data folder',(t)=>{
 const f=fixture(t,{portable:true,target:'user'});assert.equal(resolveInstallation(f.exe).portable,false);
});
test('VS Code layout: spaces, %, &, ! and Unicode in installation path are literal',(t)=>{
 const f=fixture(t,{hash:HASH});assert.match(f.exe,/žluťoučký/);assert.equal(resolveInstallation(f.exe).cli,f.cli);
});
test('VS Code layout: fake standalone tunnel binary has no desktop layout',(t)=>{
 const f=fixture(t,{executableName:'code-tunnel.exe'});assert.throws(()=>resolveInstallation(f.exe),/desktopovou edici/);
});
test('VS Code layout: missing/relative executable does not trigger a search or spawn',()=>{
 assert.throws(()=>resolveInstallation('Code.exe'),/absolutní/);assert.throws(()=>resolveInstallation(path.join(os.tmpdir(),'nonexistent-unique-code','Code.exe')),/neexistuje/);
});
test('Open editor: case-insensitive inherited IPC/debug/portable env is removed',()=>{
 const original={PATH:'ordinary path',HTTPS_PROXY:'ordinary proxy',vscode_ipc_hook_cli:'remote-pipe',VSCODE_PORTABLE:'other-portable',VSCODE_EXTENSIONS:'wrong extensions',VSCODE_INSPECTOR_OPTIONS:'autodebug',Node_Options:'--require bad',node_path:'bad',electron_run_as_node:'0',ELECTRON_NO_ATTACH_CONSOLE:'1'};
 const env=isolatedEnvironment(original);assert.deepEqual(env,{PATH:'ordinary path',HTTPS_PROXY:'ordinary proxy',ELECTRON_RUN_AS_NODE:'1'});assert.equal(original.electron_run_as_node,'0');
});
test('Open editor: production path probes CLI then installs and verifies same target',(t)=>{
 const f=fixture(t,{hash:HASH});let calls=[];
 return manage({executable:f.exe,resolveLayout:true,vsix:'bridge.vsix',profile:'Vývoj & remote',userDataDir:'D:\\Data & 100% !\\user',extensionsDir:'D:\\Extensions'},async(exe,args,opts)=>{
  calls.push({exe,args,opts});return success(args.includes('--version')?`1.100.0\n${FULL_HASH}\nx64\n`:args.includes('--list-extensions')?'local-mission-control.bridge@0.4.2\n':'installed\n');
 }).then(r=>{
  assert(r.ok);assert(r.reloadSuggested);assert.equal(calls.length,3);assert.equal(r.layout.cli,f.cli);assert.deepEqual(r.commands.map(c=>c.phase),['preflight','operation','verification']);
  for(const c of calls){assert.equal(c.exe,f.exe);assert.equal(c.args[0],f.cli);assert.equal(c.opts.env.ELECTRON_RUN_AS_NODE,'1');assert(!c.args.includes('--wait'));assert(!c.args.includes('--new-window'));assert(!c.args.includes('--reuse-window'));assert.equal(c.opts.cwd,f.root);assert(c.args.includes('D:\\Data & 100% !\\user'));assert(c.args.includes('D:\\Extensions'));assert(c.args.includes('Vývoj & remote'));}
 });
});
test('Open editor: failed CLI preflight never installs the bridge',(t)=>{
 const f=fixture(t);let count=0;return manage({executable:f.exe,resolveLayout:true,vsix:'bridge.vsix'},async()=>{count++;return {...success(),exitCode:7};}).then(r=>{assert.equal(r.ok,false);assert.equal(count,1);});
});
test('Open editor: non-CLI response is not accepted as successful installation',(t)=>{
 const f=fixture(t);let count=0;return manage({executable:f.exe,resolveLayout:true,vsix:'bridge.vsix'},async()=>{count++;return success('Window opened\n');}).then(r=>{assert.equal(r.ok,false);assert.equal(count,1);});
});
test('Open editor: mismatched commit is detected before installation',(t)=>{
 const f=fixture(t,{hash:HASH});let count=0;return manage({executable:f.exe,resolveLayout:true,vsix:'bridge.vsix'},async()=>{count++;return success('1.100.0\n'+'f'.repeat(40)+'\nx64\n');}).then(r=>{assert.equal(r.ok,false);assert.equal(count,1);assert.match(r.message,/neodpovídá/);});
});
test('Open editor: DEP0169 from preflight remains diagnostic only',(t)=>{
 const f=fixture(t);return manage({executable:f.exe,resolveLayout:true,vsix:'bridge.vsix'},async(_exe,args)=>({...success(args.includes('--version')?'1.100.0\n':args.includes('--list-extensions')?'local-mission-control.bridge@0.4.2\n':''),stderr:'[DEP0169] warning\n'})).then(r=>{assert.equal(r.ok,true);assert.equal(r.hasWarnings,true);});
});
test('VS Code context: relative data dirs or embedded newlines are rejected',async()=>{
 await assert.rejects(manage({userDataDir:'relative',action:'verify'}),/absolutní/);await assert.rejects(manage({profile:'bad\nprofile'}),/Neplatná/);
});
test('Integration with mock CLI: unrelated long-running process stays running',async(t)=>{
 const f=fixture(t);const editor=spawn(process.execPath,['-e','setInterval(()=>{},1000)'],{stdio:'ignore'});
 const exited=new Promise(resolve=>editor.once('exit',resolve));
 try {
  const fake=path.resolve('tests/fixtures/fake-vscode.cjs');
  const state=path.join(f.root,'state');const {capture}=require('../windows/vscode-cli.cjs');
  const r=await manage({executable:process.execPath,cli:fake,vsix:'bridge.vsix'},(e,a,o)=>capture(e,a,{...o,env:{...o.env,FAKE_CODE_STATE:state}}));
  assert(r.ok);assert.equal(editor.exitCode,null);assert.equal(process.kill(editor.pid,0),true);
 } finally {editor.kill();await exited;}
});
