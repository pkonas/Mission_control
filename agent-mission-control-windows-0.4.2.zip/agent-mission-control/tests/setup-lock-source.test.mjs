// Source-contract checks, NOT execution of Windows PowerShell or .NET mutexes.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read = name => readFileSync(new URL('../windows/'+name, import.meta.url),'utf8');
const install=read('Install.ps1'), locks=read('Setup-Lock.ps1'), probe=read('Test-SetupLock.ps1');
const operation=install.slice(install.indexOf('function Invoke-MCOperation('),install.indexOf('# Environment validation is read-only.'));
const ui=install.slice(install.indexOf('# Environment validation is read-only.'));
const enter=locks.slice(locks.indexOf('function Enter-MCSetupMutex('), locks.indexOf('function Exit-MCSetupMutex('));
const paths=locks.slice(locks.indexOf('function Test-MCSetupEntryPath('),locks.indexOf('function Get-MCSetupCandidates'));
const patterns=[...paths.matchAll(/\$Path -match '(\(\?i\)[^']+)'/g)].map(m=>new RegExp(m[1].replace(/^\(\?i\)/,''),'i'));
const candidate=p=>patterns.some(re=>re.test(p));
test('Source contract: operation owns mutex, UI startup does not acquire it',()=>{
 assert(operation.includes('$lease = Enter-MCSetupMutex $lockName'));
 const startup=ui.slice(0,ui.indexOf('$form = New-Object'));
 assert(!startup.includes('Enter-MCSetupMutex'));
 assert(!install.includes('held for the whole UI'));
 assert(!install.includes('$ownsMutex'));
});
test('Source contract: lock remains compatible with older versions and busy state is never bypassed',()=>{
 assert(locks.includes("'Local\\AgentMissionControl-Setup-' + $sid"));
 assert(enter.includes('$mutex.WaitOne(0)'));
 assert(enter.includes('if (-not $acquired) { $mutex.Dispose(); return $null }'));
 assert(operation.indexOf('if ($null -eq $lease)') < operation.indexOf('Set-MCPrivateDirectory'));
 assert(!enter.includes('Remove-Item') && !enter.includes('ReadAllText') && !enter.includes('ProcessId'));
});
test('Source contract: mutex release is guaranteed separately from diagnostic cleanup',()=>{
 assert.match(operation,/finally\s*\{\s*Exit-MCSetupMutex \$lease/);
 assert.match(locks,/GetBaseException\(\) -is \[Threading\.AbandonedMutexException\]/);
 assert.match(locks,/finally \{ \$Lease\.Mutex\.Dispose\(\); \$Lease\.Released=\$true \}/);
 assert(operation.includes('MC_SETUP_LOCK_RELEASED'));
 assert(operation.indexOf('Get-MCInstallation') > operation.indexOf('Enter-MCSetupMutex'));
});
test('Source contract: owner record is informative and rejects recycled process IDs',()=>{
 assert(locks.includes('$candidate.StartTicks -ceq [string]$record.startTicks'));
 assert(locks.includes('$candidate.UserSid -ceq $record.userSid'));
 assert(locks.includes('$candidate.SessionId -eq $record.sessionId'));
 assert(locks.includes('jejich vlastnictví zámku nelze potvrdit'));
 assert(locks.includes('Držitele se nepodařilo určit'));
 assert(!/\bStop-Process\b|\.Kill\(|taskkill\b/.test(locks));
});
test('Source contract: an actual multiprocess preflight is wired before stop/replace',()=>{
 assert(operation.includes("'Test-SetupLock.ps1'"));
 assert(operation.indexOf("'Test-SetupLock.ps1'") < operation.indexOf('Install-MissionControl $action'));
 assert(operation.includes("$testResult.ExitCode -ne 0 -or $testResult.StdOut -notmatch 'MC_SETUP_LOCK_TEST_OK:'"));
 assert(probe.includes('MCSetupLock-Test-'));
 assert(!probe.includes('Get-MCSetupMutexName'));
 assert(probe.includes('Enter-MCSetupMutex $name'));
 assert(probe.includes('$lease.Abandoned'));
 assert(probe.includes('live separate process excludes entry'));
});
test('Diagnostic path expressions: actual installer and maintenance entrypoints recognized',()=>{
 assert.equal(patterns.length,4);
 for(const p of [
  'C:\\Users\\petr\\AppData\\Local\\Temp\\MissionControl-'+ 'a'.repeat(32)+'\\bootstrap.ps1',
  'C:\\Users\\petr\\AppData\\Local\\Temp\\MissionControl-'+ 'b'.repeat(32)+'\\payload\\windows\\Install.ps1',
  'C:\\Users\\petr\\AppData\\Local\\Temp\\MissionControl-maintenance-'+ 'c'.repeat(32)+'\\windows\\Install.ps1',
  'C:\\Users\\petr\\AppData\\Local\\AgentMissionControl\\maintenance\\Launch.ps1',
  'C:\\Users\\petr\\Downloads\\agent-mission-control\\windows\\Source-Setup.ps1',
  'C:\\Users\\petr\\AppData\\Local\\Programs\\AgentMissionControl\\windows\\Uninstall.ps1'
 ]) assert(candidate(p),p);
});
test('Diagnostic path expressions: unrelated PowerShell work and loose substring matches rejected',()=>{
 for(const p of [
  'C:\\work\\my-script.ps1', 'C:\\work\\MissionControl-not-a-guid\\bootstrap.ps1',
  'C:\\Temp\\MissionControl-'+ 'a'.repeat(32)+'\\bootstrap.ps1.bak',
  'C:\\tmp\\xAgentMissionControl\\maintenance\\Launch.ps1',
  'C:\\Users\\petr\\.vscode\\extensions\\something\\main.ps1',
  'C:\\work\\MissionControl-'+ 'a'.repeat(32)+'\\other.ps1'
 ]) assert(!candidate(p),p);
});
test('Source contract: command-line diagnostics excludes -Command mentions and the current PID',()=>{
 assert(locks.includes("@('-Command','-c','-EncodedCommand','-e','-ec')"));
 assert(locks.includes("@('-File','-f')"));
 assert(locks.includes('$row.ProcessId -eq $PID'));
 assert(locks.includes('GetOwnerSid'));
 assert(locks.includes('[int]$row.SessionId -ne $session'));
});
test('Source contract: critical new scripts retain UTF-8 BOM for PowerShell 5.1',()=>{
 for(const p of ['Install.ps1','Setup-Lock.ps1','Test-SetupLock.ps1']) assert.equal(read(p).charCodeAt(0),0xFEFF);
});
