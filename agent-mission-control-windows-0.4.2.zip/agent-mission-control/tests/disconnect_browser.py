"""Chromium DOM tests on inline production UI: offline demo + simulated API.
The environment blocks localhost browser navigation; this is NOT a live
browser-to-hub test. Actual HTTP/persistence/producer tests are in disconnect.test.mjs.
"""
from pathlib import Path
import json, os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
checks=[];errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1500,'height':1000})
    page.on('pageerror',lambda e: errors.append(str(e)))
    html=(ROOT/'dashboard-demo.html').read_text()
    page.set_content(html,wait_until='load')
    page.locator('[data-select="backend"]').click()
    page.locator('[data-action="disconnect"]').click()
    assert page.locator('#confirmDisconnect').is_visible()
    assert 'neodesílá' in page.locator('#modal').inner_text().lower()
    assert page.locator('.disconnect-list li').count()==1
    checks.append('Offline: visible monitor-only removal button and explicit scope dialog')
    page.locator('#modal [data-action="close-modal"]').last.click()
    assert page.locator('.session-row').count()==8
    checks.append('Offline: cancelling leaves all 8 sessions intact')
    page.evaluate("snapshot.sessions.find(s=>s.id==='eshop').sourceId=snapshot.sessions.find(s=>s.id==='backend').sourceId; render();")
    # Demo uses 'eshop' in some historical fixtures. Locate second agent directly instead.
    page.locator('#agentFilter').select_option('codex')
    page.locator('[data-action="disconnect"]').click()
    assert page.locator('.disconnect-list li').count()==2
    assert 'E-shop' in page.locator('.disconnect-list').inner_text()
    checks.append('Offline: scope includes both tools, even the task hidden by the current filter')
    page.screenshot(path=str(ROOT/'docs/disconnect-dialog-preview.png'),full_page=True)
    page.locator('#confirmDisconnect').click()
    assert not page.locator('#modal').is_visible()
    assert page.evaluate('snapshot.sessions.length')==6
    assert page.evaluate("snapshot.sessions.every(s=>!['backend','eshop'].includes(s.id))")
    assert page.evaluate('snapshot.sessions.every(s=>s.state!=="disconnected" || s.id==="legacy")')
    checks.append('Offline: confirmation removes only the chosen connection, not other projects')
    page.locator('#clearFiltersButton').click();page.locator('#demoStepButton').click()
    assert page.locator('.session-row').count()==6
    checks.append('Offline: redraw and simulated events do not recreate removed rows')
    page.locator('[data-select="legacy"]').click();page.locator('[data-action="disconnect"]').click();page.locator('#confirmDisconnect').click()
    assert page.locator('.session-row').count()==5
    checks.append('Offline: disconnected historical connection can also be removed')
    page.evaluate("snapshot.sources=[{id:'empty-source',label:'Empty connection',connectionEpoch:'epoch-empty',connected:true}]")
    page.locator('#setupButton').click();page.locator('[data-source-disconnect="empty-source"]').click()
    assert '0 relací' in page.locator('#modal').inner_text();page.locator('#confirmDisconnect').click()
    assert page.evaluate('snapshot.sources.length')==0
    checks.append('Offline: source with no agent task is removable from Connection settings')
    page.evaluate("snapshot.sources=[{id:'unsafe-label',label:'<img src=x onerror=window.bad=1>',connectionEpoch:'epoch-safe'}]; showDisconnect('unsafe-label');")
    assert page.locator('#modal img').count()==0 and page.evaluate('window.bad || null') is None
    checks.append('Offline: untrusted connection label is rendered as text, never HTML')
    page.set_viewport_size({'width':390,'height':844});assert page.evaluate('document.body.scrollWidth')<=390
    assert page.locator('#confirmDisconnect').is_visible()
    checks.append('Offline: removal dialog fits mobile width with accessible confirmation')
    page.close()
    # Exercise the actual non-OFFLINE fetch/UI path, but provide API doubles.
    # No network access or localhost navigation policy bypass is involved.
    mock='''<script>
    const now=Date.now();
    window.fixture={version:1,revision:1,hubId:'fixture-hub',serverTime:now,demo:false,sources:[{id:'live-source',connectionEpoch:'epoch-live',label:'Fixture source',connected:true}],sessions:[{key:'a'.repeat(24),sourceId:'live-source',sourceEpoch:'epoch-live',id:'fixture-task',agent:'zoo',project:'Fixture project',workspace:'/fixture',host:'test',environment:'Linux',evidence:'api',state:'working',effectiveState:'working',connected:true,stateSince:now,activityAt:now,activity:'Fixture event',events:[],messages:[],files:[],pending:[],capabilities:[]}]};
    window.oldFixture=structuredClone(window.fixture);window.requests=[];window.failRemoval=false;
    window.fetch=async(url,opts={})=>{
      const data=opts.body?JSON.parse(opts.body):undefined;window.requests.push({url,method:opts.method||'GET',data});
      let status=200,body;
      if(url==='/api/state')body=structuredClone(window.fixture);
      else if(url==='/api/disconnect'){
        if(window.failRemoval){status=503;body={error:'Testovací výpadek hubu'};}
        else if(window.fixture.sources[0]&&data.epoch!==window.fixture.sources[0].connectionEpoch){status=409;body={error:'Připojení se mezitím změnilo. Nové připojení nebylo odpojeno.'};}
        else{window.fixture.sessions=window.fixture.sessions.filter(s=>s.sourceId!==data.sourceId);window.fixture.sources=window.fixture.sources.filter(s=>s.id!==data.sourceId);window.fixture.revision++;body={removed:true};}
      }else{status=404;body={error:'Unexpected mock request'};}
      return new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json'}});
    };
    window.EventSource=class{addEventListener(){}close(){}};
    </script>'''
    live=html.replace('window.MC_OFFLINE=true','window.MC_OFFLINE=false').replace('<script>window.MC_OFFLINE=false',mock+'<script>window.MC_OFFLINE=false')
    page=browser.new_page(viewport={'width':1500,'height':1000});page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(live,wait_until='load')
    page.wait_for_function("document.querySelectorAll('.session-row').length===1")
    checks.append('Simulated API: real non-offline UI renders authenticated snapshot fixture')
    page.evaluate('window.failRemoval=true');page.locator('[data-action="disconnect"]').click();page.locator('#confirmDisconnect').click()
    page.wait_for_function("document.querySelector('#disconnectError').textContent.includes('výpadek')")
    assert page.locator('#confirmDisconnect').is_enabled() and page.locator('.session-row').count()==1
    checks.append('Simulated API: failed removal shows error, retains row and allows retry')
    page.evaluate("window.failRemoval=false;window.fixture.sources[0].connectionEpoch='epoch-new'")
    page.locator('#confirmDisconnect').click();page.wait_for_function("document.querySelector('#disconnectError').textContent.includes('mezitím')")
    assert page.evaluate('window.requests.at(-1).data.epoch')=='epoch-live'
    assert page.locator('.session-row').count()==1
    checks.append('Simulated API: dialog uses captured epoch; replacement connection is not removed')
    page.evaluate("window.fixture.sources[0].connectionEpoch='epoch-live'")
    page.locator('#confirmDisconnect').click();page.wait_for_function("document.querySelectorAll('.session-row').length===0")
    assert page.evaluate("window.requests.some(r=>r.url==='/api/disconnect'&&r.method==='POST'&&r.data.sourceId==='live-source')")
    assert not page.evaluate("window.requests.some(r=>r.url==='/api/action')")
    checks.append('Simulated API: correct POST endpoint; refreshed list; no agent action request')
    page.evaluate('accept(window.oldFixture)');assert page.locator('.session-row').count()==0
    checks.append('Simulated API: delayed lower-revision snapshot cannot reinsert removed row')
    page.screenshot(path=str(ROOT/'docs/disconnect-empty-preview.png'),full_page=True)
    assert errors==[],errors
    checks.append('Both UI modes: no uncaught JavaScript errors')
    browser.close()
print(json.dumps({'passed':len(checks),'kind':'inline Chromium: offline demo and API doubles, NOT real hub navigation','checks':checks},ensure_ascii=False,indent=2))
