/* Linux-executable tests of the ACTUAL shutdown.h and arguments.h source.
 * OS functions are simulated. This is not a Windows integration test. */
#define MC_NATIVE_TEST 1
#include "../../windows/native/util.h"
#include "../../windows/native/arguments.h"
#include "../../windows/native/shutdown.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    DWORD pid,parent,session;int sid;WCHAR path[2048],name[260];uint64_t created;
    BOOL alive,graceful,canForce,job,terminateFails,terminationHangs,imageFails,ownerFails;
    unsigned kills,requests;
} Fake;
static Fake processes[80],self;
static unsigned processCount,snapshotIndex,enumerations,starts;
static uint64_t clockNow;
static DWORD lastError;
static BOOL snapshotFails,sessionFails;
static WCHAR command[4096],localDir[1800],argStore[4096];static LPWSTR argPointers[80];
static char logs[32768];static size_t logSize;
static unsigned tests;
#define CHECK(x) do {if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static void pass(const char *name){++tests;printf("PASS %s\n",name);}
static void reset(void){
    memset(processes,0,sizeof(processes));memset(&self,0,sizeof(self));
    processCount=snapshotIndex=enumerations=starts=0;clockNow=0;lastError=0;
    snapshotFails=sessionFails=0;mcTrayCount=mcChildCount=mcForced=0;logSize=0;logs[0]=0;
    self.pid=1;self.sid=42;self.session=3;self.alive=1;
    wc(localDir,1800,W("C:\\Users\\petr\\AppData\\Local"));
    wc(command,4096,W("\"C:\\Temp\\Mission Control\\MissionControlStop.exe\" \"--stop\""));
}
static Fake *add(const WCHAR *path,DWORD pid,DWORD parent,BOOL graceful){
    Fake *p=&processes[processCount++];p->pid=pid;p->parent=parent;p->session=self.session;p->sid=self.sid;
    p->created=(uint64_t)pid*100;p->alive=1;p->graceful=graceful;p->canForce=1;p->job=1;
    wc(p->path,2048,path);const WCHAR *name=path;for(const WCHAR *s=path;*s;s++)if(*s=='\\')name=s+1;wc(p->name,260,name);return p;
}
static Fake *tray(BOOL graceful){return add(W("C:\\Users\\petr\\AppData\\Local\\Programs\\AgentMissionControl\\MissionControl.exe"),100,9,graceful);}
static Fake *hub(void){return add(W("C:\\Users\\petr\\AppData\\Local\\Programs\\AgentMissionControl\\runtime\\node.exe"),101,100,0);}
static Fake *lookup(DWORD pid){if(pid==self.pid)return &self;for(unsigned i=0;i<processCount;i++)if(processes[i].pid==pid)return &processes[i];return NULLPTR;}
static void end(Fake *p){p->alive=0;if(p->job)for(unsigned i=0;i<processCount;i++)if(processes[i].parent==p->pid)processes[i].alive=0;}
static BOOL contains(const char *needle){size_t n=al(needle);for(size_t i=0;i+n<=logSize;i++){size_t j=0;while(j<n&&logs[i+j]==needle[j])j++;if(j==n)return 1;}return 0;}
DWORD GetEnvironmentVariableW(LPCWSTR key,LPWSTR dest,DWORD cap){CHECK(weq(key,W("LOCALAPPDATA")));CHECK(wc(dest,cap,localDir));return (DWORD)wl(dest);}
DWORD GetCurrentProcessId(void){return self.pid;}
HANDLE GetCurrentProcess(void){return &self;}
HANDLE GetStdHandle(DWORD kind){CHECK(kind==(DWORD)-11);return (HANDLE)99;}
BOOL WriteFile(HANDLE h,const void *p,DWORD n,DWORD *written,void *o){(void)o;CHECK(h==(HANDLE)99);CHECK(logSize+n+1<sizeof(logs));memcpy(logs+logSize,p,n);logSize+=n;logs[logSize]=0;*written=n;return 1;}
BOOL CloseHandle(HANDLE h){CHECK(h);return 1;}
DWORD GetLastError(void){return lastError;}
HANDLE OpenProcess(DWORD rights,BOOL inherit,DWORD pid){CHECK(!inherit);Fake*p=lookup(pid);if(!p){lastError=87;return NULLPTR;}if((rights&MC_PROCESS_TERMINATE)&&!p->canForce){lastError=5;return NULLPTR;}return p;}
BOOL QueryFullProcessImageNameW(HANDLE h,DWORD flags,LPWSTR out,DWORD*n){(void)flags;Fake*p=h;if(p->imageFails)return 0;CHECK(wc(out,*n,p->path));*n=(DWORD)wl(out);return 1;}
BOOL GetProcessTimes(HANDLE h,FILETIME*c,FILETIME*e,FILETIME*k,FILETIME*u){(void)e;(void)k;(void)u;Fake*p=h;c->dwLowDateTime=(DWORD)p->created;c->dwHighDateTime=(DWORD)(p->created>>32);return 1;}
BOOL ProcessIdToSessionId(DWORD pid,DWORD*s){if(sessionFails)return 0;Fake*p=lookup(pid);if(!p)return 0;*s=p->session;return 1;}
BOOL OpenProcessToken(HANDLE p,DWORD rights,HANDLE*t){CHECK(rights==8);if(((Fake*)p)->ownerFails)return 0;*t=p;return 1;}
BOOL GetTokenInformation(HANDLE h,int kind,void*out,DWORD cap,DWORD*used){CHECK(kind==1&&cap>=16);*(void**)out=&((Fake*)h)->sid;*used=16;return 1;}
BOOL EqualSid(void*a,void*b){return *(int*)a==*(int*)b;}
static WCHAR lower(WCHAR c){return c>='A'&&c<='Z'?c+32:c;}
int CompareStringOrdinal(LPCWSTR a,int n,LPCWSTR b,int m,BOOL ignore){CHECK(n==-1&&m==-1);for(;*a&&*b;a++,b++)if((ignore?lower(*a):*a)!=(ignore?lower(*b):*b))return 1;return *a==*b?2:1;}
HANDLE CreateToolhelp32Snapshot(DWORD flags,DWORD pid){CHECK(flags==2&&pid==0);enumerations++;snapshotIndex=0;if(snapshotFails)return INVALID_HANDLE;return (HANDLE)88;}
static BOOL emit(PROCESSENTRY32W*p){if(snapshotIndex>=processCount){lastError=18;return 0;}Fake*f=&processes[snapshotIndex++];p->th32ProcessID=f->pid;p->th32ParentProcessID=f->parent;wc(p->szExeFile,260,f->name);return 1;}
BOOL Process32FirstW(HANDLE h,PROCESSENTRY32W*p){CHECK(h==(HANDLE)88&&p->dwSize==sizeof(*p));snapshotIndex=0;return emit(p);}
BOOL Process32NextW(HANDLE h,PROCESSENTRY32W*p){CHECK(h==(HANDLE)88);return emit(p);}
BOOL EnumWindows(BOOL(*fn)(HWND,LPARAM),LPARAM context){for(unsigned i=0;i<processCount;i++)if(processes[i].alive)CHECK(fn(&processes[i],context));return 1;}
DWORD GetWindowThreadProcessId(HWND w,DWORD*pid){*pid=((Fake*)w)->pid;return 1;}
int GetClassNameW(HWND w,LPWSTR out,int n){(void)w;CHECK(wc(out,n,W("AgentMissionControlTrayV2")));return (int)wl(out);}
BOOL PostMessageW(HWND w,UINT msg,WPARAM wp,LPARAM lp){CHECK(msg==WM_CLOSE&&wp==0&&lp==0);Fake*p=w;p->requests++;if(p->graceful)end(p);return 1;}
DWORD WaitForSingleObject(HANDLE h,DWORD ms){CHECK(ms==0);return ((Fake*)h)->alive?WAIT_TIMEOUT:WAIT_OBJECT_0;}
BOOL TerminateProcess(HANDLE h,UINT code){CHECK(code==0);Fake*p=h;CHECK(mcSamePath(p->path,mcExpectedExe));p->kills++;if(p->terminateFails)return 0;if(!p->terminationHangs)end(p);return 1;}
uint64_t GetTickCount64(void){return clockNow;}
void Sleep(DWORD ms){clockNow+=ms;}
LPWSTR GetCommandLineW(void){return command;}
// Test double for Windows API: sufficient quoting cases used below. The native
// build calls the real CommandLineToArgvW from shell32.dll, not this test parser.
LPWSTR *CommandLineToArgvW(LPCWSTR input,int*count){
    WCHAR*out=argStore;*count=0;const WCHAR*p=input;
    while(*p){while(*p==' '||*p=='\t')p++;if(!*p)break;argPointers[(*count)++]=out;BOOL quoted=0;
        while(*p&&(quoted||(*p!=' '&&*p!='\t'))){if(*p=='"'){quoted=!quoted;p++;}else *out++=*p++;}*out++=0;
    }return argPointers;
}
HANDLE LocalFree(HANDLE h){CHECK(h==argPointers);return NULLPTR;}
static BOOL legacyHasArg(const WCHAR*cmd,const WCHAR*arg){size_t n=wl(arg);for(const WCHAR*p=cmd;*p;p++){if(p!=cmd&&p[-1]!=' ')continue;size_t i=0;while(i<n&&p[i]==arg[i])i++;if(i==n&&(!p[i]||p[i]==' '))return 1;}return 0;}

int main(void){
    Fake *a,*b,*other;int code;
    reset();CHECK(mcReadStopMode());CHECK(mcRunStop()==0);CHECK(contains("ALREADY_STOPPED"));CHECK(starts==0);pass("stopped installation is an immediate no-op, not a new tray");
    reset();a=tray(1);b=hub();CHECK(mcRunStop()==0);CHECK(!a->alive&&!b->alive&&a->kills==0);CHECK(contains("VERIFIED_STOPPED"));pass("legacy 0.2 tray window accepts graceful close; job hub exits");
    reset();a=tray(0);b=hub();CHECK(mcRunStop()==0);CHECK(a->kills==1&&b->kills==0&&!b->alive);CHECK(clockNow==12000);pass("unresponsive verified tray fallback; no node termination");
    reset();a=tray(0);a->canForce=0;b=hub();CHECK(mcRunStop()==13);CHECK(a->alive&&b->alive&&a->kills==0);pass("denied termination fails closed without touching the hub");
    reset();a=tray(0);a->terminateFails=1;CHECK(mcRunStop()==14);CHECK(a->alive);pass("real TerminateProcess failure is reported");
    reset();a=tray(0);a->terminationHangs=1;CHECK(mcRunStop()==15);CHECK(clockNow==17000);pass("forced termination acknowledgement has a bounded wait");
    reset();a=tray(1);a->job=0;b=hub();CHECK(mcRunStop()==16);CHECK(b->alive&&b->kills==0);CHECK(clockNow==4000);pass("residual owned hub is reported, never killed by name");
    reset();a=tray(1);b=hub();other=add(W("C:\\Users\\petr\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"),200,9,0);CHECK(mcRunStop()==0);CHECK(other->alive&&other->kills==0&&other->requests==0);pass("open VS Code is untouched");
    reset();a=tray(1);other=add(W("C:\\Program Files\\nodejs\\node.exe"),201,100,0);a->job=0;CHECK(mcRunStop()==0);CHECK(other->alive&&other->kills==0);pass("unrelated node.exe not owned by application is untouched");
    reset();other=add(W("C:\\Other\\MissionControl.exe"),202,9,0);CHECK(mcRunStop()==0);CHECK(other->alive&&other->kills==0&&other->requests==0);pass("same basename in another directory is untouched");
    reset();a=tray(0);a->sid=77;CHECK(mcRunStop()==0);CHECK(a->alive&&a->kills==0);pass("different user SID is never stopped");
    reset();a=tray(0);a->session=7;CHECK(mcRunStop()==11);CHECK(a->alive&&a->kills==0&&a->requests==0);pass("same account in another Windows session blocks update safely");
    reset();snapshotFails=1;CHECK(mcRunStop()==10);pass("process enumeration failure is not success");
    reset();a=tray(0);a->imageFails=1;CHECK(mcRunStop()==11);CHECK(a->alive&&a->kills==0);pass("unverifiable image path fails closed");
    reset();a=tray(0);a->ownerFails=1;CHECK(mcRunStop()==11);CHECK(a->alive&&a->kills==0);pass("unverifiable owner fails closed");
    reset();a=tray(1);b=hub();b->created=a->created-1;a->job=0;CHECK(mcRunStop()==0);CHECK(b->alive&&b->kills==0);pass("older process with reused parent PID is not an owned hub");
    reset();sessionFails=1;CHECK(mcRunStop()==18);pass("missing session identity aborts before any shutdown");
    reset();wc(localDir,1800,W("relative\\path"));CHECK(mcRunStop()==17);CHECK(enumerations==0);pass("relative application root is rejected");
    reset();a=tray(1);wc(a->path,2048,W("c:\\USERS\\PETR\\AppData\\Local\\Programs\\AgentMissionControl\\MissionControl.exe"));CHECK(mcRunStop()==0);CHECK(!a->alive);pass("exact Windows path comparison tolerates case differences");
    reset();for(unsigned i=0;i<33;i++){a=tray(0);a->pid=100+i;}CHECK(mcRunStop()==12);for(unsigned i=0;i<33;i++)CHECK(processes[i].alive);pass("excessive target count aborts before shutdown");
    reset();wc(command,4096,W("\"C:\\Temp\\MC.exe\" \"--quit\""));CHECK(!legacyHasArg(command,W("--quit")));CHECK(mcReadTrayMode()==MC_MODE_QUIT);pass("regression: installer-quoted quit was lost by old parser");
    reset();wc(command,4096,W("MC.exe --quit"));CHECK(legacyHasArg(command,W("--quit")));CHECK(mcReadTrayMode()==MC_MODE_QUIT);pass("unquoted quit also selects control-only mode");
    reset();wc(command,4096,W("MC.exe \"--background\""));CHECK(mcReadTrayMode()==MC_MODE_BACKGROUND);pass("quoted background flag is recognized");
    reset();wc(command,4096,W("\"C:\\Temp\\--quit folder\\MC.exe\""));CHECK(mcReadTrayMode()==MC_MODE_OPEN);pass("argument-looking text inside executable path is not a flag");
    reset();wc(command,4096,W("MC.exe --quit-other"));CHECK(mcReadTrayMode()==MC_MODE_INVALID);pass("partial argument match cannot trigger shutdown");
    reset();wc(command,4096,W("MC.exe --quit --background"));CHECK(mcReadTrayMode()==MC_MODE_INVALID);pass("contradictory modes fail closed");
    reset();wc(command,4096,W("MC.exe\t\"--quit\"\t"));CHECK(mcReadTrayMode()==MC_MODE_QUIT);pass("tab-separated quit is decoded through the OS parser");
    reset();wc(command,4096,W("MC.exe"));CHECK(!mcReadStopMode());CHECK(mcReadTrayMode()==MC_MODE_OPEN);pass("controller without explicit stop mode cannot act");
    reset();wc(command,4096,W("MC.exe --stop --background"));CHECK(!mcReadStopMode());pass("controller has no start or combined mode");
    reset();wc(command,4096,W("MC.exe --quit --quit"));CHECK(mcReadTrayMode()==MC_MODE_QUIT);pass("idempotent repeated quit flag");
    reset();wc(command,4096,W("MC.exe \"--check\""));CHECK(mcReadControllerMode()==0);CHECK(enumerations==0);pass("quoted controller preflight is a side-effect-free check");
    (void)code;
    printf("%u native-source scenarios passed (Win32 API simulations).\n",tests);return 0;
}
