#!/usr/bin/env sh
# Run from anywhere. Requires a C11 compiler; uses Win32 API test doubles.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
BIN=$(mktemp)
trap 'rm -f "$BIN"' EXIT HUP INT TERM
"${CC:-cc}" -std=c11 -fshort-wchar -fno-builtin -ffunction-sections -fdata-sections \
  -Wl,--gc-sections -Wall -Wextra -Werror -Wno-unused-function \
  "$ROOT/tests/native/shutdown-test.c" -o "$BIN"
"$BIN"
