/* Production popup timing/navigation code, Win32 calls simulated on Linux. */
#define MC_NATIVE_TEST 1
#include "../../windows/native/util.h"
#include <stdio.h>
#include <stdlib.h>
static HWND window=(HWND)1;static BOOL notifyEnabled=1;static char instance[33]="11111111111111111111111111111111";
static unsigned opened,closed;static char openedId[33];static uint64_t clockNow;static POINT cursor;static RECT rectangle={0,0,400,200};
static HANDLE openSettings(DWORD access){(void)access;return NULLPTR;}
static DWORD request(const WCHAR*r,BOOL p,BOOL a,char*o,DWORD c){(void)r;(void)p;(void)a;(void)o;(void)c;return 0;}
#include "../../windows/native/notification.h"
static void openNotice(const char*id){opened++;memcpy(openedId,id,33);}
uint64_t GetTickCount64(void){return clockNow;}
BOOL KillTimer(HWND h,uintptr_t id){(void)h;(void)id;return 1;}
BOOL DestroyWindow(HWND h){(void)h;closed++;return 1;}
BOOL GetCursorPos(POINT*p){*p=cursor;return 1;}
BOOL GetWindowRect(HWND h,RECT*r){(void)h;*r=rectangle;return 1;}
LRESULT DefWindowProcW(HWND h,UINT m,WPARAM w,LPARAM l){(void)h;(void)m;(void)w;(void)l;return 0;}
LONG RegSetValueExW(HANDLE h,LPCWSTR a,DWORD b,DWORD c,const BYTE*d,DWORD e){(void)h;(void)a;(void)b;(void)c;(void)d;(void)e;return 0;}
LONG RegCloseKey(HANDLE h){(void)h;return 0;}
static unsigned count;
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static void pass(const char*s){count++;printf("PASS %s\n",s);}
static void ready(void){noticeWindow=(HWND)2;clockNow=1000;noticeUntil=61000;memcpy(noticeId,"abcdef0123456789abcdef0123456789",33);cursor.x=-1;cursor.y=-1;closed=opened=0;}
int main(void){
 CHECK(noticeSeconds==60);CHECK(pendingOpenNotice[0]==0);pass("Default project popup is 60 seconds");
 CHECK(validNoticeDuration(0)&&validNoticeDuration(30)&&validNoticeDuration(60)&&validNoticeDuration(120)&&validNoticeDuration(300)&&!validNoticeDuration(8)&&!validNoticeDuration(99999));pass("Only deliberate supported durations are accepted");
 CHECK(hexId("abcdef0123456789abcdef0123456789",32));CHECK(!hexId("../other",32));CHECK(!hexId("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz",32));pass("Opaque notice targets require exactly 32 hex characters");
 ready();clockNow=60999;noticeProc(noticeWindow,WM_TIMER,2,0);CHECK(!closed);pass("Popup does not close before chosen interval");
 ready();clockNow=61000;noticeProc(noticeWindow,WM_TIMER,2,0);CHECK(closed==1&&opened==0);pass("Expiry only dismisses; it never navigates or approves");
 ready();noticeUntil=0;clockNow=999999;noticeProc(noticeWindow,WM_TIMER,2,0);CHECK(!closed);pass("Until closed mode has no automatic timeout");
 ready();clockNow=61000;cursor.x=100;cursor.y=100;noticeProc(noticeWindow,WM_TIMER,2,0);CHECK(!closed&&noticeUntil==62000);pass("Hover prevents disappearance under pointer");
 ready();noticeProc(noticeWindow,WM_COMMAND,MC_POP_OPEN,0);CHECK(opened==1&&closed==1&&eq(openedId,"abcdef0123456789abcdef0123456789"));pass("Open button navigates to captured notice, not newest project");
 ready();noticeProc(noticeWindow,WM_COMMAND,MC_POP_BODY,0);CHECK(opened==1);pass("Click on body navigates to the same event");
 ready();noticeProc(noticeWindow,WM_COMMAND,MC_POP_CLOSE,0);CHECK(opened==0&&closed==1);pass("Close button never opens event or triggers action");
 ready();noticeProc(noticeWindow,0x0100,27,0);CHECK(opened==0&&closed==1);pass("Escape dismisses only");
 ready();chooseNoticeDuration(120);CHECK(noticeSeconds==120&&noticeUntil==121000);chooseNoticeDuration(0);CHECK(!noticeUntil);pass("Runtime duration choice updates timer without changing event identity");
 ready();noticeProc(noticeWindow,WM_COMMAND,2,0);CHECK(opened==0&&closed==1);pass("Dialog Escape command dismisses only");
 ready();noticeProc(noticeWindow,WM_COMMAND,1,0);CHECK(opened==1&&closed==1);pass("Dialog default command opens exact notice only");
 printf("%u notification scenarios passed (Win32 API doubles; not Windows execution).\n",count);return 0;
}
