import test from 'node:test';import assert from 'node:assert/strict';import {createRequire} from 'node:module';import {readFileSync} from 'node:fs';import vm from 'node:vm';
const require=createRequire(new URL('../bridge/src/extension.cjs',import.meta.url));
const version=JSON.parse(readFileSync(new URL('../package.json',import.meta.url))).version;
const token='b'.repeat(64),flush=()=>new Promise(r=>setImmediate(r));
let fixtureRun=0;
function harness({paired=false,identityGate=null,status='live',consent='Připojit',workspaceStore=new Map(),secretStore=new Map(),disconnectError=null}={}){
 const fixtureId=++fixtureRun;
 const commands=new Map(),instances=[],messages=[],effects={secretsStored:0,desktopReads:0,identityReads:0,dialogs:0,subprocesses:0,stops:0,disconnects:0,intervals:[]};
 if(paired)secretStore.set('hubToken',token);
 const disposable={dispose(){}};const config={hubUrl:'http://127.0.0.1:4317',gitStatus:false};
 const vscode={version:'test',env:{remoteName:null,uriScheme:'vscode'},extensions:{getExtension:()=>undefined},
   workspace:{isTrusted:true,workspaceFolders:[{name:'P',uri:{fsPath:'/repo',scheme:'file'}}],getConfiguration:()=>({get:(k,v)=>k in config?config[k]:v,update:async(k,v)=>{config[k]=v;}})},
   window:{createOutputChannel:()=>({appendLine(){},show(){},dispose(){}}),createStatusBarItem:()=>({show(){},dispose(){}}),registerUriHandler:()=>disposable,
     showInformationMessage:async m=>{messages.push(m);effects.dialogs++;return consent;},showWarningMessage:async(m,...args)=>{messages.push(m);return args.includes('Odpojit a odebrat')?'Odpojit a odebrat':undefined;},showErrorMessage:async m=>{messages.push(m);},
     showInputBox:async o=>{effects.dialogs++;return o.password?token:'http://127.0.0.1:4317';}},
   StatusBarAlignment:{Left:1},ConfigurationTarget:{Global:1,Workspace:2},commands:{registerCommand:(id,fn)=>{commands.set(id,fn);return disposable;},executeCommand:async()=>{}}};
 const context={subscriptions:[],extension:{extensionKind:2,packageJSON:{version}},secrets:{get:async k=>secretStore.get(k),store:async(k,v)=>{effects.secretsStored++;secretStore.set(k,v);},delete:async k=>{secretStore.delete(k);}},workspaceState:{get:(k,d)=>workspaceStore.has(k)?workspaceStore.get(k):d,update:async(k,v)=>{if(v===undefined)workspaceStore.delete(k);else workspaceStore.set(k,v);}}};
 class FakeProducer{
   constructor(opts){Object.assign(this,opts);this.epoch='test-epoch-'+fixtureId+'-'+instances.length;this.opts=opts;this.stopped=false;this.claimed=false;instances.push(this);}
   start(){queueMicrotask(()=>{if(this.stopped)return;if(status==='live'){this.claimed=true;this.opts.onStatus(true,'Připojeno');}else if(status==='duplicate'){this.conflict=Object.assign(new Error('Již připojeno'),{code:'CONNECTION_IN_USE'});this.stopped=true;this.opts.onStatus(false,this.conflict.message,this.conflict);}});return this;}
   async inspect(){return {owned:true};}
   markDirty(){}
   async stop(){effects.stops++;this.stopped=true;}
   async disconnect(){effects.disconnects++;this.stopped=true;if(disconnectError)throw disconnectError;return {removed:true,count:1};}
 }
 const deps={vscode,'./producer.cjs':{Producer:FakeProducer},'./identity.cjs':{workspaceIdentity:async()=>{effects.identityReads++;if(identityGate)await identityGate;return {hostId:'host',sourceId:'stable',folders:[{original:'/repo',canonical:'/repo'}]};}},
   './desktop.cjs':{readDesktop:async()=>{effects.desktopReads++;return {hub:config.hubUrl,token};},RelayTransport:class{}},
   'node:child_process':{execFile(){effects.subprocesses++;throw new Error('Should not spawn subprocess');}}};
 const box={module:{exports:{}},require:id=>deps[id]||require(id),process,setInterval:fn=>{effects.intervals.push(fn);return effects.intervals.length;},clearInterval(){},URLSearchParams};
 vm.runInNewContext(readFileSync(new URL('../bridge/src/extension.cjs',import.meta.url),'utf8'),box,{filename:'actual-bridge.cjs'});
 const activation=box.module.exports.activate(context);
 return {commands,instances,messages,effects,activation,workspaceStore,secretStore,setDisconnectError:e=>{disconnectError=e;},close:()=>box.module.exports.deactivate(),status:()=>commands.get('missionControl.getStatus')(),vscode};
}
test('Actual bridge under VS Code API mock: mixed rapid connect commands create one producer',async()=>{
 const h=harness();await h.activation;
 try{await Promise.all(Array.from({length:20},(_,n)=>h.commands.get(n%2?'missionControl.connect':'missionControl.connectDesktop')()));await flush();
 assert.equal(h.instances.length,1);assert.equal(h.effects.secretsStored,1);assert.equal(h.effects.desktopReads,1);assert.equal(h.effects.dialogs,2);assert((await h.status()).connected);
 }finally{await h.close();}
});
test('Actual bridge under VS Code API mock: already live connection is not reset or paired twice',async()=>{
 const h=harness({paired:true});await h.activation;await flush();
 try{const original=h.instances[0];await h.commands.get('missionControl.connect')();await h.commands.get('missionControl.connectDesktop')();assert.equal(h.instances.length,1);assert.equal(h.effects.stops,0);assert.equal(h.effects.secretsStored,0);assert.equal(h.effects.desktopReads,0);assert(!original.stopped);assert(h.messages.every(m=>m.includes('již připojena')));}
 finally{await h.close();}
});
test('Actual bridge under VS Code API mock: existing reconnect loop cannot be duplicated',async()=>{
 const h=harness({paired:true,status:'connecting'});await h.activation;
 try{await h.commands.get('missionControl.connectDesktop')();assert.equal(h.instances.length,1);assert.equal(h.effects.desktopReads,0);assert.equal(h.effects.secretsStored,0);assert((await h.status()).connecting);}
 finally{await h.close();}
});
test('Actual bridge under VS Code API mock: conflict does not touch winning agents; status explains it',async()=>{
 const h=harness({paired:true,status:'duplicate'});await h.activation;await flush();
 try{const s=await h.status();assert.equal(s.connected,false);assert.equal(s.connectionState,'duplicate');assert.equal(s.duplicate.code,'CONNECTION_IN_USE');assert.equal(h.effects.subprocesses,0);assert.equal(h.effects.secretsStored,0);}
 finally{await h.close();}
});
test('Actual bridge under VS Code API mock: cancelled consent allows another attempt without creating an instance',async()=>{
 const h=harness({consent:undefined}); // supply actual cancellation explicitly
 await h.activation;h.vscode.window.showInformationMessage=async()=>undefined;
 try{await h.commands.get('missionControl.connectDesktop')();await h.commands.get('missionControl.connectDesktop')();assert.equal(h.instances.length,0);assert.equal(h.effects.secretsStored,0);assert.equal(h.effects.desktopReads,2);}
 finally{await h.close();}
});
test('Actual bridge under VS Code API mock: disconnect while start awaits identity cancels stale start',async()=>{
 let resolve;const h=harness({paired:true,identityGate:new Promise(r=>{resolve=r;})});await flush();
 await h.commands.get('missionControl.disconnect')();resolve();await h.activation;
 try{assert.equal(h.instances.length,0);assert.equal((await h.status()).connected,false);assert.equal((await h.status()).paired,false);}
 finally{await h.close();}
});
test('Actual bridge under VS Code API mock: deactivate while start awaits identity creates no producer',async()=>{
 let resolve;const h=harness({paired:true,identityGate:new Promise(r=>{resolve=r;})});await flush();await h.close();resolve();await h.activation;assert.equal(h.instances.length,0);
});

test('Actual bridge under VS Code API mock: conflict fences delayed Zoo API activation',async()=>{
 let resolve,bindings=0,activations=0;const activation=new Promise(r=>{resolve=r;});const h=harness({paired:true});
 h.vscode.extensions.getExtension=()=>({packageJSON:{version:'test'},activate:()=>{activations++;return activation;}});
 await h.activation;await flush();assert.equal(activations,1);
 const candidate=h.instances[0];candidate.conflict=Object.assign(new Error('Already reported by another source'),{code:'SESSION_IN_USE'});candidate.stopped=true;candidate.opts.onStatus(false,candidate.conflict.message,candidate.conflict);
 resolve({on(){bindings++;},getCurrentTaskStack:()=>[]});await flush();
 try{assert.equal(bindings,0);assert.equal((await h.status()).connectionState,'duplicate');}
 finally{await h.close();}
});

// Production extension code is executed in a VS Code API replacement here.
test('Bridge disconnect: confirmed removal stops only monitoring, retains shared token, and persists pause',async()=>{
 const h=harness({paired:true});await h.activation;await flush();
 try{const p=h.instances[0];await h.commands.get('missionControl.disconnect')();
 assert(p.stopped);assert.equal(h.effects.disconnects,1);assert.equal(h.secretStore.get('hubToken'),token);
 assert.equal(h.effects.subprocesses,0);const s=await h.status();assert(!s.connected);assert(s.paused);assert(!s.paired);assert(!s.pendingRemoval);
 assert(h.messages.some(m=>m.includes('odebráno z dashboardu')));
 }finally{await h.close();}
});
test('Bridge disconnect: cancellation leaves the producer and saved state unchanged',async()=>{
 const h=harness({paired:true});await h.activation;await flush();h.vscode.window.showWarningMessage=async()=>undefined;
 try{await h.commands.get('missionControl.disconnect')();assert((await h.status()).connected);assert(!h.instances[0].stopped);assert.equal(h.effects.disconnects,0);assert(!h.workspaceStore.has('missionControl.disconnectIntent.v1'));}
 finally{await h.close();}
});
test('Bridge disconnect: repeat clicks share one removal and never start another collector',async()=>{
 const h=harness({paired:true});await h.activation;await flush();
 try{await Promise.all(Array.from({length:20},()=>h.commands.get('missionControl.disconnect')()));assert.equal(h.effects.disconnects,1);assert.equal(h.instances.filter(x=>x.claimed).length,1);await h.commands.get('missionControl.disconnect')();assert.equal(h.effects.disconnects,1);}
 finally{await h.close();}
});
test('Bridge disconnect: removal from dashboard stops listeners and survives extension restart',async()=>{
 const storage=new Map(),secrets=new Map();const h=harness({paired:true,workspaceStore:storage,secretStore:secrets});await h.activation;await flush();
 const p=h.instances[0];p.removed=Object.assign(new Error('Removed in dashboard'),{code:'CONNECTION_REMOVED'});p.stopped=true;p.opts.onStatus(false,p.removed.message,p.removed);await flush();
 assert((await h.status()).paused);await h.close();
 const next=harness({workspaceStore:storage,secretStore:secrets});await next.activation;
 try{assert.equal(next.instances.length,0);assert((await next.status()).paused);await next.commands.get('missionControl.connect')();await flush();assert.equal(next.instances.length,1);assert.equal(next.instances[0].opts.resume,true);assert((await next.status()).connected);assert(!(await next.status()).paused);}
 finally{await next.close();}
});
test('Bridge disconnect: offline removal remains pending, then finishes after restart without collecting',async()=>{
 const storage=new Map(),secrets=new Map();const h=harness({paired:true,workspaceStore:storage,secretStore:secrets,disconnectError:new Error('Hub offline')});await h.activation;await flush();
 await h.commands.get('missionControl.disconnect')();assert((await h.status()).pendingRemoval);assert([...secrets].some(([k,v])=>k.startsWith('disconnectToken:')&&v===token));await h.close();
 const next=harness({workspaceStore:storage,secretStore:secrets});await next.activation;await flush();await flush();
 try{assert((await next.status()).paused);assert(!(await next.status()).pendingRemoval);assert.equal(next.effects.disconnects,1);assert(next.instances.every(x=>!x.claimed));assert.equal(secrets.get('hubToken'),token);assert(![...secrets.keys()].some(k=>k.startsWith('disconnectToken:')));}
 finally{await next.close();}
});
test('Bridge disconnect: stale pending removal does not claim or remove a replacement connection',async()=>{
 const storage=new Map(),secrets=new Map();const h=harness({paired:true,workspaceStore:storage,secretStore:secrets,disconnectError:Object.assign(new Error('Replacement'),{code:'NOT_OWNER'})});await h.activation;await flush();
 try{await h.commands.get('missionControl.disconnect')();assert(!(await h.status()).pendingRemoval);assert((await h.status()).paused);assert(h.messages.some(m=>m.includes('Nové připojení')));assert.equal(h.effects.subprocesses,0);}
 finally{await h.close();}
});
test('Bridge disconnect: a remote removal fences delayed Zoo API activation',async()=>{
 let resolve,bindings=0;const gate=new Promise(r=>{resolve=r;});const h=harness({paired:true});h.vscode.extensions.getExtension=()=>({packageJSON:{version:'test'},activate:()=>gate});await h.activation;await flush();
 const p=h.instances[0];p.removed=Object.assign(new Error('removed'),{code:'CONNECTION_REMOVED'});p.stopped=true;p.opts.onStatus(false,p.removed.message,p.removed);resolve({on(){bindings++;},getCurrentTaskStack:()=>[]});await flush();
 try{assert.equal(bindings,0);assert((await h.status()).paused);}finally{await h.close();}
});

test('Bridge disconnect: completing one workspace removal retains other pending credentials',async()=>{
 const secrets=new Map(),a=harness({paired:true,secretStore:secrets,disconnectError:new Error('Offline')}),b=harness({paired:true,secretStore:secrets,disconnectError:new Error('Offline')});await a.activation;await b.activation;await flush();
 try{await a.commands.get('missionControl.disconnect')();await b.commands.get('missionControl.disconnect')();assert.equal([...secrets.keys()].filter(k=>k.startsWith('disconnectToken:')).length,2);a.setDisconnectError(null);await a.commands.get('missionControl.disconnect')();assert.equal([...secrets.keys()].filter(k=>k.startsWith('disconnectToken:')).length,1);assert((await b.status()).pendingRemoval);assert.equal(secrets.get('hubToken'),token);}
 finally{await a.close();await b.close();}
});
