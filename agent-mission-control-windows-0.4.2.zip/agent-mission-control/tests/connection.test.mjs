import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import path from 'node:path';
import vm from 'node:vm';
const require=createRequire(import.meta.url);
const {createController,versionAtLeast,sameHost}=require('../connector/src/controller.cjs');
const {monitoringBlockReason}=require('../bridge/src/readiness.cjs');
const {manageSuite,manage}=require('../windows/vscode-cli.cjs');
const version=JSON.parse(readFileSync(new URL('../package.json',import.meta.url))).version;
const folder=(scheme='file')=>({name:'repo',uri:{scheme,fsPath:'/tmp/repo'}});
const ready=(remoteName=null)=>({protocol:1,version,runtimeBuild:version+'-recovery.1',remoteName,extensionKind:2,blockedReason:'',paired:false,connected:false,message:'Not paired'});
function mock({remoteName='wsl',trusted=true,folders=[folder()],status=ready(remoteName),missing=false,answer='Nainstalovat',installError='',becomesReady=true,corrupt=false}={}){
  const calls=[],messages=[],logs=[];let current=status,available=!missing;
  const bytes=Buffer.from('test package');
  const vscode={env:{remoteName},workspace:{isTrusted:trusted,workspaceFolders:folders},Uri:{joinPath:(_base,...p)=>({fsPath:'/test/'+p.join('/'),scheme:'file'})},
    commands:{getCommands:async()=>available?['missionControl.getStatus']:[],executeCommand:async(c,...args)=>{calls.push({c,args});if(c==='missionControl.getStatus')return current;
      if(c==='workbench.extensions.installExtension'){if(installError)throw new Error(installError);if(becomesReady){available=true;current=ready(remoteName);}}
    }},window:{showInformationMessage:async(...args)=>{messages.push({type:'info',args});return answer;},showWarningMessage:async(...args)=>{messages.push({type:'warning',args});},showErrorMessage:async(...args)=>{messages.push({type:'error',args});}}};
  const context={extension:{packageJSON:{version}},extensionUri:{fsPath:'/test'}};
  const c=createController(vscode,context,{log:s=>logs.push(s),wait:async()=>{},readFile:async file=>file.endsWith('.json')?JSON.stringify({id:'local-mission-control.bridge',version,sha256:corrupt?'0'.repeat(64):createHash('sha256').update(bytes).digest('hex')}):bytes});
  return {c,vscode,calls,messages,logs};
}
test('Connection: UI companion is UI-only; bridge remains workspace-only',()=>{
 const c=JSON.parse(readFileSync(new URL('../connector/package.json',import.meta.url))),b=JSON.parse(readFileSync(new URL('../bridge/package.json',import.meta.url)));
 assert.deepEqual(c.extensionKind,['ui']);assert.deepEqual(b.extensionKind,['workspace']);assert(!c.extensionDependencies);assert(c.contributes.commands.some(c=>c.command==='missionControl.setup'));assert.equal(b.capabilities.untrustedWorkspaces.supported,'limited');
});
test('Connection: version ordering prevents stale activation and downgrade',()=>{assert(versionAtLeast('0.4.2','0.4.2'));assert(versionAtLeast('0.4.20','0.4.2'));assert(!versionAtLeast('0.3.4','0.4.2'));assert(!versionAtLeast('garbage','0.4.2'));});
test('Connection: local bridge cannot masquerade as remote',()=>{assert(!sameHost(ready(null),'wsl'));assert(!sameHost({...ready('wsl'),extensionKind:1},'wsl'));assert(sameHost(ready('wsl'),'wsl'));assert(!sameHost({...ready('wsl'),protocol:2},'wsl'));});
test('Connection: missing command gives a diagnostic rather than throwing',async()=>{const m=mock({missing:true});const p=await m.c.probe();assert(!p.ready);assert.match(p.reason,/Bridge/);});
test('Connection: activation error is reported',async()=>{const m=mock();m.vscode.commands.executeCommand=async()=>{throw new Error('Module load failed');};assert.match((await m.c.probe()).reason,/Module load failed/);});
test('Connection: diagnostics probe never installs or pairs',async()=>{const m=mock({missing:true});await m.c.probe();assert.equal(m.calls.length,0);assert.equal(m.messages.length,0);});
test('Connection: Restricted Mode cannot install or connect through Setup',async()=>{const m=mock({trusted:false,missing:true});await m.c.setup();assert.equal(m.calls.length,0);assert.match(m.messages[0].args[0],/Restricted Mode/);});
test('Connection: empty window does not pair',async()=>{const m=mock({folders:[]});await m.c.setup();assert.equal(m.calls.length,0);assert.match(m.messages[0].args[0],/složku projektu/);});
test('Connection: WSL active bridge dispatches existing desktop command',async()=>{const m=mock();await m.c.setup();assert(m.calls.some(c=>c.c==='missionControl.connectDesktop'));assert(!m.calls.some(c=>c.c==='workbench.extensions.installExtension'));});
test('Connection: SSH active bridge dispatches manual tunnel pairing',async()=>{const m=mock({remoteName:'ssh-remote'});await m.c.setup();assert(m.calls.some(c=>c.c==='missionControl.connect'));assert(!m.calls.some(c=>c.c==='missionControl.connectDesktop'));});
test('Connection: installation consent is required',async()=>{const m=mock({missing:true,answer:undefined}); // default argument would choose install; explicitly cancel callback
 m.vscode.window.showInformationMessage=async()=>undefined;await m.c.setup();assert(!m.calls.some(c=>c.c==='workbench.extensions.installExtension'));});
test('Connection: missing bridge is installed from hash-checked URI then probed',async()=>{const m=mock({missing:true});await m.c.setup();const call=m.calls.find(c=>c.c==='workbench.extensions.installExtension');assert(call);assert.equal(call.args[0].fsPath,'/test/resources/bridge.vsix');assert.equal(typeof call.args[0],'object');assert(m.calls.some(c=>c.c==='missionControl.connectDesktop'));assert(m.logs.some(s=>s.includes('MC_BRIDGE_ACTIVE')));});
test('Connection: corrupted embedded VSIX is never handed to VS Code',async()=>{const m=mock({missing:true,corrupt:true});await m.c.setup();assert(!m.calls.some(c=>c.c==='workbench.extensions.installExtension'));assert(m.messages.some(m=>m.type==='error'&&m.args[0].includes('integrity')));});
test('Connection: install error never claims a connection',async()=>{const m=mock({missing:true,installError:'Disk full'});await m.c.setup();assert(!m.calls.some(c=>c.c==='missionControl.connectDesktop'));assert(m.messages.some(m=>m.type==='error'&&m.args[0].includes('Disk full')));});
test('Connection: installed-on-disk but inactive bridge does NOT connect or reload',async()=>{const m=mock({missing:true,becomesReady:false});await m.c.setup();assert(!m.calls.some(c=>/reloadWindow|connectDesktop/.test(c.c)));assert(m.messages.some(m=>m.type==='warning'&&m.args[0].includes('ještě neodpovídá')));});
test('Connection: still-loaded old bridge triggers update, not premature pairing',async()=>{const m=mock({status:{...ready('wsl'),version:'0.2.0'},becomesReady:false});await m.c.setup();assert(m.calls.some(c=>c.c==='workbench.extensions.installExtension'));assert(!m.calls.some(c=>c.c==='missionControl.connectDesktop'));});
test('Connection: wrong-host bridge is not used even after a claimed install',async()=>{const m=mock({status:ready(null),becomesReady:false});await m.c.setup();assert(!m.calls.some(c=>c.c==='missionControl.connectDesktop'));});
test('Connection: blocked workspace never reaches a pairing command',async()=>{const m=mock({status:{...ready('wsl'),blockedReason:'virtual workspace'}});await m.c.setup();assert(!m.calls.some(c=>c.c==='missionControl.connectDesktop'));assert(m.messages.some(m=>m.args[0].includes('virtual')));});
test('Connection: repair never downgrades a newer bridge',async()=>{const m=mock({status:{...ready('wsl'),version:'0.5.0'}});await m.c.repair();assert(!m.calls.some(c=>c.c==='workbench.extensions.installExtension'));assert(m.messages.some(m=>m.args[0].includes('downgrade')));});
test('Connection: successful pairing dispatch is not falsely reported as live',async()=>{const m=mock();const p=await m.c.setup();assert.equal(p.status.connected,false);assert(!m.messages.some(m=>/úspěšně připojen/i.test(m.args[0])));});
for(const [name,args,expected] of [
 ['restricted',{trusted:false,folders:[folder()]},/Restricted/],['empty',{trusted:true,folders:[]},/složku/],
 ['virtual',{trusted:true,folders:[folder('github')]},/Virtuální/],['wrong host',{trusted:true,folders:[folder('vscode-remote')],remoteName:'wsl',extensionKind:1},/vzdáleného/],
 ['remote ready',{trusted:true,folders:[folder('vscode-remote')],remoteName:'wsl',extensionKind:2},/^$/],
 ['local ready',{trusted:true,folders:[folder()]},/^$/]]){
 test('Bridge guard: '+name,()=>assert.match(monitoringBlockReason(args),expected));
}
// Run actual bridge activation code with an injected VS Code API. This is NOT
// a real Extension Host test; it proves registration and no-I/O guard paths.
async function activateBridge({trusted=false,folders=[folder()],remoteName=null,kind=2}={}){
 const commands=new Map(),effects={secretReads:0,execs:0,desktop:0,producer:0,observers:0,warnings:[]};
 const disposable={dispose(){}};const status={show(){},dispose(){}};
 const vscode={version:'test',env:{remoteName,uriScheme:'vscode'},workspace:{isTrusted:trusted,workspaceFolders:folders,getConfiguration:()=>({get:(_k,v)=>v,update:async()=>{}})},
 window:{createOutputChannel:()=>({appendLine(){},show(){},dispose(){}}),createStatusBarItem:()=>status,registerUriHandler:()=>disposable,showWarningMessage:async m=>effects.warnings.push(m)},
 StatusBarAlignment:{Left:1},ConfigurationTarget:{Global:1,Workspace:2},commands:{registerCommand:(id,fn)=>{commands.set(id,fn);return disposable;}}};
 const context={subscriptions:[],extension:{extensionKind:kind,packageJSON:{version}},secrets:{get:async()=>{effects.secretReads++;return undefined;},delete:async()=>{}},workspaceState:{get(){}}};
 const deps={vscode,'node:child_process':{execFile(){effects.execs++;throw new Error('Unexpected subprocess');}},'./producer.cjs':{Producer:class{constructor(){effects.producer++;}}},'./desktop.cjs':{readDesktop:async()=>{effects.desktop++;throw new Error('Unexpected Windows discovery');},RelayTransport:class{}},'./codex-observer.cjs':{CodexObserver:class{constructor(){effects.observers++;}}}};
 const requireBridge=createRequire(new URL('../bridge/src/extension.cjs',import.meta.url));
 const box={module:{exports:{}},exports:{},require:id=>deps[id]||requireBridge(id),process,setInterval,clearInterval,URLSearchParams};
 vm.runInNewContext(readFileSync(new URL('../bridge/src/extension.cjs',import.meta.url),'utf8'),box,{filename:'actual-bridge-extension.cjs'});
 await box.module.exports.activate(context);return {commands,effects,context,api:box.module.exports};
}
test('Actual bridge activation under API mock: all contributed commands register in Restricted Mode',async()=>{
 const b=await activateBridge();const meta=JSON.parse(readFileSync(new URL('../bridge/package.json',import.meta.url)));
 for(const c of meta.contributes.commands)assert(b.commands.has(c.command),c.command);
 const s=await b.commands.get('missionControl.getStatus')();assert(s.blockedReason.includes('Restricted'));assert.equal(b.effects.secretReads,0);
 for(const cmd of ['missionControl.connectDesktop','missionControl.connect','missionControl.enableCodexObservation'])await b.commands.get(cmd)();
 assert.deepEqual([b.effects.execs,b.effects.desktop,b.effects.producer,b.effects.observers],[0,0,0,0]);b.api.deactivate();
});
test('Actual bridge activation under API mock: empty window exposes commands without collection',async()=>{
 const b=await activateBridge({trusted:true,folders:[]});assert(b.commands.has('missionControl.connectDesktop'));await b.commands.get('missionControl.connectDesktop')();assert.equal(b.effects.desktop,0);assert.equal(b.effects.secretReads,0);b.api.deactivate();
});
test('Actual bridge activation under API mock: remote UI override cannot collect local data',async()=>{
 const b=await activateBridge({trusted:true,remoteName:'wsl',kind:1});const s=await b.commands.get('missionControl.getStatus')();assert.match(s.blockedReason,/vzdáleného/);assert.equal(b.effects.secretReads,0);b.api.deactivate();
});
function fakeSuite({fail='',omit=''}={}){
 const installed=new Map(),calls=[];
 const run=async(file,args)=>{calls.push(args);let stdout='',stderr='';let exitCode=0;
  if(args.includes('--install-extension')){
   const vsix=args[args.indexOf('--install-extension')+1];const id=vsix.includes('connection')?'local-mission-control.connector':'local-mission-control.bridge';
   if(id===fail){exitCode=8;stderr='Install failed';}else if(id!==omit)installed.set(id,version);
  }else if(args.includes('--uninstall-extension'))installed.delete(args[args.indexOf('--uninstall-extension')+1]);
  else if(args.includes('--list-extensions'))stdout=[...installed].map(([id,v])=>id+'@'+v).join('\n');
  return {exitCode,stdout,stderr,spawnError:'',timedOut:false,overflow:false};
 };
 const config={executable:'code.exe',cli:'cli.js',vsix:'/safe/bridge.vsix',connectorVsix:'/safe/connection.vsix',version,profile:'Vývoj a WSL'};
 return {installed,calls,run,config};
}
test('Installer suite: installs and verifies both packages in exactly the selected profile',async()=>{const m=fakeSuite();const r=await manageSuite(m.config,m.run);assert(r.ok);assert.equal(r.reports.length,2);assert.equal(r.activationVerified,false);assert.equal(m.installed.size,2);for(const call of m.calls)assert.deepEqual(call.slice(1,3),['--profile','Vývoj a WSL']);});
test('Installer suite: missing UI companion means partial install, never full success',async()=>{const m=fakeSuite({omit:'local-mission-control.connector'});const r=await manageSuite(m.config,m.run);assert(!r.ok);assert(!r.reports[0].ok);assert(r.reports[1].ok);});
test('Installer suite: failed bridge does not prevent local diagnostics companion installation',async()=>{const m=fakeSuite({fail:'local-mission-control.bridge'});const r=await manageSuite(m.config,m.run);assert(!r.ok);assert(m.installed.has('local-mission-control.connector'));});
test('Installer suite: repair is idempotent',async()=>{const m=fakeSuite();assert((await manageSuite(m.config,m.run)).ok);assert((await manageSuite(m.config,m.run)).ok);assert.equal(m.installed.size,2);});
test('Installer suite: uninstall removes only our two IDs',async()=>{const m=fakeSuite();await manageSuite(m.config,m.run);m.installed.set('ZooCodeOrganization.zoo-code','1');m.installed.set('openai.chatgpt','1');const r=await manageSuite({...m.config,action:'uninstall'},m.run);assert(r.ok);assert.deepEqual([...m.installed.keys()],['ZooCodeOrganization.zoo-code','openai.chatgpt']);});
test('Installer suite: refuses unrelated extension IDs',async()=>{await assert.rejects(manage({action:'uninstall',extensionId:'openai.chatgpt'}),/Unsupported extension ID/);});
test('Actual connector activation under API mock: visible setup, diagnostics and tree without bridge',async()=>{
 const registered=new Map(),status={},trees=[];const disposable={dispose(){}};
 class Emitter{event=()=>disposable;fire(){}dispose(){}}
 class Item{constructor(label){this.label=label;}}
 const api={EventEmitter:Emitter,TreeItem:Item,TreeItemCollapsibleState:{None:0},StatusBarAlignment:{Left:1},version:'test',env:{remoteName:'ssh-remote'},workspace:{isTrusted:false,workspaceFolders:[folder('vscode-remote')]},
   window:{createOutputChannel:()=>({appendLine(){},show(){},dispose(){}}),createStatusBarItem:()=>Object.assign(status,{show(){},dispose(){}}),registerTreeDataProvider:(id,p)=>{trees.push({id,p});return disposable;}},
   extensions:{onDidChange:()=>disposable},commands:{registerCommand:(id,fn)=>{registered.set(id,fn);return disposable;},getCommands:async()=>[]}};
 const context={subscriptions:[],extension:{packageJSON:{version}},extensionUri:{fsPath:'/mock'}};
 const req=createRequire(new URL('../connector/src/extension.cjs',import.meta.url));const box={require:id=>id==='vscode'?api:req(id),module:{exports:{}},setInterval:()=>99,clearInterval(){}};
 vm.runInNewContext(readFileSync(new URL('../connector/src/extension.cjs',import.meta.url),'utf8'),box);box.module.exports.activate(context);
 await new Promise(r=>setImmediate(r));assert.equal(status.command,'missionControl.setup');assert(registered.has('missionControl.setup'));assert(registered.has('missionControl.connectionDiagnostics'));assert.equal(trees[0].id,'missionControl.connection');assert.equal(trees[0].p.getChildren()[0].command.command,'missionControl.setup');
 for(const d of context.subscriptions)d.dispose();
});

for(const field of ['connected','connecting']){
 test('Connection: '+field+' cache delegates ownership verification to bridge',async()=>{const m=mock({status:{...ready('wsl'),[field]:true}});const result=await m.c.setup();assert(result.status[field]);assert.equal(m.calls.filter(c=>c.c==='missionControl.connectDesktop').length,1);assert(!m.calls.some(c=>c.c==='workbench.extensions.installExtension'));});
}
test('Connection duplicate guard: rapid setup clicks send a single command',async()=>{
 const m=mock();await Promise.all(Array.from({length:20},()=>m.c.setup()));assert.equal(m.calls.filter(c=>c.c==='missionControl.connectDesktop').length,1);
});

test('Connection panel: disconnect uses current bridge, never install/pair/agent commands',async()=>{const m=mock({status:{...ready('wsl'),connected:true}});await m.c.disconnect();assert.equal(m.calls.filter(x=>x.c==='missionControl.disconnect').length,1);assert(!m.calls.some(x=>x.c.includes('installExtension')||x.c==='missionControl.connectDesktop'));});
test('Connection panel: absent bridge directs user to dashboard, does not install',async()=>{const m=mock({missing:true});await m.c.disconnect();assert(!m.calls.some(x=>x.c==='missionControl.disconnect'||x.c==='workbench.extensions.installExtension'));assert(m.messages.some(x=>x.args[0].includes('dashboardu')));});
test('Connection panel: disconnect command is contributed and activated',()=>{const m=JSON.parse(readFileSync(new URL('../connector/package.json',import.meta.url)));assert(m.contributes.commands.some(c=>c.command==='missionControl.disconnectHere'));assert(m.activationEvents.includes('onCommand:missionControl.disconnectHere'));});

test('Connection: new manifest without runtime build cannot masquerade as loaded recovery code',async()=>{
 const m=mock({status:{...ready('wsl'),runtimeBuild:undefined},becomesReady:false});
 const p=await m.c.probe();assert(!p.ready);assert.match(p.reason,/běžící kód/);
 await m.c.setup();assert(!m.calls.some(c=>c.c==='missionControl.connectDesktop'));
});
