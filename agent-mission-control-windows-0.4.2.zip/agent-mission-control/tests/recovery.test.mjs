import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,rm} from 'node:fs/promises';
import {readFileSync} from 'node:fs';
import os from 'node:os';import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {createHub} from '../src/server.mjs';
import {bridgeHarness,until,pause,TOKEN,native,browser} from './helpers/live-bridge.mjs';
import flights from '../bridge/src/single-flight.cjs';
import producers from '../bridge/src/producer.cjs';
const {recoveryFlight}=flights;
const envelope=(id='recovery-source',epoch=randomUUID())=>({version:1,sourceId:id,epoch,label:'Recovery fixture'});
const request=e=>({...e,recoveryProtocol:1,userInitiated:true,requestId:randomUUID()});
const gate=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return {promise,resolve,reject};};
async function fixture(fn,{persist=false,relay=false}={}){
 const folder=await mkdtemp(path.join(os.tmpdir(),'mc-recovery-'));
 const hub=await createHub({port:0,persist,dataDir:path.join(folder,'data'),token:TOKEN});
 const h=bridgeHarness({hub,folder,remoteName:relay?'wsl':null,relay});
 try{await h.activation;await until(()=>hub.store.sessions.size===1);await fn({hub,h,ui:await browser(hub),folder});}
 finally{await h.close();await hub.close();await rm(folder,{recursive:true,force:true});}
}
async function withHub(fn){const h=await createHub({port:0,persist:false,token:TOKEN});try{await fn(h);}finally{await h.close();}}

test('Recovery scheduler: explicit resume cannot disappear behind automatic start',async()=>{
 const g=gate(),seen=[];let active=0,maxActive=0;
 const start=recoveryFlight(async({resume=false}={})=>{maxActive=Math.max(maxActive,++active);seen.push(resume);if(!resume)await g.promise;active--;return resume;});
 const auto=start();await pause(1);const explicit=start({resume:true});assert.notEqual(auto,explicit);g.resolve();
 assert.equal(await auto,false);assert.equal(await explicit,true);assert.deepEqual(seen,[false,true]);assert.equal(maxActive,1);assert(!start.busy);
});
test('Recovery scheduler: twenty explicit clicks queue only one recovery behind automatic work',async()=>{
 const g=gate(),calls=[];const start=recoveryFlight(async({resume=false}={})=>{calls.push(resume);if(!resume)await g.promise;return resume;});
 const auto=start();const commands=Array.from({length:20},()=>start({resume:true}));assert(commands.every(p=>p===commands[0]));g.resolve();await auto;assert((await Promise.all(commands)).every(Boolean));assert.deepEqual(calls,[false,true]);
});
test('Recovery scheduler: failing automatic start does not swallow explicit recovery',async()=>{
 const g=gate();const start=recoveryFlight(async({resume=false}={})=>{if(!resume){await g.promise;throw new Error('synthetic startup failure');}return 'connected';});
 const auto=start();const wait=assert.rejects(auto,/synthetic/);const explicit=start({resume:true});g.resolve();await wait;assert.equal(await explicit,'connected');
});
test('Recovery scheduler: background events cannot overlap an active recovery',async()=>{
 const g=gate();let count=0;const start=recoveryFlight(async()=>{count++;await g.promise;return 'connected';});
 const explicit=start({resume:true});const auto=start();assert.equal(auto,explicit);g.resolve();await start.wait();assert.equal(count,1);
});
for(const relay of [false,true])test(`Recovery regression: workspace event at token lookup, ${relay?'stdio relay':'HTTP'}`,()=>fixture(async({hub,h,ui})=>{
 const old=await h.freeze();await ui('/api/disconnect',{sourceId:old.sourceId,epoch:old.epoch});await old.tick();await until(async()=>(await h.status()).paused);
 const get=h.secrets.get.bind(h.secrets);let fired=false;
 h.secrets.get=key=>{if(key==='hubToken'&&!fired){fired=true;h.fireWorkspaceFolders();}return get(key);};
 await h.command('missionControl.reconnect');await until(()=>hub.store.sessions.size===1);
 const s=await h.status();assert(fired);assert(s.connected);assert(!s.paused);assert.equal(h.instances.filter(p=>p.started&&!p.stopped).length,1);assert.equal(h.instances.length,2);
 assert.equal(s.lastRecovery.code,'MC_RECOVERY_OK');assert.equal(s.hubVersion,'0.4.2');assert.equal(s.runtimeBuild,'0.4.2-codex-hooks.1');
 assert(h.logs.some(l=>l.includes('"endpoint":"/api/reconnect"')));assert(!h.logs.join('\n').includes(TOKEN));assert.equal(h.effects.zooStops,0);
},{relay}));
test('Recovery runtime identity: changing disk manifest does not change executing build',()=>{
 const text=readFileSync(new URL('../bridge/src/extension.cjs',import.meta.url),'utf8');
 assert(text.includes("version:RUNTIME_VERSION,runtimeBuild:RUNTIME_BUILD,manifestVersion:context.extension.packageJSON.version"));
});
test('Recovery report: contains outcome and loaded build but no token or chat contents',()=>fixture(async({hub,h,ui})=>{
 const old=await h.freeze();await ui('/api/disconnect',{sourceId:old.sourceId,epoch:old.epoch});await h.command('missionControl.reconnect');
 const report=await h.command('missionControl.copyConnectionReport');assert.equal(report.runtimeBuild,'0.4.2-codex-hooks.1');assert.equal(report.lastRecovery.code,'MC_RECOVERY_OK');
 assert(!JSON.stringify(report).includes(TOKEN));assert(!('messages' in report));assert(!('sessions' in report));
}));
test('Recovery HTTP: only a native bearer request with explicit protocol is accepted',()=>withHub(async h=>{
 const e=request(envelope());const ui=await browser(h);
 assert.equal((await ui('/api/reconnect',e)).status,401);
 for(const body of [{...e,userInitiated:false},{...e,recoveryProtocol:0},{...e,requestId:''}]){
  const r=await native(h,'/api/reconnect',body);assert.equal(r.status,400);assert.equal(r.body.code,'INVALID_RECOVERY_REQUEST');
 }
 assert.equal(h.store.sources.size,0);
}));
test('Recovery HTTP: exact source, epoch and request acknowledged; old epoch still rejected',()=>withHub(async h=>{
 const old=envelope();await native(h,'/api/claim',old);await native(h,'/api/disconnect-source',old);
 const e=request(envelope(old.sourceId));const r=await native(h,'/api/reconnect',e);assert.equal(r.status,200);assert.equal(r.body.epoch,e.epoch);assert.equal(r.body.sourceId,e.sourceId);assert.equal(r.body.requestId,e.requestId);assert.equal(r.body.recoveryProtocol,1);
 assert.equal(h.store.detachedSources.size,0);
 const stale=await native(h,'/api/reconnect',request(old));assert.equal(stale.status,409);assert.equal(stale.body.code,'CONNECTION_REMOVED');assert.equal(stale.body.reason,'epoch-retired');
 assert.equal((await native(h,'/api/disconnect-source',old)).body.code,'NOT_OWNER');assert.equal(h.store.sources.get(e.sourceId).epoch,e.epoch);
}));
test('Recovery HTTP: twenty attempts cannot seize another active workspace owner',()=>withHub(async h=>{
 const owner=envelope();await native(h,'/api/claim',owner);
 const results=await Promise.all(Array.from({length:20},()=>native(h,'/api/reconnect',request(envelope(owner.sourceId)))));
 assert(results.every(r=>r.status===409&&r.body.code==='CONNECTION_IN_USE'));assert.equal(h.store.sources.get(owner.sourceId).epoch,owner.epoch);
}));
test('Recovery HTTP: twenty fresh attempts after removal produce one winner',()=>withHub(async h=>{
 const owner=envelope();await native(h,'/api/claim',owner);await native(h,'/api/disconnect-source',owner);
 const results=await Promise.all(Array.from({length:20},()=>native(h,'/api/reconnect',request(envelope(owner.sourceId)))));
 assert.equal(results.filter(r=>r.status===200).length,1);assert.equal(results.filter(r=>r.status===409).length,19);assert.equal(h.store.snapshot().sources.length,1);
}));
test('Recovery Producer: a missing new endpoint stops with an upgrade error, without legacy fallback',async()=>{
 const requests=[],statuses=[];
 const p=new producers.Producer({hub:'http://127.0.0.1:4317',token:TOKEN,sourceId:'source',resume:true,getSessions:()=>[],onStatus:(ok,m,e)=>statuses.push(e),transport:{request:async(h,t,u)=>{requests.push(u);if(u==='/api/release')return {released:false};throw Object.assign(new Error('Unknown API endpoint'),{status:404});},stop(){}}});
 try{await p.tick();assert(p.stopped);assert.equal(p.resume,false);assert(!p.timer);assert.equal(statuses[0].code,'HUB_UPGRADE_REQUIRED');assert(!requests.includes('/api/claim'));}finally{await p.stop();}
});
test('Recovery Producer: wrong response epoch cannot be reported as success',async()=>{
 const statuses=[];const p=new producers.Producer({hub:'http://127.0.0.1:4317',token:TOKEN,sourceId:'source',resume:true,getSessions:()=>[],onStatus:(ok,m,e)=>statuses.push({ok,e}),transport:{request:async(h,t,u,m,b)=>u==='/api/release'?{released:true}:{accepted:true,recoveryProtocol:1,sourceId:b.sourceId,requestId:b.requestId,epoch:'different-epoch'},stop(){}}});
 try{await p.tick();assert(p.stopped);assert(!p.claimed);assert(!statuses[0].ok);assert.equal(statuses[0].e.code,'INVALID_RECOVERY_ACK');}finally{await p.stop();}
});
test('Recovery persistence: confirmed explicit removal and recovery survive actual hub restart',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'mc-recovery-state-'));let h;
 try{
  h=await createHub({port:0,persist:true,dataDir:dir,token:TOKEN});const old=envelope();await native(h,'/api/claim',old);await native(h,'/api/disconnect-source',old);
  const fresh=request(envelope(old.sourceId));assert.equal((await native(h,'/api/reconnect',fresh)).status,200);
  const saved=JSON.parse(await readFile(path.join(dir,'state.json'),'utf8'));assert.equal(saved.detachedSources.length,0);assert(saved.retiredEpochs[0][1].includes(old.epoch));
  await h.close();h=await createHub({port:0,persist:true,dataDir:dir,token:TOKEN});assert.equal((await native(h,'/api/claim',old)).status,409);
  assert.equal((await native(h,'/api/claim',envelope(old.sourceId))).status,200);
 }finally{await h?.close();await rm(dir,{recursive:true,force:true});}
});
test('Recovery persistence: failing disk write releases unconfirmed owner and permits a new explicit try',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'mc-recovery-disk-'));let h;
 try{
  h=await createHub({port:0,persist:true,dataDir:dir,token:TOKEN});const old=envelope();await native(h,'/api/claim',old);await native(h,'/api/disconnect-source',old);await mkdir(path.join(dir,'state.json.tmp'));
  const bad=request(envelope(old.sourceId)),r=await native(h,'/api/reconnect',bad);assert.equal(r.status,400);assert.equal(r.body.code,'RECOVERY_SAVE_FAILED');assert.equal(h.store.sourceAlive(h.store.sources.get(old.sourceId)),false);
  await rm(path.join(dir,'state.json.tmp'),{recursive:true});assert.equal((await native(h,'/api/reconnect',request(envelope(old.sourceId)))).status,200);
 }finally{await h?.close();await rm(dir,{recursive:true,force:true});}
});
