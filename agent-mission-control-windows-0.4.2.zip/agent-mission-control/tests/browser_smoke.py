"""Optional UI smoke test. Requires Python Playwright and a Chromium executable.
Tests the self-contained demo, not a real VS Code installation or model account.
"""
import json
import os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parents[1]
results = []
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=os.environ.get('CHROMIUM', '/usr/bin/chromium'), headless=True, args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 1600, 'height': 1080}, device_scale_factor=1)
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.set_content((ROOT/'dashboard-demo.html').read_text(), wait_until='load')
    assert page.locator('.session-row').count() == 8
    assert 'UKÁZKOVÁ DATA' in page.locator('#modeBadge').inner_text()
    results.append('Initial view: 8 synthetic sessions; visible demo label')
    page.locator('#navigation [data-view="attention"]').click()
    assert page.locator('.session-row').count() == 2
    results.append('Attention filter')
    page.locator('#clearFiltersButton').click()
    page.locator('#search').fill('crawler')
    assert page.locator('.session-row').count() == 1
    results.append('Project search')
    page.locator('#clearFiltersButton').click()
    page.locator('#agentFilter').select_option('zoo')
    assert page.locator('.session-row').count() == 4
    results.append('Agent filter')
    page.locator('#clearFiltersButton').click()
    page.locator('[data-environment="WSL"]').click()
    assert page.locator('.session-row').count() == 2
    results.append('Environment filter')
    page.locator('#clearFiltersButton').click()
    page.locator('[data-select="backend"]').click()
    page.locator('[data-tab="messages"]').click()
    assert page.locator('.message').count() == 2
    page.locator('[data-tab="diff"]').click()
    assert page.locator('.diff-line.add').count() > 0
    results.append('Message and diff tabs')
    page.locator('[data-action="ack"]').click()
    assert 'seen' in page.locator('[data-action="ack"]').get_attribute('class')
    assert 'Čeká na schválení' in page.locator('.banner-title').inner_text()
    results.append('Acknowledgement does not approve an action')
    page.locator('[data-action="snooze"]').click()
    assert 'odloženo' in page.locator('.banner-time').inner_text()
    results.append('Snooze')
    page.locator('#demoStepButton').click()
    page.locator('#navigation [data-view="attention"]').click()
    assert page.locator('.session-row').count() == 3
    results.append('Simulated event updates attention queue')
    page.locator('#setupButton').click()
    assert page.locator('#modal').is_visible()
    page.locator('[data-action="close-modal"]').click()
    results.append('Connection guide dialog')
    page.evaluate("snapshot.sessions[0].project='<img src=x onerror=window.XSS=1>'; render();")
    assert page.evaluate('window.XSS || null') is None
    assert page.locator('.project-name img').count() == 0
    results.append('HTML escaping for producer-controlled text')
    # Fresh, deterministic document without redeclaring script globals.
    page.close()
    page = browser.new_page(viewport={'width': 1600, 'height': 1080}, device_scale_factor=1)
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.set_content((ROOT/'dashboard-demo.html').read_text(), wait_until='load')
    assert page.evaluate('document.body.scrollWidth') <= 1600
    page.screenshot(path=str(ROOT.parent/'mission-control-preview.png'), full_page=True)
    page.set_viewport_size({'width': 390, 'height': 844})
    page.wait_for_timeout(150)
    assert page.evaluate('document.body.scrollWidth') <= 390
    page.screenshot(path=str(ROOT.parent/'mission-control-mobile.png'), full_page=True)
    results.append('Desktop 1600px and mobile 390px layouts; no horizontal overflow')
    assert errors == [], errors
    results.append('No uncaught browser JavaScript errors')
    browser.close()
print(json.dumps({'passed':len(results),'checks':results},ensure_ascii=False,indent=2))
