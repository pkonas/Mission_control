// Synthetic Zoo Task, real Bridge/Producer/hub. Never executes a shell command.
import {createHub} from '../../src/server.mjs';
import {bridgeHarness,until,TOKEN} from '../helpers/live-bridge.mjs';
import {mkdtemp,mkdir,rm} from 'node:fs/promises';import path from 'node:path';import os from 'node:os';import readline from 'node:readline';
const dir=await mkdtemp(path.join(os.tmpdir(),'mc-browser-zoo-'));const folder=path.join(dir,'eshop');await mkdir(folder);
const desktopSecret='c'.repeat(64);const hub=await createHub({port:0,persist:false,token:TOKEN,desktopSecret,instanceId:'d'.repeat(32)});
const h=bridgeHarness({hub,folder});let ts=Date.now();
const task={taskId:'test-zoo-task',lastMessageTs:ts,askResponse:undefined,abort:false,abandoned:false,calls:[],
 interactiveAsk:{type:'ask',ask:'command',ts,text:'npm test -- --runInBand',isProtected:false},
 handleWebviewAskResponse(r){this.calls.push(r);this.askResponse=r;queueMicrotask(()=>{this.interactiveAsk=undefined;h.zoo.emit('taskActive',this.taskId);});}};
h.zoo.sidebarProvider={getCurrentTask:()=>task};await h.activation;await until(()=>hub.store.snapshot().sessions.some(s=>s.pending?.length));
const env={version:1,sourceId:'other-project-fixture',epoch:'other-epoch',label:'Other synthetic project'};let seq=0;
const heartbeat=()=>hub.store.ingest({...env,seq:++seq,sessions:[{id:'other-run',agent:'codex',role:'main',project:'backend',workspace:'/synthetic/backend',host:'fixture',hostId:'fixture',environment:'Linux',evidence:'api',state:'working',activity:'Doplňuje testy',activityAt:Date.now(),stateSince:Date.now(),capabilities:[]}]});heartbeat();const timer=setInterval(heartbeat,4000);
console.log(JSON.stringify({url:hub.url,token:TOKEN,desktopSecret}));
process.on('SIGTERM',()=>{void close();});
const rl=readline.createInterface({input:process.stdin});for await(const line of rl){try{const x=JSON.parse(line);
 if(x.op==='ask'){task.askResponse=undefined;task.lastMessageTs=++ts;task.interactiveAsk={type:'ask',ask:x.ask||'command',ts,text:x.text||'npm run build',isProtected:!!x.protected};h.zoo.emit('taskInteractive',task.taskId);h.instances.at(-1).markDirty();await h.instances.at(-1).tick();}
 console.log(JSON.stringify({calls:task.calls,state:hub.store.snapshot()}));
 }catch(e){console.log(JSON.stringify({error:e.message}));}}
async function close(){clearInterval(timer);await h.close();await hub.close();await rm(dir,{recursive:true,force:true});process.exit(0);}await close();
