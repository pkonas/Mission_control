'use strict';
const fs=require('node:fs');
const args=process.argv.slice(2);const state=process.env.FAKE_CODE_STATE;const scenario=process.env.FAKE_CODE_SCENARIO||'warning';
if(process.env.FAKE_CODE_ARGS)fs.appendFileSync(process.env.FAKE_CODE_ARGS,JSON.stringify(args)+'\n');
const warning='(node:43000) [DEP0169] DeprecationWarning: `url.parse()` behavior is not standardized and prone to errors that have security implications. Use the WHATWG URL API instead. CVEs are not issued for `url.parse()` vulnerabilities.\n';
if(scenario==='warning')process.stderr.write(warning);
if(scenario==='failure'){process.stderr.write('Real VSIX error: incompatible extension\n');process.exitCode=7;}
else if(args.includes('--install-extension')){
 if(scenario!=='missing')fs.writeFileSync(state,scenario==='wrong'?'0.2.0':'0.4.2');
 process.stdout.write('Extension installation finished.\n');
}else if(args.includes('--uninstall-extension')){
 if(scenario!=='retain')try{fs.unlinkSync(state);}catch{}
 process.stdout.write('Uninstall finished.\n');
}else if(args.includes('--list-extensions')){
 if(scenario==='list-failure'){process.exitCode=9;process.stderr.write('Cannot read extension directory.\n');}
 else {process.stdout.write('other.publisher@1.0.0\n');if(fs.existsSync(state))process.stdout.write('local-mission-control.bridge@'+fs.readFileSync(state,'utf8')+'\n');}
}else {process.stderr.write('Unexpected arguments');process.exitCode=8;}
