// Test fixture only. No user files or credentials are read.
import {createHub} from '../../src/server.mjs';import {createDemo} from '../../public/demo.mjs';
const hub=await createHub({port:0,persist:false,token:'fixture-token-'+ 'a'.repeat(64)});const sessions=createDemo().map(s=>({...s,role:s.role||'main',historical:!!s.historical,evidence:s.evidence==='observed'?'observed':'api',current:true}));
let seq=0;const envelope={version:1,sourceId:'browser-fixture',epoch:'browser-epoch-0001',label:'Synthetic browser fixture'};
const heartbeat=()=>hub.store.ingest({...envelope,seq:++seq,sessions:sessions.filter(s=>s.state!=='disconnected')});heartbeat();
const timer=setInterval(heartbeat,5000);console.log(JSON.stringify({url:hub.url,token:hub.token,envelope,sessions}));
process.on('SIGTERM',async()=>{clearInterval(timer);await hub.close();process.exit(0)});
