// Protocol fixture only. Does not invoke a model or execute any command.
import readline from 'node:readline';
const send=m=>process.stdout.write(JSON.stringify(m)+'\n');
const notification=(method,params)=>send({method,params});
const rl=readline.createInterface({input:process.stdin});
rl.on('line',line=>{const m=JSON.parse(line);
  if(m.method==='initialize')send({id:m.id,result:{userAgent:'fixture/1'}});
  else if(m.method==='thread/start')send({id:m.id,result:{thread:{id:'mock-thread'}}});
  else if(m.method==='turn/start'){
    send({id:m.id,result:{turn:{id:'turn-1',status:'inProgress'}}});
    notification('turn/started',{threadId:'mock-thread',turn:{id:'turn-1'}});
    notification('item/agentMessage/delta',{threadId:'mock-thread',itemId:'a',delta:'Testovací odpověď'});
    send({id:91,method:'item/commandExecution/requestApproval',params:{threadId:'mock-thread',turnId:'turn-1',itemId:'cmd',command:'echo fixture only',reason:'Synthetic approval'}});
  }else if(m.id===91&&m.result){
    notification('serverRequest/resolved',{threadId:'mock-thread',requestId:91});
    notification('turn/diff/updated',{threadId:'mock-thread',turnId:'turn-1',diff:'--- a/test\n+++ b/test\n+fixture\n'});
    notification('turn/completed',{threadId:'mock-thread',turn:{id:'turn-1',status:'completed'}});
  }else if(m.method==='turn/interrupt'){send({id:m.id,result:{}});notification('turn/completed',{threadId:'mock-thread',turn:{id:'turn-1',status:'interrupted'}});}
  else if(m.method&&m.id!==undefined)send({id:m.id,result:{}});
});
