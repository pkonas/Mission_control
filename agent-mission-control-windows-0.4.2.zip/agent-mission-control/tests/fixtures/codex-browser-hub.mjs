// Real hub, Bridge, Producer and executable hook; synthetic Codex event producer.
import {mkdtemp,mkdir,rm} from 'node:fs/promises';import path from 'node:path';import os from 'node:os';import {spawn} from 'node:child_process';import readline from 'node:readline';
import {createHub} from '../../src/server.mjs';import {bridgeHarness,until,TOKEN} from '../helpers/live-bridge.mjs';import config from '../../bridge/src/codex-hook-config.cjs';
const dir=await mkdtemp(path.join(os.tmpdir(),'mc-codex-browser-')),home=path.join(dir,'codex'),folder=path.join(dir,'monografie'),second=path.join(dir,'backend');await mkdir(folder);await mkdir(second);
const install=await config.installHook({home,node:process.execPath}),desktopSecret='d'.repeat(64),hub=await createHub({port:0,persist:false,token:TOKEN,desktopSecret,instanceId:'a'.repeat(32)});
const h=bridgeHarness({hub,folder,settings:{codexHome:home},workspaceStore:new Map([['missionControl.codexDashboardControls.v1',true]])}),other=bridgeHarness({hub,folder:second});
const calls=[],children=[];let sequence=0;
async function ask(text='npm test -- --runInBand',description='Spustit testy projektu?',extra={}){
 const n=++sequence,p=spawn(process.execPath,[install.script],{stdio:['pipe','pipe','pipe']});children.push(p);let output='';p.stdout.setEncoding('utf8');p.stdout.on('data',x=>output+=x);p.stderr.on('data',()=>{});
 p.on('exit',()=>{let verdict={};try{verdict=JSON.parse(output);}catch{}calls.push({n,decision:verdict.hookSpecificOutput?.decision?.behavior||'delegate'});});
 p.stdin.end(JSON.stringify({hook_event_name:'PermissionRequest',session_id:'original-vscode-codex-thread',turn_id:'original-turn',cwd:folder,tool_name:'Bash',tool_input:{command:text,description},...extra}));
 await until(()=>hub.store.snapshot().sessions.some(s=>s.agent==='codex'&&s.pending.some(p=>p.summary===description)),'Codex hook request in real hub',6000);return n;
}
await Promise.all([h.activation,other.activation]);await until(async()=>(await h.status()).codexControls.listening);
await ask();console.log(JSON.stringify({url:hub.url,token:TOKEN,desktopSecret}));
let chain=Promise.resolve();readline.createInterface({input:process.stdin}).on('line',line=>{chain=chain.then(async()=>{const x=JSON.parse(line);let r={};if(x.op==='status')r={calls,status:await h.status()};if(x.op==='ask')r={n:await ask(x.text,x.description||'Další požadavek',x.extra||{})};if(x.op==='cancel'){for(const p of children)if(p.exitCode===null)p.kill();await until(async()=>(await h.status()).codexControls.pending===0);r={ok:true};}console.log(JSON.stringify(r));}).catch(e=>console.log(JSON.stringify({error:e.message})));});
let closing=false;async function close(){if(closing)return;closing=true;for(const p of children)if(p.exitCode===null)p.kill();await h.close();await other.close();await hub.close();await rm(dir,{recursive:true,force:true});process.exit();}process.on('SIGTERM',()=>void close());process.on('SIGINT',()=>void close());
