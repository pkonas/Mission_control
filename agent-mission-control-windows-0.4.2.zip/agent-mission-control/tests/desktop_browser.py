"""Browser integration tests for the real desktop-mode hub; no Windows desktop emulation."""
import os, json, tempfile, subprocess, time, urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
secret='a'*64
checks=[]
with tempfile.TemporaryDirectory() as temp:
    env={**os.environ,'MC_DESKTOP_SECRET':secret,'MC_INSTANCE_ID':'b'*32,'MC_DATA_DIR':temp,'MC_PORT':'14319'}
    p=subprocess.Popen(['node',str(ROOT/'src/server.mjs')],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    url='http://127.0.0.1:14319'
    try:
        for _ in range(100):
            try:
                with urllib.request.urlopen(url+'/healthz',timeout=.2):break
            except Exception:time.sleep(.05)
        req=urllib.request.Request(url+'/api/desktop/ticket',method='POST',headers={'Authorization':'Bearer '+secret})
        ticket=urllib.request.urlopen(req).read().decode()
        with sync_playwright() as pw:
            b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
            context=b.new_context(viewport={'width':1500,'height':1000})
            page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
            page.goto(url+'/#desktop-ticket='+ticket)
            page.wait_for_function("document.querySelector('#hubStatus').textContent.includes('Lokální hub připojen')")
            assert not page.locator('#modal').is_visible()
            checks.append('One-time desktop link signs the browser in without a token dialog')
            assert page.url==url+'/'
            assert page.evaluate('location.hash')==''
            assert ticket not in page.evaluate('JSON.stringify(localStorage)')
            checks.append('Ticket removed from URL and not persisted in localStorage')
            assert 'v liště' in page.locator('#notificationsButton').inner_text()
            page.locator('#notificationsButton').click();assert 'prohlížeč zavřený' in page.locator('#modalContent').inner_text()
            page.locator('[data-action="close-modal"]').click()
            checks.append('Browser explains native notification ownership instead of duplicating notifications')
            r=context.request.post(url+'/api/desktop/login',data={'ticket':ticket});assert r.status==401
            checks.append('Consumed ticket cannot sign in again')
            page.reload();page.wait_for_function("document.querySelector('#hubStatus').textContent.includes('Lokální hub připojen')")
            assert not page.locator('#modal').is_visible()
            checks.append('Reload uses the protected session cookie')
            anonymous=b.new_context();other=anonymous.new_page();other.goto(url+'/')
            other.wait_for_selector('#loginForm');assert 'ikony Mission Control' in other.locator('#modalContent').inner_text()
            checks.append('Unpaired browser sees native-app recovery instructions')
            assert not errors,errors
            checks.append('No uncaught browser JavaScript errors')
            b.close()
    finally:
        p.terminate();out,err=p.communicate(timeout=5)
        token=(Path(temp)/'token').read_text().strip()
        assert token not in out.decode() and secret not in out.decode()
        checks.append('Desktop process stdout does not contain either secret')
print(json.dumps({'passed':len(checks),'checks':checks},ensure_ascii=False,indent=2))
