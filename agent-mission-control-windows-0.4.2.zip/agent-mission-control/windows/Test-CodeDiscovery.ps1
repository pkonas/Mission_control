﻿#requires -Version 5.1
# Read-only Windows checks. Creates only a disposable fixture directory.
# -Live includes actual process/registry/PATH discovery; it installs nothing.
param([switch]$Live)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Code-Discovery.ps1')
$count=0
function Assert-Same($Actual,$Expected,[string]$Label) {
    if ($Actual -cne $Expected) { throw "$Label expected [$Expected], got [$Actual]" }
    $script:count++; Write-Host "PASS $Label"
}
foreach ($file in Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1') {
    $tokens=$null; $errors=$null
    [void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
    if ($errors.Count) { throw ($errors | Out-String) }
    $count++; Write-Host "PASS PowerShell AST $($file.Name)"
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('mc-code-discovery-' + [Guid]::NewGuid().ToString('N'))
try {
    $root=Join-Path $temp 'VS Code & žluťoučký 100% !'
    [void][IO.Directory]::CreateDirectory((Join-Path $root 'bin'))
    [void][IO.Directory]::CreateDirectory((Join-Path $root 'a123456789\resources\app\out'))
    $exe=Join-Path $root 'Code.exe'; [IO.File]::WriteAllText($exe,'fixture, not a real executable')
    $cmd=Join-Path $root 'bin\code.cmd'
    [IO.File]::WriteAllText($cmd,'"%~dp0..\Code.exe" "%~dp0..\a123456789\resources\app\out\cli.js" %*')
    Assert-Same (Get-MCCodeExecutable $exe) $exe 'running EXE with versioned resources is discoverable'
    Assert-Same (Get-MCCodeExecutable $cmd) $exe 'PATH code.cmd resolves to desktop executable'
    Assert-Same (Get-MCCodeExecutable $root) $exe 'registry install directory resolves'
    Assert-Same (Get-MCCodeExecutable ('"'+$exe+'",0')) $exe 'DisplayIcon suffix is removed'
    Assert-Same (Get-MCCodeExecutable ('"'+$exe+'" "%1"')) $exe 'registry open command is not executed'
    Assert-Same (Get-MCCodeExecutable 'relative\Code.exe') $null 'relative EXE is rejected'
    Assert-Same (Get-MCCodeExecutable (Join-Path $root 'code-tunnel.exe')) $null 'standalone tunnel is not desktop'
    $context=Get-MCCodeContext ('"'+$exe+'" --user-data-dir "D:\Data & 100% !\User" --extensions-dir="D:\Rozšíření" --profile "Vývoj remote"')
    Assert-Same $context.UserDataDir 'D:\Data & 100% !\User' 'quoted custom user-data-dir'
    Assert-Same $context.ExtensionsDir 'D:\Rozšíření' 'equals custom extensions-dir'
    Assert-Same $context.Profile 'Vývoj remote' 'named profile'
    $context=Get-MCCodeContext ('"'+$exe+'" --user-data-dir relative')
    Assert-Same ([bool]$context.ContextWarning) $true 'relative context is flagged, not guessed'
    $context=Get-MCCodeContext ('"'+$exe+'" -- --profile not-an-option')
    Assert-Same $context.Profile '' 'do not treat filename arguments as options'
    if ($Live) {
        $found=@(Get-MCCodeCandidates)
        Write-Host 'READ-ONLY actual local VS Code targets:'
        $found | Select-Object Executable,Source,Running,UserDataDir,ExtensionsDir,Profile | Format-List | Out-Host
        foreach($note in $script:MCCodeDiscoveryNotes) { Write-Host $note }
    }
} finally { if(Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Recurse -Force } }
Write-Host "$count checks passed under PowerShell $($PSVersionTable.PSVersion)."
