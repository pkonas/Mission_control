﻿#requires -Version 5.1
& (Join-Path $PSScriptRoot 'Install.ps1')
exit $global:MCSetupExitCode
