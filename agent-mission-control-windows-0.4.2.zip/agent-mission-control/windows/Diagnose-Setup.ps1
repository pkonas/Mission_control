﻿#requires -Version 5.1
# Read-only diagnostics: no file deletion, no process termination, no policy change.
# Run in ordinary Windows PowerShell, under the same account/session as setup.
[CmdletBinding()]
param([switch]$Json)
$ErrorActionPreference='Stop'
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$session=[Diagnostics.Process]::GetCurrentProcess().SessionId
$name='Local\AgentMissionControl-Setup-'+$sid
$state='Unknown'; $detail=''; $mutex=$null; $acquired=$false
try {
    $mutex=[Threading.Mutex]::OpenExisting($name)
    try { $acquired=$mutex.WaitOne(0) }
    catch {
        if ($_.Exception.GetBaseException() -is [Threading.AbandonedMutexException]) { $acquired=$true }
        else { throw }
    }
    $state=if($acquired){'Free'}else{'Busy'}
} catch {
    if ($_.Exception.GetBaseException() -is [Threading.WaitHandleCannotBeOpenedException]) { $state='Free' }
    else { $detail=$_.Exception.Message }
} finally {
    if ($null -ne $mutex) {
        try { if($acquired){$mutex.ReleaseMutex()} } finally { $mutex.Dispose() }
    }
}
$candidates=@(); $queryError=''
try {
    $rows=@(Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction Stop)
    $candidates=@(foreach($row in $rows) {
        if ($row.ProcessId -eq $PID -or [int]$row.SessionId -ne $session -or
            $row.CommandLine -notmatch '(?i)(AgentMissionControl|MissionControl-|agent-mission-control)' -or
            $row.CommandLine -notmatch '(?i)(bootstrap|Install|Source-Setup|Uninstall|Launch)\.ps1') {continue}
        try {
            $owner=Invoke-CimMethod -InputObject $row -MethodName GetOwnerSid -ErrorAction Stop
            if($owner.ReturnValue -ne 0 -or $owner.Sid -ne $sid){continue}
            [pscustomobject]@{ ProcessId=[int]$row.ProcessId; Name=$row.Name;
                ParentProcessId=[int]$row.ParentProcessId; SessionId=[int]$row.SessionId;
                CreationDate=$row.CreationDate; CommandLine=$row.CommandLine }
        } catch { continue }
    })
} catch {$queryError=$_.Exception.Message}
$result=[pscustomobject]@{ MutexState=$state; MutexName=$name; Detail=$detail; QueryError=$queryError; Candidates=$candidates;
    Note='Processes are possible setup workers, not proven mutex owners. No processes or files have been removed.' }
if($Json){$result | ConvertTo-Json -Depth 6;return}
Write-Host ('Stav zámku údržby: '+$state)
if($detail){Write-Host $detail}
if($queryError){Write-Host ('Výpis procesů nebyl dostupný: '+$queryError)}
if($candidates.Count){
    Write-Host 'Možné pomocné procesy údržby; samotný výpis nepotvrzuje vlastnictví zámku:'
    $candidates | Format-List ProcessId,Name,ParentProcessId,SessionId,CreationDate,CommandLine
}else{Write-Host 'Žádný odpovídající pomocný proces se nepodařilo dohledat.'}
Write-Host 'Pokud je zámek Free, spusťte nový instalátor. Pokud je Busy, dokončete či běžně zavřete původního průvodce nebo jeho chybový dialog.'
Write-Host 'Neukončujte všechny powershell.exe, node.exe ani VS Code. Nemažte data ani domnělé soubory zámku.'
