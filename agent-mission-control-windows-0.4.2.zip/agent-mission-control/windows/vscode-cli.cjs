'use strict';
/** VS Code installer adapter: never treat stderr as an exit status.
 * Executes the same Code.exe + cli.js entrypoint as Microsoft's code.cmd,
 * without a shell. Results are persisted independently of PowerShell streams.
 */
const {spawn}=require('node:child_process');
const fs=require('node:fs/promises');
const path=require('node:path');
const {resolveInstallation}=require('./vscode-layout.cjs');
const EXTENSION_ID='local-mission-control.bridge';
const CONNECTOR_ID='local-mission-control.connector';
const MAX_OUTPUT=4*1024*1024;
function capture(executable,args,{env=process.env,timeoutMs=180000,maxOutput=MAX_OUTPUT,cwd}={}){
  return new Promise(resolve=>{
    let child,stdout='',stderr='',bytes=0,timer,settled=false,timedOut=false,overflow=false,spawnError='';
    const finish=(code,signal)=>{if(settled)return;settled=true;clearTimeout(timer);resolve({exitCode:code,signal,stdout,stderr,timedOut,overflow,spawnError});};
    try {child=spawn(executable,args,{shell:false,windowsHide:true,stdio:['ignore','pipe','pipe'],env,cwd});}
    catch(e){spawnError=e.message;finish(null,null);return;}
    const read=key=>chunk=>{bytes+=Buffer.byteLength(chunk);if(bytes>maxOutput){overflow=true;child.kill();return;}if(key==='out')stdout+=chunk;else stderr+=chunk;};
    child.stdout.setEncoding('utf8');child.stderr.setEncoding('utf8');child.stdout.on('data',read('out'));child.stderr.on('data',read('err'));
    child.on('error',e=>{spawnError=e.message;});
    child.on('close',finish);
    timer=setTimeout(()=>{timedOut=true;child.kill();},timeoutMs);
  });
}
function succeeded(result){return result.exitCode===0&&!result.timedOut&&!result.overflow&&!result.spawnError;}
function listedVersions(text,id=EXTENSION_ID){
  return text.replace(/^\uFEFF/,'').split(/\r?\n/).map(s=>s.trim()).filter(s=>s.toLowerCase().startsWith(id.toLowerCase()+'@')).map(s=>s.slice(id.length+1));
}
function explain(result){
  if(result.timedOut)return 'VS Code CLI překročilo časový limit.';
  if(result.overflow)return 'VS Code CLI překročilo limit diagnostického výstupu.';
  if(result.spawnError)return `VS Code CLI nelze spustit: ${result.spawnError}`;
  return `VS Code CLI skončilo s kódem ${result.exitCode}${result.signal?' ('+result.signal+')':''}.`;
}
function isolatedEnvironment(parent=process.env) {
  const env={...parent};
  // Windows environment names are case-insensitive. Do not inherit another
  // open/remote/portable editor's IPC routing, auto-debug hook or data directory.
  const unwanted=new Set(['VSCODE_DEV','VSCODE_IPC_HOOK_CLI','VSCODE_IPC_HOOK',
    'VSCODE_CWD','VSCODE_CLI','VSCODE_PORTABLE','VSCODE_EXTENSIONS',
    'VSCODE_USER_DATA_DIR','VSCODE_INSPECTOR_OPTIONS','VSCODE_NODE_OPTIONS',
    'NODE_OPTIONS','NODE_PATH','ELECTRON_RUN_AS_NODE','ELECTRON_NO_ATTACH_CONSOLE']);
  for(const key of Object.keys(env))if(key.toUpperCase().startsWith('VSCODE_')||unwanted.has(key.toUpperCase()))delete env[key];
  env.ELECTRON_RUN_AS_NODE='1';
  return env;
}
async function manage({executable,cli,action='install',vsix,version='0.4.2',profile='',
  userDataDir='',extensionsDir='',extensionId=EXTENSION_ID,resolveLayout=false,resourceVersion='',timeoutMs=180000},run=capture){
  if(![EXTENSION_ID,CONNECTOR_ID].includes(extensionId))throw new Error('Unsupported extension ID');
  if(!['install','uninstall','verify'].includes(action))throw new Error('Unsupported bridge action');
  for(const [key,value] of Object.entries({profile,userDataDir,extensionsDir})) {
    if(typeof value!=='string'||/[\x00\r\n]/.test(value))throw new Error(`Neplatná hodnota ${key}.`);
    if(key!=='profile'&&value&&!path.isAbsolute(value)&&!path.win32.isAbsolute(value))throw new Error(`${key} musí být absolutní cesta.`);
  }
  const commands=[];
  let layout=null;
  if(resolveLayout) {
    try{layout=resolveInstallation(executable,{resourceVersion});cli=layout.cli;}
    catch(e){return {ok:false,action,commands,message:'Detekce CLI: '+e.message};}
  }
  if(!cli)throw new Error('Chybí ověřená cesta ke CLI.');
  const env=isolatedEnvironment();
  const base=[cli];
  if(userDataDir)base.push('--user-data-dir',userDataDir);
  if(extensionsDir)base.push('--extensions-dir',extensionsDir);
  if(profile)base.push('--profile',profile);
  const invoke=async(args,phase='operation')=>{
    const r=await run(executable,[...base,...args],{env,timeoutMs:phase==='preflight'?Math.min(timeoutMs,20000):timeoutMs,cwd:resolveLayout?path.dirname(executable):undefined});
    commands.push({args,phase,result:r});return r;
  };
  const result=(fields)=>({action,commands,layout,...fields});
  if(resolveLayout) {
    const probe=await invoke(['--version'],'preflight');
    if(!succeeded(probe))return result({ok:false,message:'Samostatné CLI VS Code nelze spustit. '+explain(probe)});
    const lines=probe.stdout.trim().replace(/^\uFEFF/,'').split(/\r?\n/).map(s=>s.trim());
    if(!/^\d+\.\d+\.\d+(?:-[^\s]+)?$/.test(lines[0]||''))return result({ok:false,message:'Odpověď neodpovídá VS Code CLI; instalaci bridge nespouštím.'});
    if(layout.resourceVersion&&!lines.some(line=>/^[a-f0-9]{40}$/i.test(line)&&line.toLowerCase().startsWith(layout.resourceVersion.toLowerCase()))) {
      return result({ok:false,message:'Verze CLI neodpovídá aktivní verzované složce VS Code. Dokončete aktualizaci samotného editoru.'});
    }
  }
  let operation=null;
  if(action==='install'){
    if(!vsix)throw new Error('VSIX path required');
    operation=await invoke(['--install-extension',vsix,'--force']);
  } else if(action==='uninstall'){
    const before=await invoke(['--list-extensions','--show-versions'],'verification');
    if(!succeeded(before))return result({ok:false,message:explain(before)});
    if(!listedVersions(before.stdout,extensionId).length)return result({ok:true,alreadyAbsent:true,message:'Bridge již není nainstalován ve zvoleném lokálním profilu.'});
    operation=await invoke(['--uninstall-extension',extensionId]);
  }
  if(operation&&!succeeded(operation))return result({ok:false,message:explain(operation)});
  const check=await invoke(['--list-extensions','--show-versions'],'verification');
  if(!succeeded(check))return result({ok:false,message:'Ověření výsledku selhalo. '+explain(check)});
  const versions=listedVersions(check.stdout,extensionId);
  const ok=action==='uninstall'?versions.length===0:versions.includes(version);
  return result({ok,versions,reloadSuggested:ok&&action==='install',hasWarnings:commands.some(c=>c.result.stderr.trim()),message:ok?
    (action==='uninstall'?'Bridge byl odinstalován a jeho nepřítomnost ověřena.':`Bridge ${version} je nainstalován; verze byla ověřena.`):
    (action==='uninstall'?'CLI skončilo kódem 0, ale bridge je stále v seznamu.':`CLI skončilo kódem 0, ale seznam nepotvrdil bridge ${version}. Nalezeno: ${versions.join(', ')||'nic'}.`)});
}
/** Both packages target exactly the selected local profile; no remote shell is used. */
async function manageSuite(config,run=capture){
  const targets=[
    {extensionId:CONNECTOR_ID,vsix:config.connectorVsix,label:'Connection'},
    {extensionId:EXTENSION_ID,vsix:config.vsix,label:'Bridge'}
  ];
  const reports=[];
  for(const target of targets){
    let report;
    try{report=await manage({...config,...target},run);}
    catch(e){report={ok:false,message:e.message,commands:[]};}
    reports.push({...report,extensionId:target.extensionId,label:target.label});
  }
  const ok=reports.every(r=>r.ok);
  return {
    ok,action:config.action||'install',scope:'selected-local-profile',activationVerified:false,
    profile:config.profile||'',reports,layout:reports.find(r=>r.layout)?.layout||null,
    commands:reports.flatMap(r=>r.commands.map(c=>({...c,extensionId:r.extensionId}))),
    message:ok?(config.action==='uninstall'?'Oba doplňky Mission Control byly odstraněny ze zvoleného místního profilu.':
      `MC_VSCODE_PACKAGES_VERIFIED: Connection + Bridge ${config.version}; instalace na disku v cílovém místním profilu ověřena. Aktivace v otevřených oknech ani připojení k hubu tím ještě nejsou potvrzeny.`):
      reports.map(r=>`${r.label}: ${r.ok?'ověřeno':r.message}`).join(' | ')
  };
}
async function main(argv){
  const configPath=argv[0],resultPath=argv[1];
  if(!configPath||!resultPath)throw new Error('Usage: node vscode-cli.cjs config.json result.json');
  let result;
  try{const config=JSON.parse((await fs.readFile(configPath,'utf8')).replace(/^\uFEFF/,''));result=await (config.suite?manageSuite:manage)(config);}
  catch(e){result={ok:false,message:e.message,commands:[]};}
  await fs.writeFile(resultPath,JSON.stringify(result,null,2)+'\n',{encoding:'utf8',mode:0o600});
  process.exitCode=result.ok?0:2;
}
module.exports={capture,succeeded,listedVersions,explain,manage,manageSuite,isolatedEnvironment,EXTENSION_ID,CONNECTOR_ID};
if(require.main===module)main(process.argv.slice(2)).catch(e=>{process.stderr.write(e.message+'\n');process.exitCode=1;});
