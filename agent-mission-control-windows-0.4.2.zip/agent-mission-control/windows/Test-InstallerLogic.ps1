﻿#requires -Version 5.1
# Non-destructive developer checks: no registry writes or application installation.
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
$script:LogBox=$null
$count=0
function Assert-Equal($Actual,$Expected,[string]$Label) {
    if ($Actual -cne $Expected) { throw "$Label -- expected: [$Expected], actual: [$Actual]" }
    $script:count++; Write-Host "PASS $Label"
}
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1') {
    $tokens=$null; $errors=$null
    [void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
    if ($errors.Count) { throw ($errors | Out-String) }
    $count++; Write-Host "PASS PowerShell AST $($file.Name)"
}
Assert-Equal (Resolve-MCMode Auto Absent '' '0.4.2') 'Install' 'new installation'
Assert-Equal (Resolve-MCMode Auto Installed '0.2.0' '0.4.2') 'Update' 'upgrade 0.2 to 0.3'
Assert-Equal (Resolve-MCMode Auto Installed '0.4.2' '0.4.2') 'Repair' 'repair same version'
Assert-Equal (Resolve-MCMode Auto Damaged '' '0.4.2') 'Repair' 'repair registered damaged installation'
Assert-Equal (Resolve-MCMode Uninstall Installed '0.2.0' '0.4.2') 'Uninstall' 'remove previous installation'
foreach($case in @(@('Auto','Conflict','','0.4.2'),@('Auto','Installed','0.4.2','0.4.2'),@('Repair','Absent','','0.4.2'))) {
    $threw=$false;try{[void](Resolve-MCMode $case[0] $case[1] $case[2] $case[3])}catch{$threw=$true}
    Assert-Equal $threw $true ('reject unsafe mode '+($case -join ','))
}
Assert-Equal (ConvertTo-MCArgument '') '""' 'empty native argument'
Assert-Equal (ConvertTo-MCArgument 'C:\test dir\') '"C:\test dir\\"' 'trailing backslash'
Assert-Equal (ConvertTo-MCArgument 'a"b') '"a\"b"' 'embedded quote'
$ps=(Get-Process -Id $PID).Path
$r=Invoke-MCProcess $ps @('-NoLogo','-NoProfile','-Command','[Console]::Out.Write("ok");[Console]::Error.Write("[DEP0169] warning");exit 0') 30
Assert-Equal $r.ExitCode 0 'native stderr does not throw under ErrorActionPreference Stop'
Assert-Equal $r.StdOut 'ok' 'native stdout captured separately'
Assert-Equal $r.StdErr '[DEP0169] warning' 'native warning retained'
$r=Invoke-MCProcess $ps @('-NoLogo','-NoProfile','-Command','[Console]::Error.Write("real failure");exit 7') 30
Assert-Equal $r.ExitCode 7 'real native failure is retained'
Write-Host "$count checks passed under PowerShell $($PSVersionTable.PSVersion)."
