﻿#requires -Version 5.1
# Read-only discovery. No process termination, registry writes, .cmd execution,
# elevation or recursive scanning of disks. CLI layout is rechecked by Node.
function Get-MCCodeExecutable([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
    try {
        $p = [Environment]::ExpandEnvironmentVariables($Value.Trim())
        if ($p -match '^"([^"\r\n]+)"') { $p = $Matches[1] }
        elseif ($p -match '^(.*?\.exe)(?:\s|,[-0-9]+\s*$)') { $p = $Matches[1] }
        $p = $p.Trim().Trim('"')
        if (-not [IO.Path]::IsPathRooted($p)) { return $null }
        if (Test-Path -LiteralPath $p -PathType Container) {
            foreach ($n in @('Code.exe','Code - Insiders.exe')) {
                $candidate = Join-Path $p $n
                if (Test-Path -LiteralPath $candidate -PathType Leaf) {
                    $found = Get-MCCodeExecutable $candidate
                    if ($found) { return $found }
                }
            }
            return $null
        }
        if ([IO.Path]::GetExtension($p) -eq '.cmd') {
            $name = [IO.Path]::GetFileName($p)
            if ($name -notin @('code.cmd','code-insiders.cmd')) { return $null }
            $folder = Split-Path $p -Parent
            if ((Split-Path $folder -Leaf) -ne 'bin') { return $null }
            $exeName = if ($name -eq 'code-insiders.cmd') { 'Code - Insiders.exe' } else { 'Code.exe' }
            $p = Join-Path (Split-Path $folder -Parent) $exeName
        }
        if ([IO.Path]::GetFileName($p) -notin @('Code.exe','Code - Insiders.exe')) { return $null }
        if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { return $null }
        $p = [IO.Path]::GetFullPath($p)
        $root = Split-Path $p -Parent
        $cmd = if ([IO.Path]::GetFileName($p) -eq 'Code.exe') { 'code.cmd' } else { 'code-insiders.cmd' }
        # A running executable need not have unversioned resources. Current
        # Microsoft builds select their commit folder in the adjacent launcher.
        if ((Test-Path -LiteralPath (Join-Path $root "bin\$cmd") -PathType Leaf) -or
            (Test-Path -LiteralPath (Join-Path $root 'resources\app\out\cli.js') -PathType Leaf)) { return $p }
        $v = [Diagnostics.FileVersionInfo]::GetVersionInfo($p).ProductVersion
        if ($v -match '^[a-fA-F0-9]{8,40}$' -and
            (Test-Path -LiteralPath (Join-Path $root "$v\resources\app\out\cli.js") -PathType Leaf)) { return $p }
    } catch { }
    return $null
}
function Split-MCCodeArguments([string]$CommandLine) {
    if (-not $CommandLine) { return @() }
    # Use the Windows parser rather than Invoke-Expression or splitting at spaces.
    if (-not ('MCCodeNativeArgs' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class MCCodeNativeArgs {
    [DllImport("shell32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
    private static extern IntPtr CommandLineToArgvW(string cmd, out int count);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr p);
    public static string[] Split(string cmd) {
        int count; IntPtr p = CommandLineToArgvW(cmd, out count);
        if (p == IntPtr.Zero) return new string[0];
        try {
            string[] result = new string[count];
            for (int i=0; i<count; i++) result[i] = Marshal.PtrToStringUni(Marshal.ReadIntPtr(p, i*IntPtr.Size));
            return result;
        } finally { LocalFree(p); }
    }
}
'@ -ErrorAction Stop | Out-Null
    }
    return [MCCodeNativeArgs]::Split($CommandLine)
}
function Get-MCCodeContext([string]$CommandLine) {
    $context = @{ UserDataDir=''; ExtensionsDir=''; Profile=''; ContextWarning='' }
    if (-not $CommandLine) { return $context }
    try {
        $arguments = @(Split-MCCodeArguments $CommandLine)
        for ($i=0; $i -lt $arguments.Count; $i++) {
            $arg = $arguments[$i]
            if ($arg -eq '--') { break }
            foreach ($pair in @(@('user-data-dir','UserDataDir'),@('extensions-dir','ExtensionsDir'),@('profile','Profile'))) {
                $flag = '--' + $pair[0]; $value = $null
                if ($arg.StartsWith($flag + '=', [StringComparison]::OrdinalIgnoreCase)) { $value = $arg.Substring($flag.Length + 1) }
                elseif ($arg -eq $flag -and $i+1 -lt $arguments.Count) { $i++; $value = $arguments[$i] }
                if ($null -ne $value) {
                    if ($pair[1] -ne 'Profile' -and -not [IO.Path]::IsPathRooted($value)) {
                        $context.ContextWarning = 'Běžící VS Code používá relativní datovou cestu. Doplňte její absolutní cestu; pracovní adresář jiného procesu neodhaduji.'
                    } else { $context[$pair[1]] = $value }
                    break
                }
            }
        }
    } catch { $context.ContextWarning = 'Parametry běžícího VS Code nelze přečíst. Ověřte vlastní datové složky a profil.' }
    return $context
}
function Get-MCCodeCandidates([string]$SavedFile = '') {
    $seeds = New-Object 'System.Collections.Generic.List[object]'
    $notes = New-Object 'System.Collections.Generic.List[string]'
    $session = (Get-Process -Id $PID).SessionId
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $runningRoots = @{}
    # Prefer the current user's actual executable, including portable/custom paths.
    try {
        $processes = @(Get-CimInstance -ClassName Win32_Process -Filter "Name = 'Code.exe' OR Name = 'Code - Insiders.exe'" -OperationTimeoutSec 4 -ErrorAction Stop)
        foreach ($p in $processes) {
            if ($p.SessionId -ne $session) { continue }
            # Ignore Chromium helpers: they do not describe the selected user-data dir.
            if ($p.CommandLine -match '(?:^|\s)--type(?:=|\s)' -or $p.CommandLine -match '[\\/]cli(?:ProcessMain)?\.js') { continue }
            try {
                $owner = Invoke-CimMethod -InputObject $p -MethodName GetOwnerSid -OperationTimeoutSec 3 -ErrorAction Stop
                if ($owner.ReturnValue -ne 0 -or $owner.Sid -ne $sid) { continue }
                $exe = [string]$p.ExecutablePath
                if (-not $exe) { $exe = (Get-Process -Id $p.ProcessId -ErrorAction Stop).Path }
                $context = Get-MCCodeContext ([string]$p.CommandLine)
                $seeds.Add([pscustomobject]@{ Path=$exe; Source='běžící VS Code'; Rank=10; Running=$true; ProcessId=$p.ProcessId; Context=$context })
            } catch { $notes.Add('Některý běžící proces nebylo možné přečíst; pokračuji dalšími zdroji.') }
        }
    } catch { $notes.Add('WMI/CIM není dostupné; použiji registr, PATH, zástupce a známé instalační složky.') }
    if ($SavedFile -and (Test-Path -LiteralPath $SavedFile -PathType Leaf)) {
        try {
            $saved = Get-Content -LiteralPath $SavedFile -Raw -Encoding UTF8 | ConvertFrom-Json
            $context = @{ UserDataDir=[string]$saved.userDataDir; ExtensionsDir=[string]$saved.extensionsDir; Profile=[string]$saved.profile; ContextWarning='' }
            $seeds.Add([pscustomobject]@{ Path=[string]$saved.executable; Source='poslední ověřená volba'; Rank=20; Running=$false; ProcessId=0; Context=$context })
        } catch { $notes.Add('Uložená cesta není čitelná; bude znovu dohledána.') }
    }
    # Both registry views and both per-user/system installations. Read only.
    foreach ($hive in @('HKCU:','HKLM:')) {
        foreach ($prefix in @('Software','Software\WOW6432Node')) {
            foreach ($app in @('Code.exe','code-insiders.exe','Code - Insiders.exe')) {
                $key = "$hive\$prefix\Microsoft\Windows\CurrentVersion\App Paths\$app"
                try {
                    $item = Get-Item -LiteralPath $key -ErrorAction Stop
                    $seeds.Add([pscustomobject]@{ Path=[string]$item.GetValue(''); Source='registr App Paths'; Rank=30; Running=$false; ProcessId=0; Context=@{} })
                } catch { }
            }
            $uninstall = "$hive\$prefix\Microsoft\Windows\CurrentVersion\Uninstall"
            foreach ($key in @(Get-ChildItem -LiteralPath $uninstall -ErrorAction SilentlyContinue)) {
                try {
                    $v = Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction Stop
                    if ($v.DisplayName -notmatch '^(?:Microsoft )?Visual Studio Code(?:\s|$)') { continue }
                    foreach ($value in @($v.DisplayIcon,$v.InstallLocation)) {
                        if ($value) { $seeds.Add([pscustomobject]@{ Path=[string]$value; Source='registr instalací'; Rank=35; Running=$false; ProcessId=0; Context=@{} }) }
                    }
                } catch { }
            }
        }
        foreach ($app in @('vscode','vscode-insiders','Applications\Code.exe','Applications\Code - Insiders.exe')) {
            try {
                $key = Get-Item -LiteralPath "$hive\Software\Classes\$app\shell\open\command" -ErrorAction Stop
                $seeds.Add([pscustomobject]@{ Path=[string]$key.GetValue(''); Source='registr asociací'; Rank=38; Running=$false; ProcessId=0; Context=@{} })
            } catch { }
        }
    }
    foreach ($name in @('code.cmd','code-insiders.cmd','Code.exe','Code - Insiders.exe')) {
        foreach ($cmd in @(Get-Command $name -CommandType Application -All -ErrorAction SilentlyContinue)) {
            $seeds.Add([pscustomobject]@{ Path=[string]$cmd.Source; Source='PATH'; Rank=40; Running=$false; ProcessId=0; Context=@{} })
        }
    }
    # Typical locations plus Scoop's direct installation, not its executable shims.
    foreach ($base in @($env:LOCALAPPDATA,$env:ProgramW6432,$env:ProgramFiles,${env:ProgramFiles(x86)})) {
        if (-not $base) { continue }
        $prefix = if ($base -eq $env:LOCALAPPDATA) { 'Programs\' } else { '' }
        foreach ($relative in @('Microsoft VS Code\Code.exe','Microsoft VS Code Insiders\Code - Insiders.exe')) {
            $seeds.Add([pscustomobject]@{ Path=(Join-Path $base ($prefix+$relative)); Source='instalační složka'; Rank=60; Running=$false; ProcessId=0; Context=@{} })
        }
    }
    foreach ($base in @($env:SCOOP, $(if ($env:USERPROFILE) { Join-Path $env:USERPROFILE 'scoop' }))) {
        if (-not $base) { continue }
        foreach ($relative in @('apps\vscode\current\Code.exe','apps\vscode-insiders\current\Code - Insiders.exe')) {
            $seeds.Add([pscustomobject]@{ Path=(Join-Path $base $relative); Source='Scoop'; Rank=55; Running=$false; ProcessId=0; Context=@{} })
        }
    }
    # Only fixed Start Menu/Desktop locations and one directory level; no drive scan.
    $shell = $null
    try {
        $shell = New-Object -ComObject WScript.Shell
        foreach ($folder in @([Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('CommonPrograms'),[Environment]::GetFolderPath('DesktopDirectory'),[Environment]::GetFolderPath('CommonDesktopDirectory'))) {
            if (-not $folder) { continue }
            $links = @(Get-ChildItem -LiteralPath $folder -Filter '*Code*.lnk' -File -ErrorAction SilentlyContinue)
            foreach ($sub in @(Get-ChildItem -LiteralPath $folder -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '(Visual Studio Code|VS Code|Microsoft)' })) {
                if ($sub.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
                $links += @(Get-ChildItem -LiteralPath $sub.FullName -Filter '*.lnk' -File -ErrorAction SilentlyContinue)
            }
            foreach ($link in $links) {
                $shortcut = $null
                try {
                    $shortcut = $shell.CreateShortcut($link.FullName)
                    $context = Get-MCCodeContext ('"' + $shortcut.TargetPath + '" ' + $shortcut.Arguments)
                    $seeds.Add([pscustomobject]@{ Path=[string]$shortcut.TargetPath; Source='zástupce Windows'; Rank=50; Running=$false; ProcessId=0; Context=$context })
                } catch { }
                finally { if ($shortcut) { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shortcut) } }
            }
        }
    } catch { $notes.Add('Zástupce Windows nebylo možné přečíst.') }
    finally { if ($shell) { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell) } }
    $result = New-Object 'System.Collections.Generic.List[object]'
    $seen = @{}
    foreach ($seed in @($seeds | Sort-Object Rank,Path)) {
        $exe = Get-MCCodeExecutable ([string]$seed.Path)
        if (-not $exe) { continue }
        # Avoid preferring an additional default-data candidate over the running
        # instance's explicitly configured extension/data directories.
        if (-not $seed.Running -and $runningRoots.ContainsKey($exe)) { continue }
        if ($seed.Running) { $runningRoots[$exe] = $true }
        $ctx = $seed.Context
        $id = ($exe + '|' + [string]$ctx.UserDataDir + '|' + [string]$ctx.ExtensionsDir + '|' + [string]$ctx.Profile).ToLowerInvariant()
        if ($seen.ContainsKey($id)) { continue }; $seen[$id] = $true
        $channel = if ([IO.Path]::GetFileName($exe) -eq 'Code.exe') { 'VS Code' } else { 'VS Code Insiders' }
        $version = ''; try { $version = [Diagnostics.FileVersionInfo]::GetVersionInfo($exe).ProductVersion } catch { }
        $display = "$channel — $($seed.Source) — $exe"
        if ($ctx.UserDataDir) { $display += " — data: $($ctx.UserDataDir)" }
        if ($ctx.Profile) { $display += " — profil: $($ctx.Profile)" }
        $result.Add([pscustomobject]@{ Executable=$exe; ResourceVersion=$version; Source=$seed.Source; Running=[bool]$seed.Running; ProcessId=$seed.ProcessId; UserDataDir=[string]$ctx.UserDataDir; ExtensionsDir=[string]$ctx.ExtensionsDir; Profile=[string]$ctx.Profile; ContextWarning=[string]$ctx.ContextWarning; Display=$display })
    }
    $script:MCCodeDiscoveryNotes = @($notes.ToArray())
    return $result.ToArray()
}
