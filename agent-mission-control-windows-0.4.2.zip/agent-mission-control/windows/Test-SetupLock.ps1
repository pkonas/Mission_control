﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Run','Hold','Abandon')][string]$TestMode='Run',
    [string]$MutexName='', [string]$Fixture=''
)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'Setup-Lock.ps1')
$script:LogBox=$null
if ($TestMode -ne 'Run') {
    if ($MutexName -notmatch '^Local\\MCSetupLock-Test-[a-f0-9]{32}$' -or
        -not [IO.Path]::IsPathRooted($Fixture) -or
        [IO.Path]::GetFileName($Fixture) -notmatch '^mc-setup-lock-test-[a-f0-9]{32}$' -or
        -not [IO.Directory]::Exists($Fixture)) { throw 'Invalid isolated mutex test fixture.' }
    $lease=Enter-MCSetupMutex $MutexName
    if ($null -eq $lease) { throw 'Isolated child mutex unexpectedly busy.' }
    [IO.File]::WriteAllText((Join-Path $Fixture 'ready'), 'ready')
    $clock=[Diagnostics.Stopwatch]::StartNew()
    while (-not [IO.File]::Exists((Join-Path $Fixture 'release'))) {
        if ($clock.Elapsed.TotalSeconds -gt 12) { Exit-MCSetupMutex $lease; exit 3 }
        Start-Sleep -Milliseconds 30
    }
    if ($TestMode -eq 'Abandon') {
        # The parent retains a handle to this TEST mutex. Exit while owning it
        # to exercise the actual .NET AbandonedMutexException recovery path.
        [Environment]::Exit(0)
    }
    Exit-MCSetupMutex $lease
    exit 0
}
$script:checks=0
function Assert-MCTest([bool]$Condition,[string]$Label) {
    if (-not $Condition) { throw ('Setup lock test failed: '+$Label) }
    $script:checks++; Write-Output ('PASS '+$Label)
}
function Start-MCTestChild([string]$Mode,[string]$Name,[string]$Folder) {
    $info=New-Object Diagnostics.ProcessStartInfo
    $info.FileName=[Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
    $argv=@('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$PSCommandPath,
        '-TestMode',$Mode,'-MutexName',$Name,'-Fixture',$Folder)
    $info.Arguments=(($argv | ForEach-Object { ConvertTo-MCArgument $_ }) -join ' ')
    $info.UseShellExecute=$false; $info.CreateNoWindow=$true
    $info.RedirectStandardOutput=$true; $info.RedirectStandardError=$true
    $p=New-Object Diagnostics.Process; $p.StartInfo=$info
    try {
        if (-not $p.Start()) { throw 'Cannot start isolated test worker.' }
        return [pscustomobject]@{ Process=$p; Out=$p.StandardOutput.ReadToEndAsync(); Err=$p.StandardError.ReadToEndAsync() }
    } catch { $p.Dispose(); throw }
}
function Wait-MCTestReady($Child,[string]$Folder) {
    $watch=[Diagnostics.Stopwatch]::StartNew()
    while (-not [IO.File]::Exists((Join-Path $Folder 'ready'))) {
        if ($Child.Process.HasExited) { throw ('Isolated test worker exited: '+$Child.Err.GetAwaiter().GetResult()) }
        if ($watch.Elapsed.TotalSeconds -gt 8) { throw 'Isolated lock test worker did not become ready.' }
        Start-Sleep -Milliseconds 30
    }
}
function Stop-MCTestChild($Child,[string]$Folder) {
    if ($null -eq $Child) { return }
    try {
        if (-not $Child.Process.HasExited) {
            [IO.File]::WriteAllText((Join-Path $Folder 'release'),'release')
            if (-not $Child.Process.WaitForExit(3000)) {
                # Only the exact test child represented by this retained handle.
                # No process searches or broad kills; real workers are untouched.
                $Child.Process.Kill(); [void]$Child.Process.WaitForExit(3000)
            }
        }
    } finally { $Child.Process.Dispose() }
}
$root=Join-Path ([IO.Path]::GetTempPath()) ('mc-setup-lock-test-'+[Guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($root)
$name='Local\MCSetupLock-Test-'+[Guid]::NewGuid().ToString('N')
$child=$null; $lease=$null; $observer=$null
try {
    # Parse all bundled scripts in the real PowerShell before application changes.
    foreach ($file in Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1') {
        $tokens=$null; $errors=$null
        [void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
        if ($errors.Count) { throw ($errors | Out-String) }
    }
    Assert-MCTest $true 'bundled PowerShell scripts parse'
    $lease=Enter-MCSetupMutex $name
    Assert-MCTest ($null -ne $lease) 'free mutex acquired'
    Exit-MCSetupMutex $lease; Exit-MCSetupMutex $lease; $lease=$null
    Assert-MCTest $true 'release is idempotent'
    $child=Start-MCTestChild Hold $name $root
    Wait-MCTestReady $child $root
    $lease=Enter-MCSetupMutex $name
    Assert-MCTest ($null -eq $lease) 'live separate process excludes entry'
    [IO.File]::WriteAllText((Join-Path $root 'release'),'release')
    Assert-MCTest ($child.Process.WaitForExit(3000)) 'holder exits normally'
    Assert-MCTest ($child.Process.ExitCode -eq 0) 'holder reports success'
    Stop-MCTestChild $child $root; $child=$null
    $lease=Enter-MCSetupMutex $name
    Assert-MCTest ($null -ne $lease) 'released process does not leave a busy lock'
    Exit-MCSetupMutex $lease; $lease=$null
    try {
        $lease=Enter-MCSetupMutex $name
        throw 'expected test failure'
    } catch {
        if ($_.Exception.Message -ne 'expected test failure') { throw }
    } finally { Exit-MCSetupMutex $lease; $lease=$null }
    $lease=Enter-MCSetupMutex $name
    Assert-MCTest ($null -ne $lease) 'finally releases on an operation exception'
    Exit-MCSetupMutex $lease; $lease=$null
    foreach ($file in @('ready','release')) { [IO.File]::Delete((Join-Path $root $file)) }
    $child=Start-MCTestChild Abandon $name $root
    Wait-MCTestReady $child $root
    $observer=[Threading.Mutex]::OpenExisting($name)
    [IO.File]::WriteAllText((Join-Path $root 'release'),'release')
    Assert-MCTest ($child.Process.WaitForExit(3000)) 'test process abandons mutex and exits'
    Assert-MCTest ($child.Process.ExitCode -eq 0) 'abandoning child exits without forced termination'
    Stop-MCTestChild $child $root; $child=$null
    $lease=Enter-MCSetupMutex $name
    Assert-MCTest ($null -ne $lease -and $lease.Abandoned) 'abandoned .NET mutex transfers ownership'
    Exit-MCSetupMutex $lease; $lease=$null
    [IO.File]::WriteAllText((Join-Path $root 'setup-owner.json'),'{"processId":999999,"obsolete":true}')
    $lease=Enter-MCSetupMutex $name
    Assert-MCTest ($null -ne $lease) 'obsolete diagnostic JSON does not authorize or prevent locking'
    Exit-MCSetupMutex $lease; $lease=$null
    Write-Output ("MC_SETUP_LOCK_TEST_OK: $script:checks checks; PowerShell $($PSVersionTable.PSVersion)")
} finally {
    Exit-MCSetupMutex $lease
    if ($null -ne $observer) { $observer.Dispose() }
    Stop-MCTestChild $child $root
    if ([IO.Directory]::Exists($root)) { [IO.Directory]::Delete($root,$true) }
}
