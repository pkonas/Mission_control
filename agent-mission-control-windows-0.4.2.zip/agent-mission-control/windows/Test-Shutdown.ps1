﻿#requires -Version 5.1
# Non-destructive Windows smoke test. The child processes receive an isolated
# LOCALAPPDATA, so the controller cannot target the real installed application.
# This script was included, but NOT executed in the Linux build environment.
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
$script:LogBox = $null
$oldLocal = $env:LOCALAPPDATA
$sandbox = Join-Path ([IO.Path]::GetTempPath()) ('MC-stop-test-' + [Guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($sandbox)
try {
    $env:LOCALAPPDATA = $sandbox
    $controller = Join-Path $PSScriptRoot 'bin\MissionControlStop.exe'
    $tray = Join-Path $PSScriptRoot 'bin\MissionControl.exe'
    $r = Invoke-MCProcess $controller @('--check') 8
    if ($r.ExitCode -ne 0 -or $r.StdOut.Trim() -ne 'MCSTOP_READY 0.4.2') { throw 'Controller preflight failed.' }
    Write-Host 'PASS actual Windows CLI parser: quoted --check'
    $r = Invoke-MCProcess $tray @('--quit') 8
    if ($r.ExitCode -ne 0) { throw 'Quoted --quit with no running tray failed.' }
    if (Test-Path -LiteralPath (Join-Path $sandbox 'AgentMissionControl')) { throw '--quit unexpectedly created application data.' }
    Write-Host 'PASS quoted --quit: no tray, no application data created'
    $r = Invoke-MCProcess $controller @('--stop') 8
    if ($r.ExitCode -ne 0 -or $r.StdOut -notmatch 'MCSTOP_ALREADY_STOPPED') { throw 'Isolated controller no-op failed.' }
    Write-Host 'PASS controller on isolated empty application root'
    $r = Invoke-MCProcess $controller @('--stop','--background') 8
    if ($r.ExitCode -ne 64) { throw 'Controller accepted an invalid mode.' }
    $r = Invoke-MCProcess $tray @('--invalid') 8
    if ($r.ExitCode -ne 64) { throw 'Tray accepted an invalid mode.' }
    Write-Host 'PASS invalid modes fail without starting a GUI'
    Write-Host '5 isolated Windows smoke checks passed. Real upgrade/repair/uninstall are not tested by this script.'
} finally {
    $env:LOCALAPPDATA = $oldLocal
    if (Test-Path -LiteralPath $sandbox) { Remove-Item -LiteralPath $sandbox -Recurse -Force }
}
