﻿#requires -Version 5.1
# Runs the shipped PowerShell writer on real files in an isolated TEMP directory.
# Does NOT install/uninstall Mission Control or touch registry, projects or agents.
param([switch]$ReproduceLegacy)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
$count = 0
function Assert-MCTest($Condition, [string]$Label) {
    if (-not $Condition) { throw "FAIL: $Label" }
    $script:count++; Write-Host "PASS: $Label"
}
function Assert-MCThrows([scriptblock]$Operation, [string]$Label) {
    $thrown = $false
    try { & $Operation } catch { $thrown = $true }
    Assert-MCTest $thrown $Label
}
foreach ($file in Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1') {
    $tokens = $null; $errors = $null
    [void][Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors)
    Assert-MCTest ($errors.Count -eq 0) ("PowerShell parser: " + $file.Name)
}
$root = Join-Path ([IO.Path]::GetTempPath()) ('mc-write-check-' + [Guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($root)
try {
    $data = Join-Path $root 'petr test [1] & žluťoučký'
    [void][IO.Directory]::CreateDirectory($data)
    $result = Test-MCAtomicWrite $data
    Assert-MCTest ($result.Checks -eq 12) 'automatic preflight runs 12 real writes and byte comparisons'
    Assert-MCTest (@(Get-ChildItem -LiteralPath $data -Force).Count -eq 0) 'preflight removes only its fixture'
    $file = Join-Path $data 'port.txt'
    Write-MCAtomic $file '4317'
    Assert-MCTest ([IO.File]::ReadAllText($file) -ceq '4317') 'first install creates port file'
    Write-MCAtomic $file '4317'
    Assert-MCTest ([IO.File]::ReadAllText($file) -ceq '4317') 'upgrade with existing port (original failure path)'
    Write-MCAtomic $file '5432'
    Assert-MCTest ([IO.File]::ReadAllText($file) -ceq '5432') 'upgrade with changed port'
    Write-MCAtomic $file '5432'
    Assert-MCTest ([IO.File]::ReadAllText($file) -ceq '5432') 'repeated repair'
    $cache = Join-Path $data 'current.json'
    Write-MCAtomic $cache '{"version":"0.2.0"}'
    Write-MCAtomic $cache '{"version":"0.4.2"}'
    Assert-MCTest (([IO.File]::ReadAllText($cache) | ConvertFrom-Json).version -eq '0.4.2') 'existing maintenance cache is replaced'
    $bytes = [IO.File]::ReadAllBytes($file)
    Assert-MCTest ([Convert]::ToBase64String($bytes) -ceq [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes('5432'))) 'UTF-8 without BOM'
    Write-MCAtomic $file ''
    Assert-MCTest (([IO.FileInfo]::new($file)).Length -eq 0) 'empty replacement text is supported'
    Write-MCAtomic $file 'restore'
    Assert-MCTest (@(Get-ChildItem -LiteralPath $data -Force).Count -eq 2) 'successful replacements leave no backup or staging files'
    Assert-MCThrows { Write-MCAtomic '' 'bad' } 'reject empty path'
    Assert-MCThrows { Write-MCAtomic $null 'bad' } 'reject null path'
    Assert-MCThrows { Write-MCAtomic 'relative.txt' 'bad' } 'reject relative path'
    Assert-MCThrows { Write-MCAtomic $data 'bad' } 'reject directory as destination'
    Assert-MCThrows { Write-MCAtomic (Join-Path (Join-Path $data 'missing') 'port.txt') 'bad' } 'reject nonexistent parent'
    Assert-MCTest ([IO.File]::ReadAllText($file) -ceq 'restore') 'invalid-path failures preserve real fixture data'
    if ($env:OS -eq 'Windows_NT') {
        $lock = [IO.FileStream]::new($file, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
        try {
            Assert-MCThrows { Write-MCAtomic $file 'must not replace locked data' } 'sharing violation is not hidden by a delete-and-move fallback'
        } finally { $lock.Dispose() }
        Assert-MCTest ([IO.File]::ReadAllText($file) -ceq 'restore') 'locked destination remains intact'
    } else { Write-Host 'SKIP: Windows sharing violation semantics (requires Windows)' }
    if ($ReproduceLegacy) {
        $legacySource = Join-Path $root 'legacy-source.txt'; $legacyTarget = Join-Path $root 'legacy-target.txt'
        [IO.File]::WriteAllText($legacySource, 'new'); [IO.File]::WriteAllText($legacyTarget, 'old')
        try {
            [IO.File]::Replace($legacySource, $legacyTarget, $null)
            Write-Host 'LEGACY: this runtime did not reproduce null-to-empty binding; no Windows 5.1 claim is made.'
        } catch { Write-Host ('LEGACY_REPRODUCED: ' + $_.Exception.Message) }
    }
} finally {
    if ([IO.Directory]::Exists($root)) { [IO.Directory]::Delete($root, $true) }
}
Write-Host "$count assertions passed on $($PSVersionTable.PSVersion) / $([Environment]::OSVersion)."
