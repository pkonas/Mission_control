'use strict';
/** Resolve the real VS Code CLI without running code.cmd or guessing the newest
 * commit directory. Microsoft's active launcher is authoritative, including
 * builds with <commit>/resources/app/out/cli.js. No recursive disk scan.
 */
const fs = require('node:fs');
const path = require('node:path');
function file(p) { try { return fs.statSync(p).isFile(); } catch { return false; } }
function directory(p) { try { return fs.statSync(p).isDirectory(); } catch { return false; } }
function same(a,b) { return path.resolve(a).toLowerCase() === path.resolve(b).toLowerCase(); }
function inside(root,p) { const rel=path.relative(root,p); return rel!=='' && !rel.startsWith('..'+path.sep) && rel!=='..' && !path.isAbsolute(rel); }
function expandLauncherToken(token, launcher) {
  if (!/^%~dp0/i.test(token)) throw new Error('Nepodporovaný formát spouštěče VS Code.');
  const suffix=token.slice(5);
  if (/[%\x00\r\n]/.test(suffix)) throw new Error('Dynamické proměnné ve spouštěči nejsou podporovány.');
  return path.resolve(path.dirname(launcher), ...suffix.split(/[\\/]/));
}
function parseLauncher(text, launcher, executable) {
  if (text.length>65536) throw new Error('Spouštěč VS Code je neočekávaně velký.');
  const matches=[...text.matchAll(/^\s*"(%~dp0[^"\r\n]+\.exe)"\s+"(%~dp0[^"\r\n]+[\\/]cli\.js)"\s+%\*\s*$/gim)];
  if (matches.length!==1) throw new Error('Nelze jednoznačně přečíst CLI z aktivního code.cmd. Spouštěč nebyl proveden.');
  const target=expandLauncherToken(matches[0][1],launcher);
  const cli=expandLauncherToken(matches[0][2],launcher);
  const root=path.dirname(executable);
  if (!same(target,executable)) throw new Error('code.cmd odkazuje na jiné Code.exe; odmítám smíchat dvě instalace.');
  const rel=path.relative(root,cli).split(path.sep).join('/');
  if (!inside(root,cli) || !/^(?:[a-f0-9]{8,40}\/)?resources\/app\/out\/cli\.js$/i.test(rel)) {
    throw new Error('CLI odkazuje mimo podporovanou strukturu zvolené instalace.');
  }
  return cli;
}
function resolveInstallation(executable, {resourceVersion=''}={}) {
  if (typeof executable!=='string' || !path.isAbsolute(executable)) throw new Error('Cesta k VS Code musí být absolutní.');
  const name=path.basename(executable);
  if (!/^(Code|Code - Insiders)\.exe$/i.test(name) || !file(executable)) throw new Error('Zvolené Code.exe neexistuje nebo nejde o podporovanou desktopovou edici.');
  const root=path.dirname(executable), insiders=/Insiders/i.test(name);
  const launcher=path.join(root,'bin',insiders?'code-insiders.cmd':'code.cmd');
  let cli, method;
  if (file(launcher)) {
    cli=parseLauncher(fs.readFileSync(launcher,'utf8').replace(/^\uFEFF/,''),launcher,executable);
    method='active-launcher';
    // Do not silently use stale resources after a partial VS Code update.
    if (!file(cli)) throw new Error('Aktivní code.cmd odkazuje na chybějící CLI. Dokončete aktualizaci nebo opravte samotné VS Code.');
  } else {
    const version=String(resourceVersion).trim();
    if (/^[a-f0-9]{8,40}$/i.test(version)) {
      cli=path.join(root,version,'resources','app','out','cli.js');method='executable-version';
    } else {
      cli=path.join(root,'resources','app','out','cli.js');method='legacy-layout';
    }
    if (!file(cli)) throw new Error('Chybí code.cmd i odpovídající CLI. Verzi nevybírám odhadem z náhodné podsložky.');
  }
  const app=path.dirname(path.dirname(cli));
  const metadataPath=path.join(app,'product.json');
  let metadata={};
  if (file(metadataPath)) {
    try { metadata=JSON.parse(fs.readFileSync(metadataPath,'utf8').replace(/^\uFEFF/,'')); }
    catch { throw new Error('Soubor product.json zvolené instalace je poškozený.'); }
    if (metadata.applicationName && metadata.applicationName!==(insiders?'code-insiders':'code')) {
      throw new Error('Metadata CLI neodpovídají zvolené edici VS Code.');
    }
  }
  return {executable, cli, launcher:file(launcher)?launcher:null, method,
    portable:!('target' in metadata)&&directory(path.join(root,'data')),
    product:insiders?'VS Code Insiders':'VS Code',
    resourceVersion:path.relative(root,cli).split(path.sep).length===5?path.relative(root,cli).split(path.sep)[0]:''};
}
module.exports={parseLauncher,resolveInstallation};
