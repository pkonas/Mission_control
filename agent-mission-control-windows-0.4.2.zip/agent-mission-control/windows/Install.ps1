﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Auto','Install','Update','Repair','Uninstall')][string]$Mode = 'Auto',
    [switch]$Unattended, [int]$Port = 4317, [switch]$NoAutoStart, [switch]$EnableAutoStart,
    [switch]$NoOpen, [switch]$SkipBridge, [switch]$RemoveData, [switch]$RemoveBridge,
    [string]$CodePath = '', [string]$CodeProfile = '', [string]$PayloadArchive = '',
    [string]$CodeUserDataDir = '', [string]$CodeExtensionsDir = ''
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
. (Join-Path $PSScriptRoot 'Common.ps1')
. (Join-Path $PSScriptRoot 'Code-Discovery.ps1')
. (Join-Path $PSScriptRoot 'Setup-Lock.ps1')
$script:Source = Split-Path $PSScriptRoot -Parent
$script:InstallDir = Join-Path $env:LOCALAPPDATA 'Programs\AgentMissionControl'
$script:DataDir = Join-Path $env:LOCALAPPDATA 'AgentMissionControl'
$script:CacheDir = Join-Path $script:DataDir 'maintenance'
$script:LinkDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Mission Control'
$script:RunKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$script:UninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AgentMissionControl'
$script:Version = '0.4.2'
$script:NodeVersion = '24.21.0'
$script:NodeZipHash = '158f7685b44de51f6c0df1d153526cbcd3e1bc739a8dfc607721cef75de9e541'
$script:NodeExeHash = 'ba4e6d110e8c1592a1ecd390f6b05f3da124b13871a5be62b341a07a853c6c32'
$script:Installing = $false; $script:LogBox = $null; $script:LogPath = $null
$script:SetupLines = New-Object 'System.Collections.Generic.List[string]'
$script:Warnings = 0
$script:DetectedCodes = @(); $script:SelectedCodeTarget = $null
$script:BridgeUserDataDir = $CodeUserDataDir; $script:BridgeExtensionsDir = $CodeExtensionsDir
$global:MCInstallFailed = $false; $global:MCSetupExitCode = 0
function Write-ProgressLine([string]$Text) {
    $line = ('[{0:HH:mm:ss}] {1}' -f [DateTime]::Now, $Text)
    $script:SetupLines.Add($line)
    if ($script:LogPath) { try { [IO.File]::AppendAllText($script:LogPath, $line + "`r`n", [Text.UTF8Encoding]::new($false)) } catch {} }
    if ($script:LogBox) { $script:LogBox.AppendText($line + "`r`n"); [Windows.Forms.Application]::DoEvents() }
    else { Write-Host $line }
}
function Write-MCWarning([string]$Text) { $script:Warnings++; Write-ProgressLine ("UPOZORNĚNÍ: $Text") }
function Get-MCInstallation {
    Assert-MCNotLink $script:InstallDir
    $registered = Get-ItemProperty -LiteralPath $script:UninstallKey -ErrorAction SilentlyContinue
    $ownedRegistry = $false
    if ($registered -and $registered.InstallLocation) {
        $ownedRegistry = [IO.Path]::GetFullPath($registered.InstallLocation).TrimEnd('\') -eq [IO.Path]::GetFullPath($script:InstallDir).TrimEnd('\')
    }
    $marker = $null
    try { $marker = Get-Content -LiteralPath (Join-Path $script:InstallDir 'install-id.json') -Raw | ConvertFrom-Json } catch {}
    $ownedMarker = $marker -and $marker.app -eq 'agent-mission-control'
    $exists = Test-Path -LiteralPath $script:InstallDir
    $version = if ($ownedMarker) { [string]$marker.version } elseif ($ownedRegistry) { [string]$registered.DisplayVersion } else { '' }
    $state = 'Absent'
    if ($exists -and -not ($ownedMarker -or $ownedRegistry)) { $state = 'Conflict' }
    elseif ($ownedMarker -or $ownedRegistry) {
        $state = 'Installed'
        foreach ($f in @('install-id.json','MissionControl.exe','runtime\node.exe','src\server.mjs')) {
            if (-not (Test-Path -LiteralPath (Join-Path $script:InstallDir $f) -PathType Leaf)) { $state = 'Damaged' }
        }
    }
    $auto = (Get-ItemProperty -LiteralPath $script:RunKey -Name 'AgentMissionControl' -ErrorAction SilentlyContinue).AgentMissionControl
    return [pscustomobject]@{ State=$state; Version=$version; AutoStart=[bool]$auto }
}
function Remove-MCAutoStart {
    if (Test-Path -LiteralPath $script:RunKey) {
        $key = Get-Item -LiteralPath $script:RunKey
        if ($key.GetValueNames() -contains 'AgentMissionControl') { Remove-ItemProperty -LiteralPath $script:RunKey -Name 'AgentMissionControl' -ErrorAction Stop }
    }
}
function New-MCShortcut([string]$Name, [string]$Target, [string]$Arguments = '') {
    [void][IO.Directory]::CreateDirectory($script:LinkDir)
    $path = Join-Path $script:LinkDir $Name
    Assert-MCNotLink $path
    $shell = New-Object -ComObject WScript.Shell
    try {
        $shortcut = $shell.CreateShortcut($path); $shortcut.TargetPath = $Target; $shortcut.Arguments = $Arguments
        $shortcut.WorkingDirectory = $env:TEMP; $shortcut.Save()
    } finally { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell) }
}
function Stop-MCApplication {
    # Never run a tray executable (old or new) to stop the installed application.
    # The headless controller verifies path + SID + Windows session, retains
    # process handles, and cannot start a hub or an application window.
    $stopper = Join-Path $script:Source 'windows\bin\MissionControlStop.exe'
    $check = Invoke-MCProcess $stopper @('--check') 8
    if ($check.ExitCode -ne 0 -or $check.StdOut.Trim() -ne "MCSTOP_READY $($script:Version)") {
        throw 'Samostatný řadič zastavení neprošel kontrolou. Instalace nic neukončila ani nepřepsala.'
    }
    Write-ProgressLine 'Samostatný řadič zastavení je připraven; nevytváří další tray aplikaci.'
    Write-ProgressLine 'Zastavuji ověřenou instalaci Mission Control. VS Code ani agenty neukončuji.' 
    $result = Invoke-MCProcess $stopper @('--stop') 30
    foreach ($line in (($result.StdOut + "`n" + $result.StdErr) -split '\r?\n')) {
        if ($line.Trim()) { Write-ProgressLine ('Řadič zastavení: ' + $line.Trim()) }
    }
    if ($result.ExitCode -ne 0) {
        throw "Ukončení Mission Control nebylo ověřeno (kód $($result.ExitCode)). Soubory instalace se nepřepíší. Viz řádky MCSTOP v protokolu; nepoužívejte plošné ukončování node.exe ani VS Code."
    }
    if ($result.StdOut -notmatch 'MCSTOP_(VERIFIED_STOPPED|ALREADY_STOPPED)') {
        throw 'Řadič nevrátil potvrzení o zastavení. Soubory instalace se nepřepíší.'
    }
    if ($result.StdOut -match 'MCSTOP_FORCED_VERIFIED_TRAY') {
        Write-MCWarning 'Původní spouštěč nereagoval na běžné ukončení. Byl ukončen pouze ověřený proces Mission Control; jeho vlastní hub byl následně ověřen jako ukončený.'
    }
    if ($result.StdOut -match 'MCSTOP_ALREADY_STOPPED') {
        Write-ProgressLine 'Mission Control již neběží. Pokračuji bez spouštění pomocné tray aplikace.'
    } else {
        Write-ProgressLine 'Ukončení Mission Control a pozorovaného vlastního hubu bylo ověřeno.'
    }
    return [bool]($result.StdOut -match 'MCSTOP_VERIFIED_TRAY')
}
function Resolve-MCCode([string]$Selected = '') {
    $exe = Get-MCCodeExecutable $Selected
    if (-not $exe) {
        $script:DetectedCodes = @(Get-MCCodeCandidates (Join-Path $script:DataDir 'vscode-target.json'))
        if (-not $Selected -and $script:DetectedCodes.Count) { return $script:DetectedCodes[0] }
        if ($Selected) { Write-ProgressLine 'Zvolená cesta VS Code není platná. Použijte Znovu najít; cíl instalace bez vašeho výběru neměním.' }
        return $null
    }
    if ($script:SelectedCodeTarget -and $script:SelectedCodeTarget.Executable -eq $exe) { return $script:SelectedCodeTarget }
    foreach ($candidate in $script:DetectedCodes) { if ($candidate.Executable -eq $exe) { return $candidate } }
    $version = ''; try { $version = [Diagnostics.FileVersionInfo]::GetVersionInfo($exe).ProductVersion } catch { }
    return [pscustomobject]@{ Executable=$exe; Source='zvolená cesta'; ResourceVersion=$version; Running=$false; Profile=''; UserDataDir=''; ExtensionsDir=''; ContextWarning='' }
}
function Invoke-MCBridge([string]$Action, [string]$Selected, [string]$Profile) {
    $code = Resolve-MCCode $Selected
    if (-not $code) { Write-MCWarning 'Lokální VS Code nebyl dohledán mezi procesy, v registru, PATH ani zástupcích. Použijte Znovu najít nebo vyberte Code.exe. WSL/SSH se instalátorem nemění.'; return }
    $node = Join-Path $script:InstallDir 'runtime\node.exe'
    if (-not (Test-Path -LiteralPath $node) -or (Get-FileHash -LiteralPath $node -Algorithm SHA256).Hash.ToLowerInvariant() -ne $script:NodeExeHash) {
        Write-MCWarning 'Soukromý runtime chybí nebo neprošel kontrolou; bridge nebyl změněn. Lze jej spravovat přímo ve VS Code.'; return
    }
    $operationId = [Guid]::NewGuid().ToString('N')
    $configFile = Join-Path $script:DataDir "bridge-$operationId-config.json"
    $resultFile = Join-Path $script:DataDir "bridge-$operationId-result.json"
    try {
        $userData = $script:BridgeUserDataDir; $extensions = $script:BridgeExtensionsDir
        if (-not $Profile) { $Profile = $code.Profile }
        if (-not $userData) { $userData = $code.UserDataDir }
        if (-not $extensions) { $extensions = $code.ExtensionsDir }
        if ($code.ContextWarning -and -not $script:BridgeUserDataDir -and -not $script:BridgeExtensionsDir) { throw $code.ContextWarning }
        foreach ($p in @($userData,$extensions)) { if ($p -and -not [IO.Path]::IsPathRooted($p)) { throw 'Vlastní datové cesty VS Code musí být absolutní.' } }
        Write-ProgressLine ("VS Code: $($code.Executable); zdroj: $($code.Source); profil: " + $(if ($Profile) { $Profile } else { 'výchozí' }))
        if ($userData) { Write-ProgressLine "Datová složka VS Code: $userData" }
        if ($extensions) { Write-ProgressLine "Složka rozšíření VS Code: $extensions" }
        Write-ProgressLine 'VS Code nechávám otevřený. Spouštím samostatné CLI bez čekání na zavření editoru.'
        $config = @{ executable=$code.Executable; suite=$true; connectorVsix=(Join-Path $script:InstallDir "dist\mission-control-connection-$($script:Version).vsix"); resolveLayout=$true; resourceVersion=$code.ResourceVersion; action=$Action; version=$script:Version; profile=$Profile; userDataDir=$userData; extensionsDir=$extensions; vsix=(Join-Path $script:InstallDir "dist\mission-control-bridge-$($script:Version).vsix") }
        Write-MCAtomic $configFile ($config | ConvertTo-Json)
        $result = Invoke-MCProcess $node @((Join-Path $script:Source 'windows\vscode-cli.cjs'), $configFile, $resultFile) 820
        if (-not (Test-Path -LiteralPath $resultFile)) { throw "Pomocník nevytvořil výsledek. Exit code $($result.ExitCode). $($result.StdErr)" }
        $report = Get-Content -LiteralPath $resultFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($report.layout) { Write-ProgressLine ("CLI: $($report.layout.cli); zdroj cesty: $($report.layout.method)") }
        foreach ($command in $report.commands) {
            Write-ProgressLine ("CLI {0}: exit={1}" -f ($command.args -join ' '), $command.result.exitCode)
            if ($command.result.stdout) { Write-ProgressLine ("stdout: " + $command.result.stdout.Trim()) }
            if ($command.result.stderr) { Write-ProgressLine ("stderr (diagnostika, nikoli automaticky chyba): " + $command.result.stderr.Trim()) }
        }
        if ($report.ok -and $result.ExitCode -eq 0) {
            Write-ProgressLine $report.message
            Write-MCAtomic (Join-Path $script:DataDir 'vscode-target.json') (@{ executable=$code.Executable; profile=$Profile; userDataDir=$userData; extensionsDir=$extensions } | ConvertTo-Json)
            if ($Action -eq 'install') { Write-ProgressLine 'Connection + Bridge jsou na disku ve zvoleném lokálním profilu. Ve VS Code klikněte dole na Mission Control nebo použijte Mission Control: Setup Connection. Místní panel nabídne instalaci bridge do právě otevřeného WSL/SSH okna. Chybí-li i panel, zkontrolujte profil, Enable a po doběhnutí agentů Developer: Reload Window; editor sám nerestartuji.' }
        } else { Write-MCWarning ($report.message + ' Podrobnosti: ' + $resultFile) }
    } catch { Write-MCWarning ('Bridge nebyl ověřen: ' + $_.Exception.Message) }
    finally { if (Test-Path -LiteralPath $configFile) { Remove-Item -LiteralPath $configFile -Force -ErrorAction SilentlyContinue } }
}
function Wait-MCHealth([int]$HubPort, [string]$ExpectedVersion) {
    $deadline = [DateTime]::UtcNow.AddSeconds(30)
    while ([DateTime]::UtcNow -lt $deadline) {
        if ($script:LogBox) { [Windows.Forms.Application]::DoEvents() }
        try {
            $request = [Net.HttpWebRequest]::Create("http://127.0.0.1:$HubPort/healthz")
            $request.Proxy = $null; $request.Timeout = 700; $request.AllowAutoRedirect = $false
            $response = $request.GetResponse()
            try {
                $reader = New-Object IO.StreamReader($response.GetResponseStream())
                try { $health = $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose() }
                $descriptor = Get-Content -LiteralPath (Join-Path $script:DataDir 'connection.json') -Raw | ConvertFrom-Json
                if ($health.ok -and $health.version -eq $ExpectedVersion -and $health.instanceId -match '^[a-f0-9]{32}$' -and $descriptor.instanceId -eq $health.instanceId -and $descriptor.node -eq (Join-Path $script:InstallDir 'runtime\node.exe') -and $descriptor.hub -eq "http://127.0.0.1:$HubPort") { return $true }
            } finally { $response.Dispose() }
        } catch {}
        Start-Sleep -Milliseconds 250
    }
    return $false
}
function Save-MCMetadata {
    $snapshot = @{ Registry=(Get-MCRegistrySnapshot $script:UninstallKey); Files=@{}; Links=@{}; Run=$null }
    $rk = Get-Item -LiteralPath $script:RunKey -ErrorAction SilentlyContinue
    if ($rk -and ($rk.GetValueNames() -contains 'AgentMissionControl')) { $snapshot.Run = $rk.GetValue('AgentMissionControl') }
    foreach ($path in @((Join-Path $script:DataDir 'port.txt'), (Join-Path $script:DataDir 'connection.json'), (Join-Path $script:CacheDir 'current.json'), (Join-Path $script:CacheDir 'Launch.ps1'))) {
        Assert-MCNotLink $path
        $snapshot.Files[$path] = if (Test-Path -LiteralPath $path) { ,([IO.File]::ReadAllBytes($path)) } else { $null }
    }
    foreach ($name in @('Mission Control.lnk','Odinstalovat.lnk','Navod.lnk','Sprava instalace.lnk')) {
        $path = Join-Path $script:LinkDir $name; Assert-MCNotLink $path
        $snapshot.Links[$path] = if (Test-Path -LiteralPath $path) { ,([IO.File]::ReadAllBytes($path)) } else { $null }
    }
    return $snapshot
}
function Restore-MCMetadata($Snapshot) {
    Restore-MCRegistry $script:UninstallKey $Snapshot.Registry
    [void](New-Item -Path $script:RunKey -Force)
    if ($null -ne $Snapshot.Run) { [void](New-ItemProperty -Path $script:RunKey -Name 'AgentMissionControl' -Value $Snapshot.Run -PropertyType String -Force) }
    else { Remove-MCAutoStart }
    foreach ($group in @($Snapshot.Files,$Snapshot.Links)) {
        foreach ($entry in $group.GetEnumerator()) {
            if ($null -eq $entry.Value) { if (Test-Path -LiteralPath $entry.Key) { Remove-Item -LiteralPath $entry.Key -Force } }
            else { [void][IO.Directory]::CreateDirectory((Split-Path $entry.Key -Parent)); [IO.File]::WriteAllBytes($entry.Key, $entry.Value) }
        }
    }
}
function Set-MCMaintenanceCache {
    Set-MCPrivateDirectory $script:CacheDir
    $payload = $PayloadArchive
    $madeArchive = $false
    if (-not $payload -or -not (Test-Path -LiteralPath $payload)) {
        # Source ZIP path: cache an independent copy, never repair from installed files.
        $payload = Join-Path $env:TEMP ("MissionControl-payload-" + [Guid]::NewGuid().ToString('N') + '.zip')
        [IO.Compression.ZipFile]::CreateFromDirectory($script:Source, $payload, [IO.Compression.CompressionLevel]::Optimal, $false)
        $madeArchive = $true
    }
    try {
        $hash = (Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash.ToLowerInvariant()
        $name = "payload-$($script:Version)-$hash.zip"
        $destination = Join-Path $script:CacheDir $name
        Assert-MCNotLink $destination
        if (-not (Test-Path -LiteralPath $destination) -or (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hash) { Copy-Item -LiteralPath $payload -Destination $destination -Force }
        Copy-Item -LiteralPath (Join-Path $script:Source 'windows\Launch-Maintenance.ps1') -Destination (Join-Path $script:CacheDir 'Launch.ps1') -Force
        Write-MCAtomic (Join-Path $script:CacheDir 'current.json') (@{ app='agent-mission-control'; version=$script:Version; file=$name; sha256=$hash } | ConvertTo-Json)
    } finally { if ($madeArchive -and (Test-Path -LiteralPath $payload)) { Remove-Item -LiteralPath $payload -Force } }
}
function Register-MCApplication([bool]$AutoStart) {
    $exe = Join-Path $script:InstallDir 'MissionControl.exe'
    $ps = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $launcher = Join-Path $script:CacheDir 'Launch.ps1'
    $baseArgs = '-NoLogo -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File ' + (ConvertTo-MCArgument $launcher)
    New-MCShortcut 'Mission Control.lnk' $exe
    New-MCShortcut 'Sprava instalace.lnk' $ps ($baseArgs + ' -Mode Auto')
    New-MCShortcut 'Odinstalovat.lnk' $ps ($baseArgs + ' -Mode Uninstall')
    New-MCShortcut 'Navod.lnk' (Join-Path $script:InstallDir 'windows\Navod.html')
    [void](New-Item -Path $script:RunKey -Force)
    if ($AutoStart) {
        $command = '"' + $exe + '" --background'
        if ($command.Length -ge 260) { throw 'Cesta je příliš dlouhá pro automatické spuštění.' }
        [void](New-ItemProperty -Path $script:RunKey -Name 'AgentMissionControl' -Value $command -PropertyType String -Force)
    } else { Remove-MCAutoStart }
    [void](New-Item -Path $script:UninstallKey -Force)
    foreach ($entry in @{
        DisplayName='Agent Mission Control'; DisplayVersion=$script:Version; Publisher='Local Mission Control (neoficialni nastroj)'
        InstallLocation=$script:InstallDir; DisplayIcon=$exe; InstallDate=[DateTime]::Now.ToString('yyyyMMdd')
        UninstallString=('"' + $ps + '" ' + $baseArgs + ' -Mode Uninstall')
        QuietUninstallString=('"' + $ps + '" ' + $baseArgs + ' -Mode Uninstall -Unattended')
        ModifyPath=('"' + $ps + '" ' + $baseArgs + ' -Mode Auto')
    }.GetEnumerator()) { [void](New-ItemProperty -Path $script:UninstallKey -Name $entry.Key -Value $entry.Value -PropertyType String -Force) }
    # Windows Settings has Uninstall; classic Programs and Features also exposes Change.
    [void](New-ItemProperty -Path $script:UninstallKey -Name 'NoModify' -Value 0 -PropertyType DWord -Force)
    [void](New-ItemProperty -Path $script:UninstallKey -Name 'NoRepair' -Value 1 -PropertyType DWord -Force) # repair is inside our Change UI, not MSI repair
}

function Prepare-MCRuntime([string]$stage) {
        $runtime = Join-Path $stage 'runtime'
        $oldNode = Join-Path $script:InstallDir 'runtime\node.exe'
        if ((Test-Path -LiteralPath $oldNode) -and (Get-FileHash -LiteralPath $oldNode -Algorithm SHA256).Hash.ToLowerInvariant() -eq $script:NodeExeHash) {
            Write-ProgressLine 'Používám již ověřený soukromý Node.js runtime.'
            Copy-Item -LiteralPath (Join-Path $script:InstallDir 'runtime') -Destination $runtime -Recurse
        } else {
            $archiveName = "node-v$($script:NodeVersion)-win-x64.zip"
            $archive = Join-Path $stage $archiveName
            $cached = Join-Path $PSScriptRoot "cache\$archiveName"
            if (Test-Path -LiteralPath $cached) {
                Write-ProgressLine 'Načítám přiložený offline archiv runtime.'
                Copy-Item -LiteralPath $cached -Destination $archive
            } else {
                $url = "https://nodejs.org/dist/v$($script:NodeVersion)/$archiveName"
                Write-ProgressLine "Stahuji Node.js $($script:NodeVersion) z nodejs.org…"
                $client = New-Object Net.WebClient
                try {
                    $client.Headers['User-Agent'] = 'MissionControlInstaller/0.4.2'
                    $task = $client.DownloadFileTaskAsync([Uri]$url, $archive)
                    $watch = [Diagnostics.Stopwatch]::StartNew()
                    while (-not $task.IsCompleted) {
                        [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100
                        if ($watch.Elapsed.TotalMinutes -gt 10) { $client.CancelAsync(); throw 'Stažení překročilo limit. Ověřte připojení nebo použijte offline archiv.' }
                    }
                    $task.GetAwaiter().GetResult()
                } finally { $client.Dispose() }
            }
            Write-ProgressLine 'Ověřuji SHA-256 runtime; při neshodě se instalace zastaví.'
            if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $script:NodeZipHash) {
                throw 'Kontrolní součet Node.js neodpovídá připnutému oficiálnímu vydání. Archiv nebyl spuštěn. Neobcházejte tuto kontrolu.'
            }
            [IO.Compression.ZipFile]::ExtractToDirectory($archive, $stage)
            Move-Item -LiteralPath (Join-Path $stage "node-v$($script:NodeVersion)-win-x64") -Destination $runtime
            Remove-Item -LiteralPath $archive -Force
        }
        $node = Join-Path $runtime 'node.exe'
        if ((Get-FileHash -LiteralPath $node -Algorithm SHA256).Hash.ToLowerInvariant() -ne $script:NodeExeHash) { throw 'Neplatný kontrolní součet node.exe.' }
        $run = Invoke-MCProcess $node @('--version') 30
        if ($run.ExitCode -ne 0 -or $run.StdOut.Trim() -ne "v$($script:NodeVersion)") { throw 'Soukromý Node.js nelze spustit. Ověřte pravidla Windows a podporovanou verzi systému.' }
        Write-ProgressLine 'Runtime je připraven. Systémový Node.js ani PATH se nemění.'

}
function Install-MissionControl([string]$Action, [bool]$AutoStart, [bool]$Open, [bool]$InstallBridge, [int]$HubPort, [string]$SelectedCode, [string]$Profile) {
    if ($HubPort -lt 1024 -or $HubPort -gt 65535) { throw 'Port musí být 1024 až 65535.' }
    $existing = Get-MCInstallation
    [void](Resolve-MCMode $Action $existing.State $existing.Version $script:Version)
    Assert-MCTree $script:InstallDir; Assert-MCTree $script:CacheDir; Assert-MCNotLink $script:LinkDir
    $stage = "$($script:InstallDir).staging-$([Guid]::NewGuid().ToString('N'))"
    $backup = "$($script:InstallDir).previous-$([Guid]::NewGuid().ToString('N'))"
    $snapshot = Save-MCMetadata
    $switched = $false; $stopped = $false; $committed = $false; $movedOld = $false; $wasRunning = $false
    $phase = 'kontrola zápisu před změnou instalace'
    try {
        Write-ProgressLine 'Předběžně ověřuji vytvoření a opakované nahrazení souborů. Původní aplikace zatím zůstává beze změny.'
        $probeResult = Test-MCAtomicWrite $script:DataDir
        Write-ProgressLine ("MC_ATOMIC_WRITE_OK: {0} zápisů a kontrol obsahu; PowerShell {1}." -f $probeResult.Checks, $probeResult.PowerShell)
        $phase = 'příprava nových aplikačních souborů'
        Set-MCPrivateDirectory $stage
        Write-ProgressLine "Operace: $Action. Verze $($existing.Version) -> $($script:Version). Data a párovací token zůstávají beze změny."
        foreach ($name in @('src','public','bridge','connector','dist','windows','docs','codex.example.json','package.json','README.cs.md','README.md','LICENSE')) {
            $item = Join-Path $script:Source $name
            if (Test-Path -LiteralPath $item) { Copy-Item -LiteralPath $item -Destination $stage -Recurse -Force }
        }
        Copy-Item -LiteralPath (Join-Path $stage 'windows\bin\MissionControl.exe') -Destination (Join-Path $stage 'MissionControl.exe') -Force
        $phase = 'příprava soukromého runtime'
        Prepare-MCRuntime $stage
        Write-MCAtomic (Join-Path $stage 'install-id.json') (@{ app='agent-mission-control'; version=$script:Version; installedAt=[DateTime]::UtcNow.ToString('o') } | ConvertTo-Json)
        $phase = 'zastavení původní aplikace'
        $wasRunning = Stop-MCApplication; $stopped = $true
        $phase = 'výměna aplikačních souborů'
        if (Test-Path -LiteralPath $script:InstallDir) { Move-Item -LiteralPath $script:InstallDir -Destination $backup; $movedOld = $true }
        Move-Item -LiteralPath $stage -Destination $script:InstallDir; $switched = $true
        $phase = 'uložení portu do port.txt'
        Write-ProgressLine ("Ukládám port: " + (Join-Path $script:DataDir 'port.txt'))
        Write-MCAtomic (Join-Path $script:DataDir 'port.txt') "$HubPort"
        Write-ProgressLine 'MC_PORT_WRITE_OK'
        $phase = 'aktualizace balíčku pro opravu a odinstalování'
        Set-MCMaintenanceCache
        Write-ProgressLine 'MC_MAINTENANCE_CACHE_OK'
        $phase = 'registrace aplikace, zástupců a automatického spuštění'
        Register-MCApplication $AutoStart
        $phase = 'spuštění a ověření nového hubu'
        $descriptorPath = Join-Path $script:DataDir 'connection.json'
        if (Test-Path -LiteralPath $descriptorPath) { Remove-Item -LiteralPath $descriptorPath -Force }
        $exe = Join-Path $script:InstallDir 'MissionControl.exe'
        Start-Process -FilePath $exe -ArgumentList '--background' -WorkingDirectory $env:TEMP
        Write-ProgressLine 'Ověřuji běh nové verze hubu; při selhání obnovím předchozí instalaci…'
        if (-not (Wait-MCHealth $HubPort $script:Version)) { throw 'Nový hub neodpovídá. Zkontrolujte obsazený port, hub.log a pravidla zabezpečení.' }
        $committed = $true
        $phase = 'volitelná instalace bridge a otevření dashboardu'
        if ($InstallBridge) { Invoke-MCBridge 'install' $SelectedCode $Profile }
        if ($Open) { Start-Process -FilePath $exe -WorkingDirectory $env:TEMP }
        Write-ProgressLine "Mission Control $($script:Version) běží. Správa instalace je dostupná v nabídce Start."
        if (Test-Path -LiteralPath $backup) {
            try { Remove-Item -LiteralPath $backup -Recurse -Force }
            catch { Write-MCWarning "Předchozí soubory zůstaly zde: $backup" }
        }
    } catch {
        $failure = $_
        Write-ProgressLine ("Selhání ve fázi: $phase")
        Write-ProgressLine ("Příčina: " + $failure.Exception.GetBaseException().Message)
        if ($failure.ScriptStackTrace) { Write-ProgressLine ("Místo v instalačním kódu: " + $failure.ScriptStackTrace) }
        if (-not $committed -and ($movedOld -or $switched)) {
            Write-ProgressLine 'Provádím obnovu předchozích souborů a registrace…'
            try {
                if ($switched) { [void](Stop-MCApplication); Remove-Item -LiteralPath $script:InstallDir -Recurse -Force }
                if ((Test-Path -LiteralPath $backup) -and -not (Test-Path -LiteralPath $script:InstallDir)) { Move-Item -LiteralPath $backup -Destination $script:InstallDir }
                Restore-MCMetadata $snapshot
                if ($stopped -and $wasRunning -and (Test-Path -LiteralPath (Join-Path $script:InstallDir 'MissionControl.exe'))) {
                    Start-Process -FilePath (Join-Path $script:InstallDir 'MissionControl.exe') -ArgumentList '--background' -WorkingDirectory $env:TEMP
                }
                Write-ProgressLine 'Předchozí soubory a nastavení byly obnoveny; případné dřívější poškození tím není opraveno.'
            } catch { Write-MCWarning ('Automatická obnova není dokončená: ' + $_.Exception.Message + ". Zachovaná záloha: $backup") }
        } elseif (-not $committed) {
            Write-ProgressLine 'Instalace se zastavila před výměnou souborů. Původní soubory a registrace nebyly změněny; obnova není potřeba.'
            if ($stopped -and $wasRunning -and (Test-Path -LiteralPath (Join-Path $script:InstallDir 'MissionControl.exe'))) {
                try { Start-Process -FilePath (Join-Path $script:InstallDir 'MissionControl.exe') -ArgumentList '--background' -WorkingDirectory $env:TEMP }
                catch { Write-MCWarning ('Původní aplikaci nelze znovu spustit: ' + $_.Exception.Message) }
            }
        }
        throw $failure
    } finally {
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
    }
}
function Uninstall-MissionControl([bool]$DeleteData, [bool]$DeleteBridge, [string]$SelectedCode, [string]$Profile) {
    $existing = Get-MCInstallation
    [void](Resolve-MCMode 'Uninstall' $existing.State $existing.Version $script:Version)
    Assert-MCTree $script:InstallDir; Assert-MCTree $script:CacheDir; Assert-MCNotLink $script:LinkDir
    if ($DeleteData) { Assert-MCTree $script:DataDir }
    $snapshot = Save-MCMetadata
    $backup = "$($script:InstallDir).removing-$([Guid]::NewGuid().ToString('N'))"
    [void](Stop-MCApplication)
    # Own Codex hook handlers must not point at a runtime being removed.
    # Custom Codex homes on other hosts remain an explicit Bridge command.
    $cleanupNode = Join-Path $script:InstallDir 'runtime\node.exe'
    $cleanupScript = Join-Path $script:Source 'windows\remove-codex-hooks.cjs'
    if ((Test-Path -LiteralPath $cleanupNode) -and (Test-Path -LiteralPath $cleanupScript)) {
        try {
            if ((Get-FileHash -LiteralPath $cleanupNode -Algorithm SHA256).Hash.ToLowerInvariant() -eq $script:NodeExeHash) {
                $cleaned = Invoke-MCProcess $cleanupNode @($cleanupScript, $cleanupNode) 20
                if ($cleaned.ExitCode -ne 0) { Write-MCWarning 'Vlastní Codex hooky se nepodařilo odebrat. Použijte Bridge: Remove Codex Hooks from This Host.' }
                else { Write-ProgressLine 'Zkontrolovány vlastní Codex hooky navázané na odinstalovaný runtime. Ostatní hooky/politiky zůstávají zachované.' }
            }
        } catch { Write-MCWarning 'Kontrola vlastních Codex hooků nebyla dokončena; konfiguraci lze zkontrolovat v Codex /hooks.' }
    }
    # Optional extension changes cannot be rolled back by the app's file transaction.
    if ($DeleteBridge) { Invoke-MCBridge 'uninstall' $SelectedCode $Profile }
    try {
        if (Test-Path -LiteralPath $script:InstallDir) { Move-Item -LiteralPath $script:InstallDir -Destination $backup }
        Remove-MCAutoStart
        if (Test-Path -LiteralPath $script:UninstallKey) { Remove-Item -LiteralPath $script:UninstallKey -Recurse -Force }
        foreach ($name in @('Mission Control.lnk','Odinstalovat.lnk','Navod.lnk','Sprava instalace.lnk')) {
            $link = Join-Path $script:LinkDir $name
            if (Test-Path -LiteralPath $link) { Remove-Item -LiteralPath $link -Force }
        }
    } catch {
        $failure = $_
        if ((Test-Path -LiteralPath $backup) -and -not (Test-Path -LiteralPath $script:InstallDir)) { Move-Item -LiteralPath $backup -Destination $script:InstallDir }
        Restore-MCMetadata $snapshot
        throw $failure
    }
    Set-Location $env:TEMP
    # Registration has now been removed. Locked leftover files are reported, never concealed.
    if (Test-Path -LiteralPath $backup) {
        try { Remove-Item -LiteralPath $backup -Recurse -Force }
        catch { Write-MCWarning "Aplikace je odregistrována, ale zamčené soubory zůstaly v: $backup" }
    }
    if ((Test-Path -LiteralPath $script:LinkDir) -and @(Get-ChildItem -LiteralPath $script:LinkDir -Force).Count -eq 0) { Remove-Item -LiteralPath $script:LinkDir -Force }
    $descriptor = Join-Path $script:DataDir 'connection.json'
    if (Test-Path -LiteralPath $descriptor) { Remove-Item -LiteralPath $descriptor -Force }
    if (Test-Path -LiteralPath $script:CacheDir) { Remove-Item -LiteralPath $script:CacheDir -Recurse -Force }
    if ($DeleteData) {
        # Do not recreate the deleted data directory just to save the uninstall log.
        $logCopy = Join-Path $env:TEMP ('MissionControl-uninstall-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss') + '.log')
        [IO.File]::WriteAllLines($logCopy, $script:SetupLines, [Text.Encoding]::UTF8); $script:LogPath = $logCopy
        Remove-Item -LiteralPath $script:DataDir -Recurse -Force
        if (Test-Path -LiteralPath 'HKCU:\Software\AgentMissionControl') { Remove-Item -LiteralPath 'HKCU:\Software\AgentMissionControl' -Recurse -Force }
        Write-ProgressLine "Aplikace i její data byly odstraněny. Protokol: $logCopy"
    } else { Write-ProgressLine "Aplikace byla odinstalována. Data a token zůstávají v $script:DataDir pro případnou novou instalaci." }
    Write-ProgressLine 'Rozšíření Codex a Zoo Code, projekty ani WSL/SSH instalace nebyly odinstalovány. U vlastní konfigurace hooků Codexu byl odstraněn pouze nezměněný záznam Mission Control závislý na odebíraném runtime.'
}
function Invoke-MCOperation([string]$Action, [bool]$Auto, [bool]$Open, [bool]$Bridge, [int]$HubPort, [bool]$DeleteData, [bool]$DeleteBridge, [string]$SelectedCode, [string]$Profile) {
    # Only the operation owns the mutex. Idle/completed UI windows hold no lock.
    # Keep the legacy name so a 0.3.0-0.3.3 worker cannot modify files concurrently.
    $lockName = Get-MCSetupMutexName
    $lease = Enter-MCSetupMutex $lockName
    if ($null -eq $lease) {
        throw [InvalidOperationException]::new((Get-MCSetupConflictText $script:DataDir $lockName))
    }
    $ownerWritten = $false
    try {
        $script:Warnings = 0
        Set-MCPrivateDirectory $script:DataDir
        $script:LogPath = Join-Path $script:DataDir ('setup-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff') + '.log')
        Write-MCSetupOwner $script:DataDir $lockName $script:Version $Action
        $ownerWritten = $true
        Write-ProgressLine ("MC_SETUP_LOCK_ACQUIRED: PID $PID; zámek platí jen po dobu operace.")
        if ($lease.Abandoned) { Write-MCWarning 'Předchozí proces opustil zámek. Znovu ověřuji stav instalace; samotné převzetí zámku nepotvrzuje konzistenci souborů.' }
        # Test the actual production mutex code with isolated child processes on
        # this Windows/.NET runtime. Failure leaves the installed application alone.
        Write-ProgressLine 'Ověřuji zámek údržby na oddělených testovacích procesech; aplikace se zatím nemění.'
        $testHost=[Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        $testResult=Invoke-MCProcess $testHost @('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',(Join-Path $PSScriptRoot 'Test-SetupLock.ps1')) 40
        foreach ($testLine in (($testResult.StdOut + "`n" + $testResult.StdErr) -split '\r?\n')) {
            if ($testLine.Trim()) { Write-ProgressLine ('Kontrola zámku: '+$testLine.Trim()) }
        }
        if ($testResult.ExitCode -ne 0 -or $testResult.StdOut -notmatch 'MC_SETUP_LOCK_TEST_OK:') {
            throw 'Kontrola zámku selhala. Původní aplikace nebyla zastavena ani vyměněna; viz diagnostika.'
        }
        # Re-read under the mutex; the UI snapshot may have become outdated.
        $current = Get-MCInstallation
        $action = Resolve-MCMode $Action $current.State $current.Version $script:Version
        if ($action -eq 'Uninstall') { Uninstall-MissionControl $DeleteData $DeleteBridge $SelectedCode $Profile }
        else { Install-MissionControl $action $Auto $Open $Bridge $HubPort $SelectedCode $Profile }
        if ($script:Warnings) { Write-ProgressLine "DOKONČENO S UPOZORNĚNÍMI ($script:Warnings). Viz diagnostika výše."; $global:MCSetupExitCode = 2 }
        else { Write-ProgressLine 'HOTOVO — operace byla dokončena.'; $global:MCSetupExitCode = 0 }
    } finally {
        try {
            if ($ownerWritten) {
                try { Remove-MCSetupOwner $script:DataDir }
                catch { Write-ProgressLine ('Diagnostický záznam se nepodařilo odstranit; sám nic nezamyká: ' + $_.Exception.Message) }
            }
        } finally {
            Exit-MCSetupMutex $lease
            Write-ProgressLine 'MC_SETUP_LOCK_RELEASED: průvodce může zůstat otevřený.'
        }
    }
}
# Environment validation is read-only. No mutex is held merely for opening UI.
try {
    if (-not [Environment]::Is64BitOperatingSystem -or $env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') { throw 'Tento instalátor je pro Windows x64, nikoli ARM64 nebo 32bitové Windows.' }
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    if ($identity.IsSystem) { throw 'Spouštějte instalátor pod svým uživatelským účtem, ne jako SYSTEM.' }
    if ($NoAutoStart -and $EnableAutoStart) { throw 'NoAutoStart a EnableAutoStart nelze použít současně.' }
    $initial = Get-MCInstallation
    $resolvedMode = Resolve-MCMode $Mode $initial.State $initial.Version $script:Version
    if (-not $PSBoundParameters.ContainsKey('Port')) {
        $savedPort = Join-Path $script:DataDir 'port.txt'; $value = 0
        if ((Test-Path -LiteralPath $savedPort) -and [int]::TryParse(([IO.File]::ReadAllText($savedPort)).Trim(), [ref]$value) -and $value -ge 1024 -and $value -le 65535) { $Port = $value }
    }
    $defaultAuto = if ($initial.State -eq 'Absent') { $true } else { $initial.AutoStart }
    if ($NoAutoStart) { $defaultAuto = $false }; if ($EnableAutoStart) { $defaultAuto = $true }
    $script:DetectedCodes = @(Get-MCCodeCandidates (Join-Path $script:DataDir 'vscode-target.json'))
    if (-not $CodePath -and $script:DetectedCodes.Count) {
        $script:SelectedCodeTarget = $script:DetectedCodes[0]
        $CodePath = $script:SelectedCodeTarget.Executable
        if (-not $CodeProfile) { $CodeProfile = $script:SelectedCodeTarget.Profile }
        if (-not $CodeUserDataDir) { $CodeUserDataDir = $script:SelectedCodeTarget.UserDataDir }
        if (-not $CodeExtensionsDir) { $CodeExtensionsDir = $script:SelectedCodeTarget.ExtensionsDir }
    }
    $script:BridgeUserDataDir=$CodeUserDataDir; $script:BridgeExtensionsDir=$CodeExtensionsDir
    if ($Unattended) {
        if (($RemoveData -or $RemoveBridge) -and $resolvedMode -ne 'Uninstall') { throw 'RemoveData/RemoveBridge lze použít pouze s Mode Uninstall.' }
        Invoke-MCOperation $resolvedMode $defaultAuto (-not $NoOpen) (-not $SkipBridge) $Port $RemoveData $RemoveBridge $CodePath $CodeProfile
        return
    }
    [Windows.Forms.Application]::EnableVisualStyles()
    $form = New-Object Windows.Forms.Form
    $form.Text = "Mission Control $script:Version — instalace a údržba"
    $form.ClientSize = New-Object Drawing.Size(780, ([Math]::Min(822, [Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Height - 100)))
    $form.AutoScroll = $true; $form.AutoScrollMinSize = New-Object Drawing.Size(760, 822)
    $form.StartPosition = 'CenterScreen'; $form.FormBorderStyle = 'FixedDialog'; $form.MaximizeBox = $false
    $form.AutoScaleMode = 'Dpi'; $form.Font = New-Object Drawing.Font('Segoe UI', 10)
    $title = New-Object Windows.Forms.Label
    $title.Text = 'Mission Control — správa instalace'; $title.Location = New-Object Drawing.Point(22,18); $title.Size = New-Object Drawing.Size(735,38)
    $title.Font = New-Object Drawing.Font('Segoe UI',18,[Drawing.FontStyle]::Bold); $form.Controls.Add($title)
    $description = New-Object Windows.Forms.Label
    $description.Text = if ($initial.State -eq 'Absent') { 'Nová instalace pro aktuálního uživatele. Hub se spouští automaticky; systémový Node.js, PATH ani firewall se nemění.' } else { "Nalezena verze $($initial.Version) ($($initial.State)). Aktualizace i oprava zachovají data, token, port a nastavení. Oprava znovu nasadí soubory tohoto balíčku." }
    $description.Location = New-Object Drawing.Point(24,65); $description.Size = New-Object Drawing.Size(731,58); $form.Controls.Add($description)
    $modeLabel = New-Object Windows.Forms.Label; $modeLabel.Text = 'Operace:'; $modeLabel.Location = New-Object Drawing.Point(24,132); $modeLabel.Size = New-Object Drawing.Size(110,25); $form.Controls.Add($modeLabel)
    $choice = New-Object Windows.Forms.ComboBox; $choice.DropDownStyle = 'DropDownList'; $choice.Location = New-Object Drawing.Point(142,128); $choice.Size = New-Object Drawing.Size(608,28)
    $actions = New-Object 'System.Collections.Generic.List[string]'
    if ($initial.State -eq 'Absent') { [void]$choice.Items.Add('Nainstalovat'); $actions.Add('Install') }
    else {
        $older = $false
        try { $older = [version]$initial.Version -lt [version]$script:Version } catch {}
        if ($older) { [void]$choice.Items.Add("Aktualizovat na $script:Version"); $actions.Add('Update') }
        [void]$choice.Items.Add("Opravit instalaci soubory verze $script:Version"); $actions.Add('Repair')
        [void]$choice.Items.Add('Odinstalovat'); $actions.Add('Uninstall')
    }
    $form.Controls.Add($choice)
    $auto = New-Object Windows.Forms.CheckBox; $auto.Text='Spouštět hub po přihlášení do Windows'; $auto.Checked=$defaultAuto
    $auto.Location=New-Object Drawing.Point(24,168); $auto.Size=New-Object Drawing.Size(730,26); $form.Controls.Add($auto)
    $open = New-Object Windows.Forms.CheckBox; $open.Text='Po dokončení otevřít dashboard'; $open.Checked=(-not $NoOpen)
    $open.Location=New-Object Drawing.Point(24,197); $open.Size=New-Object Drawing.Size(730,26); $form.Controls.Add($open)
    $bridge = New-Object Windows.Forms.CheckBox; $bridge.Text='Nainstalovat / opravit Connection + Bridge ve zvoleném profilu VS Code'; $bridge.Checked=(-not $SkipBridge)
    $bridge.Location=New-Object Drawing.Point(24,226); $bridge.Size=New-Object Drawing.Size(730,26); $form.Controls.Add($bridge)
    $removeDataBox = New-Object Windows.Forms.CheckBox; $removeDataBox.Text='Odstranit také historii, token a nastavení Mission Control (nevratné)'; $removeDataBox.Checked=[bool]$RemoveData
    $removeDataBox.Location=New-Object Drawing.Point(24,168); $removeDataBox.Size=New-Object Drawing.Size(730,26); $form.Controls.Add($removeDataBox)
    $removeBridgeBox = New-Object Windows.Forms.CheckBox; $removeBridgeBox.Text='Odinstalovat také Connection + Bridge ze zvoleného lokálního profilu'; $removeBridgeBox.Checked=[bool]$RemoveBridge
    $removeBridgeBox.Location=New-Object Drawing.Point(24,197); $removeBridgeBox.Size=New-Object Drawing.Size(730,26); $form.Controls.Add($removeBridgeBox)
    $portLabel=New-Object Windows.Forms.Label; $portLabel.Text='Port hubu:'; $portLabel.Location=New-Object Drawing.Point(24,267); $portLabel.Size=New-Object Drawing.Size(100,25); $form.Controls.Add($portLabel)
    $portInput=New-Object Windows.Forms.NumericUpDown; $portInput.Minimum=1024; $portInput.Maximum=65535; $portInput.Value=$Port
    $portInput.Location=New-Object Drawing.Point(142,263); $portInput.Size=New-Object Drawing.Size(105,28); $form.Controls.Add($portInput)
    $codeLabel=New-Object Windows.Forms.Label; $codeLabel.Text='VS Code EXE:'; $codeLabel.Location=New-Object Drawing.Point(24,306); $codeLabel.Size=New-Object Drawing.Size(112,25); $form.Controls.Add($codeLabel)
    $codeInput=New-Object Windows.Forms.TextBox; $codeInput.Location=New-Object Drawing.Point(142,302); $codeInput.Size=New-Object Drawing.Size(390,28); $codeInput.Text=$CodePath; $form.Controls.Add($codeInput)
    $browse=New-Object Windows.Forms.Button; $browse.Text='Vybrat…'; $browse.Location=New-Object Drawing.Point(542,301); $browse.Size=New-Object Drawing.Size(94,30); $form.Controls.Add($browse)
    $findCode=New-Object Windows.Forms.Button; $findCode.Text='Znovu najít'; $findCode.Location=New-Object Drawing.Point(646,301); $findCode.Size=New-Object Drawing.Size(105,30); $form.Controls.Add($findCode)
    $codeChoicesLabel=New-Object Windows.Forms.Label; $codeChoicesLabel.Text='Nalezené:'; $codeChoicesLabel.Location=New-Object Drawing.Point(24,344); $codeChoicesLabel.Size=New-Object Drawing.Size(110,25); $form.Controls.Add($codeChoicesLabel)
    $codeChoices=New-Object Windows.Forms.ComboBox; $codeChoices.DropDownStyle='DropDownList'; $codeChoices.Location=New-Object Drawing.Point(142,340); $codeChoices.Size=New-Object Drawing.Size(608,28); $codeChoices.DropDownWidth=1050; $form.Controls.Add($codeChoices)
    $profileLabel=New-Object Windows.Forms.Label; $profileLabel.Text='Profil VS Code:'; $profileLabel.Location=New-Object Drawing.Point(24,383); $profileLabel.Size=New-Object Drawing.Size(115,25); $form.Controls.Add($profileLabel)
    $profileInput=New-Object Windows.Forms.TextBox; $profileInput.Location=New-Object Drawing.Point(142,379); $profileInput.Size=New-Object Drawing.Size(300,28); $profileInput.Text=$CodeProfile; $form.Controls.Add($profileInput)
    $hint=New-Object Windows.Forms.Label; $hint.Text='Prázdné = výchozí profil.'; $hint.Location=New-Object Drawing.Point(451,382); $hint.Size=New-Object Drawing.Size(300,28); $form.Controls.Add($hint)
    $dataLabel=New-Object Windows.Forms.Label; $dataLabel.Text='Data VS Code:'; $dataLabel.Location=New-Object Drawing.Point(24,421); $dataLabel.Size=New-Object Drawing.Size(115,25); $form.Controls.Add($dataLabel)
    $dataInput=New-Object Windows.Forms.TextBox; $dataInput.Location=New-Object Drawing.Point(142,417); $dataInput.Size=New-Object Drawing.Size(608,28); $dataInput.Text=$CodeUserDataDir; $form.Controls.Add($dataInput)
    $extensionsLabel=New-Object Windows.Forms.Label; $extensionsLabel.Text='Rozšíření:'; $extensionsLabel.Location=New-Object Drawing.Point(24,459); $extensionsLabel.Size=New-Object Drawing.Size(115,25); $form.Controls.Add($extensionsLabel)
    $extensionsInput=New-Object Windows.Forms.TextBox; $extensionsInput.Location=New-Object Drawing.Point(142,455); $extensionsInput.Size=New-Object Drawing.Size(608,28); $extensionsInput.Text=$CodeExtensionsDir; $form.Controls.Add($extensionsInput)
    $codeStatus=New-Object Windows.Forms.Label; $codeStatus.Location=New-Object Drawing.Point(24,494); $codeStatus.Size=New-Object Drawing.Size(728,48); $form.Controls.Add($codeStatus)
    $script:FillingCodeChoices=$false
    function Set-MCCodeSelection($Candidate) {
        $script:SelectedCodeTarget=$Candidate
        $codeInput.Text=$Candidate.Executable; $profileInput.Text=$Candidate.Profile
        $dataInput.Text=$Candidate.UserDataDir; $extensionsInput.Text=$Candidate.ExtensionsDir
        $codeStatus.Text='Zdroj: ' + $Candidate.Source + '. Prázdné datové cesty = výchozí / portable. Otevřená okna nezavírám.'
        if ($Candidate.ContextWarning) { $codeStatus.Text=$Candidate.ContextWarning }
    }
    function Fill-MCCodeChoices([bool]$SelectFirst) {
        $script:FillingCodeChoices=$true
        try {
            $codeChoices.Items.Clear()
            foreach ($candidate in $script:DetectedCodes) { [void]$codeChoices.Items.Add($candidate.Display) }
            if ($script:DetectedCodes.Count) {
                $index=0
                for ($i=0; $i -lt $script:DetectedCodes.Count; $i++) { if ($script:DetectedCodes[$i].Executable -eq $codeInput.Text) { $index=$i; break } }
                $codeChoices.SelectedIndex=$index
                if ($SelectFirst -or -not $codeInput.Text) { Set-MCCodeSelection $script:DetectedCodes[$index] }
                else { $codeStatus.Text='Cesta doplněna; přesné CLI a verze bridge budou ověřeny při instalaci. VS Code nemusíte zavírat.' }
            } else { $codeStatus.Text='VS Code nebyl automaticky nalezen. Spusťte jej a stiskněte Znovu najít, případně zvolte Code.exe.' }
        } finally { $script:FillingCodeChoices=$false }
    }
    $codeChoices.Add_SelectedIndexChanged({ if (-not $script:FillingCodeChoices -and $codeChoices.SelectedIndex -ge 0) { Set-MCCodeSelection $script:DetectedCodes[$codeChoices.SelectedIndex] } })
    $findCode.Add_Click({
        $findCode.Enabled=$false; $form.UseWaitCursor=$true
        try {
            $script:DetectedCodes=@(Get-MCCodeCandidates (Join-Path $script:DataDir 'vscode-target.json'))
            # A refresh intentionally re-selects the running executable, not a stale path.
            $codeInput.Text=''; Fill-MCCodeChoices $true
            Write-ProgressLine ("Dohledáno instalací / kontextů VS Code: " + $script:DetectedCodes.Count)
            foreach ($note in $script:MCCodeDiscoveryNotes) { Write-ProgressLine $note }
        } catch { Write-ProgressLine ('Detekce: ' + $_.Exception.Message) }
        finally { $findCode.Enabled=$true; $form.UseWaitCursor=$false }
    })
    $browse.Add_Click({
        $dialog=New-Object Windows.Forms.OpenFileDialog
        $dialog.Filter='VS Code (Code.exe; Code - Insiders.exe)|Code.exe;Code - Insiders.exe|Spouštěč (code.cmd; code-insiders.cmd)|code.cmd;code-insiders.cmd'
        try {
            if ($dialog.ShowDialog() -eq 'OK') {
                $found=Resolve-MCCode $dialog.FileName
                if ($found) { Set-MCCodeSelection $found }
                else { [void][Windows.Forms.MessageBox]::Show('Soubor nepatří rozpoznané desktopové instalaci VS Code.','VS Code','OK','Warning') }
            }
        } finally { $dialog.Dispose() }
    })
    Fill-MCCodeChoices $false
    $codeInput.Add_TextChanged({
        if ($script:SelectedCodeTarget -and $script:SelectedCodeTarget.Executable -ne $codeInput.Text.Trim()) {
            $script:SelectedCodeTarget=$null
            $profileInput.Text=''; $dataInput.Text=''; $extensionsInput.Text=''
            $codeStatus.Text='Cesta byla ručně změněna. Kontext předchozí instalace byl vymazán; vyberte položku Nalezené pro jeho načtení.'
        }
    })
    $script:LogBox=New-Object Windows.Forms.TextBox; $script:LogBox.Multiline=$true; $script:LogBox.ReadOnly=$true; $script:LogBox.ScrollBars='Vertical'
    $script:LogBox.Location=New-Object Drawing.Point(24,546); $script:LogBox.Size=New-Object Drawing.Size(727,197)
    $script:LogBox.Text="Aplikace: $script:InstallDir`r`nData: $script:DataDir`r`nBalíček není podepsaný certifikátem. Ochranu Windows nevypínejte.`r`nZámek údržby se získává až při operaci; ne při otevření průvodce.`r`nVS Code stderr se ukládá do diagnostiky; úspěch potvrzuje návratový kód a seznam rozšíření.`r`n"
    $form.Controls.Add($script:LogBox)
    $execute=New-Object Windows.Forms.Button; $execute.Location=New-Object Drawing.Point(435,763); $execute.Size=New-Object Drawing.Size(177,38); $form.Controls.Add($execute)
    $close=New-Object Windows.Forms.Button; $close.Text='Zavřít'; $close.Location=New-Object Drawing.Point(628,763); $close.Size=New-Object Drawing.Size(122,38); $close.Add_Click({ $form.Close() }); $form.Controls.Add($close)
    $copyLog=New-Object Windows.Forms.Button; $copyLog.Text='Zkopírovat protokol'; $copyLog.Location=New-Object Drawing.Point(24,763); $copyLog.Size=New-Object Drawing.Size(185,38); $copyLog.Add_Click({ [Windows.Forms.Clipboard]::SetText($script:LogBox.Text) }); $form.Controls.Add($copyLog)
    $diagnose=New-Object Windows.Forms.Button; $diagnose.Text='Diagnostika zámku'; $diagnose.Location=New-Object Drawing.Point(222,763); $diagnose.Size=New-Object Drawing.Size(200,38); $form.Controls.Add($diagnose)
    $diagnose.Add_Click({
        if ($script:Installing) { return }
        try {
            $name=Get-MCSetupMutexName
            $probe=Enter-MCSetupMutex $name
            if ($null -eq $probe) { Write-ProgressLine (Get-MCSetupConflictText $script:DataDir $name) }
            else {
                Exit-MCSetupMutex $probe
                Write-ProgressLine 'MC_SETUP_LOCK_FREE: zámek je nyní volný. Instalaci lze zkusit znovu.'
            }
        } catch { Write-ProgressLine ('Diagnostika zámku: '+$_.Exception.Message) }
    })
    $choice.Add_SelectedIndexChanged({
        $uninstall=$actions[$choice.SelectedIndex] -eq 'Uninstall'
        $auto.Visible=-not $uninstall; $open.Visible=-not $uninstall; $bridge.Visible=-not $uninstall; $portInput.Enabled=-not $uninstall
        $removeDataBox.Visible=$uninstall; $removeBridgeBox.Visible=$uninstall
        $execute.Text=switch($actions[$choice.SelectedIndex]) { 'Install'{'Nainstalovat'} 'Update'{'Aktualizovat'} 'Repair'{'Opravit'} 'Uninstall'{'Odinstalovat'} }
    })
    $index=$actions.IndexOf($resolvedMode); if ($index -lt 0) { $index=0 }; $choice.SelectedIndex=$index
    $form.Add_FormClosing({ if ($script:Installing) { $_.Cancel=$true } })
    $execute.Add_Click({
        $action=$actions[$choice.SelectedIndex]
        if ($action -eq 'Uninstall') {
            $text='Odinstalovat Mission Control? Codex, Zoo Code a projekty zůstanou nainstalované. Vlastní hooky Mission Control závislé na odebíraném runtime se odstraní; ostatní hooky zůstanou.'
            if ($removeDataBox.Checked) { $text+="`r`nPOZOR: uložená historie, párovací token a nastavení Mission Control budou trvale odstraněny." }
            else { $text+="`r`nHistorie a párovací token zůstanou zachovány." }
            if ([Windows.Forms.MessageBox]::Show($text,'Potvrdit odinstalování','YesNo','Warning') -ne 'Yes') { return }
        }
        $script:Installing=$true; $global:MCInstallFailed=$false; $global:MCSetupExitCode=0
        foreach($control in @($execute,$close,$choice,$auto,$open,$bridge,$removeDataBox,$removeBridgeBox,$portInput,$codeInput,$profileInput,$browse,$findCode,$codeChoices,$dataInput,$extensionsInput)) { $control.Enabled=$false }
        try {
            $script:BridgeUserDataDir=$dataInput.Text.Trim(); $script:BridgeExtensionsDir=$extensionsInput.Text.Trim()
            # Empty/custom edits must not silently revive another target's context.
            if ($script:SelectedCodeTarget -and $script:SelectedCodeTarget.Executable -eq $codeInput.Text.Trim()) {
                $script:SelectedCodeTarget.UserDataDir=$script:BridgeUserDataDir
                $script:SelectedCodeTarget.ExtensionsDir=$script:BridgeExtensionsDir
                $script:SelectedCodeTarget.Profile=$profileInput.Text.Trim()
            }
            Invoke-MCOperation $action $auto.Checked $open.Checked $bridge.Checked ([int]$portInput.Value) $removeDataBox.Checked $removeBridgeBox.Checked $codeInput.Text.Trim() $profileInput.Text.Trim()
            if ($script:Warnings) {
                $execute.Text='Zopakovat opravu'
                foreach($control in @($execute,$codeInput,$profileInput,$browse,$findCode,$codeChoices,$dataInput,$extensionsInput)) { $control.Enabled=$true }
                if ($action -ne 'Uninstall') {
                    $repairIndex=$actions.IndexOf('Repair')
                    if ($repairIndex -lt 0) { [void]$choice.Items.Add("Opravit instalaci soubory verze $script:Version"); $actions.Add('Repair'); $repairIndex=$actions.Count-1 }
                    $choice.SelectedIndex=$repairIndex
                } else { $execute.Enabled=$false }
            } else { $execute.Text='Hotovo' }
        } catch {
            $global:MCInstallFailed=$true; $global:MCSetupExitCode=1
            Write-ProgressLine ('CHYBA: '+$_.Exception.Message)
            [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Operace nebyla dokončena','OK','Error')
            foreach($control in @($execute,$choice,$auto,$open,$bridge,$removeDataBox,$removeBridgeBox,$portInput,$codeInput,$profileInput,$browse,$findCode,$codeChoices,$dataInput,$extensionsInput)) { $control.Enabled=$true }
        } finally { $script:Installing=$false; $close.Enabled=$true }
    })
    [void]$form.ShowDialog()
} catch {
    $global:MCInstallFailed=$true; $global:MCSetupExitCode=1
    Write-ProgressLine ('CHYBA: '+$_.Exception.Message)
    if (-not $Unattended) { [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Mission Control','OK','Error') }
}
