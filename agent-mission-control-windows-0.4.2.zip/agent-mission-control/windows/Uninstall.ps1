﻿#requires -Version 5.1
param([switch]$Unattended,[switch]$RemoveData,[switch]$RemoveBridge)
# Compatibility entrypoint: use the cached independent package, not files being removed.
$launcher=Join-Path $env:LOCALAPPDATA 'AgentMissionControl\maintenance\Launch.ps1'
if (Test-Path -LiteralPath $launcher) {
    & $launcher -Mode Uninstall -Unattended:$Unattended -RemoveData:$RemoveData -RemoveBridge:$RemoveBridge
    exit $LASTEXITCODE
}
& (Join-Path $PSScriptRoot 'Install.ps1') -Mode Uninstall -Unattended:$Unattended -RemoveData:$RemoveData -RemoveBridge:$RemoveBridge
exit $global:MCSetupExitCode
