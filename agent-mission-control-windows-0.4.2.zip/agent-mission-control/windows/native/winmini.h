/* Minimal Win32 declarations for this SDK-free, CRT-free x64 build.
 * Structure layouts follow the Windows SDK. No third-party runtime is linked. */
#ifndef WINMINI_H
#define WINMINI_H
#include <stddef.h>
#include <stdint.h>
typedef unsigned short WCHAR; typedef const WCHAR *LPCWSTR; typedef WCHAR *LPWSTR;
typedef void *HANDLE; typedef void *HWND; typedef void *HICON; typedef void *HMENU; typedef void *HINSTANCE;
typedef uint32_t DWORD; typedef int32_t LONG; typedef unsigned int UINT; typedef int BOOL;
typedef unsigned short WORD; typedef unsigned char BYTE; typedef uintptr_t WPARAM; typedef intptr_t LPARAM; typedef intptr_t LRESULT;
typedef uintptr_t SIZE_T; typedef intptr_t LONG_PTR; typedef uintptr_t ULONG_PTR; typedef int64_t LONGLONG;
#ifdef MC_NATIVE_TEST
#define API
#else
#define API __declspec(dllimport)
#endif
#define W(s) ((const WCHAR*)L##s)
#define NULLPTR ((void*)0)
#define INVALID_HANDLE ((HANDLE)(intptr_t)-1)
#define WM_DESTROY 2
#define WM_CLOSE 16
#define WM_TIMER 275
#define WM_COMMAND 273
#define WM_APP 32768
#define WM_LBUTTONDBLCLK 515
#define WM_RBUTTONUP 517
#define WM_CONTEXTMENU 123
#define WM_QUERYENDSESSION 17
#define WM_ENDSESSION 22
#define MB_OK 0
#define MB_ICONERROR 16
#define MB_ICONINFORMATION 64
#define WS_OVERLAPPED 0
#define WAIT_OBJECT_0 0
#define WAIT_TIMEOUT 258
#define INFINITE 0xffffffff
#define ERROR_ALREADY_EXISTS 183
#define CREATE_NO_WINDOW 0x08000000
#define CREATE_SUSPENDED 4
#define GENERIC_READ 0x80000000
#define GENERIC_WRITE 0x40000000
#define FILE_APPEND_DATA 4
#define OPEN_EXISTING 3
#define OPEN_ALWAYS 4
#define CREATE_ALWAYS 2
#define FILE_ATTRIBUTE_NORMAL 128
#define FILE_SHARE_READ 1
#define FILE_SHARE_WRITE 2
#define FILE_SHARE_DELETE 4
#define STARTF_USESTDHANDLES 0x100
#define SW_SHOWNORMAL 1
#define MF_STRING 0
#define MF_SEPARATOR 0x800
#define MF_CHECKED 8
#define MF_DISABLED 2
#define TPM_RETURNCMD 0x100
#define TPM_RIGHTBUTTON 2
#define NIM_ADD 0
#define NIM_MODIFY 1
#define NIM_DELETE 2
#define NIF_MESSAGE 1
#define NIF_ICON 2
#define NIF_TIP 4
#define NIF_INFO 16
#define NIIF_INFO 1
#define NIIF_WARNING 2
#define GMEM_MOVEABLE 2
#define CF_UNICODETEXT 13
#define HKEY_CURRENT_USER ((HANDLE)(intptr_t)(int32_t)0x80000001)
#define KEY_READ 0x20019
#define KEY_WRITE 0x20006
#define REG_SZ 1
#define WINHTTP_ACCESS_TYPE_NO_PROXY 1
#define WINHTTP_QUERY_STATUS_CODE 19
#define WINHTTP_QUERY_FLAG_NUMBER 0x20000000
#define HTTP_STATUS_OK 200
#define HANDLE_FLAG_INHERIT 1

typedef struct {LONG x,y;} POINT;
typedef struct {LONG left,top,right,bottom;} RECT;
typedef struct {HWND hwnd;UINT message;WPARAM wParam;LPARAM lParam;DWORD time;POINT pt;DWORD lPrivate;} MSG;
typedef LRESULT (*WNDPROC)(HWND,UINT,WPARAM,LPARAM);
typedef struct {UINT style;WNDPROC lpfnWndProc;int cbClsExtra,cbWndExtra;HINSTANCE hInstance;HICON hIcon;HANDLE hCursor,hbrBackground;LPCWSTR lpszMenuName,lpszClassName;} WNDCLASSW;
typedef struct {DWORD nLength;void*lpSecurityDescriptor;BOOL bInheritHandle;} SECURITY_ATTRIBUTES;
typedef struct {DWORD cb;LPWSTR lpReserved,lpDesktop,lpTitle;DWORD dwX,dwY,dwXSize,dwYSize,dwXCountChars,dwYCountChars,dwFillAttribute,dwFlags;WORD wShowWindow,cbReserved2;BYTE*lpReserved2;HANDLE hStdInput,hStdOutput,hStdError;} STARTUPINFOW;
typedef struct {HANDLE hProcess,hThread;DWORD dwProcessId,dwThreadId;} PROCESS_INFORMATION;
typedef struct {DWORD cbSize;HWND hWnd;UINT uID,uFlags,uCallbackMessage;HICON hIcon;WCHAR szTip[128];DWORD dwState,dwStateMask;WCHAR szInfo[256];UINT uTimeoutOrVersion;WCHAR szInfoTitle[64];DWORD dwInfoFlags;BYTE guidItem[16];HICON hBalloonIcon;} NOTIFYICONDATAW;
typedef struct {LONGLONG PerProcessUserTimeLimit,PerJobUserTimeLimit;DWORD LimitFlags;SIZE_T MinimumWorkingSetSize,MaximumWorkingSetSize;DWORD ActiveProcessLimit;ULONG_PTR Affinity;DWORD PriorityClass,SchedulingClass;} JOBOBJECT_BASIC_LIMIT_INFORMATION;
typedef struct {uint64_t ReadOperationCount,WriteOperationCount,OtherOperationCount,ReadTransferCount,WriteTransferCount,OtherTransferCount;} IO_COUNTERS;
typedef struct {JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation;IO_COUNTERS IoInfo;SIZE_T ProcessMemoryLimit,JobMemoryLimit,PeakProcessMemoryUsed,PeakJobMemoryUsed;} JOBOBJECT_EXTENDED_LIMIT_INFORMATION;

API DWORD GetModuleFileNameW(HANDLE,LPWSTR,DWORD); API DWORD GetEnvironmentVariableW(LPCWSTR,LPWSTR,DWORD); API BOOL SetEnvironmentVariableW(LPCWSTR,LPCWSTR);
API DWORD GetTempPathW(DWORD,LPWSTR); API BOOL CreateDirectoryW(LPCWSTR,void*); API DWORD GetFileAttributesW(LPCWSTR); API HANDLE CreateFileW(LPCWSTR,DWORD,DWORD,SECURITY_ATTRIBUTES*,DWORD,DWORD,HANDLE); API BOOL ReadFile(HANDLE,void*,DWORD,DWORD*,void*); API BOOL WriteFile(HANDLE,const void*,DWORD,DWORD*,void*); API BOOL CloseHandle(HANDLE); API BOOL DeleteFileW(LPCWSTR); API BOOL RemoveDirectoryW(LPCWSTR); API BOOL MoveFileExW(LPCWSTR,LPCWSTR,DWORD); API BOOL GetFileSizeEx(HANDLE,LONGLONG*);
API BOOL CreateProcessW(LPCWSTR,LPWSTR,void*,void*,BOOL,DWORD,void*,LPCWSTR,STARTUPINFOW*,PROCESS_INFORMATION*); API BOOL GetExitCodeProcess(HANDLE,DWORD*); API DWORD ResumeThread(HANDLE); API BOOL TerminateProcess(HANDLE,UINT); API DWORD WaitForSingleObject(HANDLE,DWORD);
API HANDLE CreateMutexW(void*,BOOL,LPCWSTR); API BOOL ReleaseMutex(HANDLE); API HANDLE CreateEventW(void*,BOOL,BOOL,LPCWSTR); API HANDLE OpenEventW(DWORD,BOOL,LPCWSTR); API BOOL SetEvent(HANDLE); API DWORD GetLastError(void);
API uint64_t GetTickCount64(void); API DWORD GetCurrentProcessId(void); API void Sleep(DWORD); API void ExitProcess(UINT); API HANDLE GetModuleHandleW(LPCWSTR);
API HANDLE CreateJobObjectW(void*,LPCWSTR); API BOOL SetInformationJobObject(HANDLE,int,void*,DWORD); API BOOL AssignProcessToJobObject(HANDLE,HANDLE);
API HANDLE GlobalAlloc(UINT,SIZE_T); API void*GlobalLock(HANDLE); API BOOL GlobalUnlock(HANDLE); API HANDLE GlobalFree(HANDLE);
API WORD RegisterClassW(const WNDCLASSW*); API HWND CreateWindowExW(DWORD,LPCWSTR,LPCWSTR,DWORD,int,int,int,int,HWND,HMENU,HINSTANCE,void*); API BOOL DestroyWindow(HWND); API LRESULT DefWindowProcW(HWND,UINT,WPARAM,LPARAM); API BOOL GetMessageW(MSG*,HWND,UINT,UINT); API BOOL TranslateMessage(const MSG*); API LRESULT DispatchMessageW(const MSG*); API BOOL PostMessageW(HWND,UINT,WPARAM,LPARAM); API void PostQuitMessage(int);
API UINT RegisterWindowMessageW(LPCWSTR); API uintptr_t SetTimer(HWND,uintptr_t,UINT,void*); API BOOL KillTimer(HWND,uintptr_t); API HICON LoadIconW(HINSTANCE,LPCWSTR); API BOOL GetCursorPos(POINT*); API BOOL SetForegroundWindow(HWND); API HMENU CreatePopupMenu(void); API BOOL AppendMenuW(HMENU,UINT,uintptr_t,LPCWSTR); API UINT TrackPopupMenu(HMENU,UINT,int,int,int,HWND,void*); API BOOL DestroyMenu(HMENU); API int MessageBoxW(HWND,LPCWSTR,LPCWSTR,UINT);
API BOOL OpenClipboard(HWND); API BOOL EmptyClipboard(void); API HANDLE SetClipboardData(UINT,HANDLE); API BOOL CloseClipboard(void);
API BOOL Shell_NotifyIconW(DWORD,NOTIFYICONDATAW*); API HINSTANCE ShellExecuteW(HWND,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,int);
API BOOL SystemFunction036(void*,DWORD); /* RtlGenRandom */
API LONG RegCreateKeyExW(HANDLE,LPCWSTR,DWORD,LPWSTR,DWORD,DWORD,void*,HANDLE*,DWORD*); API LONG RegOpenKeyExW(HANDLE,LPCWSTR,DWORD,DWORD,HANDLE*); API LONG RegSetValueExW(HANDLE,LPCWSTR,DWORD,DWORD,const BYTE*,DWORD); API LONG RegQueryValueExW(HANDLE,LPCWSTR,DWORD*,DWORD*,BYTE*,DWORD*); API LONG RegDeleteValueW(HANDLE,LPCWSTR); API LONG RegCloseKey(HANDLE);
API HANDLE WinHttpOpen(LPCWSTR,DWORD,LPCWSTR,LPCWSTR,DWORD); API BOOL WinHttpSetTimeouts(HANDLE,int,int,int,int); API HANDLE WinHttpConnect(HANDLE,LPCWSTR,WORD,DWORD); API HANDLE WinHttpOpenRequest(HANDLE,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR*,DWORD); API BOOL WinHttpSendRequest(HANDLE,LPCWSTR,DWORD,void*,DWORD,DWORD,uintptr_t); API BOOL WinHttpReceiveResponse(HANDLE,void*); API BOOL WinHttpQueryHeaders(HANDLE,DWORD,LPCWSTR,void*,DWORD*,DWORD*); API BOOL WinHttpReadData(HANDLE,void*,DWORD,DWORD*); API BOOL WinHttpCloseHandle(HANDLE);
API BOOL WinHttpSetOption(HANDLE,DWORD,void*,DWORD);
API LPWSTR GetCommandLineW(void);
API LPWSTR *CommandLineToArgvW(LPCWSTR,int*);
API HANDLE LocalFree(HANDLE);
API HANDLE OpenMutexW(DWORD,BOOL,LPCWSTR);
API HANDLE LoadImageW(HINSTANCE,LPCWSTR,UINT,int,int,UINT);
API BOOL DestroyIcon(HICON);
typedef struct {DWORD dwLowDateTime,dwHighDateTime;} FILETIME;
typedef struct {DWORD dwSize,cntUsage,th32ProcessID;ULONG_PTR th32DefaultHeapID;DWORD th32ModuleID,cntThreads,th32ParentProcessID;LONG pcPriClassBase;DWORD dwFlags;WCHAR szExeFile[260];} PROCESSENTRY32W;
API HANDLE GetCurrentProcess(void);
API HANDLE GetStdHandle(DWORD);
API HANDLE OpenProcess(DWORD,BOOL,DWORD);
API BOOL QueryFullProcessImageNameW(HANDLE,DWORD,LPWSTR,DWORD*);
API BOOL GetProcessTimes(HANDLE,FILETIME*,FILETIME*,FILETIME*,FILETIME*);
API BOOL ProcessIdToSessionId(DWORD,DWORD*);
API HANDLE CreateToolhelp32Snapshot(DWORD,DWORD);
API BOOL Process32FirstW(HANDLE,PROCESSENTRY32W*);
API BOOL Process32NextW(HANDLE,PROCESSENTRY32W*);
API BOOL OpenProcessToken(HANDLE,DWORD,HANDLE*);
API BOOL GetTokenInformation(HANDLE,int,void*,DWORD,DWORD*);
API BOOL EqualSid(void*,void*);
API int CompareStringOrdinal(LPCWSTR,int,LPCWSTR,int,BOOL);
API BOOL EnumWindows(BOOL(*)(HWND,LPARAM),LPARAM);
API DWORD GetWindowThreadProcessId(HWND,DWORD*);
API int GetClassNameW(HWND,LPWSTR,int);
_Static_assert(sizeof(PROCESSENTRY32W)==568,"PROCESSENTRY32W layout");
#if defined(__x86_64__) || defined(_M_X64)
_Static_assert(sizeof(STARTUPINFOW)==104,"STARTUPINFOW layout");
_Static_assert(sizeof(PROCESS_INFORMATION)==24,"PROCESS_INFORMATION layout");
_Static_assert(sizeof(NOTIFYICONDATAW)==976,"NOTIFYICONDATAW layout");
_Static_assert(sizeof(WNDCLASSW)==72,"WNDCLASSW layout");
_Static_assert(sizeof(MSG)==48,"MSG layout");
_Static_assert(sizeof(SECURITY_ATTRIBUTES)==24,"SECURITY_ATTRIBUTES layout");
_Static_assert(sizeof(JOBOBJECT_EXTENDED_LIMIT_INFORMATION)==144,"Job information layout");
#endif
API BOOL IsDialogMessageW(HWND,MSG*);
API BOOL SystemParametersInfoW(UINT,UINT,void*,UINT);
API UINT GetDpiForSystem(void);
API BOOL GetWindowRect(HWND,RECT*);
API BOOL ShowWindow(HWND,int);
API LRESULT SendMessageW(HWND,UINT,WPARAM,LPARAM);
API HANDLE GetStockObject(int);
API int MultiByteToWideChar(UINT,DWORD,const char*,int,LPWSTR,int);
API LONG SHQueryUserNotificationState(int*);
#endif
