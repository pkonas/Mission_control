/* Small application-owned notification, not a Windows balloon (whose duration
 * modern Windows ignores). No command buttons: a click only opens a notice ID.
 * Standard Win32 controls provide keyboard/screen-reader names. */
#ifndef MC_NOTIFICATION_H
#define MC_NOTIFICATION_H
#define MC_POP_OPEN 701
#define MC_POP_CLOSE 702
#define MC_POP_TITLE 703
#define MC_POP_BODY 704
static HWND noticeWindow;
static char noticeId[33],lastNoticeId[33],pendingOpenNotice[33];
static unsigned noticeSeconds=60;
static uint64_t noticeUntil;
static void openNotice(const char*id);
static BOOL hexId(const char*s,unsigned length){if(al(s)!=length)return 0;for(unsigned i=0;i<length;i++)if(!((s[i]>='0'&&s[i]<='9')||(s[i]>='a'&&s[i]<='f')))return 0;return 1;}
static BOOL validNoticeDuration(unsigned v){return v==0||v==30||v==60||v==120||v==300;}
static void closeNotice(void){if(noticeWindow){HWND h=noticeWindow;noticeWindow=NULLPTR;KillTimer(h,2);DestroyWindow(h);}noticeId[0]=0;}
static void chooseNoticeDuration(unsigned v){if(!validNoticeDuration(v))return;noticeSeconds=v;HANDLE k=openSettings(KEY_WRITE);if(k){DWORD value=v;RegSetValueExW(k,W("NotificationSeconds"),0,4,(BYTE*)&value,4);RegCloseKey(k);}if(noticeWindow)noticeUntil=v?GetTickCount64()+(uint64_t)v*1000:0;}
static LRESULT noticeProc(HWND h,UINT msg,WPARAM wp,LPARAM lp){
 if(msg==WM_COMMAND){unsigned id=(unsigned)wp&0xffff;if(id==MC_POP_CLOSE||id==2){closeNotice();return 0;}if(id==1||id==MC_POP_OPEN||id==MC_POP_TITLE||id==MC_POP_BODY){char target[33];memcpy(target,noticeId,33);closeNotice();if(hexId(target,32))openNotice(target);return 0;}}
 if(msg==0x0202){char target[33];memcpy(target,noticeId,33);closeNotice();if(hexId(target,32))openNotice(target);return 0;}
 if(msg==WM_CLOSE){closeNotice();return 0;}
 if(msg==0x0100&&wp==27){closeNotice();return 0;}
 if(msg==WM_TIMER&&wp==2){if(noticeUntil&&GetTickCount64()>=noticeUntil){POINT p;RECT r;if(GetCursorPos(&p)&&GetWindowRect(h,&r)&&p.x>=r.left&&p.x<r.right&&p.y>=r.top&&p.y<r.bottom){noticeUntil=GetTickCount64()+1000;return 0;}closeNotice();}return 0;}
 return DefWindowProcW(h,msg,wp,lp);
}
static BOOL showNotice(const char*id,const char*title,const char*body){
 if(noticeWindow||!hexId(id,32))return 0;
 RECT area;if(!SystemParametersInfoW(0x0030,0,&area,0))return 0; /* SPI_GETWORKAREA */
 UINT dpi=GetDpiForSystem();if(dpi<96||dpi>384)dpi=96;
 int w=(int)(440*dpi/96),height=(int)(210*dpi/96),gap=(int)(16*dpi/96);
 WCHAR wt[180],wb[500];if(!MultiByteToWideChar(65001,8,title,-1,wt,180)||!MultiByteToWideChar(65001,8,body,-1,wb,500))return 0;
 HINSTANCE module=GetModuleHandleW(NULLPTR);
 WNDCLASSW cls;memset(&cls,0,sizeof(cls));cls.lpfnWndProc=noticeProc;cls.hInstance=module;cls.lpszClassName=W("MissionControlNoticeV1");cls.hbrBackground=(HANDLE)(intptr_t)6;RegisterClassW(&cls);
 HWND h=CreateWindowExW(0x00010088,cls.lpszClassName,W("Mission Control — událost"),0x80800000,area.right-w-gap,area.bottom-height-gap,w,height,window,NULLPTR,module,NULLPTR);
 if(!h)return 0;
 noticeWindow=h;memcpy(noticeId,id,33);
 const DWORD childStyle=0x50000100; /* CHILD | VISIBLE | SS_NOTIFY */
 HWND a=CreateWindowExW(0,W("STATIC"),wt,childStyle,gap,gap,w-gap*2,(int)(42*dpi/96),h,(HMENU)(uintptr_t)MC_POP_TITLE,module,NULLPTR);
 HWND b=CreateWindowExW(0,W("STATIC"),wb,childStyle,gap,(int)(61*dpi/96),w-gap*2,(int)(63*dpi/96),h,(HMENU)(uintptr_t)MC_POP_BODY,module,NULLPTR);
 HWND c=CreateWindowExW(0,W("BUTTON"),W("Otevřít událost"),0x50010001,gap,(int)(144*dpi/96),(int)(235*dpi/96),(int)(36*dpi/96),h,(HMENU)(uintptr_t)MC_POP_OPEN,module,NULLPTR);
 HWND d=CreateWindowExW(0,W("BUTTON"),W("Zavřít"),0x50010000,(int)(272*dpi/96),(int)(144*dpi/96),(int)(145*dpi/96),(int)(36*dpi/96),h,(HMENU)(uintptr_t)MC_POP_CLOSE,module,NULLPTR);
 if(!a||!b||!c||!d){closeNotice();return 0;}
 HANDLE font=GetStockObject(17);HWND ctrls[]={a,b,c,d};for(unsigned i=0;i<4;i++)if(ctrls[i])SendMessageW(ctrls[i],0x0030,(WPARAM)font,1);
 noticeUntil=noticeSeconds?GetTickCount64()+(uint64_t)noticeSeconds*1000:0;if(!SetTimer(h,2,500,NULLPTR)){closeNotice();return 0;}
 memcpy(lastNoticeId,id,33);
 ShowWindow(h,4); /* SW_SHOWNOACTIVATE: never steal editor focus. */
 return 1;
}
static void acknowledgeNotice(const char*id){if(!hexId(id,32))return;WCHAR path[128]=L"/api/desktop/notification-delivered?id=",wide[33];ascii(wide,33,id);wa(path,128,wide);request(path,1,1,NULLPTR,0);}
static void pollNotice(void){
 if(!notifyEnabled||noticeWindow)return;
 int notificationState=0; /* Defer while Windows reports busy/presentation/full-screen. */
 if(SHQueryUserNotificationState(&notificationState)!=0||notificationState!=5)return;
 char response[2048];if(request(W("/api/desktop/next-notification"),0,1,response,sizeof(response))!=200)return;
 char*lines[6];unsigned n=0;lines[n++]=response;for(char*p=response;*p&&n<6;p++)if(*p=='\n'){*p=0;lines[n++]=p+1;}
 if(n<3||!eq(lines[0],"MCN1")||!eq(lines[1],instance)||!hexId(lines[2],32))return;
 if(eq(lastNoticeId,lines[2])){acknowledgeNotice(lines[2]);return;}
 if(n<5)return;
 if(showNotice(lines[2],lines[3],lines[4]))acknowledgeNotice(lines[2]);
}
#endif
