#ifndef MC_UTIL_H
#define MC_UTIL_H
#include "winmini.h"
void *memset(void*d,int v,size_t n){unsigned char*p=d;while(n--)*p++=(unsigned char)v;return d;}
void *memcpy(void*d,const void*s,size_t n){unsigned char*p=d;const unsigned char*q=s;while(n--)*p++=*q++;return d;}
static size_t wl(const WCHAR*s){size_t n=0;while(s[n])++n;return n;}
static size_t al(const char*s){size_t n=0;while(s[n])++n;return n;}
static int eq(const char*a,const char*b){while(*a&&*a==*b){++a;++b;}return *a==*b;}
static int weq(const WCHAR*a,const WCHAR*b){while(*a&&*a==*b){++a;++b;}return *a==*b;}
static BOOL wc(WCHAR*d,size_t cap,const WCHAR*s){size_t n=wl(s);if(n>=cap)return 0;memcpy(d,s,(n+1)*2);return 1;}
static BOOL wa(WCHAR*d,size_t cap,const WCHAR*s){size_t n=wl(d);return wc(d+n,cap-n,s);}
static BOOL ascii(WCHAR*d,size_t cap,const char*s){size_t n=al(s);if(n>=cap)return 0;for(size_t i=0;i<=n;i++)d[i]=(BYTE)s[i];return 1;}
static void number(WCHAR*d,unsigned n){WCHAR t[16];unsigned i=0;do{t[i++]=(WCHAR)('0'+n%10);n/=10;}while(n);unsigned j=0;while(i)d[j++]=t[--i];d[j]=0;}
static BOOL randomhex(char*out,DWORD n){BYTE b[32];if(n>32||!SystemFunction036(b,n))return 0;const char*h="0123456789abcdef";for(DWORD i=0;i<n;i++){out[2*i]=h[b[i]>>4];out[2*i+1]=h[b[i]&15];}out[2*n]=0;return 1;}
static void parent(WCHAR*p){size_t n=wl(p);while(n&&p[n-1]!='\\')--n;if(n)p[n-1]=0;}
static BOOL fileExists(const WCHAR*p){DWORD a=GetFileAttributesW(p);return a!=0xffffffff&&!(a&16);}
static BOOL join(WCHAR*out,size_t cap,const WCHAR*base,const WCHAR*leaf){return wc(out,cap,base)&&wa(out,cap,W("\\"))&&wa(out,cap,leaf);}
#endif
