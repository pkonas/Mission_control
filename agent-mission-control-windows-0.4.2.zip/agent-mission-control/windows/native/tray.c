#include "util.h"
#include "arguments.h"
#define CAP 2048
#define WM_TRAY (WM_APP+1)
#define ID_OPEN 100
#define ID_TOKEN 101
#define ID_RESTART 102
#define ID_LOG 103
#define ID_STARTUP 104
#define ID_NOTIFY 105
#define ID_BRIDGE 106
#define ID_QUIT 107
#define ID_HELP 108
#define ID_MAINTENANCE 109
static WCHAR exe[CAP],root[CAP],data[CAP],node[CAP],logPath[CAP],baseUrl[128];
static WCHAR mutexName[128],openName[128],quitName[128];
static HANDLE mutex,openEvent,quitEvent,job;static PROCESS_INFORMATION child;
static HWND window;static NOTIFYICONDATAW tray;static UINT taskbarCreated;
static char secret[65],instance[33],fingerprint[65];
static unsigned port=4317,failures,restarts;static BOOL quitting,wantOpen,paused,notifyEnabled=1,busy;
static uint64_t nextStart,nextPoll,startedAt;static BOOL healthy;

static void dialog(const WCHAR*text){MessageBoxW(window,text,W("Mission Control"),MB_OK|MB_ICONERROR);}
static void balloon(const WCHAR*title,const WCHAR*text,BOOL error){
  wc(tray.szInfoTitle,64,title);wc(tray.szInfo,256,text);tray.uFlags=NIF_INFO;tray.dwInfoFlags=error?NIIF_WARNING:NIIF_INFO;tray.uTimeoutOrVersion=8000;Shell_NotifyIconW(NIM_MODIFY,&tray);
}
static void tip(const WCHAR*text){wc(tray.szTip,128,text);tray.uFlags=NIF_TIP;Shell_NotifyIconW(NIM_MODIFY,&tray);}
static void pathLog(void){ShellExecuteW(window,W("open"),data,NULLPTR,NULLPTR,SW_SHOWNORMAL);}
static HANDLE openSettings(DWORD access){HANDLE key=NULLPTR;DWORD disp;RegCreateKeyExW(HKEY_CURRENT_USER,W("Software\\AgentMissionControl"),0,NULLPTR,0,access,NULLPTR,&key,&disp);return key;}
static void setNotifications(BOOL enabled){HANDLE k=openSettings(KEY_WRITE);if(k){DWORD v=enabled?1:0;RegSetValueExW(k,W("Notifications"),0,4,(BYTE*)&v,4);RegCloseKey(k);}notifyEnabled=enabled;}
static BOOL isStartup(void){HANDLE k;WCHAR v[CAP];DWORD n=sizeof(v),type=0;BOOL enabled=0;if(RegOpenKeyExW(HKEY_CURRENT_USER,W("Software\\Microsoft\\Windows\\CurrentVersion\\Run"),0,KEY_READ,&k)==0){enabled=RegQueryValueExW(k,W("AgentMissionControl"),NULLPTR,&type,(BYTE*)v,&n)==0;RegCloseKey(k);}return enabled;}
static void toggleStartup(void){HANDLE k;DWORD disp;LONG result=RegCreateKeyExW(HKEY_CURRENT_USER,W("Software\\Microsoft\\Windows\\CurrentVersion\\Run"),0,NULLPTR,0,KEY_READ|KEY_WRITE,NULLPTR,&k,&disp);if(result){dialog(W("Automatické spuštění nelze změnit. Zkontrolujte pravidla správce Windows."));return;}
 if(isStartup())result=RegDeleteValueW(k,W("AgentMissionControl"));else{WCHAR cmd[CAP]=L"\"";wa(cmd,CAP,exe);wa(cmd,CAP,W("\" --background"));if(wl(cmd)>=260){RegCloseKey(k);dialog(W("Cesta je příliš dlouhá pro položku Run. Použijte zástupce ve složce Po spuštění."));return;}result=RegSetValueExW(k,W("AgentMissionControl"),0,REG_SZ,(const BYTE*)cmd,(DWORD)((wl(cmd)+1)*2));}RegCloseKey(k);if(result)dialog(W("Změna automatického spuštění se nezdařila."));
}
static void logsRotate(void){HANDLE f=CreateFileW(logPath,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULLPTR,OPEN_EXISTING,0,NULLPTR);if(f!=INVALID_HANDLE){LONGLONG n=0;GetFileSizeEx(f,&n);CloseHandle(f);if(n>2097152){WCHAR backup[CAP];wc(backup,CAP,logPath);wa(backup,CAP,W(".1"));MoveFileExW(logPath,backup,1);}}}
static DWORD request(const WCHAR*route,BOOL post,BOOL auth,char*out,DWORD cap){
 HANDLE s=WinHttpOpen(W("MissionControl/0.4.2"),WINHTTP_ACCESS_TYPE_NO_PROXY,NULLPTR,NULLPTR,0);if(!s)return 0;
 WinHttpSetTimeouts(s,1200,1200,1200,1200);HANDLE c=WinHttpConnect(s,W("127.0.0.1"),(WORD)port,0);HANDLE r=c?WinHttpOpenRequest(c,post?W("POST"):W("GET"),route,NULLPTR,NULLPTR,NULLPTR,0):NULLPTR;
 DWORD status=0;if(r){DWORD never=0;WinHttpSetOption(r,88,&never,sizeof(never));WCHAR headers[192]=L"";if(auth){wc(headers,192,W("Authorization: Bearer "));WCHAR t[65];ascii(t,65,secret);wa(headers,192,t);wa(headers,192,W("\r\n"));}
 if(WinHttpSendRequest(r,headers,(DWORD)wl(headers),NULLPTR,0,0,0)&&WinHttpReceiveResponse(r,NULLPTR)){
 DWORD size=4;WinHttpQueryHeaders(r,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,NULLPTR,&status,&size,NULLPTR);
 DWORD used=0,n=0;if(out&&cap){while(used<cap-1&&WinHttpReadData(r,out+used,cap-used-1,&n)&&n){used+=n;}out[used]=0;}}
 WinHttpCloseHandle(r);}if(c)WinHttpCloseHandle(c);WinHttpCloseHandle(s);return status;
}
#include "notification.h"
static void copyToken(void){WCHAR p[CAP];join(p,CAP,data,W("token"));HANDLE f=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ,NULLPTR,OPEN_EXISTING,0,NULLPTR);if(f==INVALID_HANDLE){dialog(W("Párovací token zatím neexistuje. Počkejte na spuštění hubu."));return;}char buf[257];DWORD n=0;BOOL ok=ReadFile(f,buf,256,&n,NULLPTR);CloseHandle(f);while(n&&(buf[n-1]=='\n'||buf[n-1]=='\r'||buf[n-1]==' '))--n;buf[n]=0;if(!ok||n<32||n>=256){dialog(W("Token není platný. Otevřete diagnostiku."));return;}
 HANDLE h=GlobalAlloc(GMEM_MOVEABLE,(n+1)*2);if(!h)return;WCHAR*t=GlobalLock(h);ascii(t,n+1,buf);GlobalUnlock(h);if(!OpenClipboard(window)){GlobalFree(h);return;}EmptyClipboard();if(!SetClipboardData(CF_UNICODETEXT,h))GlobalFree(h);CloseClipboard();balloon(W("Párovací token zkopírován"),W("Vložte jej do Mission Control: Connect ve VS Code. Token umožňuje přístup k hubu; nesdílejte jej."),0);
}
static void openNotice(const char*id){if(id&&hexId(id,32))memcpy(pendingOpenNotice,id,33);else pendingOpenNotice[0]=0;char ticket[128];if(!healthy){wantOpen=1;nextStart=GetTickCount64();paused=0;return;}if(request(W("/api/desktop/ticket"),1,1,ticket,sizeof(ticket))!=200||al(ticket)!=64){balloon(W("Dashboard není připraven"),W("Zkuste jej znovu otevřít z ikony u hodin. Diagnostiku najdete v nabídce."),1);return;}for(unsigned i=0;i<64;i++)if(!((ticket[i]>='0'&&ticket[i]<='9')||(ticket[i]>='a'&&ticket[i]<='f')))return;
 WCHAR url[512],t[65];wc(url,512,baseUrl);wa(url,512,W("/#desktop-ticket="));ascii(t,65,ticket);wa(url,512,t);if(pendingOpenNotice[0]){wa(url,512,W("&notice="));ascii(t,65,pendingOpenNotice);wa(url,512,t);}pendingOpenNotice[0]=0;if((intptr_t)ShellExecuteW(window,W("open"),url,NULLPTR,NULLPTR,SW_SHOWNORMAL)<=32)dialog(W("Nepodařilo se otevřít výchozí prohlížeč."));
}
static void openDashboard(void){openNotice(NULLPTR);}
static void stopHub(void){if(child.hProcess){if(WaitForSingleObject(child.hProcess,0)==WAIT_TIMEOUT){request(W("/api/desktop/shutdown"),1,1,NULLPTR,0);if(WaitForSingleObject(child.hProcess,2500)==WAIT_TIMEOUT)TerminateProcess(child.hProcess,1);}WaitForSingleObject(child.hProcess,1500);CloseHandle(child.hProcess);child.hProcess=NULLPTR;}if(job){CloseHandle(job);job=NULLPTR;}healthy=0;}
static void failedLaunch(const WCHAR*why){paused=1;healthy=0;tip(W("Mission Control — hub není spuštěn"));balloon(W("Hub nelze spustit"),why,1);}
static void launch(void){
 if(child.hProcess||paused||quitting)return;
 if(request(W("/healthz"),0,0,NULLPTR,0)!=0){failedLaunch(W("Port používá jiný proces nebo starý hub. Ten nebyl ukončen. Změňte port opětovnou instalací, nebo starý hub zavřete a zvolte Restartovat."));return;}
 WCHAR server[CAP],cmd[CAP*3],portText[16],s[65],id[33];join(server,CAP,root,W("src\\server.mjs"));
 if(!fileExists(node)||!fileExists(server)){failedLaunch(W("Chybí runtime nebo soubory aplikace. Spusťte znovu instalátor."));return;}
 if(!randomhex(secret,32)||!randomhex(instance,16)){failedLaunch(W("Windows neposkytl bezpečná náhodná data."));return;}
 logsRotate();SECURITY_ATTRIBUTES sa={sizeof(sa),NULLPTR,1};HANDLE out=CreateFileW(logPath,FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE,&sa,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULLPTR);HANDLE in=CreateFileW(W("NUL"),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,&sa,OPEN_EXISTING,0,NULLPTR);
 if(out==INVALID_HANDLE||in==INVALID_HANDLE){if(out!=INVALID_HANDLE)CloseHandle(out);if(in!=INVALID_HANDLE)CloseHandle(in);failedLaunch(W("Nelze otevřít diagnostický soubor. Zkontrolujte přístup k datovému adresáři."));return;}
 job=CreateJobObjectW(NULLPTR,NULLPTR);JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits;memset(&limits,0,sizeof(limits));limits.BasicLimitInformation.LimitFlags=0x2000;
 if(!job||!SetInformationJobObject(job,9,&limits,sizeof(limits))){if(job)CloseHandle(job);job=NULLPTR;CloseHandle(in);CloseHandle(out);failedLaunch(W("Nelze vytvořit Windows Job Object pro bezpečné vlastnictví hubu."));return;}
 wc(cmd,CAP*3,W("\""));wa(cmd,CAP*3,node);wa(cmd,CAP*3,W("\" \""));wa(cmd,CAP*3,server);wa(cmd,CAP*3,W("\""));
 number(portText,port);ascii(s,65,secret);ascii(id,33,instance);
 SetEnvironmentVariableW(W("MC_PORT"),portText);SetEnvironmentVariableW(W("MC_DATA_DIR"),data);SetEnvironmentVariableW(W("MC_DESKTOP_SECRET"),s);SetEnvironmentVariableW(W("MC_INSTANCE_ID"),id);SetEnvironmentVariableW(W("NODE_OPTIONS"),NULLPTR);SetEnvironmentVariableW(W("NODE_PATH"),NULLPTR);
 STARTUPINFOW si;memset(&si,0,sizeof(si));si.cb=sizeof(si);si.dwFlags=STARTF_USESTDHANDLES;si.hStdOutput=out;si.hStdError=out;si.hStdInput=in;memset(&child,0,sizeof(child));
 BOOL ok=CreateProcessW(node,cmd,NULLPTR,NULLPTR,1,CREATE_NO_WINDOW|CREATE_SUSPENDED,NULLPTR,root,&si,&child);
 SetEnvironmentVariableW(W("MC_DESKTOP_SECRET"),NULLPTR);SetEnvironmentVariableW(W("MC_INSTANCE_ID"),NULLPTR);CloseHandle(out);CloseHandle(in);
 if(!ok){CloseHandle(job);job=NULLPTR;failedLaunch(W("Node.js nelze spustit. Ověřte instalaci a pravidla zabezpečení Windows."));return;}
 if(!AssignProcessToJobObject(job,child.hProcess)){TerminateProcess(child.hProcess,1);CloseHandle(child.hProcess);CloseHandle(child.hThread);memset(&child,0,sizeof(child));CloseHandle(job);job=NULLPTR;failedLaunch(W("Hub nelze bezpečně přiřadit spouštěči. Jiných procesů se aplikace nedotkla."));return;}
 ResumeThread(child.hThread);CloseHandle(child.hThread);child.hThread=NULLPTR;startedAt=GetTickCount64();nextPoll=startedAt+1000;failures=0;healthy=0;tip(W("Mission Control — spouštění hubu…"));
}
static BOOL parseStatus(char*b,unsigned*needs,unsigned*working,unsigned*review,unsigned*total,char**fp){char*lines[8];unsigned n=0;lines[n++]=b;for(char*p=b;*p&&n<8;p++)if(*p=='\n'){*p=0;lines[n++]=p+1;}if(n<8||!eq(lines[0],"MC2")||!eq(lines[1],instance)||al(lines[6])!=64)return 0;unsigned*values[]={needs,working,review,total};for(unsigned i=0;i<4;i++){unsigned x=0;for(char*p=lines[i+2];*p;p++){if(*p<'0'||*p>'9'||x>100000)return 0;x=x*10+(unsigned)(*p-'0');}*values[i]=x;}*fp=lines[6];return 1;}
static void poll(void){char buf[512],*fp;unsigned needs,working,review,total;if(request(W("/api/desktop/status"),0,1,buf,sizeof(buf))!=200||!parseStatus(buf,&needs,&working,&review,&total,&fp)){++failures;if(failures>=3&&GetTickCount64()-startedAt>15000){balloon(W("Hub neodpovídá"),W("Spouštěč obnoví pouze svůj proces hubu. Běžících agentů se nedotkne."),1);stopHub();nextStart=GetTickCount64()+5000;}return;}
 healthy=1;failures=0;if(GetTickCount64()-startedAt>60000)restarts=0;
 WCHAR text[128]=L"Mission Control — ",n[16];number(n,needs);wa(text,128,n);wa(text,128,W(" čeká · "));number(n,working);wa(text,128,n);wa(text,128,W(" pracuje"));tip(text);
 if(!eq(fingerprint,fp))memcpy(fingerprint,fp,65);
 pollNotice();
 if(wantOpen){wantOpen=0;if(pendingOpenNotice[0]){char target[33];memcpy(target,pendingOpenNotice,33);openNotice(target);}else openDashboard();}
}
static void restartHub(void){stopHub();paused=0;restarts=0;nextStart=GetTickCount64();tip(W("Mission Control — restartování hubu…"));}
static void menu(void){POINT p;GetCursorPos(&p);HMENU m=CreatePopupMenu();AppendMenuW(m,MF_STRING,ID_OPEN,W("Otevřít dashboard"));AppendMenuW(m,MF_STRING,ID_TOKEN,W("Zkopírovat párovací token"));AppendMenuW(m,MF_STRING,ID_BRIDGE,W("Doplněk pro VS Code…"));AppendMenuW(m,MF_SEPARATOR,0,NULLPTR);AppendMenuW(m,MF_STRING,ID_RESTART,W("Restartovat hub"));AppendMenuW(m,MF_STRING|(isStartup()?MF_CHECKED:0),ID_STARTUP,W("Spouštět po přihlášení"));AppendMenuW(m,MF_STRING|(notifyEnabled?MF_CHECKED:0),ID_NOTIFY,W("Upozornění u lišty"));AppendMenuW(m,MF_STRING|(noticeSeconds==30?MF_CHECKED:0),130,W("Doba upozornění: 30 sekund"));AppendMenuW(m,MF_STRING|(noticeSeconds==60?MF_CHECKED:0),131,W("Doba upozornění: 60 sekund"));AppendMenuW(m,MF_STRING|(noticeSeconds==120?MF_CHECKED:0),132,W("Doba upozornění: 2 minuty"));AppendMenuW(m,MF_STRING|(noticeSeconds==300?MF_CHECKED:0),133,W("Doba upozornění: 5 minut"));AppendMenuW(m,MF_STRING|(noticeSeconds==0?MF_CHECKED:0),134,W("Doba upozornění: do zavření"));AppendMenuW(m,MF_STRING,ID_LOG,W("Diagnostika a data…"));AppendMenuW(m,MF_STRING,ID_HELP,W("Návod…"));AppendMenuW(m,MF_STRING,ID_MAINTENANCE,W("Opravit / odinstalovat…"));AppendMenuW(m,MF_SEPARATOR,0,NULLPTR);AppendMenuW(m,MF_STRING,ID_QUIT,W("Ukončit Mission Control"));SetForegroundWindow(window);UINT choice=TrackPopupMenu(m,TPM_RETURNCMD|TPM_RIGHTBUTTON,p.x,p.y,0,window,NULLPTR);DestroyMenu(m);PostMessageW(window,0,0,0);if(choice)PostMessageW(window,WM_COMMAND,choice,0);}
static LRESULT wndProc(HWND h,UINT msg,WPARAM wp,LPARAM lp){
 if(msg==taskbarCreated){tray.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP;Shell_NotifyIconW(NIM_ADD,&tray);return 0;}
 if(msg==WM_TRAY){if(lp==WM_LBUTTONDBLCLK||lp==0x405)openDashboard();else if(lp==WM_RBUTTONUP||lp==WM_CONTEXTMENU)menu();return 0;}
 if(msg==WM_TIMER&&!busy&&!quitting){busy=1;if(WaitForSingleObject(quitEvent,0)==WAIT_OBJECT_0){busy=0;PostMessageW(h,WM_CLOSE,0,0);return 0;}if(WaitForSingleObject(openEvent,0)==WAIT_OBJECT_0)openDashboard();uint64_t now=GetTickCount64();if(child.hProcess&&WaitForSingleObject(child.hProcess,0)==WAIT_OBJECT_0){CloseHandle(child.hProcess);child.hProcess=NULLPTR;if(job){CloseHandle(job);job=NULLPTR;}healthy=0;unsigned delay=2u<<(restarts<5?restarts:5);if(delay>60)delay=60;restarts++;nextStart=now+(uint64_t)delay*1000;tip(W("Mission Control — obnovování hubu…"));if(restarts==1)balloon(W("Hub byl ukončen"),W("Spouštěč jej znovu zapne. Podrobnosti případné chyby jsou v diagnostice."),1);}
 if(!child.hProcess&&now>=nextStart)launch();if(child.hProcess&&now>=nextPoll){nextPoll=now+5000;poll();}busy=0;return 0;}
 if(msg==WM_COMMAND){switch((unsigned)wp){case ID_OPEN:openDashboard();break;case ID_TOKEN:copyToken();break;case ID_RESTART:restartHub();break;case ID_LOG:pathLog();break;case ID_STARTUP:toggleStartup();break;case ID_NOTIFY:setNotifications(!notifyEnabled);if(!notifyEnabled)closeNotice();break;case 130:chooseNoticeDuration(30);break;case 131:chooseNoticeDuration(60);break;case 132:chooseNoticeDuration(120);break;case 133:chooseNoticeDuration(300);break;case 134:chooseNoticeDuration(0);break;case ID_HELP:{WCHAR p[CAP];join(p,CAP,root,W("windows\\Navod.html"));ShellExecuteW(h,W("open"),p,NULLPTR,NULLPTR,SW_SHOWNORMAL);break;}case ID_BRIDGE:{WCHAR p[CAP];join(p,CAP,root,W("dist"));ShellExecuteW(h,W("open"),p,NULLPTR,NULLPTR,SW_SHOWNORMAL);break;}case ID_MAINTENANCE:{WCHAR ps[CAP],args[CAP*2],launch[CAP];if(GetEnvironmentVariableW(W("SystemRoot"),ps,CAP-100)){wa(ps,CAP,W("\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"));join(launch,CAP,data,W("maintenance\\Launch.ps1"));wc(args,CAP*2,W("-NoLogo -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File \""));wa(args,CAP*2,launch);wa(args,CAP*2,W("\" -Mode Auto"));ShellExecuteW(h,W("open"),ps,args,NULLPTR,SW_SHOWNORMAL);}break;}case ID_QUIT:PostMessageW(h,WM_CLOSE,0,0);break;}return 0;}
 if(msg==WM_QUERYENDSESSION)return 1;
 if(msg==WM_ENDSESSION&&wp){PostMessageW(h,WM_CLOSE,0,0);return 0;}
 if(msg==WM_CLOSE){quitting=1;closeNotice();KillTimer(h,1);stopHub();Shell_NotifyIconW(NIM_DELETE,&tray);DestroyWindow(h);return 0;}
 if(msg==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProcW(h,msg,wp,lp);
}
void mainCRTStartup(void){
 int mode=mcReadTrayMode();if(mode==MC_MODE_INVALID)ExitProcess(MC_MODE_INVALID);
 if(!GetModuleFileNameW(NULLPTR,exe,CAP-1)||!GetEnvironmentVariableW(W("LOCALAPPDATA"),data,CAP-80))ExitProcess(1);
 wc(root,CAP,exe);parent(root);wa(data,CAP,W("\\AgentMissionControl"));join(node,CAP,root,W("runtime\\node.exe"));join(logPath,CAP,data,W("hub.log"));
 WCHAR pp[CAP];join(pp,CAP,data,W("port.txt"));HANDLE f=CreateFileW(pp,GENERIC_READ,FILE_SHARE_READ,NULLPTR,OPEN_EXISTING,0,NULLPTR);if(f!=INVALID_HANDLE){char b[16];DWORD n=0;if(ReadFile(f,b,15,&n,NULLPTR)){b[n]=0;unsigned v=0;for(unsigned i=0;i<n&&b[i]>='0'&&b[i]<='9';i++)v=v*10+(unsigned)(b[i]-'0');if(v>=1024&&v<=65535)port=v;}CloseHandle(f);}
 wc(baseUrl,128,W("http://127.0.0.1:"));WCHAR num[16];number(num,port);wa(baseUrl,128,num);
 unsigned hash=2166136261u;for(size_t i=0;data[i];i++){hash^=data[i];hash*=16777619u;}number(num,hash);
 wc(mutexName,128,W("Local\\AgentMissionControl-"));wa(mutexName,128,num);wc(openName,128,mutexName);wa(openName,128,W("-open"));wc(quitName,128,mutexName);wa(quitName,128,W("-quit"));
 BOOL background=mode==MC_MODE_BACKGROUND;
 /* --quit is control-only, even when no tray exists. Never create an owner,
  * window, runtime, directory or hub from a shutdown invocation. */
 if(mode==MC_MODE_QUIT){
   HANDLE m=OpenMutexW(0x00100001,0,mutexName);
   if(!m){DWORD err=GetLastError();ExitProcess(err==2?0:2);}
   HANDLE e=OpenEventW(2,0,quitName);
   if(e){SetEvent(e);CloseHandle(e);}
   DWORD result=WaitForSingleObject(m,12000);
   if(result==WAIT_OBJECT_0||result==128){ReleaseMutex(m);CloseHandle(m);ExitProcess(0);}
   CloseHandle(m);ExitProcess(2);
 }
 mutex=CreateMutexW(NULLPTR,1,mutexName);DWORD mutexError=GetLastError();
 if(!mutex)ExitProcess(2);
 if(mutexError==ERROR_ALREADY_EXISTS){HANDLE e=OpenEventW(2,0,openName);if(e){SetEvent(e);CloseHandle(e);}CloseHandle(mutex);ExitProcess(0);}
 CreateDirectoryW(data,NULLPTR);
 openEvent=CreateEventW(NULLPTR,0,0,openName);quitEvent=CreateEventW(NULLPTR,0,0,quitName);if(!openEvent||!quitEvent)ExitProcess(2);
 HANDLE key=openSettings(KEY_READ);if(key){DWORD type=0,v=1,n=4;if(RegQueryValueExW(key,W("Notifications"),NULLPTR,&type,(BYTE*)&v,&n)==0&&type==4)notifyEnabled=v!=0;n=4;v=60;if(RegQueryValueExW(key,W("NotificationSeconds"),NULLPTR,&type,(BYTE*)&v,&n)==0&&type==4&&validNoticeDuration(v))noticeSeconds=v;RegCloseKey(key);}
 WNDCLASSW cls;memset(&cls,0,sizeof(cls));cls.lpfnWndProc=wndProc;cls.hInstance=GetModuleHandleW(NULLPTR);cls.lpszClassName=W("AgentMissionControlTrayV2");RegisterClassW(&cls);window=CreateWindowExW(0,cls.lpszClassName,W("Mission Control"),0,0,0,0,0,NULLPTR,NULLPTR,cls.hInstance,NULLPTR);if(!window)ExitProcess(2);
 memset(&tray,0,sizeof(tray));tray.cbSize=sizeof(tray);tray.hWnd=window;tray.uID=1;tray.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP;tray.uCallbackMessage=WM_TRAY;tray.hIcon=LoadIconW(cls.hInstance,(LPCWSTR)(uintptr_t)1);if(!tray.hIcon)tray.hIcon=LoadIconW(NULLPTR,(LPCWSTR)(uintptr_t)32512);wc(tray.szTip,128,W("Mission Control — spouštění…"));Shell_NotifyIconW(NIM_ADD,&tray);taskbarCreated=RegisterWindowMessageW(W("TaskbarCreated"));
 wantOpen=!background;nextStart=GetTickCount64();SetTimer(window,1,1000,NULLPTR);MSG msg;while(GetMessageW(&msg,NULLPTR,0,0)>0){if(!noticeWindow||!IsDialogMessageW(noticeWindow,&msg)){TranslateMessage(&msg);DispatchMessageW(&msg);}}CloseHandle(openEvent);CloseHandle(quitEvent);ReleaseMutex(mutex);CloseHandle(mutex);ExitProcess(0);
}
