/* Headless, bounded installer controller. There is deliberately no start mode. */
#include "util.h"
#include "arguments.h"
#include "shutdown.h"
void mainCRTStartup(void) {
    int mode=mcReadControllerMode();
    if(mode==MC_MODE_INVALID)ExitProcess(64);
    if(mode==0){mcStopLog("MCSTOP_READY 0.4.2",0);ExitProcess(0);}
    int result=mcRunStop();
    if(result)mcStopLog("MCSTOP_ERROR code=",(DWORD)result);
    ExitProcess((UINT)result);
}
