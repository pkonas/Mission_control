/* Arguments are decoded by Windows, never by substring scanning of the raw
 * command line. Quoted "--quit" must be exactly equivalent to --quit. */
#ifndef MC_ARGUMENTS_H
#define MC_ARGUMENTS_H
#define MC_MODE_OPEN 0
#define MC_MODE_BACKGROUND 1
#define MC_MODE_QUIT 2
#define MC_MODE_INVALID 64
static int mcTrayMode(int count, const WCHAR *const *args) {
    int mode = MC_MODE_OPEN;
    for (int i = 1; i < count; ++i) {
        int next = weq(args[i], W("--quit")) ? MC_MODE_QUIT :
                   weq(args[i], W("--background")) ? MC_MODE_BACKGROUND : MC_MODE_INVALID;
        if (next == MC_MODE_INVALID || (mode != MC_MODE_OPEN && mode != next)) return MC_MODE_INVALID;
        mode = next;
    }
    return mode;
}
static int mcReadTrayMode(void) {
    int count = 0;
    LPWSTR *args = CommandLineToArgvW(GetCommandLineW(), &count);
    if (!args || count < 1) { if (args) LocalFree(args); return MC_MODE_INVALID; }
    int mode = mcTrayMode(count, (const WCHAR *const *)args);
    LocalFree(args);
    return mode;
}
static int mcReadControllerMode(void) {
    int count = 0;
    LPWSTR *args = CommandLineToArgvW(GetCommandLineW(), &count);
    if (!args) return MC_MODE_INVALID;
    int mode = MC_MODE_INVALID;
    if (count == 2 && weq(args[1], W("--stop"))) mode = 1;
    if (count == 2 && weq(args[1], W("--check"))) mode = 0;
    LocalFree(args);
    return mode;
}
static BOOL mcReadStopMode(void) { return mcReadControllerMode() == 1; }
#endif
