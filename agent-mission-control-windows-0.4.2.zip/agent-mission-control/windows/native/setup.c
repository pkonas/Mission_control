/* Small self-extracting GUI launcher. The installer script and payload are local
 * embedded data; only the explicitly confirmed Node runtime is downloaded. */
#include "util.h"
#include "payload.h"
static WCHAR temp[2048],zip[2048],scriptPath[2048],logPath[2048],powershell[2048],command[8192];
static const char bootstrap[] =
"$ErrorActionPreference='Stop'\r\n"
"$failed=$false\r\n"
"$result=0\r\n"
"try {\r\n"
" Add-Type -AssemblyName System.IO.Compression.FileSystem\r\n"
" $destination=Join-Path $PSScriptRoot 'payload'\r\n"
" [IO.Compression.ZipFile]::ExtractToDirectory((Join-Path $PSScriptRoot 'payload.zip'),$destination)\r\n"
" & (Join-Path $destination 'windows\\Install.ps1') -PayloadArchive (Join-Path $PSScriptRoot 'payload.zip')\r\n"
" $failed=[bool]$global:MCInstallFailed\r\n"
" $result=[int]$global:MCSetupExitCode\r\n"
"} catch {\r\n"
" $failed=$true\r\n"
" [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'setup-error.txt'),($_ | Out-String))\r\n"
" Add-Type -AssemblyName System.Windows.Forms\r\n"
" [Windows.Forms.MessageBox]::Show($_.Exception.Message,'Mission Control Setup','OK','Error') | Out-Null\r\n"
"} finally {\r\n"
" if(-not $failed) { Remove-Item -LiteralPath $PSScriptRoot -Recurse -Force -ErrorAction SilentlyContinue }\r\n"
"}\r\n"
"if($failed){exit 1}else{exit $result}\r\n";
static BOOL writeNew(const WCHAR*path,const void*bytes,DWORD size){HANDLE f=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,NULLPTR,1,FILE_ATTRIBUTE_NORMAL,NULLPTR);if(f==INVALID_HANDLE)return 0;DWORD n=0;BOOL ok=WriteFile(f,bytes,size,&n,NULLPTR)&&n==size;CloseHandle(f);return ok;}
static void fail(const WCHAR*text){MessageBoxW(NULLPTR,text,W("Mission Control Setup"),MB_OK|MB_ICONERROR);ExitProcess(1);}
void mainCRTStartup(void){
 char id[33];WCHAR wid[33];if(!randomhex(id,16)||!GetTempPathW(1900,temp))fail(W("Nelze vytvořit dočasný instalační adresář."));ascii(wid,33,id);wa(temp,2048,W("MissionControl-"));wa(temp,2048,wid);if(!CreateDirectoryW(temp,NULLPTR))fail(W("Nelze vytvořit bezpečný pracovní adresář."));
 join(zip,2048,temp,W("payload.zip"));join(scriptPath,2048,temp,W("bootstrap.ps1"));join(logPath,2048,temp,W("setup-console.log"));
 if(!writeNew(zip,payload,(DWORD)sizeof(payload))||!writeNew(scriptPath,bootstrap,(DWORD)sizeof(bootstrap)-1))fail(W("Instalační soubory nelze rozbalit. Ověřte volné místo a oprávnění."));
 if(!GetEnvironmentVariableW(W("SystemRoot"),powershell,1900))fail(W("Nelze najít Windows PowerShell."));wa(powershell,2048,W("\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"));
 if(!fileExists(powershell))fail(W("Tato instalace vyžaduje Windows PowerShell 5.1. Použijte prosím zdrojový ZIP a ověřte systémové součásti."));
 wc(command,8192,W("\""));wa(command,8192,powershell);wa(command,8192,W("\" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File \""));wa(command,8192,scriptPath);wa(command,8192,W("\""));
 SECURITY_ATTRIBUTES sa={sizeof(sa),NULLPTR,1};HANDLE out=CreateFileW(logPath,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,&sa,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULLPTR);HANDLE in=CreateFileW(W("NUL"),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,&sa,OPEN_EXISTING,0,NULLPTR);if(out==INVALID_HANDLE||in==INVALID_HANDLE)fail(W("Nelze otevřít instalační diagnostiku."));
 STARTUPINFOW si;PROCESS_INFORMATION child;memset(&si,0,sizeof(si));memset(&child,0,sizeof(child));si.cb=sizeof(si);si.dwFlags=STARTF_USESTDHANDLES;si.hStdOutput=out;si.hStdError=out;si.hStdInput=in;
 BOOL ok=CreateProcessW(powershell,command,NULLPTR,NULLPTR,1,CREATE_NO_WINDOW,NULLPTR,temp,&si,&child);CloseHandle(out);CloseHandle(in);if(!ok)fail(W("Windows nespustil instalátor. Balíček není podepsaný; neobcházejte firemní bezpečnostní pravidla. Alternativou je zdrojový ZIP pro kontrolu správcem."));
 CloseHandle(child.hThread);WaitForSingleObject(child.hProcess,INFINITE);DWORD code=1;GetExitCodeProcess(child.hProcess,&code);CloseHandle(child.hProcess);
 if(code!=0&&code!=2){WCHAR error[4096]=L"Instalace nebyla dokončena. Diagnostika je zde:\n\n";wa(error,4096,temp);wa(error,4096,W("\n\nPři blokaci firemní politikou předejte zdrojový ZIP správci. Neměňte kvůli instalaci ochranu Windows."));MessageBoxW(NULLPTR,error,W("Mission Control Setup"),MB_OK|MB_ICONERROR);}ExitProcess(code);
}
