/* Installer-only shutdown. No process is started, no shell is invoked, and
 * termination is NEVER based on an executable basename or a stored PID alone.
 * Verified open handles are retained throughout the operation. */
#ifndef MC_SHUTDOWN_H
#define MC_SHUTDOWN_H
#define MC_MAX_TARGETS 32
#define MC_GRACE_MS 12000
#define MC_FORCE_WAIT_MS 5000
#define MC_CHILD_WAIT_MS 4000
#define MC_PROCESS_QUERY 0x1000
#define MC_PROCESS_SYNC 0x100000
#define MC_PROCESS_TERMINATE 1
#define MC_ERROR_NOT_FOUND 2
#define MC_ERROR_NO_MORE_FILES 18

typedef struct {
    HANDLE handle;
    DWORD pid;
    uint64_t created;
    BOOL canTerminate;
} MCStopTarget;
static MCStopTarget mcTrays[MC_MAX_TARGETS],mcChildren[MC_MAX_TARGETS];
static unsigned mcTrayCount,mcChildCount;
static WCHAR mcExpectedExe[2048],mcExpectedNode[2048];
static DWORD mcSession;
static union { uint64_t alignment; BYTE bytes[512]; } mcSelfToken;
static unsigned mcForced;
static void mcStopLog(const char *text,DWORD pid) {
    HANDLE out=GetStdHandle((DWORD)-11); if(!out||out==INVALID_HANDLE)return;
    DWORD written=0;WriteFile(out,text,(DWORD)al(text),&written,NULLPTR);
    if(pid){WCHAR w[16];char a[16];number(w,pid);unsigned i=0;for(;w[i];i++)a[i]=(char)w[i];a[i]=0;WriteFile(out,a,i,&written,NULLPTR);}
    WriteFile(out,"\r\n",2,&written,NULLPTR);
}
static BOOL mcReadOwner(HANDLE process,void *buffer,DWORD cap) {
    HANDLE token=NULLPTR;DWORD used=0;
    if(!OpenProcessToken(process,8,&token))return 0;
    BOOL ok=GetTokenInformation(token,1,buffer,cap,&used);CloseHandle(token);return ok;
}
static BOOL mcSameOwner(HANDLE process) {
    union { uint64_t alignment; BYTE bytes[512]; } token;
    return mcReadOwner(process,token.bytes,sizeof(token.bytes))&&
        EqualSid(*(void**)mcSelfToken.bytes,*(void**)token.bytes);
}
static BOOL mcSamePath(const WCHAR *a,const WCHAR *b) {
    return CompareStringOrdinal(a,-1,b,-1,1)==2;
}
static uint64_t mcCreated(HANDLE process) {
    FILETIME c,e,k,u;if(!GetProcessTimes(process,&c,&e,&k,&u))return 0;
    return ((uint64_t)c.dwHighDateTime<<32)|c.dwLowDateTime;
}
static BOOL mcAlive(MCStopTarget *t) { return WaitForSingleObject(t->handle,0)!=WAIT_OBJECT_0; }
static void mcCloseTargets(void) {
    for(unsigned i=0;i<mcTrayCount;i++)CloseHandle(mcTrays[i].handle);
    for(unsigned i=0;i<mcChildCount;i++)CloseHandle(mcChildren[i].handle);
    mcTrayCount=mcChildCount=0;
}
/* Query first, verify exact image path and owner, then request terminate rights.
 * If denied, retain the query/sync handle and still attempt graceful shutdown. */
static int mcInspect(DWORD pid,const WCHAR *expected,MCStopTarget *target,BOOL forceAccess) {
    DWORD session=0;HANDLE h=OpenProcess(MC_PROCESS_QUERY|MC_PROCESS_SYNC,0,pid);
    if(!h)return GetLastError()==87?0:-1;
    WCHAR path[2048];DWORD n=2048;
    if(!QueryFullProcessImageNameW(h,0,path,&n)) {
        int status=WaitForSingleObject(h,0)==WAIT_OBJECT_0?0:-1;CloseHandle(h);return status;
    }
    if(!mcSamePath(path,expected)){CloseHandle(h);return 0;}
    union {uint64_t alignment;BYTE bytes[512];} owner;
    if(!mcReadOwner(h,owner.bytes,sizeof(owner.bytes))){CloseHandle(h);return -1;}
    if(!EqualSid(*(void**)mcSelfToken.bytes,*(void**)owner.bytes)){CloseHandle(h);return 0;}
    if(!ProcessIdToSessionId(pid,&session)){CloseHandle(h);return -1;}
    if(session!=mcSession){mcStopLog("MCSTOP_OTHER_SESSION pid=",pid);CloseHandle(h);return -1;}
    uint64_t created=mcCreated(h);
    if(!created){CloseHandle(h);return -1;}
    BOOL canTerminate=0;
    if(forceAccess){
        HANDLE full=OpenProcess(MC_PROCESS_QUERY|MC_PROCESS_SYNC|MC_PROCESS_TERMINATE,0,pid);
        if(full){
            // Retain identity across the handle upgrade; never trust a recycled PID.
            if(mcCreated(full)==created){CloseHandle(h);h=full;canTerminate=1;}else CloseHandle(full);
        }
    }
    target->handle=h;target->pid=pid;target->created=created;target->canTerminate=canTerminate;
    return 1;
}
static int mcCollectTrays(void) {
    HANDLE snap=CreateToolhelp32Snapshot(2,0);if(snap==INVALID_HANDLE)return 10;
    PROCESSENTRY32W p;memset(&p,0,sizeof(p));p.dwSize=sizeof(p);
    if(!Process32FirstW(snap,&p)){DWORD error=GetLastError();CloseHandle(snap);return error==MC_ERROR_NO_MORE_FILES?0:10;}
    int failure=0;
    do {
        if(!mcSamePath(p.szExeFile,W("MissionControl.exe")))continue;
        MCStopTarget t;int status=mcInspect(p.th32ProcessID,mcExpectedExe,&t,1);
        if(status<0){failure=11;break;}
        if(status>0){
            if(mcTrayCount>=MC_MAX_TARGETS){CloseHandle(t.handle);failure=12;break;}
            mcTrays[mcTrayCount++]=t;mcStopLog("MCSTOP_VERIFIED_TRAY pid=",t.pid);
        }
    } while(Process32NextW(snap,&p));
    if(!failure&&GetLastError()!=MC_ERROR_NO_MORE_FILES)failure=10;
    CloseHandle(snap);return failure;
}
static int mcCollectChildren(void) {
    // These handles are observed only; even a matching node.exe is never killed.
    HANDLE snap=CreateToolhelp32Snapshot(2,0);if(snap==INVALID_HANDLE)return 10;
    PROCESSENTRY32W p;memset(&p,0,sizeof(p));p.dwSize=sizeof(p);
    if(!Process32FirstW(snap,&p)){DWORD error=GetLastError();CloseHandle(snap);return error==MC_ERROR_NO_MORE_FILES?0:10;}
    int failure=0;
    do {
        if(!mcSamePath(p.szExeFile,W("node.exe")))continue;
        for(unsigned i=0;i<mcTrayCount;i++){
            if(p.th32ParentProcessID!=mcTrays[i].pid)continue;
            MCStopTarget t;int status=mcInspect(p.th32ProcessID,mcExpectedNode,&t,0);
            if(status<0){failure=11;break;}
            if(status>0){
                if(t.created<mcTrays[i].created){CloseHandle(t.handle);break;}
                if(mcChildCount>=MC_MAX_TARGETS){CloseHandle(t.handle);failure=12;break;}
                mcChildren[mcChildCount++]=t;mcStopLog("MCSTOP_OBSERVED_HUB pid=",t.pid);
            }
            break;
        }
        if(failure)break;
    } while(Process32NextW(snap,&p));
    if(!failure&&GetLastError()!=MC_ERROR_NO_MORE_FILES)failure=10;
    CloseHandle(snap);return failure;
}
static BOOL mcCloseWindow(HWND window,LPARAM unused) {
    (void)unused;DWORD pid=0;GetWindowThreadProcessId(window,&pid);
    for(unsigned i=0;i<mcTrayCount;i++)if(mcTrays[i].pid==pid&&mcAlive(&mcTrays[i])){
        WCHAR cls[128];
        if(GetClassNameW(window,cls,128)&&weq(cls,W("AgentMissionControlTrayV2"))){
            if(PostMessageW(window,WM_CLOSE,0,0))mcStopLog("MCSTOP_GRACEFUL_REQUEST pid=",pid);
            else mcStopLog("MCSTOP_CLOSE_REQUEST_FAILED pid=",pid);
        }
    }
    return 1;
}
static BOOL mcWaitTargets(MCStopTarget *targets,unsigned count,unsigned budget) {
    uint64_t start=GetTickCount64();
    for(;;){
        BOOL running=0;for(unsigned i=0;i<count;i++)if(mcAlive(&targets[i])){running=1;break;}
        if(!running)return 1;
        if(GetTickCount64()-start>=budget)return 0;
        Sleep(50);
    }
}
static int mcStopVerified(void) {
    // No dependence on legacy --quit parsing or legacy path-derived mutex names.
    if(!mcTrayCount){mcStopLog("MCSTOP_ALREADY_STOPPED",0);return 0;}
    EnumWindows(mcCloseWindow,0);
    if(!mcWaitTargets(mcTrays,mcTrayCount,MC_GRACE_MS)){
        for(unsigned i=0;i<mcTrayCount;i++)if(mcAlive(&mcTrays[i])){
            MCStopTarget *t=&mcTrays[i];
            if(!t->canTerminate){mcStopLog("MCSTOP_ACCESS_DENIED pid=",t->pid);return 13;}
            // Only retained, positively verified tray handles reach TerminateProcess.
            mcStopLog("MCSTOP_FORCED_VERIFIED_TRAY pid=",t->pid);
            if(!TerminateProcess(t->handle,0)){
                if(mcAlive(t)){mcStopLog("MCSTOP_TERMINATE_FAILED pid=",t->pid);return 14;}
            }else mcForced++;
        }
        if(!mcWaitTargets(mcTrays,mcTrayCount,MC_FORCE_WAIT_MS))return 15;
    }
    // The legacy tray already owns its hub through KILL_ON_JOB_CLOSE.
    // A hub that does not exit is reported, never killed by name/PID/port.
    if(!mcWaitTargets(mcChildren,mcChildCount,MC_CHILD_WAIT_MS)){
        mcStopLog("MCSTOP_OWNED_HUB_STILL_RUNNING",0);return 16;
    }
    mcStopLog("MCSTOP_VERIFIED_STOPPED",0);return 0;
}
static int mcRunStop(void) {
    WCHAR local[1800];DWORD n=GetEnvironmentVariableW(W("LOCALAPPDATA"),local,1800);
    if(!n||n>=1800||!((local[0]&&local[1]==':'&&local[2]=='\\')||(local[0]=='\\'&&local[1]=='\\')))return 17;
    if(!join(mcExpectedExe,2048,local,W("Programs\\AgentMissionControl\\MissionControl.exe"))||
       !join(mcExpectedNode,2048,local,W("Programs\\AgentMissionControl\\runtime\\node.exe")))return 17;
    if(!ProcessIdToSessionId(GetCurrentProcessId(),&mcSession)||
       !mcReadOwner(GetCurrentProcess(),mcSelfToken.bytes,sizeof(mcSelfToken.bytes)))return 18;
    int result=mcCollectTrays();
    if(!result&&mcTrayCount)result=mcCollectChildren();
    if(!result)result=mcStopVerified();
    mcCloseTargets();return result;
}
#endif
