'use strict';
// Launched by the WSL extension through Windows interop. No listening socket,
// shell commands, file reads, arbitrary URLs, or approvals are exposed here.
const {createInterface}=require('node:readline');
const rl=createInterface({input:process.stdin,crlfDelay:Infinity});
let queue=Promise.resolve(),queued=0;
function validate(m){
  if(!m||typeof m.id!=='string'||m.id.length>100)throw new Error('Invalid request ID');
  const u=new URL(m.hub);
  if(u.protocol!=='http:'||u.hostname!=='127.0.0.1'||u.username||u.password||u.search||u.hash||!['','/'].includes(u.pathname))throw new Error('Relay only supports Windows loopback HTTP');
  const methods={'/api/ingest':'POST','/api/result':'POST','/api/commands':'GET','/api/claim':'POST','/api/release':'POST','/api/disconnect-source':'POST','/api/connection-status':'GET','/api/reconnect':'POST'};
  const p=new URL(m.path,u.origin);
  if(p.origin!==u.origin||methods[p.pathname]!==m.method||p.hash)throw new Error('Unsupported producer endpoint');
  if(typeof m.token!=='string'||m.token.length<32||m.token.length>256)throw new Error('Missing pairing token');
  return p.href;
}
function emit(obj){process.stdout.write(JSON.stringify(obj)+'\n');}
rl.on('line',line=>{
  if(line.length>3_000_000||queued>=8){emit({id:null,ok:false,error:'Relay input limit exceeded'});rl.close();process.stdin.destroy();return;}
  queued++;
  queue=queue.then(async()=>{let m;try{
    m=JSON.parse(line);const url=validate(m);
    const res=await fetch(url,{method:m.method,headers:{Authorization:`Bearer ${m.token}`,'Content-Type':'application/json'},body:m.method==='POST'?JSON.stringify(m.data):undefined,redirect:'error',signal:AbortSignal.timeout(8000)});
    const text=await res.text();if(Buffer.byteLength(text)>2_000_000)throw new Error('Relay response limit exceeded');
    const body=JSON.parse(text);if(!res.ok)throw Object.assign(new Error(body.error||`HTTP ${res.status}`),{status:res.status,code:body.code,ownerLabel:body.ownerLabel,existingKey:body.existingKey,retryAfterMs:body.retryAfterMs,hubVersion:body.hubVersion,requestId:body.requestId,reason:body.reason});
    emit({id:m.id,ok:true,body});
  }catch(e){emit({id:typeof m?.id==='string'?m.id:null,ok:false,error:e.message,status:e.status,code:e.code,ownerLabel:e.ownerLabel,existingKey:e.existingKey,retryAfterMs:e.retryAfterMs,hubVersion:e.hubVersion,requestId:e.requestId,reason:e.reason});}finally{queued--;}});
});
rl.on('close',()=>{queue.finally(()=>process.exit(0));});
process.stdout.on('error',()=>process.exit(1));
