﻿#requires -Version 5.1
# All lock ownership decisions come from the OS mutex, NEVER from a PID file.
# The name intentionally matches 0.3.0-0.3.3 to exclude old maintenance workers.
# Functions have no startup side effects and do not stop or kill any processes.
function Enter-MCSetupMutex([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { throw 'Chybí název zámku údržby.' }
    $mutex = [Threading.Mutex]::new($false, $Name)
    $acquired = $false; $abandoned = $false
    try {
        try { $acquired = $mutex.WaitOne(0) }
        catch {
            if ($_.Exception.GetBaseException() -is [Threading.AbandonedMutexException]) {
                # .NET grants ownership when it reports abandonment. No timeout
                # or PID-age heuristic may authorize entry to a live mutex.
                $acquired = $true; $abandoned = $true
            } else { throw }
        }
        if (-not $acquired) { $mutex.Dispose(); return $null }
        return [pscustomobject]@{ Mutex=$mutex; Name=$Name; Abandoned=$abandoned; Released=$false }
    } catch { $mutex.Dispose(); throw }
}
function Exit-MCSetupMutex($Lease) {
    if ($null -eq $Lease -or $Lease.Released) { return }
    # Must run on the acquiring thread, in the operation's finally block.
    try { $Lease.Mutex.ReleaseMutex() }
    finally { $Lease.Mutex.Dispose(); $Lease.Released=$true }
}
function Get-MCSetupMutexName {
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    return ('Local\AgentMissionControl-Setup-' + $sid)
}
function Get-MCSetupEntryScript([string]$CommandLine) {
    # Return only a -File entry point; do not mistake mentions in -Command text
    # for a running installer. The caller still labels old workers as candidates.
    $argsList = @(Split-MCCodeArguments $CommandLine)
    for ($i=1; $i -lt $argsList.Count; $i++) {
        if ($argsList[$i] -in @('-Command','-c','-EncodedCommand','-e','-ec')) { return '' }
        if ($argsList[$i] -in @('-File','-f')) {
            if ($i+1 -lt $argsList.Count) { return [string]$argsList[$i+1] }
            return ''
        }
    }
    return ''
}
function Test-MCSetupEntryPath([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    # Diagnostic filtering only. This NEVER authorizes process termination.
    return [bool]($Path -match '(?i)(?:^|[\\/])MissionControl-[a-f0-9]{32}[\\/](?:bootstrap\.ps1|payload[\\/]windows[\\/](?:Install|Source-Setup)\.ps1)$' -or
        $Path -match '(?i)(?:^|[\\/])MissionControl-maintenance-[a-f0-9]{32}[\\/]windows[\\/]Install\.ps1$' -or
        $Path -match '(?i)(?:^|[\\/])AgentMissionControl[\\/]maintenance[\\/]Launch\.ps1$' -or
        $Path -match '(?i)(?:^|[\\/])(?:agent-mission-control|AgentMissionControl)[\\/]windows[\\/](?:Install|Source-Setup|Uninstall)\.ps1$')
}
function Get-MCSetupCandidates {
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $session = [Diagnostics.Process]::GetCurrentProcess().SessionId
    # CIM is read-only here. Candidates aren't proof that a process owns a mutex.
    $rows = @(Get-CimInstance -ClassName Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction Stop)
    foreach ($row in $rows) {
        if ($row.ProcessId -eq $PID -or [int]$row.SessionId -ne $session) { continue }
        try {
            $owner = Invoke-CimMethod -InputObject $row -MethodName GetOwnerSid -ErrorAction Stop
            if ($owner.ReturnValue -ne 0 -or $owner.Sid -ne $sid) { continue }
            $entry = Get-MCSetupEntryScript ([string]$row.CommandLine)
            if (-not (Test-MCSetupEntryPath $entry)) { continue }
            $p = [Diagnostics.Process]::GetProcessById([int]$row.ProcessId)
            try {
                $startTicks = $p.StartTime.ToUniversalTime().Ticks.ToString()
                # Validate against the process creation time captured by CIM,
                # allowing CIM's lower timestamp precision, to reject PID reuse.
                if ($row.CreationDate -and [Math]::Abs(($p.StartTime.ToUniversalTime() - ([datetime]$row.CreationDate).ToUniversalTime()).TotalSeconds) -gt 1) { continue }
                [pscustomobject]@{ ProcessId=[int]$row.ProcessId; ProcessName=[string]$row.Name;
                    ParentProcessId=[int]$row.ParentProcessId; SessionId=$session; UserSid=$sid;
                    StartTimeUtc=$p.StartTime.ToUniversalTime().ToString('o'); StartTicks=$startTicks;
                    EntryScript=$entry; WindowTitle=$p.MainWindowTitle }
            } finally { $p.Dispose() }
        } catch { continue } # A process may exit while it is being inspected.
    }
}
function Read-MCSetupOwner([string]$Directory, [string]$MutexName, [object[]]$Candidates) {
    # An owner record is explanatory only, never a lock or recovery instruction.
    $path = Join-Path $Directory 'setup-owner.json'
    try {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $null }
        Assert-MCNotLink $Directory; Assert-MCNotLink $path
        if ((Get-Item -LiteralPath $path).Length -gt 16384) { return $null }
        $record = [IO.File]::ReadAllText($path) | ConvertFrom-Json
        if ($record.app -ne 'agent-mission-control-setup' -or $record.mutex -cne $MutexName) { return $null }
        foreach ($candidate in $Candidates) {
            if ($candidate.ProcessId -eq $record.processId -and $candidate.StartTicks -ceq [string]$record.startTicks -and
                $candidate.UserSid -ceq $record.userSid -and $candidate.SessionId -eq $record.sessionId) {
                return [pscustomobject]@{ Candidate=$candidate; Version=[string]$record.version;
                    Operation=[string]$record.operation; AcquiredAt=[string]$record.acquiredAt }
            }
        }
    } catch { }
    return $null
}
function Write-MCSetupOwner([string]$Directory, [string]$MutexName, [string]$Version, [string]$Operation) {
    $p = [Diagnostics.Process]::GetCurrentProcess()
    try {
        $record = @{ app='agent-mission-control-setup'; mutex=$MutexName;
            processId=$PID; startTicks=$p.StartTime.ToUniversalTime().Ticks.ToString();
            sessionId=$p.SessionId; userSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;
            version=$Version; operation=$Operation; acquiredAt=[DateTime]::UtcNow.ToString('o') }
        Write-MCAtomic (Join-Path $Directory 'setup-owner.json') ($record | ConvertTo-Json)
    } finally { $p.Dispose() }
}
function Remove-MCSetupOwner([string]$Directory) {
    # Called only while the operation still owns the mutex. May be absent after
    # an explicit uninstall with RemoveData; never recreate user data here.
    $path = Join-Path $Directory 'setup-owner.json'
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return }
    Assert-MCNotLink $Directory; Assert-MCNotLink $path
    [IO.File]::Delete($path)
}
function Get-MCSetupConflictText([string]$Directory, [string]$MutexName) {
    $lines = New-Object 'System.Collections.Generic.List[string]'
    $lines.Add('Zámek údržby je právě obsazen. Soubory aplikace nebyly změněny.')
    $lines.Add('Instalátor běží v powershell.exe; samotné MissionControl-Setup-*.exe nemusí být vidět.')
    $candidates = @()
    try { $candidates = @(Get-MCSetupCandidates) }
    catch { $lines.Add('Výpis pomocných procesů není dostupný: ' + $_.Exception.Message) }
    $record = Read-MCSetupOwner $Directory $MutexName $candidates
    if ($null -ne $record) {
        $c = $record.Candidate
        $lines.Add("Poslední dostupný záznam údržby (nikoliv důkaz držení zámku): PID $($c.ProcessId), $($c.ProcessName), verze $($record.Version), $($record.Operation).")
        $lines.Add("Zahájeno: $($record.AcquiredAt). Vstupní skript: $($c.EntryScript)")
    }
    if ($candidates.Count) {
        $lines.Add('Možné průvodce (jejich vlastnictví zámku nelze potvrdit):')
        foreach ($c in $candidates) {
            $lines.Add("PID $($c.ProcessId) | $($c.ProcessName) | spuštěn $($c.StartTimeUtc)")
            $lines.Add($c.EntryScript)
        }
    } else {
        $lines.Add('Držitele se nepodařilo určit. To není důkaz, že je bezpečné zámek obejít.')
    }
    $lines.Add('Dokončete nebo běžně zavřete předchozího průvodce či jeho chybový dialog, potom operaci zopakujte.')
    $lines.Add('Neukončujte všechny powershell.exe, node.exe ani VS Code. Zámek se neodstraňuje smazáním souboru.')
    return ($lines -join "`r`n")
}
