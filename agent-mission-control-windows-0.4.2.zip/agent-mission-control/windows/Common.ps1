﻿#requires -Version 5.1
# Shared routines intentionally use .NET Process rather than PowerShell native pipelines.
function ConvertTo-MCArgument([AllowEmptyString()][string]$Value) {
    # Windows CommandLineToArgvW / CRT quoting. No cmd.exe interpretation.
    if ($null -eq $Value) { $Value = '' }
    $escaped = [regex]::Replace($Value, '(\\*)"', '$1$1\"')
    $escaped = [regex]::Replace($escaped, '(\\+)$', '$1$1')
    return '"' + $escaped + '"'
}
function Invoke-MCProcess([string]$File, [string[]]$Arguments = @(), [int]$TimeoutSeconds = 240) {
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $File
    $info.Arguments = (($Arguments | ForEach-Object { ConvertTo-MCArgument $_ }) -join ' ')
    $info.UseShellExecute = $false; $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true; $info.RedirectStandardError = $true
    $info.EnvironmentVariables.Remove('NODE_OPTIONS'); $info.EnvironmentVariables.Remove('NODE_PATH')
    $process = New-Object Diagnostics.Process
    $process.StartInfo = $info
    try {
        if (-not $process.Start()) { throw "Proces nelze spustit: $File" }
        # Drain both pipes concurrently before waiting. stderr is just text.
        $outTask = $process.StandardOutput.ReadToEndAsync()
        $errTask = $process.StandardError.ReadToEndAsync()
        $watch = [Diagnostics.Stopwatch]::StartNew()
        while (-not $process.WaitForExit(100)) {
            if ($script:LogBox) { [Windows.Forms.Application]::DoEvents() }
            if ($watch.Elapsed.TotalSeconds -gt $TimeoutSeconds) {
                $process.Kill(); [void]$process.WaitForExit(5000)
                throw "Proces překročil limit $TimeoutSeconds sekund: $File"
            }
        }
        if (-not $outTask.Wait(5000) -or -not $errTask.Wait(5000)) { throw 'Proces ukončil běh, ale neuzavřel diagnostické streamy.' }
        return [pscustomobject]@{ ExitCode = $process.ExitCode; StdOut = $outTask.Result; StdErr = $errTask.Result }
    } finally { $process.Dispose() }
}
function Assert-MCNotLink([string]$Path) {
    if ((Test-Path -LiteralPath $Path) -and ((Get-Item -LiteralPath $Path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw "Odmítám měnit symbolický odkaz nebo junction: $Path"
    }
}
function Assert-MCTree([string]$Path) {
    Assert-MCNotLink $Path
    if (Test-Path -LiteralPath $Path -PathType Container) {
        # Check each directory before descending, rather than following junctions.
        foreach ($entry in Get-ChildItem -LiteralPath $Path -Force) {
            Assert-MCNotLink $entry.FullName
            if ($entry.PSIsContainer) { Assert-MCTree $entry.FullName }
        }
    }
}
function Set-MCPrivateDirectory([string]$Path) {
    Assert-MCNotLink $Path
    [void][IO.Directory]::CreateDirectory($Path)
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    $current = [Security.Principal.WindowsIdentity]::GetCurrent().User
    foreach ($sid in @($current, [Security.Principal.SecurityIdentifier]::new('S-1-5-18'), [Security.Principal.SecurityIdentifier]::new('S-1-5-32-544'))) {
        $rule = [Security.AccessControl.FileSystemAccessRule]::new($sid, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
        [void]$acl.AddAccessRule($rule)
    }
    [IO.Directory]::SetAccessControl($Path, $acl)
}
function Write-MCAtomic([string]$Path, [AllowEmptyString()][string]$Text) {
    # Do not pass PowerShell $null to File.Replace's STRING backup parameter.
    # Windows PowerShell can bind it as "", which .NET rejects as an illegal path.
    # Use unique absolute sibling paths instead. Never delete the destination first.
    if ([string]::IsNullOrWhiteSpace($Path) -or -not [IO.Path]::IsPathRooted($Path)) {
        throw 'Atomický zápis vyžaduje neprázdnou absolutní cestu k souboru.'
    }
    $fullPath = [IO.Path]::GetFullPath($Path)
    $parent = [IO.Path]::GetDirectoryName($fullPath)
    if ([string]::IsNullOrWhiteSpace([IO.Path]::GetFileName($fullPath)) -or
        -not [IO.Directory]::Exists($parent) -or [IO.Directory]::Exists($fullPath)) {
        throw "Neplatný cíl atomického zápisu nebo chybějící rodičovská složka: $fullPath"
    }
    Assert-MCNotLink $parent
    Assert-MCNotLink $fullPath
    $suffix = [Guid]::NewGuid().ToString('N')
    $temporary = "$fullPath.tmp-$suffix"
    $backup = "$fullPath.bak-$suffix"
    $completed = $false
    try {
        # CreateNew cannot truncate an existing file even on a name collision.
        $stream = [IO.FileStream]::new($temporary, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        try {
            $bytes = [Text.UTF8Encoding]::new($false).GetBytes($Text)
            $stream.Write($bytes, 0, $bytes.Length)
            $stream.Flush($true)
        } finally { $stream.Dispose() }
        if ([IO.File]::Exists($fullPath)) {
            [IO.File]::Replace($temporary, $fullPath, $backup)
        } else {
            [IO.File]::Move($temporary, $fullPath)
        }
        $completed = $true
    } catch {
        # On failure preserve any backup/staged file; a failed Replace may have
        # performed part of the operation. The installer owns transaction rollback.
        $inner = $_.Exception.GetBaseException()
        $message = "Atomický zápis selhal. Cíl: $fullPath; dočasný soubor: $temporary; záložní cesta: $backup; příčina: $($inner.Message)"
        throw [IO.IOException]::new($message, $_.Exception)
    } finally {
        if ($completed) {
            foreach ($leftover in @($temporary, $backup)) {
                if ([IO.File]::Exists($leftover)) {
                    try { [IO.File]::Delete($leftover) }
                    catch {
                        # A successful write must not become a failed upgrade just
                        # because antivirus temporarily holds a disposable backup.
                        $message = "Zápis byl dokončen; pomocný soubor nelze uklidit: $leftover"
                        if (Get-Command Write-MCWarning -CommandType Function -ErrorAction SilentlyContinue) { Write-MCWarning $message }
                        else { Write-Warning $message -WarningAction Continue }
                    }
                }
            }
        }
    }
}
function Test-MCAtomicWrite([string]$Directory) {
    # Run the actual production writer on this filesystem and PowerShell/.NET
    # runtime BEFORE stopping the app. Never touch existing configuration files.
    if ([string]::IsNullOrWhiteSpace($Directory) -or -not [IO.Path]::IsPathRooted($Directory)) {
        throw 'Kontrola zápisu vyžaduje absolutní cestu ke složce.'
    }
    $directoryPath = [IO.Path]::GetFullPath($Directory)
    Assert-MCNotLink $directoryPath
    if (-not [IO.Directory]::Exists($directoryPath)) { throw "Složka pro kontrolu zápisu neexistuje: $directoryPath" }
    $probe = Join-Path $directoryPath ('.mc-write-test-' + [Guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($probe)
    $checks = 0
    try {
        foreach ($name in @('port.txt','current.json','vscode-target.json','ověření zápisu [1].json')) {
            $target = Join-Path $probe $name
            foreach ($value in @('4317', '{"version":"0.4.2","text":"Příliš žluťoučký"}', '')) {
                Write-MCAtomic $target $value
                $actual = [IO.File]::ReadAllText($target, [Text.Encoding]::UTF8)
                if ($actual -cne $value) { throw "Kontrola obsahu po zápisu selhala: $target" }
                $expectedBytes = [Text.UTF8Encoding]::new($false).GetBytes($value)
                $actualBytes = [IO.File]::ReadAllBytes($target)
                if ([Convert]::ToBase64String($actualBytes) -cne [Convert]::ToBase64String($expectedBytes)) {
                    throw "Kontrola kódování UTF-8 bez BOM selhala: $target"
                }
                $checks++
            }
        }
        if (@(Get-ChildItem -LiteralPath $probe -Force).Count -ne 4) { throw 'Kontrola zápisu zanechala pomocné soubory.' }
        return [pscustomobject]@{ Checks=$checks; PowerShell=$PSVersionTable.PSVersion.ToString(); Directory=$directoryPath }
    } finally {
        # This is a newly created fixture directory, not any real user data.
        if ([IO.Directory]::Exists($probe)) { [IO.Directory]::Delete($probe, $true) }
    }
}
function Get-MCRegistrySnapshot([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    $key = Get-Item -LiteralPath $Path
    $items = @{}
    foreach ($name in $key.GetValueNames()) { $items[$name] = @{ Value = $key.GetValue($name); Kind = $key.GetValueKind($name).ToString() } }
    return $items
}
function Restore-MCRegistry([string]$Path, $Snapshot) {
    if (Test-Path -LiteralPath $Path) { Remove-Item -LiteralPath $Path -Recurse -Force }
    if ($null -ne $Snapshot) {
        [void](New-Item -Path $Path -Force)
        foreach ($entry in $Snapshot.GetEnumerator()) {
            [void](New-ItemProperty -Path $Path -Name $entry.Key -Value $entry.Value.Value -PropertyType $entry.Value.Kind -Force)
        }
    }
}
function Resolve-MCMode([string]$Requested, [string]$State, [string]$InstalledVersion, [string]$PackageVersion) {
    if ($State -eq 'Conflict') { throw 'Cílový adresář nepatří ověřené instalaci Mission Control. Nebude přepsán ani odstraněn.' }
    $present = $State -ne 'Absent'
    if ($Requested -eq 'Uninstall') { if (-not $present) { throw 'Není nalezena instalace k odinstalování.' }; return 'Uninstall' }
    $old = $null
    if ($InstalledVersion) { [void][version]::TryParse($InstalledVersion, [ref]$old) }
    if ($present -and $old -and $old -gt [version]$PackageVersion) { throw 'Tento balíček je starší než instalovaná verze. Downgrade není povolen; použijte novější instalátor.' }
    if ($Requested -eq 'Auto') {
        if (-not $present) { return 'Install' }
        if ($old -and $old -lt [version]$PackageVersion) { return 'Update' }
        return 'Repair'
    }
    if ($Requested -eq 'Install' -and $present) { throw 'Aplikace již existuje. Použijte Aktualizovat nebo Opravit.' }
    if ($Requested -in @('Repair','Update') -and -not $present) { throw 'Není nalezena instalace. Použijte Nainstalovat.' }
    if ($Requested -eq 'Update' -and $old -and $old -eq [version]$PackageVersion) { return 'Repair' }
    return $Requested
}
