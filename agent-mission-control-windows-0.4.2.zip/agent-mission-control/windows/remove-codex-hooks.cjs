'use strict';
// Called only during explicit Windows uninstall, before removing our runtime.
// Removes exact handlers whose installation receipt references THAT runtime.
// Never edits Codex policy/trust, other hooks or remote hosts.
const fs=require('node:fs/promises');const path=require('node:path');const os=require('node:os');
const {uninstallHook}=require('../bridge/src/codex-hook-config.cjs');
async function removeForRuntime(node,{homes=[process.env.CODEX_HOME,path.join(os.homedir(),'.codex')].filter(Boolean),platform=process.platform}={}){
  const norm=p=>platform==='win32'?path.win32.resolve(p).toLowerCase():path.resolve(p),result=[];
  for(const home of [...new Set(homes)]){
    let receipt;try{receipt=JSON.parse(await fs.readFile(path.join(home,'mission-control','installed.json'),'utf8'));}catch(e){if(e.code==='ENOENT')continue;throw e;}
    if(typeof receipt.node!=='string'||norm(receipt.node)!==norm(node)){result.push({removed:false,reason:'different-runtime'});continue;}
    result.push(await uninstallHook(home));
  }return result;
}
module.exports={removeForRuntime};
if(require.main===module){const node=process.argv[2];if(!node||!path.isAbsolute(node)){process.exitCode=2;}else removeForRuntime(node).then(r=>console.log(JSON.stringify({ok:true,results:r}))).catch(()=>{console.error('Own Codex hook cleanup failed; no policies/trust were changed.');process.exitCode=1;});}
