﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Auto','Install','Update','Repair','Uninstall')][string]$Mode='Auto',
    [switch]$Unattended, [switch]$RemoveData, [switch]$RemoveBridge,
    [switch]$SkipBridge, [switch]$NoOpen, [switch]$NoAutoStart, [switch]$EnableAutoStart,
    [int]$Port=4317, [string]$CodePath='', [string]$CodeProfile='',
    [string]$CodeUserDataDir='', [string]$CodeExtensionsDir=''
)
$ErrorActionPreference='Stop'
$work=$null; $result=1
try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $expected=Join-Path $env:LOCALAPPDATA 'AgentMissionControl\maintenance'
    if ([IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\') -ne [IO.Path]::GetFullPath($expected).TrimEnd('\')) { throw 'Tento spouštěč patří do cache instalované aplikace. Pro instalaci použijte EXE nebo Install.cmd.' }
    foreach ($p in @($expected,(Join-Path $expected 'current.json'))) {
        if ((Get-Item -LiteralPath $p -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Cache je přesměrování. Spusťte nový originální instalátor.' }
    }
    $record=Get-Content -LiteralPath (Join-Path $expected 'current.json') -Raw | ConvertFrom-Json
    if ($record.app -ne 'agent-mission-control' -or $record.file -notmatch '^payload-[0-9]+\.[0-9]+\.[0-9]+-[a-f0-9]{64}\.zip$' -or $record.sha256 -notmatch '^[a-f0-9]{64}$') { throw 'Poškozená metadata údržby. Spusťte znovu stažený instalační EXE.' }
    $archive=Join-Path $expected $record.file
    if ((Get-Item -LiteralPath $archive -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Archiv údržby je přesměrování.' }
    if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.sha256) { throw 'Kontrolní součet opravného balíčku nesouhlasí. Spusťte originální instalační EXE; kontrolu neobcházejte.' }
    $work=Join-Path $env:TEMP ('MissionControl-maintenance-'+[Guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($work)
    [IO.Compression.ZipFile]::ExtractToDirectory($archive,$work)
    $parameters=@{}; foreach($entry in $PSBoundParameters.GetEnumerator()) { $parameters[$entry.Key]=$entry.Value }
    $parameters['Mode']=$Mode; $parameters['PayloadArchive']=$archive
    & (Join-Path $work 'windows\Install.ps1') @parameters
    $result=[int]$global:MCSetupExitCode
} catch {
    if (-not $Unattended) { Add-Type -AssemblyName System.Windows.Forms; [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Mission Control — údržba','OK','Error') }
    else { [Console]::Error.WriteLine($_.Exception.Message) }
} finally {
    if ($work -and (Test-Path -LiteralPath $work)) { Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue }
}
exit $result
