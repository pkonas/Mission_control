'use strict';
const fs=require('node:fs/promises'),path=require('node:path');const {execFile}=require('node:child_process');
const probe=(file)=>new Promise((resolve,reject)=>execFile(file,['-p','JSON.stringify({name:process.release.name,node:process.versions.node,electron:process.versions.electron||null})'],{windowsHide:true,timeout:8000,maxBuffer:4096},(e,out)=>e?reject(e):resolve(out.trim())));
/** Never assume a local VS Code Electron executable is a standalone Node CLI. */
async function resolveRuntime({configured='',desktopNode='',execPath=process.execPath,platform=process.platform,envPath=process.env.PATH||'',run=probe}={}){
 const p=platform==='win32'?path.win32:path,filename=platform==='win32'?'node.exe':'node';
 const isNode=x=>p.basename(x).toLowerCase()===filename;
 const candidates=configured?[configured]:[desktopNode,isNode(execPath)?execPath:'',...envPath.split(platform==='win32'?';':':').filter(Boolean).map(d=>p.join(d,filename))].filter(Boolean);
 for(const file of [...new Set(candidates)]){
   if(!p.isAbsolute(file))continue;
   try{if(!(await fs.stat(file)).isFile())continue;const r=JSON.parse(await run(file));if(r.name==='node'&&!r.electron&&Number(r.node?.split('.')[0])>=22)return file;}catch{/* Try another actual node executable, never Code.exe. */}
 }
 throw new Error('Samostatný Node.js 22+ nebyl nalezen. Nastavte missionControl.codexHookNode na jeho absolutní cestu. Code.exe ani Code Helper nejsou Node CLI.');
}
module.exports={resolveRuntime};
