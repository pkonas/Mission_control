'use strict';
/** Private, project-scoped bridge between live Codex hook processes and the hub.
 * This server cannot launch commands. One live response socket = one decision.
 * Any failed check/timeout/transport loss yields abstention, never approval.
 */
const http=require('node:http');const fs=require('node:fs/promises');const path=require('node:path');
const {randomBytes,randomUUID,timingSafeEqual}=require('node:crypto');
const {normalize,routeName}=require('./codex-permission-hook.cjs');const {atomic}=require('./codex-hook-config.cjs');
const METHOD='codex/hook/permission';const MAX_TEXT=24000;const MAX_PENDING=20;
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
const short=(x,n=250)=>typeof x==='string'&&x.length>0&&x.length<=n;
class CodexHookServer{
  constructor({home,roots,ensureSession,onChange=()=>{},available=()=>true,now=Date.now,waitMs=300000,onHealth=()=>{},rootAvailable=()=>true,verifyConfig=async()=>true}){
    Object.assign(this,{home,roots,ensureSession,onChange,available,now,waitMs,onHealth,rootAvailable,verifyConfig});this.token=randomBytes(32).toString('hex');this.owner=randomUUID();this.pending=new Map();this.lastOutcome=new Map();this.server=null;this.stopped=false;this.lastEventAt=0;this.count=0;this.seen=new Set();
  }
  status(){return {protocol:1,configured:true,listening:!!this.server&&!this.stopped,lastEventAt:this.lastEventAt,pending:this.pending.size,received:this.count,verified:this.lastEventAt>0};}
  async start(){
    this.routeDir=path.join(this.home,'mission-control','endpoints');await fs.mkdir(this.routeDir,{recursive:true,mode:0o700});
    this.registered=await Promise.all(this.roots.map(async r=>({...r,canonical:normalize(await fs.realpath(r.path))})));
    this.server=http.createServer((req,res)=>void this.handle(req,res).catch(()=>{if(!res.headersSent)this.json(res,400,{decision:'delegate'});else res.destroy();}));
    this.server.requestTimeout=15000;this.server.headersTimeout=10000;this.server.keepAliveTimeout=1000;
    await new Promise((resolve,reject)=>{this.server.once('error',reject);this.server.listen(0,'127.0.0.1',resolve);});this.port=this.server.address().port;
    await this.publish();this.timer=setInterval(()=>{void this.publish().catch(()=>this.abstainAll('Registraci hooku nelze obnovit.'));if(!this.available())this.abstainAll('Připojení k hubu není dostupné.');for(const g of [...this.pending.values()])if(!this.rootAvailable(g.root))this.finish(g,'delegate','Monitorování tohoto projektu bylo odebráno. Pokračuje běžné schvalování Codexu.');},3000);
    this.timer.unref?.();return this;
  }
  async publish(){if(this.stopped)return;if(!await this.verifyConfig()){this.onHealth("Codex hook byl odebrán nebo změněn; rozhodování zastaveno.");await this.stop();return;}if(this.stopped)return;const enabled=this.available();for(const r of this.registered){const file=path.join(this.routeDir,routeName(r.canonical));await atomic(file,JSON.stringify({protocol:1,owner:this.owner,root:r.canonical,port:this.port,token:this.token,expiresAt:enabled&&this.rootAvailable(r.canonical)?this.now()+15000:0}));}}
  json(res,code,body){if(res.destroyed||res.writableEnded)return;res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify({protocol:1,...body}));}
  async handle(req,res){
    if(this.stopped||!this.available()){this.json(res,503,{decision:'delegate'});return;}
    if(req.method!=='POST'||req.url!=='/codex-hook'||req.headers.origin||req.headers.host!==`127.0.0.1:${this.port}`||!equal(req.headers.authorization,'Bearer '+this.token)){this.json(res,403,{decision:'delegate'});return;}
    let size=0,parts=[];for await(const chunk of req){size+=chunk.length;if(size>128*1024){this.json(res,413,{decision:'delegate'});return;}parts.push(chunk);}
    const body=JSON.parse(Buffer.concat(parts).toString('utf8')),e=body.event;
    const root=this.registered.find(r=>r.canonical===body.root);
    if(body.protocol!==1||!root||!this.rootAvailable(body.root)||!short(body.invocationId)||!e||!short(e.session_id)||!short(e.cwd,2000)||!path.isAbsolute(e.cwd)){this.json(res,400,{decision:'delegate'});return;}
    const cwd=normalize(await fs.realpath(e.cwd));if(cwd!==root.canonical&&!cwd.startsWith(root.canonical.replace(/\/$/,'')+'/')){this.json(res,403,{decision:'delegate'});return;}
    const ack={invocationId:body.invocationId,sessionId:e.session_id,turnId:e.turn_id||''};
    if(['Interrupt','Stop','SessionEnd'].includes(e.hook_event_name)){
      for(const g of [...this.pending.values()])if(g.sessionId===e.session_id&&(!e.turn_id||g.turnId===e.turn_id)&&(!e.agent_id||g.agentId===e.agent_id))this.finish(g,'delegate','Codex ukončil nebo přerušil běh.');
      this.json(res,200,{...ack,decision:'delegate'});return;
    }
    if(e.hook_event_name!=='PermissionRequest'||!short(e.turn_id)||!short(e.tool_name,200)||!e.tool_input||typeof e.tool_input!=='object'||Array.isArray(e.tool_input)||this.pending.size>=MAX_PENDING){this.json(res,400,{...ack,decision:'delegate'});return;}
    const full=JSON.stringify({tool:e.tool_name,input:e.tool_input,cwd:e.cwd,session:e.session_id,turn:e.turn_id,...(e.agent_id?{subagent:e.agent_id}:{}),...(e.agent_type?{subagentType:e.agent_type}:{})},null,2);
    if(full.length>MAX_TEXT){this.json(res,413,{...ack,decision:'delegate'});return;}
    // Transport invocation IDs are generated by our hook process, not tool text.
    if(this.seen.has(body.invocationId)){this.json(res,409,{...ack,decision:'delegate'});return;}this.seen.add(body.invocationId);if(this.seen.size>1000)this.seen.delete(this.seen.values().next().value);
    const s=await this.ensureSession(e,root);if(!s||normalize(s.canonicalWorkspace||s.workspace)!==root.canonical||this.stopped||!this.available()||!this.rootAvailable(root.canonical)||this.pending.size>=MAX_PENDING||res.destroyed){this.json(res,503,{...ack,decision:'delegate'});return;}
    const id='codex-hook-'+randomUUID(),at=this.now();
    const g={id,at,eventId:id,sessionId:e.session_id,turnId:e.turn_id,agentId:e.agent_id||'',root:root.canonical,ask:e.tool_name,summary:typeof e.tool_input.description==='string'?e.tool_input.description:`Codex žádá o povolení: ${e.tool_name}`,command:full,expiresAt:at+this.waitMs,res,ack,session:s};
    this.pending.set(id,g);this.lastEventAt=at;this.count++;
    g.timer=setTimeout(()=>this.finish(g,'delegate','Čas pro dashboard vypršel. Pokračuje standardní schvalování Codexu.'),this.waitMs);g.timer.unref?.();
    res.on('close',()=>{if(this.pending.has(id))this.finish(g,'delegate','Hook Codexu ukončil spojení.');});
    s.events||=[];s.events.push({id,at,kind:'question',text:g.summary.slice(0,6000)});s.events=s.events.slice(-100);
    this.onHealth('Codex PermissionRequest: živý dotaz ověřen', {permissionEvent:true});this.onChange();
  }
  decorate(s){
    if(s.agent!=='codex')return s;
    const asks=[...this.pending.values()].filter(g=>g.sessionId===s.id&&g.root===normalize(s.canonicalWorkspace||s.workspace));
    if(!asks.length){const last=this.lastOutcome.get(s.id);if(!last)return s;return {...s,controlNote:last.text,events:[...(s.events||[]).filter(e=>e.id!==last.event.id),last.event].sort((a,b)=>a.at-b.at).slice(-100)};}
    return {...s,evidence:'api',role:'main',historical:false,current:true,runStartedAt:Math.max(s.runStartedAt||0,asks[0].at),state:'needs_approval',stateSince:asks[0].at,activityAt:asks.at(-1).at,activity:asks[0].summary,turnId:asks[0].turnId,
      capabilities:['open','codexDecision'],controlNote:'Živý PermissionRequest původního Codexu. Run / Deny platí jen pro tento dotaz; ne pro celou relaci. Bez rozhodnutí se po 5 minutách vrátí běžné schvalování.',
      pending:asks.map(g=>({id:g.id,method:METHOD,at:g.at,eventId:g.eventId,ask:g.ask,summary:g.summary,command:g.command,expiresAt:g.expiresAt,turnId:g.turnId}))};
  }
  finish(g,decision,text){
    if(!this.pending.has(g.id))return false;this.pending.delete(g.id);clearTimeout(g.timer);
    const at=this.now(),s=g.session;
    this.lastOutcome.set(g.sessionId,{text,event:{id:g.id+'-result',at,kind:'control',text}});
    // A hook-only session is not a continuous activity feed. Do not invent a
    // running/completed state; a newer observed event may provide the next state.
    if(s.evidence==='api'&&s.sourceKind==='permissionHook'){s.state='unknown';s.activity=text;s.stateSince=at;s.activityAt=at;}
    this.json(g.res,200,{...g.ack,decision});this.onChange();return true;
  }
  decide(c){
    if(c.action!=='codexDecision'||!['run','deny','delegate'].includes(c.decision))throw new Error('Neplatné rozhodnutí Codexu.');
    const g=this.pending.get(c.requestId);
    if(!g||g.sessionId!==c.sessionId||g.turnId!==c.turnId||!this.rootAvailable(g.root)||this.stopped||!this.available()||!Number.isFinite(c.deadline)||c.deadline<this.now()||g.expiresAt<=this.now()||g.res.destroyed||g.res.writableEnded)throw new Error('Živý dotaz Codexu již není dostupný. Rozhodnutí nebylo odesláno.');
    const text=c.decision==='run'?'Run předáno procesu PermissionRequest. Není to potvrzení provedení příkazu.':c.decision==='deny'?'Deny předáno procesu PermissionRequest pro tento dotaz.':'Předáno standardnímu schvalování Codexu. Pokračujte ve VS Code.';
    // Consume the captured socket synchronously before delivery; no replay.
    this.finish(g,c.decision,text);return text;
  }
  abstainAll(reason){for(const g of [...this.pending.values()])this.finish(g,'delegate',reason+' Žádné povolení nebylo uděleno.');}
  async stop(){if(this.stopped)return;this.stopped=true;clearInterval(this.timer);this.abstainAll('Monitoring byl odpojen.');
    for(const r of this.registered||[]){const file=path.join(this.routeDir,routeName(r.canonical));try{const d=JSON.parse(await fs.readFile(file,'utf8'));if(d.owner===this.owner)await atomic(file,JSON.stringify({...d,token:'',expiresAt:0}));}catch{}}
    if(this.server){this.server.closeAllConnections?.();await new Promise(resolve=>this.server.close(resolve));this.server=null;}
  }
}
module.exports={CodexHookServer,METHOD,MAX_TEXT};
