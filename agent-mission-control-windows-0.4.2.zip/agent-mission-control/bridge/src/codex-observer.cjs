'use strict';
const fs=require('node:fs/promises');const path=require('node:path');
const {codexRecord,codexSource}=require('./normalizers.cjs');
const canonical=p=>{let v=path.resolve(p);if(process.platform==='win32')v=v.toLowerCase();return v;};
function matchWorkspace(cwd,folders){if(typeof cwd!=='string'||!path.isAbsolute(cwd))return undefined;const full=canonical(cwd);return [...folders].sort((a,b)=>b.path.length-a.path.length).find(f=>full===canonical(f.path)||full.startsWith(canonical(f.path)+path.sep));}
/** Opt-in observer. Reads only bounded pieces of recent *.jsonl files in CODEX_HOME/sessions. */
class CodexObserver{
  constructor({home,folders,onSession,onHealth=()=>{},sessionFactory,now=()=>Date.now()}){Object.assign(this,{home,folders,onSession,onHealth,sessionFactory,now});this.files=new Map();this.stopped=false;this.busy=false;}
  start(){void this.tick();return this;}
  stop(){this.stopped=true;clearTimeout(this.timer);}
  async discover(){
    const root=path.join(this.home,'sessions');const out=[];let visited=0;
    const walk=async(dir,depth)=>{
      if(depth>4||visited>2000)return;
      let entries;try{entries=await fs.readdir(dir,{withFileTypes:true});}catch(e){if(dir===root)throw e;return;}
      // Prefer recent year/month/day directories; never follow symlinks.
      entries.sort((a,b)=>b.name.localeCompare(a.name));
      for(const e of entries){if(++visited>2000)break;const full=path.join(dir,e.name);if(e.isDirectory())await walk(full,depth+1);else if(e.isFile()&&e.name.endsWith('.jsonl')){try{const st=await fs.stat(full);if(st.mtimeMs>this.now()-48*3600000)out.push({file:full,stat:st});}catch{}}}
    };
    await walk(root,0);return out.sort((a,b)=>b.stat.mtimeMs-a.stat.mtimeMs).slice(0,50);
  }
  async processFile(file,stat){
    let state=this.files.get(file);if(state&&state.mtime===stat.mtimeMs&&state.offset===stat.size)return;
    const h=await fs.open(file,'r');
    try{
      if(!state||stat.size<state.offset){
        const head=Buffer.alloc(Math.min(stat.size,512*1024));await h.read(head,0,head.length,0);
        const first=head.toString('utf8').split('\n')[0];let meta;
        try{const r=JSON.parse(first);if(r.type==='session_meta')meta=r.payload;}catch{}
        const folder=matchWorkspace(meta?.cwd,this.folders);
        if(!folder||!meta?.id)return;
        const session=this.sessionFactory(meta,folder);Object.assign(session,codexSource(meta));session.historical=true;session.current=true;
        state={offset:Math.max(0,stat.size-256*1024),carry:Buffer.alloc(0),skipFirst:stat.size>256*1024,session,mtime:0,initialSize:stat.size};
        this.files.set(file,state);
      }
      let remaining=Math.min(stat.size-state.offset,512*1024);
      if(remaining<=0){state.mtime=stat.mtimeMs;return;}
      const buf=Buffer.alloc(remaining);const read=await h.read(buf,0,remaining,state.offset);state.offset+=read.bytesRead;
      const combined=Buffer.concat([state.carry,buf.subarray(0,read.bytesRead)]);
      const end=combined.lastIndexOf(10);
      if(end<0){state.carry=combined.length<=512*1024?combined:Buffer.alloc(0);if(combined.length>512*1024)state.skipFirst=true;return;}
      let lines=combined.subarray(0,end).toString('utf8').split('\n');state.carry=combined.subarray(end+1);
      if(state.skipFirst){lines.shift();state.skipFirst=false;}
      const historical=state.offset<=state.initialSize;
      for(const line of lines){try{const record=JSON.parse(line);const before=JSON.stringify([state.session.activityAt,state.session.state,state.session.messages?.length]);codexRecord(state.session,record);if(!historical&&before!==JSON.stringify([state.session.activityAt,state.session.state,state.session.messages?.length]))state.session.historical=false;}catch{/* Partial/future records are not interpreted as agent failures. */}}
      state.mtime=stat.mtimeMs;await this.onSession(state.session);
    }finally{await h.close();}
  }
  async tick(){if(this.stopped||this.busy)return;this.busy=true;
    try{const files=await this.discover();for(const f of files){if(this.stopped)break;await this.processFile(f.file,f.stat);}this.onHealth(`Codex observation: ${this.files.size} odpovídajících JSONL relací; schvalování není zaručeno.`);}
    catch(e){this.onHealth(`Codex observation: ${e.code==='ENOENT'?'adresář sessions nebyl nalezen':e.message}`);}
    finally{this.busy=false;if(!this.stopped)this.timer=setTimeout(()=>void this.tick(),4000);}
  }
}
module.exports={CodexObserver,matchWorkspace};
