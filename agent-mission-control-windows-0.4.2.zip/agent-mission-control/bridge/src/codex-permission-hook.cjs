'use strict';
/** Codex PermissionRequest hook. Runs in the ORIGINAL Codex process's hook
 * pipeline. Stdout is exclusively Codex hook JSON; no shell/agent is launched.
 * No verdict on failure => the original approval policy continues, NOT allow.
 * Installed in CODEX_HOME/mission-control/<version>; routes are one level up.
 */
const fs=require('node:fs/promises');
const path=require('node:path');
const http=require('node:http');
const {createHash,randomUUID}=require('node:crypto');
const PROTOCOL=1;
const MAX_INPUT=128*1024;
const EVENTS=new Set(['PermissionRequest','Interrupt','Stop','SessionEnd']);
const normalize=p=>process.platform==='win32'?path.win32.normalize(p).replace(/\\/g,'/').replace(/\/$/,'').toLowerCase():path.normalize(p).replace(/\/$/,'')||'/';
const routeName=root=>createHash('sha256').update(root).digest('hex')+'.json';
async function readInput(input){let bytes=0;const chunks=[];for await(const c of input){const b=Buffer.from(c);bytes+=b.length;if(bytes>MAX_INPUT)throw new Error('input-too-large');chunks.push(b);}return JSON.parse(Buffer.concat(chunks).toString('utf8'));}
async function findRoute(cwd,dir){
  let root=normalize(await fs.realpath(cwd));
  // Most-specific registered project wins. Never guess across filesystems/hosts.
  for(let i=0;i<64;i++){
    try{const r=JSON.parse(await fs.readFile(path.join(dir,routeName(root)),'utf8'));
      if(r.protocol===PROTOCOL&&r.root===root&&Number.isInteger(r.port)&&r.port>0&&r.port<65536&&/^[a-f0-9]{64}$/.test(r.token||'')&&Number.isFinite(r.expiresAt)&&r.expiresAt>Date.now()&&r.expiresAt<Date.now()+60000)return r;
      // An explicit stale/disabled child registration must NOT fall through to a parent.
      return null;
    }catch(e){if(e.code!=='ENOENT')return null;}
    const parent=normalize(path.dirname(root));if(parent===root)break;root=parent;
  }
  return null;
}
function request(route,event,{timeoutMs=310000}={}){return new Promise(resolve=>{
  const invocationId=randomUUID();const payload=JSON.stringify({protocol:PROTOCOL,invocationId,root:route.root,event});
  let done=false;const finish=value=>{if(done)return;done=true;clearTimeout(timer);resolve(value);};
  const req=http.request({hostname:'127.0.0.1',port:route.port,path:'/codex-hook',method:'POST',headers:{Authorization:'Bearer '+route.token,'Content-Type':'application/json','Content-Length':Buffer.byteLength(payload)},agent:false},res=>{
    let data='',bytes=0;res.on('data',c=>{bytes+=c.length;if(bytes>32768){req.destroy();finish({});}else data+=c.toString('utf8');});
    res.on('end',()=>{try{const r=JSON.parse(data);if(res.statusCode===200&&r.protocol===PROTOCOL&&r.invocationId===invocationId&&r.sessionId===event.session_id&&r.turnId===(event.turn_id||'')&&['run','deny'].includes(r.decision)&&event.hook_event_name==='PermissionRequest'){
      finish({hookSpecificOutput:{hookEventName:'PermissionRequest',decision:r.decision==='run'?{behavior:'allow'}:{behavior:'deny',message:'Uživatel zamítl tento požadavek v Mission Control.'}}});
    }else finish({});}catch{finish({});}});
    res.on('error',()=>finish({}));
  });
  const timer=setTimeout(()=>{req.destroy();finish({});},timeoutMs);
  req.on('error',()=>finish({}));req.end(payload);
});}
async function main({input=process.stdin,output=process.stdout,routeDir=path.resolve(__dirname,'..','endpoints'),timeoutMs}={}){
  let verdict={};
  try{const e=await readInput(input);
    if(EVENTS.has(e.hook_event_name)&&typeof e.cwd==='string'&&path.isAbsolute(e.cwd)&&typeof e.session_id==='string'&&e.session_id.length<=250){
      // Never read transcript_path, auth files or the rest of the conversation.
      const route=await findRoute(e.cwd,routeDir);
      if(route)verdict=await request(route,e,{timeoutMs:e.hook_event_name==='PermissionRequest'?timeoutMs:1500});
    }
  }catch{/* Silent abstention: errors must never become an authorization. */}
  output.write(JSON.stringify(verdict)+'\n');return verdict;
}
module.exports={main,findRoute,routeName,normalize,request};
if(require.main===module)void main().catch(()=>{process.stdout.write('{}\n');});
