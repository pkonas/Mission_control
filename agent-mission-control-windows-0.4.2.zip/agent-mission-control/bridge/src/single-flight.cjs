'use strict';
/** All callers receive the same outcome; no overlapping dialogs or producers. */
function singleFlight(fn){
  let pending=null;
  const run=(...args)=>{
    if(pending)return pending;
    pending=Promise.resolve().then(()=>fn(...args)).finally(()=>{pending=null;});
    return pending;
  };
  run.wait=()=>pending||Promise.resolve();
  Object.defineProperty(run,'busy',{get:()=>Boolean(pending)});
  return run;
}
module.exports={singleFlight};

/**
 * Coalesce automatic starts, but NEVER discard a user's explicit resume behind
 * an automatic start. One recovery is queued after that start settles. Concurrent
 * explicit requests share that queued operation. No overlapping collectors.
 */
function recoveryFlight(fn){
  let active=null,queued=null;
  const launch=options=>{
    const entry={resume:options.resume===true,promise:null};
    active=entry;
    entry.promise=Promise.resolve().then(()=>fn(options)).finally(()=>{if(active===entry)active=null;});
    return entry.promise;
  };
  const run=(options={})=>{
    if(queued)return queued;
    if(!active)return launch(options);
    if(!options.resume||active.resume)return active.promise;
    // An auto-start may fail/return paused; the explicit operation still runs.
    const waiting=active.promise.catch(()=>{});
    queued=waiting.then(()=>{queued=null;return launch({...options,resume:true});});
    return queued;
  };
  run.wait=()=>queued||active?.promise||Promise.resolve();
  Object.defineProperty(run,'busy',{get:()=>Boolean(active||queued)});
  return run;
}
module.exports.recoveryFlight=recoveryFlight;
