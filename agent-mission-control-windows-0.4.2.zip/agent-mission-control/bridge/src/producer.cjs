'use strict';
const {randomUUID}=require('node:crypto');
function validateHub(value){const u=new URL(value);if(u.username||u.password||u.search||u.hash||!['http:','https:'].includes(u.protocol)||!['','/'].includes(u.pathname))throw new Error('Invalid hub URL');if(u.protocol==='http:'&&!['127.0.0.1','localhost','[::1]'].includes(u.hostname))throw new Error('Use loopback HTTP through an SSH tunnel, or HTTPS.');return u.origin;}
const conflictCodes=new Set(['CONNECTION_IN_USE','SESSION_IN_USE','RETIRED_EPOCH','RELEASED_CONNECTION','NOT_OWNER','DUPLICATE_SESSION']);
class Producer {
  constructor({hub,token,sourceId,label,getSessions,getProjects=()=>undefined,getHealth=()=>'',onCommand=async()=>{throw new Error('Read-only producer');},onStatus=()=>{},transport=null,resume=false}){
    Object.assign(this,{hub:validateHub(hub),token,sourceId,label,getSessions,getProjects,getHealth,onCommand,onStatus,transport});
    if(typeof token!=='string'||token.length<32)throw new Error('Missing pairing token');
    this.activeProjectRoots=null;this.epoch=randomUUID();this.seq=0;this.stopped=false;this.lastSend=0;this.failures=0;this.dirty=true;this.dirtyVersion=0;
    this.resume=resume===true;this.recoveryRequestId=this.resume?randomUUID():null;this.hubVersion=null;this.lastRequest=null;this.removed=null;this.disconnectFlight=null;this.started=false;this.claimed=false;this.inFlight=null;this.claimFlight=null;this.stopFlight=null;this.conflict=null;
  }
  envelope(){return {version:1,sourceId:this.sourceId,epoch:this.epoch,label:this.label,...(this.getProjects()?{projects:this.getProjects()}:{})};}
  async request(url,method='GET',data){
    this.lastRequest={method,endpoint:url.split('?')[0]};
    if(this.transport)return this.transport.request(this.hub,this.token,url,method,data);
    const res=await fetch(this.hub+url,{method,headers:{Authorization:`Bearer ${this.token}`,...(data?{'Content-Type':'application/json'}:{})},body:data?JSON.stringify(data):undefined,signal:AbortSignal.timeout(8000),redirect:'error'});
    const b=await res.json();
    if(!res.ok)throw Object.assign(new Error(b.error||`HTTP ${res.status}`),{status:res.status,code:b.code,ownerLabel:b.ownerLabel,existingKey:b.existingKey,retryAfterMs:b.retryAfterMs,hubVersion:b.hubVersion,requestId:b.requestId,reason:b.reason});
    return b;
  }
  async inspect(){
    const result=await this.request(`/api/connection-status?sourceId=${encodeURIComponent(this.sourceId)}&epoch=${encodeURIComponent(this.epoch)}`);
    if(result.protocol!==1||typeof result.owned!=='boolean'||result.sourceId!==this.sourceId||result.epoch!==this.epoch)
      throw new Error('Hub nepotvrdil vlastnictví připojení. Aktualizujte hub na 0.4.2 nebo novější.');
    return result;
  }
  connect(){
    if(this.stopped)return Promise.reject(new Error('Producer is stopped'));
    if(this.claimFlight)return this.claimFlight;
    this.claimFlight=(async()=>{
      const recovering=this.resume;
      let result;
      try{
        result=await this.request(recovering?'/api/reconnect':'/api/claim','POST',{
          ...this.envelope(),...(recovering?{recoveryProtocol:1,userInitiated:true,requestId:this.recoveryRequestId}:{})
        });
      }catch(e){
        if(e.status===404)throw Object.assign(new Error('Hub nepodporuje tento způsob připojení. Aktualizujte hub i Windows relay na 0.4.2 nebo novější.'),{code:'HUB_UPGRADE_REQUIRED',status:404});
        throw e;
      }
      if(result.accepted!==true)throw new Error('Hub nepotvrdil jediné připojení. Aktualizujte hub na 0.4.2 nebo novější.');
      if(recovering&&(result.recoveryProtocol!==1||result.sourceId!==this.sourceId||result.epoch!==this.epoch||result.requestId!==this.recoveryRequestId))
        throw Object.assign(new Error('Hub nepotvrdil konkrétní požadavek na obnovu. Obnova se nepovažuje za dokončenou.'),{code:'INVALID_RECOVERY_ACK'});
      this.activeProjectRoots=Array.isArray(result.activeProjectRoots)?result.activeProjectRoots:null;
      this.hubVersion=result.hubVersion||this.hubVersion;
      this.claimed=true;this.resume=false;return result;
    })().finally(()=>{this.claimFlight=null;});
    return this.claimFlight;
  }
  markDirty(){this.dirty=true;this.dirtyVersion++;}
  start(){if(this.started||this.stopped)return this;this.started=true;void this.tick();return this;}
  stop(){
    if(this.stopFlight)return this.stopFlight;
    this.stopped=true;clearTimeout(this.timer);
    this.stopFlight=(async()=>{
      // Wait for in-flight ingestion first. A late heartbeat must not resurrect
      // a released lease or keep another window blocked after explicit stop.
      await this.inFlight?.catch(()=>{});await this.claimFlight?.catch(()=>{});
      try{if(this.claimed)await this.request('/api/release','POST',this.envelope());}catch{/* Server lease also expires after a bounded heartbeat timeout. */}
      finally{this.claimed=false;this.transport?.stop();}
    })();return this.stopFlight;
  }
  disconnect(){
    if(this.disconnectFlight)return this.disconnectFlight;
    this.stopped=true;clearTimeout(this.timer);
    this.disconnectFlight=(async()=>{
      await this.inFlight?.catch(()=>{});await this.claimFlight?.catch(()=>{});await this.stopFlight?.catch(()=>{});
      try{
        const r=await this.request('/api/disconnect-source','POST',this.envelope());
        if(r.removed!==true)throw new Error('Hub nepotvrdil odebrání připojení. Aktualizujte hub na 0.4.2 nebo novější.');
        return r;
      }finally{this.claimed=false;this.transport?.stop();}
    })();return this.disconnectFlight;
  }
  tick(){
    if(this.stopped)return Promise.resolve();
    if(this.inFlight)return this.inFlight;
    this.inFlight=this.sendOnce().finally(()=>{
      this.inFlight=null;
      if(!this.stopped)this.timer=setTimeout(()=>void this.tick(),Math.min(30000,this.failures?1000*2**Math.min(this.failures,5):1000));
    });return this.inFlight;
  }
  async sendOnce(){
    try{
      if(!this.claimed)await this.connect();if(this.stopped)return;
      if(this.dirty||Date.now()-this.lastSend>4500){
        const version=this.dirtyVersion;const sessions=await this.getSessions();if(this.stopped)return;
        const batches=[];let batch=[],bytes=0;
        for(const s of sessions){const size=Buffer.byteLength(JSON.stringify(s));if(size>2500000)throw new Error('One session exceeds the 2.5 MB transport budget');if(batch.length&&(bytes+size>2500000||batch.length>=50)){batches.push(batch);batch=[];bytes=0;}batch.push(s);bytes+=size;}
        if(batch.length||!batches.length)batches.push(batch);
        for(const part of batches){
          if(this.stopped)return;
          const result=await this.request('/api/ingest','POST',{...this.envelope(),leaseVersion:1,seq:++this.seq,health:this.getHealth(),sessions:part});
          this.activeProjectRoots=Array.isArray(result.activeProjectRoots)?result.activeProjectRoots:null;
          if(result.accepted!==true)throw Object.assign(new Error('Hub odmítl aktualizaci relace.'),{code:result.reason==='retired-epoch'?'RETIRED_EPOCH':'INGEST_REJECTED'});
        }
        this.lastSend=Date.now();this.dirty=this.dirtyVersion!==version;
      }
      if(this.stopped)return;
      const b=await this.request(`/api/commands?sourceId=${encodeURIComponent(this.sourceId)}&epoch=${encodeURIComponent(this.epoch)}`);
      for(const c of b.commands||[]){
        if(this.stopped)return;
        let ok=false,message='';
        try{if(c.deadline<Date.now())throw new Error('Command expired');if(c.sourceEpoch!==this.epoch)throw new Error('Command belongs to a different connection');message=await this.onCommand(c)||'Požadavek přijat';ok=true;}catch(e){message=e.message;}
        // No replay of commands on connection loss or a lease handoff.
        await this.request('/api/result','POST',{sourceId:this.sourceId,epoch:this.epoch,id:c.id,ok,message});
      }
      if(this.stopped)return;
      this.failures=0;this.onStatus(true,'Připojeno');
    }catch(e){
      if(this.stopped)return;
      e.endpoint=this.lastRequest?.endpoint||'';this.failures++;
      if(e.code==='CONNECTION_REMOVED'){
        // A user's monitor disconnect is NOT an agent interrupt or an ownership
        // conflict. In particular, a managed Codex client must not close its RPC.
        this.removed=e;this.stopped=true;clearTimeout(this.timer);this.claimed=false;this.transport?.stop();
      }
      // An old relay can omit the machine-readable code. A 409 is terminal,
      // never an endless retry that disables the user's Connect command.
      if(e.status===409&&!e.code)e.code='HUB_CONFLICT';
      if(conflictCodes.has(e.code)||e.code==='HUB_CONFLICT'){
        this.conflict=e;this.stopped=true;clearTimeout(this.timer);
        // If this producer owned another scope, give it up, but never stop the
        // winning bridge or agent. Release verifies source AND epoch.
        try{if(this.claimed)await this.request('/api/release','POST',this.envelope());}catch{}
        this.claimed=false;this.transport?.stop();
      }
      if(this.resume){
        this.resume=false;this.stopped=true;clearTimeout(this.timer);
        // A response can be lost after server-side acceptance. Release only
        // this epoch; another window is never touched. Otherwise lease expires.
        try{await this.request('/api/release','POST',this.envelope());}catch{}
        this.claimed=false;this.transport?.stop();
      }
      if(e.code==='HUB_UPGRADE_REQUIRED'){this.stopped=true;this.transport?.stop();}
      this.onStatus(false,e.message,e);
    }
  }
}
module.exports={Producer,validateHub};
