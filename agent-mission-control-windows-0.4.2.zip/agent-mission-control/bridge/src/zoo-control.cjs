'use strict';
/**
 * Guarded Zoo task adapter, compatibility contract zoo-task-v1.
 * The public pressPrimaryButton/pressSecondaryButton API is intentionally NOT
 * used: it addresses whichever webview button happens to be current later.
 * Zoo currently exposes a TS-private (not JS #private) sidebarProvider on its
 * exported API. Feature-detect it, and target a captured live Task synchronously.
 * Missing/changed internals => read-only; never fall back to generic clicks.
 * Upstream: src/extension/api.ts; src/core/task/Task.ts (2026-10-03).
 */
const {createHash,randomUUID}=require('node:crypto');
const ALLOWED=new Set(['command','tool','use_mcp_server']);
const MAX_TEXT=24000;
class ZooControl {
  constructor(api,{enabled=()=>true,now=Date.now}={}){this.api=api;this.enabled=enabled;this.now=now;this.guards=new Map();this.consumed=new Set();}
  read(taskId){
    if(!this.enabled())return {reason:'Ovládání Zoo Code z dashboardu je v nastavení vypnuté.'};
    const provider=this.api?.sidebarProvider;
    if(!provider||typeof provider.getCurrentTask!=='function')return {reason:'Tato verze Zoo Code neposkytuje ověřitelné task API. Použijte tlačítka ve VS Code.'};
    const task=provider.getCurrentTask();
    if(!task||task.taskId!==taskId)return {reason:'Tato úloha není aktuální úlohou postranního panelu Zoo Code. Otevřete ji ve VS Code.'};
    if(typeof task.handleWebviewAskResponse!=='function'||task.handleWebviewAskResponse.constructor?.name==='AsyncFunction'||
      !('lastMessageTs' in task)||!('askResponse' in task))return {reason:'Rozhraní Zoo Code se změnilo; vzdálené schválení je z bezpečnostních důvodů vypnuté.'};
    const m=task.interactiveAsk||task.idleAsk;
    if(task.abort||task.abandoned||task.askResponse!==undefined||!m||m.type!=='ask'||m.partial||m.isAnswered||!Number.isSafeInteger(m.ts)||task.lastMessageTs!==m.ts)return {reason:'Zoo Code nyní nemá ověřený nezodpovězený požadavek.'};
    if(!ALLOWED.has(m.ask))return {reason:'Tento typ dotazu se řeší ve VS Code. Run/Deny je určené pro povolení příkazu, nástroje nebo MCP.'};
    if(typeof m.text!=='string'||!m.text.trim()||m.text.length>MAX_TEXT||(Array.isArray(m.images)&&m.images.length)||['approve','deny'].includes(m.autoApprovalDecision))return {reason:'Požadavek nelze v dashboardu zobrazit úplně nebo již má automatické rozhodnutí. Posuďte jej ve VS Code.'};
    const fingerprint=createHash('sha256').update(JSON.stringify([taskId,m.ts,m.ask,m.text,m.isProtected===true,m.autoApprovalDecision??null])).digest('hex');
    return {task,m,fingerprint};
  }
  sync(s){
    const x=this.read(s.id),old=this.guards.get(s.id);
    s.capabilities=(s.capabilities||[]).filter(c=>c!=='zooDecision');
    s.pending=(s.pending||[]).filter(p=>p.method!=='zoo/ask/decision');
    if(!x.task){this.guards.delete(s.id);s.controlNote=x.reason;return;}
    const signature=x.task.taskId+':'+x.fingerprint;
    if(this.consumed.has(signature)){s.controlNote='Pro tento dotaz už bylo rozhodnutí odesláno nebo se odesílalo. Výsledek ověřte ve VS Code; automaticky se neopakuje.';return;}
    const guard=old&&old.task===x.task&&old.m===x.m&&old.fingerprint===x.fingerprint?old:{...x,id:'zoo-'+randomUUID(),createdAt:this.now()};
    this.guards.set(s.id,guard);
    s.capabilities.push('zooDecision');s.controlNote='Run / Deny platí jen pro tento konkrétní požadavek; nemění automatické schvalování.';
    s.pending.push({id:guard.id,method:'zoo/ask/decision',ask:x.m.ask,summary:x.m.text,command:x.m.text,eventId:'zoo-'+x.m.ts,at:guard.createdAt,protected:x.m.isProtected===true});
    if(s.state!=='needs_approval'){s.state='needs_approval';s.stateSince=guard.createdAt;}
    s._interactive=true;s.activity=x.m.text.slice(0,600);s.activityAt=Math.max(s.activityAt||0,guard.createdAt);
    // Hydrate an ask that was already waiting when the bridge connected.
    const event={id:'zoo-'+x.m.ts,kind:'question',at:guard.createdAt,text:x.m.text.slice(0,6000)};
    if(!(s.events||[]).some(e=>e.id===event.id))s.events=[...(s.events||[]),event].slice(-100);
  }
  decide(s,c){
    if(c.action!=='zooDecision'||!['run','deny'].includes(c.decision))throw new Error('Nepodporované rozhodnutí Zoo Code.');
    if(c.deadline<this.now())throw new Error('Požadavek na rozhodnutí vypršel.');
    const guard=this.guards.get(s.id);
    if(!guard||guard.id!==c.requestId||c.sessionId!==s.id)throw new Error('Dotaz již není aktuální. Nic nebylo schváleno ani zamítnuto.');
    const x=this.read(s.id);
    if(!x.task||x.task!==guard.task||x.m!==guard.m||x.fingerprint!==guard.fingerprint)throw new Error('Požadavek nebo aktivní úloha Zoo Code se změnily. Otevřete aktuální událost.');
    const signature=x.task.taskId+':'+x.fingerprint;
    if(this.consumed.has(signature))throw new Error('Tento požadavek již byl vyřízen.');
    // No await, webview IPC, task switching or fallback between validation and
    // task-scoped delivery. Reserve BEFORE calling; never replay on exceptions.
    this.consumed.add(signature);if(this.consumed.size>512)this.consumed.delete(this.consumed.values().next().value);
    this.guards.delete(s.id);s.pending=[];s.capabilities=s.capabilities.filter(c=>c!=='zooDecision');
    s.state='unknown';s.stateSince=this.now();s._interactive=false;
    s.activity='Předávání rozhodnutí Zoo Code; čekám na potvrzení a další událost.';s.activityAt=this.now();
    const response=c.decision==='run'?'yesButtonClicked':'noButtonClicked';
    const result=x.task.handleWebviewAskResponse(response);
    if(result&&typeof result.then==='function'){
      Promise.resolve(result).catch(()=>{});
      throw new Error('Zoo Code použilo neočekávané asynchronní rozhraní. Výsledek zkontrolujte ve VS Code; rozhodnutí se neopakuje.');
    }
    if(x.task.askResponse!==response)throw new Error('Zoo Code nepotvrdilo převzetí rozhodnutí. Ověřte jej ve VS Code, neopakujte naslepo.');
    // Delivery confirmation is NOT successful command execution.
    s.controlNote='Rozhodnutí předáno Zoo Code. Čekám na další událost agenta.';s.activity=s.controlNote;
    return c.decision==='run'?'Run předáno Zoo Code pro tento požadavek. Výsledek vykonání sledujte v aktivitě.':'Deny předáno Zoo Code pro tento požadavek. Běh ani celé schvalování nebyly plošně vypnuty.';
  }
}
module.exports={ZooControl,MAX_TEXT,ALLOWED};
