'use strict';
const {createHash,randomUUID}=require('node:crypto');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
function platformFor(environment='',workspace='') {
  return /^windows$/i.test(environment)||/^[a-z]:[\\/]|^\\\\/.test(workspace)?'win32':/^wsl$/i.test(environment)?'wsl':'posix';
}
function normalizeWorkspace(workspace,platform='posix') {
  if(typeof workspace!=='string'||!workspace)return '';
  if(platform==='win32')return path.win32.normalize(workspace).replace(/\\/g,'/').replace(/\/$/,'').toLowerCase();
  return path.posix.normalize(workspace).replace(/\/$/,'')||'/';
}
function sessionIdentity(s) {
  const platform=platformFor(s.environment,s.workspace);
  const workspace=normalizeWorkspace(s.canonicalWorkspace||s.workspace,platform);
  // Environment labels Local Linux and SSH are the same host-side filesystem.
  // WSL remains a different namespace from Windows even for mounted folders.
  const legacy=hash([String(s.host||'').toLowerCase(),platform,workspace,s.agent,s.id]);
  return {key:hash([s.hostId||['legacy',String(s.host||'').toLowerCase(),platform],workspace,s.agent,s.id]).slice(0,24),legacy};
}
function sameSession(a,b) {
  if(a.agent!==b.agent||a.id!==b.id)return false;
  const ia=sessionIdentity(a),ib=sessionIdentity(b);
  return ia.key===ib.key||(!(a.hostId&&b.hostId)&&ia.legacy===ib.legacy);
}
/** Shared per account and host, not per VS Code window/profile/SSH alias.
 * No identifiers are written into the repository or taken from cloud accounts.
 */
async function workspaceIdentity(folders,{home=os.homedir(),hostname=os.hostname(),platform=process.platform,read=fs.readFile,realpath=fs.realpath}={}) {
  const directory=path.join(home,'.agent-mission-control');
  await fs.mkdir(directory,{recursive:true,mode:0o700});
  const file=path.join(directory,`host-${hash([hostname.toLowerCase(),platform]).slice(0,24)}.id`);
  let hostId;
  try{hostId=(await read(file,'utf8')).trim();}catch(e){if(e.code!=='ENOENT')throw e;}
  if(!hostId){
    try{
      const handle=await fs.open(file,'wx',0o600);
      try{await handle.writeFile(randomUUID()+'\n');}finally{await handle.close();}
    }catch(e){if(e.code!=='EEXIST')throw e;}
    // Another extension host may have created the file but not written it yet.
    for(let n=0;n<20;n++){
      hostId=(await read(file,'utf8')).trim();if(hostId)break;
      await new Promise(r=>setTimeout(r,25));
    }
  }
  if(!/^[a-f0-9-]{36}$/.test(hostId||''))throw new Error('Neplatná místní identita Mission Control. Připojení nebylo vytvořeno.');
  const normalized=[];
  for(const f of folders){
    const original=typeof f==='string'?f:f.path;
    // Failure is explicit: silently guessing an unresolved alias permits duplicates.
    const canonical=normalizeWorkspace(await realpath(original),platform==='win32'?'win32':'posix');
    normalized.push({original,canonical});
  }
  const roots=[...new Set(normalized.map(f=>f.canonical))].sort();
  return {hostId,folders:normalized,sourceId:`vscode-${hash([hostId,roots]).slice(0,40)}`};
}
module.exports={hash,normalizeWorkspace,platformFor,sessionIdentity,sameSession,workspaceIdentity};
