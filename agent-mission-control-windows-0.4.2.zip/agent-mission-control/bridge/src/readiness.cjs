'use strict';
/** No I/O: diagnostics remain available while collection is strictly gated. */
function monitoringBlockReason({trusted,folders=[],remoteName,extensionKind}) {
  if(!trusted)return 'Workspace je v Restricted Mode. Monitoring je vypnutý; důvěru povolte pouze známému projektu.';
  if(!folders.length)return 'Otevřete složku projektu; prázdné okno nemá co monitorovat.';
  if(folders.some(f=>!['file','vscode-remote'].includes(f.uri?.scheme)))return 'Virtuální workspace: dostupná je pouze diagnostika.';
  if(remoteName&&extensionKind!==2)return 'Bridge neběží u vzdáleného workspace. Použijte Mission Control: Setup Connection.';
  return '';
}
module.exports={monitoringBlockReason};
