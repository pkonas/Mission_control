'use strict';
/** Conservative, reversible edit of the user's Codex hooks.json. Never edits
 * permissions, sandbox, hook trust, other handlers, or project repository files. */
const fs=require('node:fs/promises');const path=require('node:path');const {randomUUID,createHash}=require('node:crypto');
const VERSION='0.4.2';const MARKER='Mission Control · rozhodnutí v dashboardu';
const EVENTS=['PermissionRequest','Interrupt','Stop','SessionEnd'];
const clone=x=>JSON.parse(JSON.stringify(x));
async function readOptional(file){try{return await fs.readFile(file,'utf8');}catch(e){if(e.code==='ENOENT')return null;throw e;}}
async function atomic(file,text){const tmp=file+'.'+randomUUID()+'.tmp';try{await fs.writeFile(tmp,text,{mode:0o600,flag:'wx'});await fs.rename(tmp,file);}finally{await fs.rm(tmp,{force:true}).catch(()=>{});}}
function quoteSh(s){return "'"+s.replace(/'/g,"'\\''")+"'";}
function buildCommand(node,script,platform=process.platform){
  if(!node||!script||/[\x00\r\n]/.test(node+script))throw new Error('Neplatná cesta hooku nebo runtime.');
  if(platform!=='win32')return quoteSh(node)+' '+quoteSh(script);
  // Explicit Windows PowerShell entry makes the command work with cmd AND
  // PowerShell as Codex's selected hook shell; no PATH lookup for the runtime.
  // Transfer stdin explicitly as UTF-8 to avoid the Windows PowerShell native
  // pipeline's legacy encoding and quoting rules.
  const q=s=>"'"+s.replace(/'/g,"''")+"'";
  const ps=`$ErrorActionPreference='Stop'; $p=New-Object System.Diagnostics.Process; $p.StartInfo.FileName=${q(node)}; $p.StartInfo.Arguments=${q('"'+script+'"')}; $p.StartInfo.UseShellExecute=$false; $p.StartInfo.CreateNoWindow=$true; $p.StartInfo.RedirectStandardInput=$true; $p.StartInfo.RedirectStandardOutput=$true; $p.StartInfo.RedirectStandardError=$true; $p.StartInfo.StandardOutputEncoding=[Text.UTF8Encoding]::new($false); if(-not $p.Start()){exit 1}; $o=$p.StandardOutput.ReadToEndAsync(); $e=$p.StandardError.ReadToEndAsync(); $r=[IO.StreamReader]::new([Console]::OpenStandardInput(),[Text.Encoding]::UTF8); $b=[Text.Encoding]::UTF8.GetBytes($r.ReadToEnd()); $p.StandardInput.BaseStream.Write($b,0,$b.Length); $p.StandardInput.Close(); $p.WaitForExit(); [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); [Console]::Write($o.Result); exit $p.ExitCode`;
  return 'powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand '+Buffer.from(ps,'utf16le').toString('base64');
}
function groups(command){return Object.fromEntries(EVENTS.map(event=>[event,{hooks:[{type:'command',command,timeout:event==='PermissionRequest'?330:3,statusMessage:MARKER}]}]));}
function parse(raw){if(!raw)return {hooks:{}};const doc=JSON.parse(raw.replace(/^\uFEFF/,''));if(!doc||typeof doc!=='object'||Array.isArray(doc)||doc.hooks!=null&&(typeof doc.hooks!=='object'||Array.isArray(doc.hooks)))throw new Error('Existující hooks.json není podporovaný JSON objekt; nebyl změněn.');doc.hooks||={};for(const k of EVENTS)if(doc.hooks[k]!=null&&!Array.isArray(doc.hooks[k]))throw new Error('Existující hook '+k+' není seznam; nebyl změněn.');return doc;}
function removeOwned(doc,receipt){const d=clone(doc);for(const [event,group] of Object.entries(receipt?.groups||{})){if(!EVENTS.includes(event))continue;const key=JSON.stringify(group);if(Array.isArray(d.hooks?.[event])){d.hooks[event]=d.hooks[event].filter(g=>JSON.stringify(g)!==key);if(!d.hooks[event].length)delete d.hooks[event];}}return d;}
async function withLock(home,fn){await fs.mkdir(home,{recursive:true,mode:0o700});const file=path.join(home,'.mission-control-hook.lock');let handle;
  for(let n=0;n<30;n++){try{handle=await fs.open(file,'wx',0o600);await handle.writeFile(JSON.stringify({pid:process.pid}));break;}catch(e){if(e.code!=='EEXIST')throw e;
    try{const x=JSON.parse(await fs.readFile(file,'utf8'));if(Number.isInteger(x.pid)&&x.pid>0){try{process.kill(x.pid,0);}catch(err){if(err.code==='ESRCH')await fs.rm(file,{force:true});}}}catch{}
    await new Promise(r=>setTimeout(r,50));}}
  if(!handle)throw new Error('Právě se upravuje Codex hooks.json. Zkuste operaci znovu; cizí procesy se neukončují.');
  try{return await fn();}finally{await handle.close();await fs.rm(file,{force:true});}}
async function installHook({home,node,platform=process.platform,source=path.join(__dirname,'codex-permission-hook.cjs')}){
  if(!path.isAbsolute(home)||!path.isAbsolute(node))throw new Error('Codex home a Node.js musí mít absolutní cestu.');
  const runtime=await fs.stat(node);if(!runtime.isFile())throw new Error('Node.js runtime nebyl nalezen.');
  return withLock(home,async()=>{const root=path.join(home,'mission-control'),dir=path.join(root,VERSION);await fs.mkdir(dir,{recursive:true,mode:0o700});await fs.mkdir(path.join(root,'endpoints'),{recursive:true,mode:0o700});
    const file=path.join(home,'hooks.json'),receiptFile=path.join(root,'installed.json'),before=await readOptional(file),previous=await readOptional(receiptFile),receipt=previous?JSON.parse(previous):null;
    const script=path.join(dir,'codex-permission-hook.cjs'),bytes=await fs.readFile(source);await atomic(script,bytes);
    const command=buildCommand(node,script,platform),owned=groups(command),doc=removeOwned(parse(before),receipt);
    for(const [event,group] of Object.entries(owned)){doc.hooks[event]||=[];doc.hooks[event].push(group);}
    const after=JSON.stringify(doc,null,2)+'\n';let backup=null;
    if(before!==after){if(before!==null){backup=file+'.before-mission-control-'+Date.now()+'-'+randomUUID()+'.json';await fs.writeFile(backup,before,{mode:0o600,flag:'wx'});}if(await readOptional(file)!==before)throw new Error('hooks.json byl mezitím změněn. Úprava nebyla přepsána.');await atomic(file,after);}
    const installed={version:VERSION,script,node,sha256:createHash('sha256').update(bytes).digest('hex'),groups:owned};
    try{await atomic(receiptFile,JSON.stringify(installed,null,2)+'\n');}catch(e){if(await readOptional(file)===after){if(before===null)await fs.rm(file);else await atomic(file,before);}throw e;}
    return {...installed,home,file,backup};});
}
async function uninstallHook(home){return withLock(home,async()=>{const root=path.join(home,'mission-control'),file=path.join(home,'hooks.json'),rf=path.join(root,'installed.json'),receiptRaw=await readOptional(rf);if(!receiptRaw)return {removed:false};const receipt=JSON.parse(receiptRaw),before=await readOptional(file);if(before!==null){const next=JSON.stringify(removeOwned(parse(before),receipt),null,2)+'\n';if(next!==before){await fs.writeFile(file+'.before-mc-remove-'+Date.now()+'.json',before,{mode:0o600,flag:'wx'});if(await readOptional(file)!==before)throw new Error('hooks.json se změnil, odebrání nebylo dokončeno.');await atomic(file,next);}}await fs.rm(rf,{force:true});return {removed:true};});}
async function installedHook(home){try{const receipt=JSON.parse(await fs.readFile(path.join(home,'mission-control','installed.json'),'utf8'));const doc=parse(await fs.readFile(path.join(home,'hooks.json'),'utf8'));const all=EVENTS.every(e=>doc.hooks[e]?.some(g=>JSON.stringify(g)===JSON.stringify(receipt.groups?.[e])));if(!all)return null;const bytes=await fs.readFile(receipt.script);return createHash('sha256').update(bytes).digest('hex')===receipt.sha256?receipt:null;}catch{return null;}}
module.exports={installHook,uninstallHook,installedHook,buildCommand,removeOwned,parse,VERSION,atomic,groups};
