'use strict';
const fs=require('node:fs/promises');const path=require('node:path');const {execFile,spawn}=require('node:child_process');const {randomUUID}=require('node:crypto');
const run=(command,args)=>new Promise((resolve,reject)=>execFile(command,args,{windowsHide:true,timeout:12000,maxBuffer:32768},(err,out)=>err?reject(new Error(`${command} is unavailable: ${err.message}`)):resolve(out.trim())));
async function readDesktop(remoteName){
  let d;
  if(process.platform==='win32'&&!remoteName){
    const root=path.join(process.env.LOCALAPPDATA||'','AgentMissionControl');
    d=JSON.parse(await fs.readFile(path.join(root,'connection.json'),'utf8'));
    d.token=(await fs.readFile(path.join(root,'token'),'utf8')).trim();
  }else if(remoteName==='wsl'){
    // Fixed PowerShell expression; paths and tokens are NOT inserted into code or arguments.
    const code='$ErrorActionPreference="Stop";[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);$r=Join-Path $env:LOCALAPPDATA "AgentMissionControl";$d=Get-Content -LiteralPath (Join-Path $r "connection.json") -Raw | ConvertFrom-Json;$t=[IO.File]::ReadAllText((Join-Path $r "token")).Trim();$d|Add-Member -NotePropertyName token -NotePropertyValue $t;$d|ConvertTo-Json -Compress';
    const output=await run('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-Command',code]);
    d=JSON.parse(output.replace(/^\uFEFF/,''));
    d.linuxNode=await run('wslpath',['-u',d.node]);
  }else throw new Error('Automatic Windows pairing is available only in local Windows or WSL. Use Mission Control: Connect for SSH.');
  if(d.version!==1||typeof d.token!=='string'||d.token.length<32)throw new Error('Windows app connection descriptor is invalid');
  const u=new URL(d.hub);if(u.protocol!=='http:'||u.hostname!=='127.0.0.1'||u.username||u.password||u.search||u.hash||!['','/'].includes(u.pathname))throw new Error('Windows app must use loopback');
  if(remoteName==='wsl'&&(typeof d.relay!=='string'||!d.relay.endsWith('\\windows\\wsl-relay.cjs')||typeof d.linuxNode!=='string'||!d.linuxNode.endsWith('/node.exe')))throw new Error('Invalid Windows relay paths');
  return d;
}
class RelayTransport{
  constructor({command,args=[]}){this.command=command;this.args=args;this.pending=new Map();this.buffer='';this.child=null;this.stopped=false;}
  ensure(){if(this.stopped)throw new Error('Relay is stopped');if(this.child)return;
    const child=spawn(this.command,this.args,{stdio:['pipe','pipe','pipe'],windowsHide:true,shell:false});this.child=child;
    const fail=reason=>{if(this.child!==child)return;this.child=null;for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(new Error(reason));}this.pending.clear();this.buffer='';};
    child.on('error',e=>fail(`Windows relay: ${e.message}`));child.on('exit',()=>fail('Windows relay disconnected'));
    child.stdin.on('error',()=>fail('Windows relay input closed'));
    child.stderr.on('data',()=>{}); // Do not persist accidental credential-bearing diagnostics.
    child.stdout.setEncoding('utf8');child.stdout.on('data',chunk=>{this.buffer+=chunk;if(this.buffer.length>3_000_000){fail('Relay output limit');child.kill();return;}let i;while((i=this.buffer.indexOf('\n'))>=0){const line=this.buffer.slice(0,i);this.buffer=this.buffer.slice(i+1);try{const r=JSON.parse(line);const p=this.pending.get(r.id);if(!p)continue;this.pending.delete(r.id);clearTimeout(p.timer);r.ok?p.resolve(r.body):p.reject(Object.assign(new Error(r.error||'Relay failed'),{status:r.status,code:r.code,ownerLabel:r.ownerLabel,existingKey:r.existingKey,retryAfterMs:r.retryAfterMs,hubVersion:r.hubVersion,requestId:r.requestId,reason:r.reason}));}catch{fail('Invalid Windows relay response');child.kill();}}});
  }
  request(hub,token,endpoint,method,data){this.ensure();return new Promise((resolve,reject)=>{const id=randomUUID();const timer=setTimeout(()=>{this.pending.delete(id);reject(new Error('Windows relay timed out'));},12000);this.pending.set(id,{resolve,reject,timer});this.child.stdin.write(JSON.stringify({id,hub,token,path:endpoint,method,data})+'\n');});}
  stop(){this.stopped=true;for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(new Error('Relay stopped'));}this.pending.clear();if(this.child){this.child.stdin.end();const child=this.child;setTimeout(()=>{if(child.exitCode===null)child.kill();},1000).unref();}this.child=null;}
}
module.exports={readDesktop,RelayTransport};
