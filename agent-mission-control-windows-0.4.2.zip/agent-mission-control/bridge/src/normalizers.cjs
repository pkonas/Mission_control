'use strict';
/** Small, pure adapters, shared by the workspace extension, Codex client and tests. */
const STATES = new Set(['unknown','idle','working','needs_input','needs_approval','error','review','paused']);
const clip = (v, n = 2400) => String(v ?? '').slice(0, n);
function addEvent(s, kind, text, id, at = Date.now()) {
  if (!text) return;
  const e = {id: String(id || `${at}-${s.events?.length || 0}`), at, kind, text: clip(text, 6000)};
  s.events ||= [];
  const old = s.events.findIndex(x => x.id === e.id);
  if (old >= 0) s.events[old] = e; else s.events.push(e);
  s.events = s.events.slice(-100);
  s.activityAt = Math.max(s.activityAt || 0, at);
}
function setState(s, state, at = Date.now()) {
  if (!STATES.has(state)) return;
  if (s.state !== state) { s.state = state; s.stateSince = at; }
}
function askState(ask) {
  if (['command','tool','use_mcp_server','command_output'].includes(ask)) return 'needs_approval';
  if (['completion_result','resume_completed_task'].includes(ask)) return 'review';
  return 'needs_input';
}
function readableText(text) {
  const raw = clip(text, 6000);
  try { const j = JSON.parse(raw); return clip(j.question || j.command || j.message || j.content || j.text || raw,6000); }
  catch { return raw; }
}
function zooEvent(s, event, args, at = Date.now()) {
  const id = args[0];
  if(event==='taskStarted'){s.runStartedAt=at;s.current=true;}
  s.historical=false;
  if(event==='taskCompleted'&&args[3]?.isSubtask===true)s.role='support';
  switch(event) {
    case 'taskStarted': case 'taskActive': case 'taskUnpaused': case 'taskAskResponded':
      s._interactive = false; s._ask = undefined; s._askText = undefined; setState(s, 'working', at); s.activity = 'Agent pracuje'; break;
    case 'taskInteractive':
      s._interactive = true; setState(s, askState(s._ask), at);
      s.activity = s._askText || 'Agent čeká na vstup v Zoo Code'; break;
    case 'taskIdle':
      if (s._ask) { setState(s, askState(s._ask), at); s.activity = s._askText || 'Zkontrolujte Zoo Code'; }
      else setState(s, 'idle', at);
      break;
    case 'taskCompleted':
      s._interactive = false; setState(s, 'review', at); s.activity = 'Úloha dokončena · připraveno ke kontrole'; break;
    case 'taskAborted': case 'taskPaused': case 'taskResumable':
      s._interactive = false; setState(s, 'paused', at); s.activity = 'Úloha pozastavena / přerušena'; break;
    case 'taskToolFailed':
      // A failed tool can be retried by the agent: never declare the whole task failed.
      addEvent(s, 'warning', `${args[1] || 'Nástroj'}: ${args[2] || 'selhal; agent může pokračovat'}`, undefined, at);
      return;
    case 'message': {
      const m = args[0]?.message;
      if (!m) return;
      const text = readableText(m.text);
      const mid = `zoo-${m.ts ?? at}`;
      if (m.type === 'ask') {
        s._ask = m.ask; s._askText = text;
        // Some ask messages are auto-approved. Only interactive/idle events prove a wait.
        if (s._interactive && !m.partial) { setState(s, askState(m.ask), at); s.activity = text || 'Čeká na odpověď'; }
      }
      const say = m.say || m.ask || 'message';
      // Do not persist raw reasoning or credentials/configuration objects.
      if (['reasoning','api_req_started','api_req_finished','checkpoint_saved'].includes(say)) return;
      if (!text) return;
      addEvent(s, m.type === 'ask' ? 'question' : say, text, mid, at);
      if (['text','followup','completion_result'].includes(say)) {
        s.messages ||= [];
        const msg = {id: mid, at, kind: m.type === 'ask' ? 'question' : 'assistant', text};
        const i = s.messages.findIndex(x => x.id === mid);
        if (i >= 0) s.messages[i] = msg; else s.messages.push(msg);
        s.messages = s.messages.slice(-30);
      }
      if (s.state === 'working') s.activity = clip(text,180);
      return;
    }
    default: return;
  }
  addEvent(s, 'status', s.activity, `${event}-${at}`, at);
}
/** Only documented provenance assigns a role; never classify a JSON message by its words. */
function codexSource(meta={}) {
  const source=meta.source;
  if(source&&typeof source==='object'){
    if(source.internal!==undefined)return {role:'internal',sourceKind:'internal',parentId:''};
    const sub=source.subagent??source.subAgent;
    if(sub!==undefined){
      if(['review','compact'].includes(sub))return {role:'internal',sourceKind:'subagent:'+sub,parentId:''};
      const spawned=sub?.thread_spawn??sub?.threadSpawn;
      return {role:'support',sourceKind:'subagent',parentId:clip(spawned?.parent_thread_id||spawned?.parentThreadId||'',250)};
    }
  }
  if(['cli','vscode','exec','mcp','appServer'].includes(source))return {role:'main',sourceKind:source,parentId:''};
  return {role:'unknown',sourceKind:'unknown',parentId:''};
}
function codexRecord(s, r) {
  const p = r?.payload || {};
  const at = Number.isFinite(Date.parse(r?.timestamp)) ? Date.parse(r.timestamp) : Date.now();
  if (r?.type === 'session_meta') {Object.assign(s,codexSource(p));return {meta:p};}
  if(s.role==='internal')return;
  if (r?.type === 'event_msg') {
    switch(p.type) {
      case 'task_started': case 'turn_started':
        s.runStartedAt=at;s.observedCompletionAt=0;s.turnId=clip(p.turn_id||p.turnId||'',250);
        setState(s,'working',at); s.activity = 'Běh zaznamenán v uložené relaci'; break;
      case 'task_complete': case 'turn_complete':
        s.observedCompletionAt=at;setState(s,'review',at); s.activity = clip(p.last_agent_message || 'Běh dokončen podle záznamu',240); break;
      case 'turn_aborted':
        setState(s,'paused',at); s.activity = 'Běh přerušen podle záznamu'; break;
      case 'agent_message': case 'user_message': {
        if(p.type==='user_message'){s.runStartedAt=at;s.observedCompletionAt=0;}
        const text = clip(p.message,6000);
        if (!text) return;
        const msg = {id:`${r.timestamp}-${p.type}`,at,kind:p.type === 'user_message'?'user':'assistant',text};
        s.messages ||= []; if (!s.messages.some(x=>x.id === msg.id)) s.messages.push(msg);
        s.messages=s.messages.slice(-30);
        s.activity=clip(text,180); addEvent(s,msg.kind,text,msg.id,at); return;
      }
      case 'exec_command_begin':
        s.activity=clip(Array.isArray(p.command) ? p.command.join(' ') : p.command,240); break;
      case 'exec_command_end':
        s.activity=`Příkaz skončil · exit ${p.exit_code ?? '?'}`; break;
      case 'error':
        // A historic error record does not prove the current live state.
        addEvent(s,'warning',clip(p.message),undefined,at); return;
      default: return;
    }
    addEvent(s,'record',s.activity,`${r.timestamp}-${p.type}`,at);
  } else if (r?.type === 'response_item' && ['function_call','custom_tool_call'].includes(p.type)) {
    s.activity = `Nástroj: ${clip(p.name,120)}`;
    addEvent(s,'tool',s.activity,`${r.timestamp}-${p.call_id}`,at);
  }
  // Never infer needs_input or approval from question marks or a long pause.
}
function codexNotification(s, method, p, requestId, at = Date.now()) {
  if (!p) return;
  if (requestId !== undefined && requestId !== null) {
    const pending = {id:requestId,method,summary:clip(p.reason || p.command || p.questions?.map(q=>q.question).join('\n') || method,6000)};
    if (p.command) pending.command=clip(p.command,6000);
    if (Array.isArray(p.questions)) pending.questions=p.questions;
    s.pending ||= []; s.pending=s.pending.filter(x=>String(x.id)!==String(requestId)); s.pending.push(pending);
    setState(s,method.includes('requestUserInput')?'needs_input':'needs_approval',at);
    s.activity=pending.summary; addEvent(s,'question',s.activity,`request-${requestId}`,at); return;
  }
  switch(method) {
    case 'turn/started': s.runStartedAt=at;s.historical=false;s.current=true;s.turnId=p.turn?.id; s.pending=[]; setState(s,'working',at); s.activity='Codex pracuje'; break;
    case 'turn/completed':
      s.pending=[]; setState(s,p.turn?.status === 'failed'?'error':p.turn?.status === 'interrupted'?'paused':'review',at);
      s.activity=p.turn?.error?.message || (s.state==='review'?'Běh dokončen · zkontrolujte výsledek':'Běh ukončen'); break;
    case 'thread/status/changed': {
      const flags=p.status?.activeFlags || [];
      if (flags.includes('waitingOnApproval')) setState(s,'needs_approval',at);
      else if (flags.includes('waitingOnUserInput')) setState(s,'needs_input',at);
      else if (p.status?.type === 'active' && !(s.pending?.length)) setState(s,'working',at);
      else if (p.status?.type === 'systemError') setState(s,'error',at);
      // Idle isn't necessarily a successfully completed turn.
      else if (p.status?.type === 'idle' && s.state==='working') setState(s,'idle',at);
      return;
    }
    case 'serverRequest/resolved':
      s.pending=(s.pending || []).filter(x=>String(x.id)!==String(p.requestId));
      if (s.pending.length) setState(s,s.pending.some(x=>x.method.includes('requestApproval'))?'needs_approval':'needs_input',at);
      else if (['needs_input','needs_approval'].includes(s.state)) setState(s,'working',at);
      return;
    case 'turn/diff/updated':
      s.diff=clip(p.diff,120000); addEvent(s,'file','Aktualizován diff aktuálního běhu',`diff-${p.turnId}`,at); return;
    case 'item/agentMessage/delta': {
      const mid=`agent-${p.itemId}`; s.messages ||= [];
      let m=s.messages.find(x=>x.id===mid);
      if (!m) { m={id:mid,kind:'assistant',at,text:''}; s.messages.push(m); }
      m.text=clip(m.text + (p.delta || ''),12000); m.at=at; s.messages=s.messages.slice(-30);
      s.activity=clip(m.text,180); s.activityAt=at; return;
    }
    case 'item/commandExecution/outputDelta': {
      const mid=`output-${p.itemId}`; const e=s.events?.find(x=>x.id===mid);
      addEvent(s,'terminal',clip((e?.text || '')+(p.delta || ''),6000),mid,at); return;
    }
    case 'item/started': case 'item/completed': {
      const item=p.item || {};
      // Raw reasoning deliberately not displayed/stored.
      if (item.type==='reasoning') return;
      if (item.type==='agentMessage' && item.text) {
        const mid=`agent-${item.id}`; s.messages ||= [];
        const m={id:mid,kind:'assistant',at,text:clip(item.text,12000)};
        const i=s.messages.findIndex(x=>x.id===mid); if(i<0)s.messages.push(m);else s.messages[i]=m;
        s.messages=s.messages.slice(-30);
      }
      s.activity=clip(item.command || (item.type==='fileChange'?'Změny souborů':item.type==='agentMessage'?'Odpověď agenta':item.type || 'Aktivita'),240);
      addEvent(s,item.type || 'activity',s.activity,`item-${item.id}-${method}`,at); return;
    }
    case 'error':
      addEvent(s,'warning',clip(p.error?.message || p.message),undefined,at);
      // willRetry=true is not a terminal failure.
      if (p.willRetry===false) { setState(s,'error',at); s.activity=clip(p.error?.message || p.message); }
      return;
    default: return;
  }
  addEvent(s,'status',s.activity,`${method}-${at}`,at);
}
function publicSession(s) {
  const result={}; for(const [k,v] of Object.entries(s)) if(!k.startsWith('_')) result[k]=v;
  return result;
}
module.exports={STATES,clip,addEvent,setState,askState,zooEvent,codexRecord,codexSource,codexNotification,publicSession};
