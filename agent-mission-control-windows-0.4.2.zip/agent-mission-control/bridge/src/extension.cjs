'use strict';
const vscode=require('vscode');const os=require('node:os');const path=require('node:path');const {randomUUID,randomBytes}=require('node:crypto');const {execFile}=require('node:child_process');
const {workspaceIdentity}=require('./identity.cjs');const {singleFlight,recoveryFlight}=require('./single-flight.cjs');
const {monitoringBlockReason}=require('./readiness.cjs');const {Producer}=require('./producer.cjs');const {readDesktop,RelayTransport}=require('./desktop.cjs');const {CodexObserver}=require('./codex-observer.cjs');const {zooEvent,publicSession}=require('./normalizers.cjs');
const run=(cmd,args)=>new Promise((resolve,reject)=>execFile(cmd,args,{timeout:8000,maxBuffer:512*1024,windowsHide:true},(err,out)=>err?reject(err):resolve(out)));
const {ZooControl}=require('./zoo-control.cjs');
const {CodexHookServer}=require('./codex-hook-server.cjs');
const {normalize:normalizeHookRoot}=require('./codex-permission-hook.cjs');
const {installHook,uninstallHook,installedHook}=require('./codex-hook-config.cjs');
const {resolveRuntime}=require('./codex-hook-runtime.cjs');
const RUNTIME_VERSION='0.4.2';
const RUNTIME_BUILD='0.4.2-codex-hooks.1';
let disposeCurrent=()=>{};
async function activate(context){
  const log=vscode.window.createOutputChannel('Mission Control');context.subscriptions.push(log);
  const status=vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left,4);status.text='$(radio-tower) MC: off';status.command='missionControl.showLog';status.show();context.subscriptions.push(status);
  let producer,observer,zooApi,zooControl,hookServer,gitTimer,removalTimer,bindings=[],sessions=new Map(),projectRoots=[],focusLinks=new Map(),zooHealth='Zoo Code: nepřipojeno',codexHealth='Codex observation: vypnuto',currentGeneration=0,connected=false,connectionMessage='Not paired',connectionState='disconnected',identity=null,shuttingDown=false;
  let lastRecovery=null;
  function recovery(stage,details={}){
    lastRecovery={...lastRecovery,stage,at:new Date().toISOString(),runtimeBuild:RUNTIME_BUILD,...details};
    // Metadata only: never log pairing tokens, chat text or command contents.
    log.appendLine('MC_RECOVERY '+JSON.stringify(lastRecovery));
  }
  const instance=randomUUID();const nonce=randomBytes(24).toString('hex');
  const config=()=>vscode.workspace.getConfiguration('missionControl');
  const codexHome=()=>config().get('codexHome')||process.env.CODEX_HOME||path.join(os.homedir(),'.codex');
  const controlsKey='missionControl.codexDashboardControls.v1';
  const hookEnabled=()=>context.workspaceState.get(controlsKey)===true;
  let hookHealth='Codex Run/Deny: vypnuto';
  const intentKey='missionControl.disconnectIntent.v1';
  const removalSecretKey=p=>`disconnectToken:${p.sourceId}:${p.epoch}`;
  const intent=()=>context.workspaceState.get(intentKey)||{paused:false,pending:null};
  const isPaused=()=>intent().paused===true;
  let intentWrites=Promise.resolve();
  function setIntent(value){
    const write=intentWrites.then(()=>context.workspaceState.update(intentKey,value));
    intentWrites=write.catch(e=>log.appendLine('Uložení záměru připojení: '+e.message));
    return write;
  }
  function pausedStatus(message){connected=false;connectionState='removed';connectionMessage=message;status.text='$(debug-disconnect) MC: odpojeno';status.tooltip=message;contexts();}
  const flushRemoval=singleFlight(async()=>{
    const pending=intent().pending;if(!pending)return {removed:true};
    const token=await context.secrets.get(removalSecretKey(pending));
    if(!token)throw new Error('Chybí uložený token pro dokončení odpojení. Připojení odeberte v dashboardu.');
    let transport=null;
    try{
      if(pending.desktopWsl){const d=await readDesktop('wsl');transport=new RelayTransport({command:d.linuxNode,args:[d.relay]});}
      const remover=new Producer({hub:pending.hub,token,sourceId:pending.sourceId,label:'Dokončení odpojení',getSessions:()=>[],transport});
      // This instance never claims or starts a collector. It only completes the
      // saved removal for the old owner, including after an offline restart.
      remover.epoch=pending.epoch;
      let result;
      try{result=await remover.disconnect();}
      catch(e){if(e.code!=='NOT_OWNER')throw e;result={removed:false,superseded:true};}
      if(intent().pending?.epoch===pending.epoch){
        await setIntent({paused:true,pending:null});
        await context.secrets.delete(removalSecretKey(pending));
      }
      pausedStatus(result.superseded?'Původní připojení již není vlastníkem. Nové připojení zůstalo nedotčené.':'Odpojeno a odebráno z dashboardu. Automatické připojování je vypnuté pro tento workspace.');
      return result;
    }finally{transport?.stop();}
  });
  const folders=()=> (vscode.workspace.workspaceFolders||[]).map(f=>({name:f.name,path:f.uri.fsPath,uri:f.uri}));
  const envLabel=()=>vscode.env.remoteName==='wsl'?'WSL':vscode.env.remoteName==='ssh-remote'?'Remote SSH':process.platform==='win32'?'Windows':'Linux';
  const blocked=()=>monitoringBlockReason({trusted:vscode.workspace.isTrusted,folders:vscode.workspace.workspaceFolders||[],remoteName:vscode.env.remoteName,extensionKind:context.extension.extensionKind});
  async function allowMonitoring(){const reason=blocked();if(!reason)return true;log.appendLine(reason);void vscode.window.showWarningMessage('Mission Control: '+reason);return false;}
  log.appendLine(`Bridge ${RUNTIME_VERSION}; loaded build ${RUNTIME_BUILD}; manifest ${context.extension.packageJSON.version}; VS Code ${vscode.version}; extension host ${os.hostname()}; remote=${vscode.env.remoteName||'local'}; trust=${vscode.workspace.isTrusted}`);
  const base=(id,agent,folder,evidence)=>({id,agent,project:folder?.name||'Workspace',workspace:folder?.path||'',host:os.hostname(),hostId:identity?.hostId||'',canonicalWorkspace:identity?.folders.find(f=>f.original===folder?.path)?.canonical||'',environment:envLabel(),state:'unknown',evidence,role:agent==='zoo'?'main':'unknown',historical:false,current:true,activity:'Čeká na první ověřenou událost',activityAt:Date.now(),stateSince:Date.now(),events:[],messages:[],pending:[],files:[],capabilities:['open'],focusUri:''});
  async function focusLink(s){
    const key=`${s.agent}:${s.id}`;if(focusLinks.has(key))return focusLinks.get(key);
    try{const uri=vscode.Uri.parse(`${vscode.env.uriScheme}://local-mission-control.bridge/focus?window=${encodeURIComponent(instance)}&nonce=${nonce}&agent=${s.agent}&task=${encodeURIComponent(s.id)}`);
    const ext=await vscode.env.asExternalUri(uri);focusLinks.set(key,ext.toString());return ext.toString();}catch(e){log.appendLine(`Focus link unavailable: ${e.message}`);return '';}
  }
  async function ensureZoo(id){
    const key=`zoo:${id}`;if(sessions.has(key))return sessions.get(key);
    if(sessions.size>=80){log.appendLine('Session limit (80) reached in this window. Reconnect the bridge.');return undefined;}
    const roots=folders();const chosen=roots.length===1?roots[0]:roots.find(f=>f.path===config().get('zooProjectRoot',''));if(!chosen)return undefined;
    const s=base(String(id),'zoo',chosen,'api');sessions.set(key,s);
    // A Zoo event does not carry an unambiguous root in a multi-root workspace.
    if(folders().length>1)s.note='Zoo Code přiřazeno ke kořenu, který uživatel výslovně zvolil. API neuvádí kořen úlohy.';
    s.focusUri=await focusLink(s);return s;
  }
  function contexts(){
    for(const [key,value] of [['missionControl.connected',connected],['missionControl.connecting',connectionState==='connecting']]){
      // Context changes only affect UI enablement; all commands also guard in code.
      if(vscode.commands.executeCommand)void Promise.resolve(vscode.commands.executeCommand('setContext',key,value)).catch(()=>{});
    }
  }
  let draining=Promise.resolve();
  function cleanup(){
    currentGeneration++;connected=false;connectionState='disconnected';connectionMessage='Not connected';
    const previous=producer,oldHook=hookServer;hookServer=undefined;producer=undefined;observer?.stop();observer=undefined;
    clearInterval(gitTimer);for(const [event,fn] of bindings)zooApi?.off?.(event,fn);bindings=[];zooApi=undefined;zooControl=undefined;sessions.clear();status.text='$(radio-tower) MC: off';contexts();
    const stopping=Promise.resolve(previous?.stop()).catch(e=>log.appendLine(`Disconnect: ${e.message}`));
    draining=Promise.all([draining,stopping,Promise.resolve(oldHook?.stop()).catch(e=>log.appendLine('Hook stop: '+e.message))]).then(()=>{});return draining;
  }
  disposeCurrent=()=>{shuttingDown=true;clearInterval(removalTimer);return cleanup();};context.subscriptions.push({dispose:disposeCurrent});
  async function attachCodexHooks(generation){
    if(!hookEnabled()){hookHealth='Codex Run/Deny: vypnuto';return;}
    if(!Array.isArray(producer?.activeProjectRoots)){hookHealth='Codex Run/Deny: aktualizujte hub na 0.4.2. Chybí ověření registrovaných projektů.';return;}
    if(!await installedHook(codexHome())){hookHealth='Codex Run/Deny: hook chybí nebo se změnil. Spusťte Enable Codex Dashboard Controls.';log.appendLine(hookHealth);return;}
    if(generation!==currentGeneration||shuttingDown)return;
    const candidate=new CodexHookServer({home:codexHome(),roots:folders(),
      verifyConfig:async()=>Boolean(await installedHook(codexHome())),
      rootAvailable:root=>producer?.activeProjectRoots?.some(p=>normalizeHookRoot(p)===root)===true,
      available:()=>generation===currentGeneration&&!shuttingDown&&connected&&!producer?.stopped&&!isPaused()&&!blocked(),
      ensureSession:async(e,root)=>{
        if(generation!==currentGeneration)return null;
        const key='codex:'+e.session_id;let s=sessions.get(key);
        if(!s){if(sessions.size>=80)return null;s=base(e.session_id,'codex',root,'api');s.role='main';s.sourceKind='permissionHook';s.note='Živý schvalovací hook původního Codexu; sám o sobě není průběžné sledování všech aktivit.';sessions.set(key,s);s.focusUri=await focusLink(s);}
        return s;
      },onChange:()=>producer?.markDirty(),onHealth:(msg,meta={})=>{hookHealth=msg;log.appendLine(meta.permissionEvent?'MC_CODEX_HOOK_VERIFIED: PermissionRequest received (tool text not logged).':'MC_CODEX_HOOK_STATUS: '+msg);}});
    try{await candidate.start();if(generation!==currentGeneration){await candidate.stop();return;}hookServer=candidate;hookHealth='Codex Run/Deny: připraveno, skutečný dotaz zatím neověřen. Důvěru hooku potvrďte v Codexu.';}
    catch(e){await candidate.stop().catch(()=>{});hookHealth='Codex Run/Deny: '+e.message;log.appendLine(hookHealth);}
  }
  const enableCodexControls=singleFlight(async()=>{
    if(!await allowMonitoring())return;
    if(!connected||!producer||producer.stopped){void vscode.window.showWarningMessage('Nejdříve připojte tento workspace k hubu.');return;}
    if(process.platform==='win32'&&vscode.workspace.getConfiguration('chatgpt').get('runCodexInWindowsSubsystemForLinux',false)){
      void vscode.window.showWarningMessage('Codex běží ve WSL, Bridge ve Windows. Otevřete projekt přes Remote WSL a zapněte ovládání tam. Hook i Bridge musí běžet ve stejném prostředí.');return;
    }
    const answer=await vscode.window.showWarningMessage('Zapnout Run / Deny pro původní Codex v tomto workspace?',{modal:true,detail:'Do '+codexHome()+'/hooks.json se přidá příkaz PermissionRequest a úklidové hooky; původní soubor se zálohuje. Obsah požadavků může obsahovat citlivé údaje a půjde do vašeho hubu. Jeden dotaz čeká nejvýše 5 minut; bez rozhodnutí pokračuje běžná politika Codexu. Změna nepovoluje žádný příkaz automaticky a nemění sandbox ani schvalovací politiku. Důvěru nového hooku musíte potvrdit v Codexu. Ostatní projekty se nezapnou.'},'Zapnout Run / Deny');
    if(answer!=='Zapnout Run / Deny')return;
    try{
      let desktopNode='';if(process.platform==='win32'){try{desktopNode=(await readDesktop(null)).node||'';}catch{/* A separately installed Node CLI can be selected instead. */}}
      const node=await resolveRuntime({configured:config().get('codexHookNode',''),desktopNode});
      const out=await installHook({home:codexHome(),node});
      await context.workspaceState.update(controlsKey,true);
      const old=hookServer;hookServer=undefined;await old?.stop();await attachCodexHooks(currentGeneration);
      log.appendLine('MC_CODEX_HOOK_CONFIGURED: '+out.file+'; runtime='+node+'; '+(out.backup?'backup='+out.backup:'no previous config'));
      log.appendLine('Konfigurace není potvrzení funkce. V Codexu zkontrolujte a schvalte hooky (CLI: /hooks) ve stejném CODEX_HOME. Načtěte Codex znovu až po dokončení běhů. Stav ověří první skutečný PermissionRequest.');log.show(true);
      void vscode.window.showInformationMessage('Mission Control: hook je nakonfigurován. Potvrďte jeho důvěru v Codexu (/hooks); po bezpečném načtení Codexu se ověří první nová žádost o povolení.');
    }catch(e){log.appendLine('Codex hook setup: '+e.message);void vscode.window.showErrorMessage('Mission Control: Codex hook nebyl nastaven: '+e.message);}
  });
  async function disableCodexControls(){await context.workspaceState.update(controlsKey,false);const old=hookServer;hookServer=undefined;await old?.stop();hookHealth='Codex Run/Deny: vypnuto pro tento workspace';producer?.markDirty();void vscode.window.showInformationMessage('Run / Deny vypnuto pro tento workspace. Nevyřízené dotazy pokračují běžným schvalováním Codexu.');}
  async function attachZoo(generation){
    if(folders().length>1&&!folders().some(f=>f.path===config().get('zooProjectRoot',''))){zooHealth='Zoo: více kořenů. Použijte Mission Control: Select Zoo Project Root. Bez výběru se aktivity nepřiřazují odhadem.';log.appendLine(zooHealth);return;}
    const ext=vscode.extensions.getExtension(config().get('zooExtensionId','ZooCodeOrganization.zoo-code'));
    if(!ext){zooHealth='Zoo Code není nainstalováno v tomto extension hostu.';log.appendLine(zooHealth);return;}
    try{
      const api=await ext.activate();if(generation!==currentGeneration)return;
      if(!api?.on||!api?.getCurrentTaskStack)throw new Error('Zoo Code neposkytuje očekávané extension API.');
      zooApi=api;zooControl=new ZooControl(api,{enabled:()=>vscode.workspace.isTrusted&&config().get('zooDashboardControls',true)});zooHealth=`Zoo Code ${ext.packageJSON.version}: API připojeno`;
      const events=['taskStarted','taskActive','taskInteractive','taskIdle','taskCompleted','taskAborted','taskPaused','taskUnpaused','taskResumable','taskAskResponded','taskToolFailed','message','taskSpawned','taskDelegated'];
      // Serialize event handling so an async focus-link lookup cannot reorder events.
      let chain=Promise.resolve();
      for(const event of events){const fn=(...args)=>{const at=Date.now();chain=chain.then(async()=>{if(generation!==currentGeneration)return;const id=event==='message'?args[0]?.taskId:args[0];if(typeof id!=='string')return;const s=await ensureZoo(id);if(!s||generation!==currentGeneration)return;s.version=`Zoo ${ext.packageJSON.version}`;if(['taskSpawned','taskDelegated'].includes(event)){const child=await ensureZoo(args[1]);if(child){child.role='support';child.parentId=s.id;}producer?.markDirty();return;}zooEvent(s,event,args,at);zooControl?.sync(s);producer?.markDirty();}).catch(e=>log.appendLine(`Zoo event: ${e.message}`));};api.on(event,fn);bindings.push([event,fn]);}
      for(const id of api.getCurrentTaskStack()||[]){const s=await ensureZoo(id);if(s){s.version=`Zoo ${ext.packageJSON.version}`;s.note=[s.note,'Bridge byl připojen k existující úloze; do první události nezná její aktuální stav.'].filter(Boolean).join(' ');}}
      producer?.markDirty();log.appendLine(zooHealth);
    }catch(e){zooHealth=`Zoo API: ${e.message}`;log.appendLine(zooHealth);}
  }
  async function refreshGit(generation){
    if(!config().get('gitStatus',true))return;
    for(const f of folders())try{
      const raw=await run('git',['--no-optional-locks','-C',f.path,'status','--porcelain=v1','-z','--untracked-files=normal']);
      const branch=(await run('git',['--no-optional-locks','-C',f.path,'rev-parse','--abbrev-ref','HEAD'])).trim();
      if(generation!==currentGeneration)return;
      const parts=raw.split('\0');const files=[];
      for(let i=0;i<parts.length&&files.length<100;i++){const line=parts[i];if(line.length<4)continue;const flags=line.slice(0,2);files.push({path:line.slice(3),status:flags.trim()||'M',scope:'workspace'});if(/[RC]/.test(flags))i++;}
      const root=projectRoots.find(p=>p.workspace===f.path);if(root)Object.assign(root,{files,branch,filesKnown:true,filesAt:Date.now()});
      for(const s of sessions.values())if(s.workspace===f.path){s.files=files;s.branch=branch;s.filesKnown=true;s.filesAt=Date.now();}
      // Git status does not reset the agent's last-activity timer.
      producer?.markDirty();
    }catch{/* Non-Git directories are supported and simply show no Git data. */}
  }
  const start=recoveryFlight(async({resume=false}={})=>{
    const stopping=cleanup();const generation=currentGeneration;await stopping;await intentWrites;if(shuttingDown||generation!==currentGeneration)return;
    if(isPaused()&&!resume){pausedStatus(intent().pending?'Odpojeno místně; čeká na odebrání z dashboardu, až bude hub dostupný.':'Odpojeno uživatelem. Pro obnovení použijte Connect.');return;}
    const reason=blocked();if(reason){connectionMessage=reason;status.text='$(info) MC: setup';status.tooltip=reason;log.appendLine(reason);return;}
    const token=await context.secrets.get('hubToken');if(!token||generation!==currentGeneration)return;
    connectionState='connecting';connectionMessage='Ověřuji, zda workspace již není připojen';contexts();
    let transport=null;
    try{
      identity=await workspaceIdentity(folders());if(generation!==currentGeneration)return;
      projectRoots=await Promise.all(folders().map(async f=>{const p=base(f.path,'project',f,'api');p.focusUri=await focusLink(p);return p;}));
      if(generation!==currentGeneration)return;
      if(config().get('windowsDesktopConnection',false)&&vscode.env.remoteName==='wsl'){
        const d=await readDesktop('wsl');if(generation!==currentGeneration)return;
        transport=new RelayTransport({command:d.linuxNode,args:[d.relay]});
      }
      let collectionStarted=false,resumeConfirmed=false;
      const beginCollection=async()=>{
        if(collectionStarted||generation!==currentGeneration||!producer||producer.stopped)return;
        collectionStarted=true;
        await attachZoo(generation);if(generation!==currentGeneration||!producer||producer.stopped)return;
        if(config().get('codexObservation',false)){
          const home=config().get('codexHome')||process.env.CODEX_HOME||path.join(os.homedir(),'.codex');
          observer=new CodexObserver({home,folders:folders(),onHealth:msg=>{codexHealth=msg;},sessionFactory:(meta,folder)=>{
            const s=base(meta.id,'codex',folder,'observed');s.version=meta.cli_version||'';s.activityAt=Date.parse(meta.timestamp)||Date.now();s.stateSince=s.activityAt;
            s.note='Pouze pozorování uložených JSONL událostí. Není to připojení k živému procesu doplňku. Schvalování a některé nové formáty historie nemusí být viditelné.';return s;
          },onSession:async s=>{if(generation!==currentGeneration)return;s.focusUri=await focusLink(s);if(generation!==currentGeneration)return;if(sessions.size<80||sessions.has(`codex:${s.id}`))sessions.set(`codex:${s.id}`,s);producer?.markDirty();}}).start();
        }
        await attachCodexHooks(generation);if(generation!==currentGeneration)return;
        void refreshGit(generation);gitTimer=setInterval(()=>void refreshGit(generation),12000);
      };
      const candidate=new Producer({transport,resume,hub:config().get('hubUrl'),token,sourceId:identity.sourceId,label:`${os.hostname()} / ${folders().map(f=>f.name).join(', ')}`,
        getProjects:()=>projectRoots,getSessions:()=>{for(const s of sessions.values())if(s.agent==='zoo')zooControl?.sync(s);return [...sessions.values()].map(s=>publicSession(hookServer?hookServer.decorate(s):s));},
        onCommand:c=>{if(generation!==currentGeneration||shuttingDown||blocked()||isPaused())throw new Error('Bridge není připraven k ovládání.');if(c.action==='codexDecision'){if(!hookServer)throw new Error('Živý Codex hook již není dostupný.');return hookServer.decide(c);}const s=sessions.get('zoo:'+c.sessionId);if(!s||!zooControl)throw new Error('Úloha Zoo Code není dostupná.');try{return zooControl.decide(s,c);}finally{producer?.markDirty();}},getHealth:()=>`${zooHealth} | ${codexHealth} | ${hookHealth}`,
        onStatus:(ok,message,error)=>{
          if(generation!==currentGeneration||producer!==candidate)return;
          connected=ok;connectionMessage=message;connectionState=ok?'connected':candidate.removed?'removed':candidate.conflict?'duplicate':candidate.stopped?'error':'connecting';contexts();
          status.text=`$(radio-tower) MC: ${ok?'live':candidate.conflict?'již připojeno':'offline'}`;status.tooltip=message;
          if(ok){
            if(resume&&!resumeConfirmed){resumeConfirmed=true;void setIntent({paused:false,pending:null}).catch(e=>log.appendLine(e.message));}
            void beginCollection().catch(e=>log.appendLine(e.message));
          }
          else{
            log.appendLine(candidate.removed&&!resume?'MC_PAUSED_BY_USER: hub eviduje úmyslné odpojení; automatický start je pozastaven.':`Hub: ${message}`);
            if(resume)recovery('failed',{code:error?.code||'CONNECT_FAILED',reason:error?.reason||null,httpStatus:error?.status||null,
              endpoint:error?.endpoint||candidate.lastRequest?.endpoint||'',requestId:candidate.recoveryRequestId,
              hubVersion:error?.hubVersion||candidate.hubVersion||null,message});
            if(candidate.removed){
              // Persist pause locally, fence pending API activation and detach
              // listeners. Never invoke Zoo abort/stop or Codex interrupt.
              currentGeneration++;void hookServer?.stop();hookServer=undefined;observer?.stop();observer=undefined;clearInterval(gitTimer);
              for(const [event,fn] of bindings)zooApi?.off?.(event,fn);bindings=[];zooApi=undefined;zooControl=undefined;sessions.clear();focusLinks.clear();
              pausedStatus('Odpojeno z dashboardu. Záznamy byly odebrány; agenti pokračují nezávisle.');
              void setIntent({paused:true,pending:null}).catch(e=>log.appendLine(e.message));
              void vscode.window.showInformationMessage('Mission Control: připojení tohoto workspace bylo odebráno z dashboardu. Agenti nebyli zastaveni.');
            }
            if(candidate.conflict){
              // Fence asynchronous API activation too: it must not reattach listeners after rejection.
              currentGeneration++;void hookServer?.stop();hookServer=undefined;
              // Stop only this rejected collector; never touch the winning bridge or agents.
              observer?.stop();clearInterval(gitTimer);for(const [event,fn] of bindings)zooApi?.off?.(event,fn);bindings=[];
              void vscode.window.showWarningMessage(`Mission Control: ${message}${error?.ownerLabel?' ('+error.ownerLabel+')':''}`);
            }
          }
        }});
      if(generation!==currentGeneration){await candidate.stop();return;}
      producer=candidate;
      if(resume)recovery('request',{requestId:candidate.recoveryRequestId||null,sourceId:identity.sourceId,hub:candidate.hub,endpoint:'/api/reconnect'});
      await context.workspaceState.update('missionControl.lastConnection',{sourceId:identity.sourceId,epoch:candidate.epoch,hub:candidate.hub,desktopWsl:config().get('windowsDesktopConnection',false)&&vscode.env.remoteName==='wsl'});
      if(generation!==currentGeneration){await candidate.stop();return;}
      candidate.start();
      if(resume){
        // Explicit commands finish with the first real HTTP result, not merely
        // after launching a background timer. Auto-start remains non-blocking.
        await candidate.inFlight;await intentWrites;
        if(producer!==candidate||shuttingDown)return;
        if(connected){recovery('connected',{code:'MC_RECOVERY_OK',requestId:candidate.recoveryRequestId||null,hubVersion:candidate.hubVersion||null});log.appendLine('MC_RECONNECTED: hub potvrdil nové připojení.');void vscode.window.showInformationMessage('Mission Control: připojení k hubu bylo potvrzeno. Projekt je zaregistrován; aktuální stav se doplní po události agenta.');}
        else {
          if(lastRecovery?.stage!=='failed')recovery('failed',{code:'CONNECT_NOT_CONFIRMED',message:connectionMessage});
          log.show(true);
          void vscode.window.showWarningMessage(`Mission Control: obnova nebyla potvrzena (${lastRecovery?.code||'CONNECT_NOT_CONFIRMED'}). Podrobnosti jsou v otevřené diagnostice. `+connectionMessage);
        }
      }
    }catch(e){
      if(generation!==currentGeneration)return;
      connectionState='disconnected';connectionMessage=e.message;contexts();transport?.stop();log.appendLine(e.message);
      if(resume){recovery('failed',{code:e.code||'START_FAILED',message:e.message});log.show(true);}
      void vscode.window.showErrorMessage(`Mission Control: ${e.message}`);
    }
  });
  const connectOnce=singleFlight(async mode=>{
    lastRecovery=null;recovery('command',{command:mode,commandId:randomUUID(),remoteName:vscode.env.remoteName||'local'});
    if(!await allowMonitoring())return;
    if(disconnectOnce.busy){void vscode.window.showInformationMessage('Mission Control: nejprve se dokončí odpojení.');return;}
    await start.wait();await intentWrites;if(shuttingDown)return;
    if(intent().pending){try{await flushRemoval();}catch(e){void vscode.window.showWarningMessage('Odpojení ještě není dokončeno: '+e.message);return;}}
    const current=producer;
    if(current&&!current.stopped){
      // A dashboard removal may have happened since our last heartbeat. Never
      // trust cached connected/connecting flags to suppress an explicit click.
      log.appendLine('MC_RECONNECT_CHECK: ověřuji skutečné vlastnictví v hubu.');
      let check;
      try{check=await current.inspect();}
      catch(e){recovery('failed',{code:e.code||'HUB_CHECK_FAILED',message:e.message});log.show(true);log.appendLine('MC_RECONNECT_CHECK_FAILED: '+e.message);void vscode.window.showWarningMessage('Mission Control: hub nyní nelze ověřit. Připojení nebylo zdvojeno. '+e.message);return;}
      if(producer!==current||shuttingDown){void vscode.window.showInformationMessage('Mission Control: stav připojení se mezitím změnil. Zopakujte Connect.');return;}
      if(check.owned&&!current.stopped&&!(mode==='reconnect'&&check.removedProjectCount>0)){
        recovery('connected',{code:'ALREADY_CONNECTED',hubVersion:check.hubVersion||null,sourceId:current.sourceId});
        void vscode.window.showInformationMessage(connected?'Mission Control: tato relace je již připojena; ověřeno v hubu. Další připojení nebylo vytvořeno.':'Mission Control: hub eviduje toto připojení; reportování se ještě ověřuje. Druhé připojení nebylo vytvořeno. '+connectionMessage);return;
      }
    }
    // Reuse the saved credential but use a NEW epoch. Retired epochs remain
    // forbidden; only this explicit path grants one-shot resume permission.
    if((current||isPaused()||mode==='reconnect')&&await context.secrets.get('hubToken')){await start({resume:true});return;}
    if(mode==='reconnect')mode=((!vscode.env.remoteName&&process.platform==='win32')||vscode.env.remoteName==='wsl')?'desktop':'manual';
    try{
      if(mode==='desktop'){
        const d=await readDesktop(vscode.env.remoteName);
        const consent=await vscode.window.showInformationMessage('Připojit tento důvěryhodný workspace k místní Windows aplikaci Mission Control? Bridge bude sdílet stav Zoo Code a přehled změn; čtení Codex historie zůstává samostatně volitelné.','Připojit');
        if(consent!=='Připojit'||shuttingDown)return;
        await config().update('hubUrl',d.hub,vscode.ConfigurationTarget.Global);
        await config().update('windowsDesktopConnection',true,vscode.ConfigurationTarget.Global);
        await context.secrets.store('hubToken',d.token);
      }else{
        const url=await vscode.window.showInputBox({title:'Mission Control · hub URL',value:config().get('hubUrl'),prompt:'Vzdálený workspace: použijte loopback adresu zpětného SSH tunelu.'});if(!url||shuttingDown)return;
        const token=await vscode.window.showInputBox({title:'Mission Control · pairing token',password:true,prompt:'Token z terminálu hubu; uloží se do VS Code SecretStorage.'});if(!token||shuttingDown)return;
        await config().update('windowsDesktopConnection',false,vscode.ConfigurationTarget.Global);await config().update('hubUrl',url.trim(),vscode.ConfigurationTarget.Global);await context.secrets.store('hubToken',token.trim());
      }
      await start({resume:true});
    }catch(e){void vscode.window.showErrorMessage(`Mission Control: ${e.message}`);}
  });
  const disconnectOnce=singleFlight(async()=>{
    if(connectOnce.busy){void vscode.window.showInformationMessage('Nejprve dokončete nebo zrušte otevřený dialog připojení.');return;}
    if(isPaused()&&!intent().pending){void vscode.window.showInformationMessage('Mission Control: tento workspace je již odpojen.');return;}
    const answer=await vscode.window.showWarningMessage('Odpojit monitorování všech projektových složek v tomto workspace a odebrat je z dashboardu? Codex, Zoo Code, soubory ani skutečná historie chatů se nemažou. Automatické připojování zůstane vypnuté do dalšího Connect.',{modal:true},'Odpojit a odebrat');
    if(answer!=='Odpojit a odebrat')return;
    const old=producer;
    const saved=intent().pending||context.workspaceState.get('missionControl.lastConnection');
    const pending=old?.epoch?{sourceId:old.sourceId,epoch:old.epoch,hub:old.hub,desktopWsl:config().get('windowsDesktopConnection',false)&&vscode.env.remoteName==='wsl'}:saved;
    // Keep the existing hub credential; it is shared by other workspaces in
    // this VS Code profile. Only the disconnect intent is workspace-specific.
    if(pending){const token=old?.token||await context.secrets.get('hubToken');if(token)await context.secrets.store(removalSecretKey(pending),token);}
    await setIntent({paused:true,pending:pending||null});
    await cleanup(); // Wait for in-flight reports before removing them.
    pausedStatus(pending?'Odpojeno místně; ověřuji odebrání v hubu.':'Odpojeno. Žádné připojení nebylo v tomto okně vytvořeno.');
    try{
      const result=await flushRemoval();
      void vscode.window.showInformationMessage(result.superseded?'Mission Control: staré připojení již skončilo. Nové připojení jiného okna nebylo odpojeno.':'Mission Control: odpojeno a odebráno z dashboardu. Agenti nebyli zastaveni.');
      return result;
    }catch(e){
      log.appendLine('Odebrání čeká na hub: '+e.message);
      pausedStatus('Odpojeno místně; odebrání v dashboardu čeká na dostupný hub.');
      void vscode.window.showWarningMessage('Mission Control: místní monitoring je vypnutý. Odebrání z dashboardu zatím není potvrzené; bridge jej zkusí znovu po připojení k hubu. '+e.message);
      return {removed:false,pending:true};
    }
  });
  context.subscriptions.push(vscode.window.registerUriHandler({async handleUri(uri){
    if(blocked())return;
    const p=new URLSearchParams(uri.query);if(uri.path!=='/focus'||p.get('window')!==instance||p.get('nonce')!==nonce){log.appendLine('Ignored a callback for another window or an expired bridge.');return;}
    if(p.get('agent')==='project'){if(folders().some(f=>f.path===p.get('task')))await vscode.commands.executeCommand('workbench.view.explorer');return;}
    const s=sessions.get(`${p.get('agent')}:${p.get('task')}`);if(!s)return;
    try{
      const commands=await vscode.commands.getCommands(true);
      if(s.agent==='zoo'){
        if(commands.includes('workbench.view.extension.zoo-code-ActivityBar'))await vscode.commands.executeCommand('workbench.view.extension.zoo-code-ActivityBar');
        if(commands.includes('zoo-code.focusInput'))await vscode.commands.executeCommand('zoo-code.focusInput');
        if(!(zooApi?.getCurrentTaskStack()||[]).includes(s.id))void vscode.window.showInformationMessage(`Mission Control: cílová úloha ${s.id} není aktivní. Vyberte ji v historii Zoo Code. Bridge ji z bezpečnostních důvodů sám neobnovuje.`);
      }else{
        // Probe actual contributed commands instead of assuming an API exists.
        const installed=vscode.extensions.getExtension('openai.chatgpt');
        if(installed&&!installed.isActive)await installed.activate();
        const contributed=installed?.packageJSON?.contributes?.commands||[];
        const cmd=contributed.find(c=>/open.*(sidebar|panel)/i.test(c.command)&&/chatgpt|codex/i.test(c.command))?.command;
        if(cmd)await vscode.commands.executeCommand(cmd);else void vscode.window.showInformationMessage('Mission Control: otevřete panel Codex a vyberte požadovanou relaci. Veřejný příkaz pro přesnou relaci není k dispozici.');
      }
    }catch(e){log.appendLine(`Focus: ${e.message}`);void vscode.window.showWarningMessage(`Mission Control: panel se nepodařilo otevřít (${e.message}).`);}
  }}));
  context.subscriptions.push(vscode.commands.registerCommand('missionControl.selectZooProject',async()=>{
    if(!await allowMonitoring())return;
    const choices=folders().map(f=>({label:f.name,description:f.path,path:f.path}));
    const choice=await vscode.window.showQuickPick(choices,{title:'Projekt sledovaný přes Zoo Code',placeHolder:'API Zoo neoznačuje kořen. Vyberte správný projekt.'});
    if(choice){await config().update('zooProjectRoot',choice.path,vscode.ConfigurationTarget.Workspace);await start();}
  }),vscode.commands.registerCommand('missionControl.connectDesktop',()=>connectOnce('desktop')),
    vscode.commands.registerCommand('missionControl.connect',()=>connectOnce('manual')),
    vscode.commands.registerCommand('missionControl.reconnect',()=>connectOnce('reconnect')),
    vscode.commands.registerCommand('missionControl.disconnect',()=>disconnectOnce()),
  vscode.commands.registerCommand('missionControl.enableCodexObservation',async()=>{
    if(!await allowMonitoring())return;
    const result=await vscode.window.showWarningMessage('Experimentální pozorování přečte posledních 48 hodin Codex JSONL relací odpovídajících tomuto workspace. Zprávy mohou obsahovat citlivý kód. Nezaručuje detekci schválení.','Zapnout');
    if(result==='Zapnout'){await config().update('codexObservation',true,vscode.ConfigurationTarget.Workspace);await start();}
  }),vscode.commands.registerCommand('missionControl.disableCodexObservation',async()=>{await config().update('codexObservation',false,vscode.ConfigurationTarget.Workspace);await start();}),
  vscode.commands.registerCommand('missionControl.showLog',()=>{log.appendLine(`${zooHealth}\n${codexHealth}\nHost: ${os.hostname()} (${envLabel()})`);log.show();}));
  context.subscriptions.push(vscode.commands.registerCommand('missionControl.enableCodexDashboardControls',()=>enableCodexControls()),
    vscode.commands.registerCommand('missionControl.disableCodexDashboardControls',disableCodexControls),
    vscode.commands.registerCommand('missionControl.removeCodexHooks',async()=>{
      if(!await allowMonitoring())return;
      const yes=await vscode.window.showWarningMessage('Odebrat hooky Mission Control z tohoto Codex home?',{modal:true,detail:'Týká se všech projektů používajících '+codexHome()+'. Ostatní hooky zůstanou zachované. Již načtené definice Codexu mohou vyžadovat jeho opětovné načtení.'},'Odebrat vlastní hooky');
      if(yes!=='Odebrat vlastní hooky')return;
      try{await disableCodexControls();await uninstallHook(codexHome());void vscode.window.showInformationMessage('Vlastní hooky Mission Control byly odebrány.');}catch(e){void vscode.window.showErrorMessage(e.message);}
    }));
  context.subscriptions.push(vscode.commands.registerCommand('missionControl.getStatus',async()=>({
    protocol:1,version:RUNTIME_VERSION,runtimeBuild:RUNTIME_BUILD,manifestVersion:context.extension.packageJSON.version,lastRecovery,hubVersion:producer?.hubVersion||lastRecovery?.hubVersion||null,remoteName:vscode.env.remoteName||null,
    extensionKind:context.extension.extensionKind,hostname:os.hostname(),trusted:vscode.workspace.isTrusted,
    workspaceCount:folders().length,blockedReason:blocked(),paired:blocked()||isPaused()?false:Boolean(await context.secrets.get('hubToken')),reconnectSupported:true,paused:isPaused(),pendingRemoval:!!intent().pending,disconnecting:disconnectOnce.busy,
    connected,connecting:connectionState==='connecting'||connectOnce.busy,connectionState,message:connectionMessage,zoo:zooHealth,codex:codexHealth,codexControls:{enabled:hookEnabled(),message:hookHealth,...(hookServer?.status()||{listening:false,verified:false})},sourceId:identity?.sourceId||'',duplicate:producer?.conflict?{code:producer.conflict.code,ownerLabel:producer.conflict.ownerLabel||'',existingKey:producer.conflict.existingKey||''}:null
  })));
  context.subscriptions.push(vscode.commands.registerCommand('missionControl.copyConnectionReport',async()=>{
    const s=await vscode.commands.executeCommand('missionControl.getStatus');
    const report={runtimeBuild:RUNTIME_BUILD,manifestVersion:context.extension.packageJSON.version,vscode:vscode.version,
      platform:process.platform,remoteName:vscode.env.remoteName||'local',state:s?.connectionState,
      paused:isPaused(),pendingRemoval:!!intent().pending,sourceId:identity?.sourceId||null,lastRecovery,codexControls:s?.codexControls};
    const text=JSON.stringify(report,null,2);log.appendLine('MC_CONNECTION_REPORT '+text);log.show(true);
    if(vscode.env.clipboard?.writeText){await vscode.env.clipboard.writeText(text);void vscode.window.showInformationMessage('Mission Control: diagnostický přehled byl zkopírován. Neobsahuje tokeny ani obsah chatů.');}
    return report;
  }));
  if(vscode.workspace.onDidGrantWorkspaceTrust)context.subscriptions.push(vscode.workspace.onDidGrantWorkspaceTrust(()=>void start().catch(e=>log.appendLine(e.message))));
  if(vscode.workspace.onDidChangeWorkspaceFolders)context.subscriptions.push(vscode.workspace.onDidChangeWorkspaceFolders(()=>void start().catch(e=>log.appendLine(e.message))));
  removalTimer=setInterval(()=>{if(!shuttingDown&&intent().pending&&!disconnectOnce.busy&&!connectOnce.busy)void flushRemoval().catch(e=>log.appendLine('Odebrání zatím čeká: '+e.message));},15000);
  context.subscriptions.push({dispose:()=>clearInterval(removalTimer)});
  await start();
  if(intent().pending)void flushRemoval().catch(e=>log.appendLine('Odebrání zatím čeká: '+e.message));
}
function deactivate(){return disposeCurrent();}
module.exports={activate,deactivate};
