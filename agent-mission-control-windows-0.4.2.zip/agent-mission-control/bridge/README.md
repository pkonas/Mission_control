# Mission Control Bridge 0.4.2

Workspace rozšíření pro projektový přehled. Registruje kořeny i bez chatů,
odebírá Zoo Code události a volitelně čte Codex JSONL podle workspace. Interní
a historické běhy nejsou samostatnými projekty.

Připojení: `Mission Control: Connect`, `Connect to Windows App` nebo `Reconnect`.
V okně s více složkami vyberte Zoo kořen pomocí `Mission Control: Select Zoo Project Root`.
`Disconnect and Remove from Dashboard` odpojuje všechny projektové kořeny tohoto
okna. Jediný kořen lze odebrat v dashboardu. Výslovný Reconnect obnoví kořeny okna,
nikoli nový chat. Automatické reporty uživatelem odebraný projekt nevrací.

Runtime: `0.4.2-codex-hooks.1`. Po aktualizaci načtěte okno znovu až po doběhnutí
agentů. Ve WSL/SSH patří Bridge na vzdálenou stranu; Connection je místní.
Příkazy a diagnostika jsou dostupné v Restricted Mode, monitorování vyžaduje
trusted filesystem workspace. Codex pozorování je opt-in a nezaručuje approvals.

Bez cloudu, bez telemetrie, bez automatického schvalování. Nepodepsaný VSIX.
Ověřeno proti náhradě VS Code API a skutečnému HTTP hubu, nikoli skutečným VS Code hostem.

Zoo Run/Deny: kompatibilitní adaptér nad vnitřním Task API, nikoli obecné
pressPrimaryButton. Přesné typy a kontroly jsou popsané ve zdrojovém projektu
v docs/ZOO_ACTIONS_041.cs.md. Neověřitelné rozhraní/dotaz => jen čtení. Nastavení
missionControl.zooDashboardControls umožňuje ovládání vypnout.

## Codex Run / Deny (0.4.2)

V připojeném projektu: `Mission Control: Enable Codex Dashboard Controls`
(panel: `Mission Control: Setup Codex Dashboard Controls`). Jednorázové potvrzení
a důvěra hooků v Codexu jsou nutné. Dokumentovaný přehled je `/hooks` v Codex CLI
ve stejném prostředí/CODEX_HOME. Samotná instalace VSIX nic neschvaluje.

Hook běží před nativním dotazem; po 5 minutách nebo předání „Vyřídit v Codexu“
pokračuje původní politika. Již zobrazený starý dotaz vyřiďte ve VS Code.
Nezakládá se druhý chat. Hook i Bridge musí běžet na stejném hostu a vyžadují
kompatibilní místní Codex s PermissionRequest a samostatné Node.js 22+.

Vypnutí workspace: `Mission Control: Disable Codex Dashboard Controls`.
Odebrání vlastních hooků z daného Codex home: `Mission Control: Remove Codex Hooks from This Host`.
Diagnostika rozlišuje konfiguraci a skutečný callback; marker `MC_CODEX_HOOK_VERIFIED`
vznikne až po živé události. Reálný Codex/VS Code nebyl zde spuštěný.
