# 0.4.2 — původní Codex: živé Run / Deny

- Opt-in PermissionRequest hook původního Codexu, bez nového chatu a bez UI scrapingu.
- Oddělené nastavení a ověření skutečného callbacku; schválení důvěry zůstává Codexu.
- Run / Deny / Vyřídit v Codexu s úplným obsahem, konkrétním živým request/turn/socket.
- Úmyslné předání a pětiminutová lhůta vrací původní schvalovací politiku, nevydávají souhlas.
- Jediný projekt i při souběhu více dotazů; notifikace míří na původní request.
- Odebrání projektu, přerušení, výpadek nebo změna hooku zneplatňují rozhodnutí.
- Zálohované slučování cizích hooků, samostatné Node CLI, vratné odebrání vlastních handlerů.
- Zachované opravy installeru, Zoo ovládání a 60sekundové aplikační upozornění.

# 0.4.0 — Projektový dashboard

- Nezávislý registr kořenů; jeden řádek pro hostitele a cestu, ne pro ID chatu.
- Sdílené vyhodnocení projektového stavu pro dashboard i Windows tray.
- Teď / Změny / Historie, filtry a připnutí, oddělení kontaktu bridge od činnosti agenta.
- Codex provenance z metadat, načtené logy jako historie, interní dokončení bez upozornění.
- Projektově omezené odpojení v dashboardu, trvalé blokování starých reportů, explicitní obnova.
- Registrace složky ještě bez události, explicitní Zoo kořen ve vícesložkovém okně.
- Bezpečná záloha před migrací; původní update/repair/uninstall a ochrany zůstávají.

Předchozí protokoly a změny níže jsou historické, nikoli výsledky běhu verze 0.4.0.

# 0.3.9 — explicit recovery cannot be lost behind automatic startup

- Reproduce the 0.3.8 lifecycle race using the original Bridge + HTTP hub and a simulated workspace event; queue explicit recovery separately.
- Add native-only /api/reconnect with source/epoch/request acknowledgement and durable intent, preserving uniqueness and retired-epoch protection.
- Stop failed explicit attempts instead of indefinitely reusing recovery consent; release unconfirmed reservations on persistence failure.
- Report the executing build separately from the on-disk manifest; Connection rejects unverified runtime builds.
- Add safe Copy Connection Report and phase/code/endpoint metadata. Never reset other projects, tokens, chat history, or agent tasks.
- Windows update/repair/uninstall mechanics unchanged apart from package version; actual Windows execution is unverified.

# 0.3.8 — explicit reconnect repair

- Fix command single-flight ownership held by undismissed informational toasts.
- Always expose recovery commands; verify ownership in the hub instead of
  trusting a stale connected/connecting snapshot.
- Add `Mission Control: Reconnect This Workspace` and Bridge `Reconnect`.
- Read-only producer ownership endpoint; cannot dequeue pending approvals.
- Durable explicit resume acknowledgement and serialized per-workspace intent.
- Treat a code-less HTTP 409 as terminal, not an endless reconnect loop.
- Preserve one active reporter, old-epoch fences, deliberate removal, credentials,
  agent processes, installer update/repair/uninstall and VS Code discovery.

# 0.3.7 — explicit disconnect and removal

- Dashboard detail and source settings: confirmed workspace/connection removal, scope preview including filtered tasks and empty sources.
- VS Code Bridge and Connection: visible disconnect commands, workspace-local persistent pause, offline removal retry on open/reopen, per-owner pending SecretStorage keys. Other workspaces retain their hub token.
- Hub: persisted detached source registry and retired-epoch fences; immediate state save before success; late heartbeats and automatic claims rejected until explicit new-owner resume.
- Queued agent requests are cancelled only before dispatch; already-delivered commands become unknown, never falsely rolled back or replayed.
- Managed Codex: monitoring can detach without closing its App Server; terminal `connect` resumes the same live thread.
- UI: monotonically ordered snapshots within a hub lifetime; fixed malformed pre-existing Codex filter option; current version badge.
- Existing installer repair/update/uninstall, discovery and ownership guards retained. Windows runtime/Extension Host tests are still not available here.

# 0.3.5 — VS Code connection discovery

## 0.3.6 — jediné připojení a jedinečná relace

- Stabilní identita bridge pro host a workspace místo náhodné identity každého okna.
- Idempotentní Connect/Setup, blokování souběhu a vysvětlení stavu připojení.
- Serverové claim/release, zákaz převzetí živého vlastníka, svázání příkazů s epochou.
- Jedinečný záznam podle hostu, cesty, agenta a skutečného ID úlohy; migrace přesných starých duplicit se zálohou.
- Rezervace spravovaného klienta Codexu před vytvářením threadu; podpora protokolu přes WSL relay.
- 44 nových automatických testů; instalátor/VSIX přebaleny jako 0.3.6, dosavadní údržba zachována.


- Added local UI companion `local-mission-control.connector`, bundled together
  with the workspace bridge in the Windows installer and repair payload.
- Added Setup Connection command, Explorer connection view and status item.
- Added checksum-verified bridge installation into the active window through
  VS Code's documented VSIX API; no Marketplace publication required.
- Separate installed, activated and hub-connected diagnostics; guarded RPC
  status lookup refuses old/wrong-host bridges and never auto-reloads.
- Restricted/virtual workspace diagnostics with explicit no-collection gates.
- Installer validates both fixed extension IDs in the selected local profile;
  optional uninstallation removes only those two IDs.
- 148 Node tests including 36 new scenarios. Real Windows and remote VS Code
  end-to-end tests remain unexecuted. Existing lifecycle fixes retained.

# Changelog

## 0.3.4 — životnost zámku údržby a dohledání PowerShell procesu

- Původní zámek se držel po celou dobu otevření průvodce, i po dokončení či chybě. Nově se získává pouze kolem operace a uvolňuje v `finally` před návratem do UI.
- Zachovaný stejný pojmenovaný mutex kvůli souběhu se staršími instalátory; živý zámek se nikdy neobchází ani nemaže podle stáří/PID. Stav instalace se čte znovu pod zámkem.
- Tlačítko Diagnostika zámku ukazuje volný/obsazený stav. Při konfliktu dohledává pomocné powershell.exe/pwsh.exe aktuálního účtu a relace podle vstupního skriptu. Starší procesy označuje pouze za kandidáty, nikoli za prokázané držitele.
- Nové operace zapisují diagnostický PID, čas vzniku, verzi a typ operace do setup-owner.json. Soubor sám nikdy nerozhoduje o zamčení; neaktuální záznam není blokací.
- Na Windows se před změnou aplikace spouští izolovaný test skutečného PowerShell/.NET mutexu: druhý proces, obsazený zámek, normální uvolnění, výjimka a opuštění zámku. Zde nebyl spuštěn.
- Dodán samostatný neinvazivní Diagnose-Setup.ps1. Nejsou zavírány cizí procesy, VS Code ani agenti pro účely obcházení zámku.
- Opravy 0.3.0–0.3.3 a operace Aktualizovat/Opravit/Odinstalovat jsou zachovány.

## 0.3.3 — oprava File.Replace při aktualizaci existující instalace

- `Write-MCAtomic` už nepředává `$null` třetímu parametru `File.Replace`. Používá tři neprázdné absolutní cesty ve stejné složce; záloha je jedinečná.
- Před zápisem kontroluje cestu a rodičovskou složku. Existující cíl se předem nemaže. Nový obsah se zapisuje do nového dočasného souboru a flushuje na disk.
- Po úspěchu uklidí pomocné soubory; při selhání ponechá případnou zálohu a dočasný soubor a uvede jejich cesty. Selhání úklidu po úspěšném zápisu se hlásí jako upozornění, nikoliv jako neúspěšný upgrade.
- Instalační preflight používá tentýž produkční PowerShell kód přímo na cílovém disku: vytvoření, nahrazení a opakované nahrazení 4 testovacích souborů, kontrola obsahu a UTF-8 bez BOM. Běží před zastavením nebo výměnou aplikace.
- Log rozlišuje fázi chyby a uvádí `MC_ATOMIC_WRITE_OK`, `MC_PORT_WRITE_OK`, `MC_MAINTENANCE_CACHE_OK` a původní stack trace při chybě. Nezapisuje tokeny nebo obsah konfigurace.
- Přidán `windows/Test-AtomicWrite.ps1` pro skutečné PowerShell/.NET testy v izolované dočasné složce, včetně původního selhání aktualizace, opakované opravy, neplatných cest a zamčeného souboru. Tento skript zde nebyl spuštěn.
- Zachováno zastavování samostatným řadičem, automatická detekce VS Code, aktualizace, oprava, odinstalování a ponechání dat/tokenů.

## 0.3.2 — oprava timeoutu při aktualizaci z 0.2.0

- Opraveno: `ConvertTo-MCArgument` správně uvozoval `--quit`, ale starý tray parser tyto uvozovky nesprávně ignoroval. Nativní spouštěč nyní používá Windows `CommandLineToArgvW`, odmítá neznámé/rozporné přepínače a jeho `--quit` nic nespouští ani nevytváří.
- Instalace, oprava i odinstalace používají samostatný `MissionControlStop.exe`. Nespouští GUI, hub, Node.js ani shell. Před použitím proběhne bezstavová kontrola `--check`.
- Řadič ověřuje úplnou cestu instalovaného EXE, SID a relaci Windows; uchovává ověřené procesní handly. Nejprve pošle WM_CLOSE původnímu oknu tray. Pokud nereaguje, po omezeném čekání ukončí pouze tento ověřený tray. Nikdy neukončuje node.exe podle názvu, portu ani samotného PID.
- Pozoruje ukončení soukromého hubu (ověřená cesta, rodič a čas vzniku); vlastní hub je už od 0.2.0 v Job Object s KILL_ON_JOB_CLOSE. Nesouvisející procesy neukončuje.
- Už neběžící tray znamená úspěšný no-op, ne spuštění kopie aplikace z Temp. Nelze-li bezpečně ověřit zastavení, soubory se nemění.
- Chyba před výměnou souborů se už nehlásí jako provedená obnova souborů.
- Zachována automatická detekce VS Code, lokální bridge, automatické spouštění, aktualizace, oprava, odinstalace a zachování dat/tokenu.

# 0.3.1 — automatické nalezení VS Code

- Předvyplnění skutečného Code.exe podle hlavního běžícího procesu aktuálního uživatele a relace Windows.
- Další zdroje: poslední ověřený cíl, registry App Paths / Uninstall / asociace, PATH, známé složky, Scoop a zástupce Windows.
- Výběr mezi nalezenými instalacemi/kontexty, tlačítko Znovu najít, editovatelné datové složky a profil.
- CLI se získá z aktivního code.cmd; podporovány jsou legacy i verzované resources. Nevybírá se náhodná / nejnovější hash složka.
- Oddělené prostředí CLI, preflight --version, instalace a ověření stejného cíle. Bez zavírání/restartování VS Code.
- Zachováno rozlišení stderr/exit code, aktualizace, oprava, odinstalování a uchování dat.
- 103 automatických Node testů v Linuxu; Windows PowerShell/GUI testy zde neprovedeny.

# Changelog

## 0.3.0

- Fix false bridge installation failure caused by DEP0169 on stderr in Windows PowerShell 5.1. No global warning suppression.
- Use shell-free Code.exe/cli.js invocation and structured result files; verify exact installed bridge ID/version after exit 0.
- Add per-user Install/Update/Repair/Uninstall UI, preserved port/autostart/token, optional bridge profile and VS Code path selection.
- Add independent hashed maintenance cache; Start menu, tray and Windows uninstall/modify registration.
- Stage updates before stopping the owned hub; attempt file/metadata rollback on pre-commit startup failure. No power-failure transaction guarantee.
- Keep data and bridge on uninstall unless explicitly selected; never uninstall Codex or Zoo Code.
- Match new desktop connection descriptor instanceId to the responding hub during installation checks.
- 75 passing Node tests; Windows lifecycle and PowerShell execution are not validated in the Linux build environment.
