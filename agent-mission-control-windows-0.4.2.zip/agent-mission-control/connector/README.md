# Mission Control Connection 0.4.2

Místní panel pro připojení a diagnostiku. Obsahuje Bridge 0.4.2 jako VSIX,
ověřuje jeho SHA-256 a verzi běžícího kódu. V prostředí WSL/SSH zůstává Connection
místně a nabízí instalaci Bridge na vzdálenou stranu po potvrzení uživatele.

`Mission Control: Setup Connection`, `Reconnect This Workspace`,
`Disconnect This Workspace` a `Copy Connection Report` zůstávají dostupné.
Hub a oba doplňky aktualizujte společně. Nový projektový přehled se zobrazuje
v dashboardu hubu 0.4.2; starý hub nestačí aktualizovat samotným VSIX.

Connection nedostává tokeny ani obsah chatů. Automaticky nerestartuje editor,
nemění Workspace Trust a neukončuje agenty. Odpojení tohoto workspace odpojí
všechny jeho kořeny; jeden kořen lze odebrat v dashboardu.

Nepodepsaný balíček. Reálný Windows/WSL VS Code host zde nebyl spuštěn.

## Codex Run / Deny (0.4.2)

V připojeném projektu: `Mission Control: Enable Codex Dashboard Controls`
(panel: `Mission Control: Setup Codex Dashboard Controls`). Jednorázové potvrzení
a důvěra hooků v Codexu jsou nutné. Dokumentovaný přehled je `/hooks` v Codex CLI
ve stejném prostředí/CODEX_HOME. Samotná instalace VSIX nic neschvaluje.

Hook běží před nativním dotazem; po 5 minutách nebo předání „Vyřídit v Codexu“
pokračuje původní politika. Již zobrazený starý dotaz vyřiďte ve VS Code.
Nezakládá se druhý chat. Hook i Bridge musí běžet na stejném hostu a vyžadují
kompatibilní místní Codex s PermissionRequest a samostatné Node.js 22+.

Vypnutí workspace: `Mission Control: Disable Codex Dashboard Controls`.
Odebrání vlastních hooků z daného Codex home: `Mission Control: Remove Codex Hooks from This Host`.
Diagnostika rozlišuje konfiguraci a skutečný callback; marker `MC_CODEX_HOOK_VERIFIED`
vznikne až po živé události. Reálný Codex/VS Code nebyl zde spuštěný.
