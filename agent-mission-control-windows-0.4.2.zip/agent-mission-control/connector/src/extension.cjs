'use strict';
const vscode=require('vscode');
const {createController}=require('./controller.cjs');
function activate(context){
  const log=vscode.window.createOutputChannel('Mission Control Connection');
  const runtimeBuild='0.4.2-codex-hooks.1';
  const controller=createController(vscode,context,{log:s=>log.appendLine(s)});
  const status=vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left,5);
  status.text='$(plug) Mission Control';status.command='missionControl.setup';
  status.tooltip='Připojit tento projekt / zkontrolovat instalaci bridge';status.show();
  const emitter=new vscode.EventEmitter();let last={ready:false,reason:'Zjišťuji stav tohoto okna…'},refreshing=false;
  async function refresh(){
    if(refreshing)return;refreshing=true;
    try{last=await controller.probe();emitter.fire();status.command=last.status?.connected?'missionControl.connectionDiagnostics':'missionControl.setup';status.text=last.status?.connected?'$(check) Mission Control: připojeno':last.status?.connecting?'$(sync~spin) Mission Control: připojuji':'$(plug) Mission Control';status.tooltip=last.ready?`Bridge ${last.status.version}: ${last.status.connected?'hub připojen':last.reason||'připojení není potvrzeno'}`:last.reason;}
    finally{refreshing=false;}
  }
  function item(label,command,description){const i=new vscode.TreeItem(label,vscode.TreeItemCollapsibleState.None);if(command)i.command={command,title:label};i.description=description;return i;}
  const provider={onDidChangeTreeData:emitter.event,getTreeItem:x=>x,getChildren:()=>[
    item(last.status?.connected?'Připojeno – zobrazit stav':last.status?.connecting?'Připojení probíhá':last.status?.duplicate?'Již připojeno jinde – znovu ověřit':'Nastavit připojení',last.status?.connected?'missionControl.connectionDiagnostics':last.status?.connecting?null:'missionControl.setup'),
    ...(last.ready&&(last.status?.connected||last.status?.connecting||last.status?.paired||last.status?.pendingRemoval)?[item(last.status?.pendingRemoval?'Dokončit odebrání z dashboardu':'Odpojit a odebrat z dashboardu','missionControl.disconnectHere')]:[]),
    item('Znovu připojit tento workspace','missionControl.reconnectHere'),
    item('Codex: zapnout Run / Deny v dashboardu','missionControl.setupCodexControls'),
    item('Nainstalovat / opravit bridge zde','missionControl.installBridgeHere'),
    item(last.ready?`Bridge ${last.status.version}: ${last.status.connected?'hub připojen':'nepřipojeno'}`:'Bridge není připraven','missionControl.connectionDiagnostics'),
    item('Diagnostika připojení','missionControl.connectionDiagnostics')
  ]};
  context.subscriptions.push(log,status,emitter,vscode.window.registerTreeDataProvider('missionControl.connection',provider),
    vscode.commands.registerCommand('missionControl.setup',async()=>{await controller.setup();await refresh();}),
    vscode.commands.registerCommand('missionControl.reconnectHere',async()=>{await controller.reconnect();await refresh();}),
    vscode.commands.registerCommand('missionControl.disconnectHere',async()=>{await controller.disconnect();await refresh();}),
    vscode.commands.registerCommand('missionControl.setupCodexControls',async()=>{const p=await controller.probe();if(!p.ready){void vscode.window.showWarningMessage(p.reason||'Nejdříve nainstalujte a připojte aktuální Bridge.');return;}await vscode.commands.executeCommand('missionControl.enableCodexDashboardControls');await refresh();}),
    vscode.commands.registerCommand('missionControl.installBridgeHere',async()=>{await controller.repair();await refresh();}),
    vscode.commands.registerCommand('missionControl.connectionDiagnostics',async()=>{
      const p=await controller.probe();log.appendLine(JSON.stringify({connector:'0.4.2',connectorBuild:runtimeBuild,connectorManifest:context.extension.packageJSON.version,vscode:vscode.version,windowRemote:vscode.env.remoteName||'local',workspaceTrusted:vscode.workspace.isTrusted,bridge:p},null,2));log.show();
    }),vscode.extensions.onDidChange(()=>void refresh()));
  if(vscode.workspace.onDidGrantWorkspaceTrust)context.subscriptions.push(vscode.workspace.onDidGrantWorkspaceTrust(()=>void refresh()));
  const timer=setInterval(()=>void refresh(),5000);context.subscriptions.push({dispose:()=>clearInterval(timer)});
  void refresh();
  // No automatic collection, pairing, installation or reload. The existing
  // bridge may reconnect using consent and credentials previously saved by it.
}
module.exports={activate};
