'use strict';
const fs=require('node:fs/promises');
const {createHash}=require('node:crypto');
const BRIDGE_ID='local-mission-control.bridge';
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function versionAtLeast(actual,expected){
  const parse=v=>/^\d+\.\d+\.\d+$/.test(v||'')?v.split('.').map(Number):null;
  const a=parse(actual),b=parse(expected);if(!a||!b)return false;
  for(let i=0;i<3;i++){if(a[i]>b[i])return true;if(a[i]<b[i])return false;}return true;
}
function sameHost(status,remoteName){return status?.protocol===1&&(status.remoteName||null)===(remoteName||null)&&(!remoteName||status.extensionKind===2);}
function bounded(promise,ms){let timer;return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Bridge nereaguje. Zkontrolujte Extension Host log a povolení rozšíření.')),ms);})]).finally(()=>clearTimeout(timer));}
/** All calls refer to this VS Code window/profile. No remote shell/SSH commands. */
function createController(vscode,context,{log=()=>{},wait=delay,readFile=fs.readFile}={}){
  // Pin the version of executing code, not a manifest replaced on disk mid-run.
  const version='0.4.2';
  const location=()=>vscode.env.remoteName?`aktuální ${vscode.env.remoteName} workspace`:'aktuální místní workspace';
  let busy=false;
  async function probe(){
    try{
      const commands=await bounded(vscode.commands.getCommands(true),5000);
      if(!commands.includes('missionControl.getStatus'))return {ready:false,reason:'Bridge v tomto okně není aktivní, chybí nebo je starší než 0.3.5.'};
      const status=await bounded(vscode.commands.executeCommand('missionControl.getStatus'),5000);
      if(!sameHost(status,vscode.env.remoteName))return {ready:false,reason:'Bridge odpovídá z jiného hostu nebo nepodporovaným protokolem. Připojení nebylo zahájeno.'};
      if(!versionAtLeast(status.version,version))return {ready:false,status,reason:`V tomto okně je načtený bridge ${status.version}; přiložený balíček je ${version}.`};
      if(typeof status.runtimeBuild!=='string'||!status.runtimeBuild.startsWith(status.version+'-'))
        return {ready:false,status,reason:'Verze v manifestu nestačí: toto okno nepotvrdilo nový běžící kód Bridge. Po dokončení práce agentů použijte Developer: Reload Window.'};
      return {ready:true,status,reason:status.blockedReason||status.message||''};
    }catch(e){return {ready:false,reason:e.message};}
  }
  async function install(force=false){
    const existing=await probe();
    if(!force&&existing.ready)return existing.status;
    if(existing.status&&versionAtLeast(existing.status.version,version)&&existing.status.version!==version){
      void vscode.window.showWarningMessage(`Bridge ${existing.status.version} je novější než přiložený ${version}. Automatický downgrade neprovádím.`);return null;
    }
    const answer=await vscode.window.showInformationMessage(
      `Nainstalovat nebo opravit Mission Control Bridge ${version} pro ${location()}? VS Code vybere host podle workspace. Otevřená okna ani agenty nerestartuji.`,
      {modal:true},'Nainstalovat');
    if(answer!=='Nainstalovat')return null;
    const metaUri=vscode.Uri.joinPath(context.extensionUri,'resources','bridge-package.json');
    const uri=vscode.Uri.joinPath(context.extensionUri,'resources','bridge.vsix');
    const meta=JSON.parse(await readFile(metaUri.fsPath,'utf8'));
    const bytes=await readFile(uri.fsPath);
    if(meta.id!==BRIDGE_ID||meta.version!==version||!Buffer.isBuffer(bytes)||bytes.length>5*1024*1024||createHash('sha256').update(bytes).digest('hex')!==meta.sha256){
      throw new Error('Přiložený VSIX neprošel kontrolou integrity. Přeinstalujte Mission Control Connection.');
    }
    log(`Instaluji ${BRIDGE_ID}@${version} do: ${location()}. Tokeny ani SSH příkazy nepředávám.`);
    // Documented VS Code API. The bridge declares extensionKind=["workspace"],
    // so VS Code's extension manager selects the current remote workspace host.
    // We intentionally pass an actual VSIX URI, never an unpublished gallery ID.
    await vscode.commands.executeCommand('workbench.extensions.installExtension',uri);
    for(let n=0;n<4;n++){
      const check=await probe();if(check.ready){log(`MC_BRIDGE_ACTIVE ${check.status.version} ${location()}`);return check.status;}
      if(n<3)await wait(400);
    }
    log('Instalační příkaz skončil, ale aktivaci správného bridge v tomto okně zatím nelze potvrdit.');
    void vscode.window.showWarningMessage('VSIX instalace skončila, ale správný bridge v tomto okně ještě neodpovídá. Zkontrolujte Extensions: Mission Control Bridge → Enable / Install in WSL/SSH. Až agenti dokončí práci, použijte Developer: Reload Window. Připojení nebylo potvrzeno.');
    return null;
  }
  async function setup({reconnect=false}={}){
    if(busy)return;busy=true;
    try{
      if(!vscode.workspace.isTrusted){void vscode.window.showWarningMessage('Mission Control: tento workspace je v Restricted Mode. Připojení a monitoring jsou vypnuté. Důvěru povolte pouze známému projektu.');return;}
      if(!(vscode.workspace.workspaceFolders||[]).length){void vscode.window.showInformationMessage('Mission Control: nejprve otevřete složku projektu. Diagnostika je dostupná i bez ní.');return;}
      const s=await install(false);if(!s)return;
      if(s.blockedReason){void vscode.window.showWarningMessage('Mission Control: '+s.blockedReason);return;}
      const automatic=(!vscode.env.remoteName&&process.platform==='win32')||vscode.env.remoteName==='wsl';
      const command=reconnect?'missionControl.reconnect':automatic?'missionControl.connectDesktop':'missionControl.connect';
      log(`Připravený bridge ${s.version}; spouštím ${command}.`);
      await vscode.commands.executeCommand(command);
      // Do not claim connected based on the success of a command; producer
      // confirms the live connection separately via getStatus.
      return await probe();
    }catch(e){log(e.message);void vscode.window.showErrorMessage('Mission Control: '+e.message);}
    finally{busy=false;}
  }
  async function repair(){
    if(busy)return;busy=true;
    try{return await install(true);}catch(e){log(e.message);void vscode.window.showErrorMessage('Mission Control: '+e.message);}finally{busy=false;}
  }
  async function disconnect(){
    if(busy)return;busy=true;
    try{
      const p=await probe();
      if(!p.ready){void vscode.window.showWarningMessage('Bridge v tomto workspace neodpovídá. Připojení můžete odebrat v dashboardu. '+p.reason);return;}
      await vscode.commands.executeCommand('missionControl.disconnect');
      return await probe();
    }catch(e){log(e.message);void vscode.window.showErrorMessage('Mission Control: '+e.message);}
    finally{busy=false;}
  }
  return {probe,setup,repair,disconnect,reconnect:()=>setup({reconnect:true}),location};
}
module.exports={createController,versionAtLeast,sameHost};
