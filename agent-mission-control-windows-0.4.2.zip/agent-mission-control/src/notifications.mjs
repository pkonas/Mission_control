import {randomBytes} from 'node:crypto';
import {stateLabels} from '../public/project-model.mjs';
const text=(v,n)=>typeof v==='string'?v.slice(0,n):'';
const validId=id=>typeof id==='string'&&/^[a-f0-9]{32}$/.test(id);
/** Event-addressed notification history. A notice never contains a runnable action.
 * Runtime tray queue is not restored after a hub restart; history is. */
export class NotificationCenter {
  constructor(saved,{now=Date.now,id=()=>randomBytes(16).toString('hex')}={}){
    this.now=now;this.id=id;this.items=[];this.queue=[];this.seen=new Set();
    for(const e of (Array.isArray(saved?.items)?saved.items:[]).slice(-200)){
      if(!validId(e.id)||!Number.isFinite(e.at))continue;
      this.items.push({id:e.id,at:e.at,projectKey:text(e.projectKey,250),sessionKey:text(e.sessionKey,250),requestId:text(e.requestId,250),eventId:text(e.eventId,250),signature:text(e.signature,1200),revision:Number.isSafeInteger(e.revision)?e.revision:0,project:text(e.project,160),agent:text(e.agent,30),state:text(e.state,30),title:text(e.title,250),summary:text(e.summary,2000)});
    }
    for(const v of (Array.isArray(saved?.seen)?saved.seen:[]).slice(-1000))if(typeof v==='string')this.seen.add(v.slice(0,1200));
  }
  capture(snapshot){
    let changed=false;
    for(const p of snapshot.projects||[]){
      if(!p.notify||!p.connected)continue;
      for(const s of (snapshot.sessions||[]).filter(s=>p.currentKeys?.includes(s.key))){
        const state=s.effectiveState||s.state;
        if(!s.connected||s.acknowledged||s.snoozed||s.historical||!['needs_input','needs_approval','review','error'].includes(state))continue;
        if(s.evidence==='observed'&&!(state==='review'&&s.role==='main'&&s.observedCompletionAt>0))continue;
        const asks=s.pending?.length?s.pending:[null];
        for(const ask of asks){
          const hook=ask?.method==='codex/hook/permission';
          const signature=hook?`${s.key}:codex-hook:${ask.id}`:`${s.key}:${s.stateRevision}:${state}:${ask?.id??''}`;
          if(this.seen.has(signature))continue;
          this.seen.add(signature);
          const event=ask?.eventId||(s.events||[]).at(-1)?.id||'';
          const notice={id:this.id(),at:this.now(),projectKey:p.key,sessionKey:s.key,requestId:ask?String(ask.id):'',eventId:event,signature,revision:s.stateRevision,
            project:p.project,agent:s.agent,state,title:`${p.project} · ${stateLabels[state]||state}`,
            summary:text(ask?.summary||s.activity||p.activity,2000)};
          this.items.push(notice);this.queue.push(notice.id);changed=true;
        }
      }
    }
    this.items=this.items.slice(-200);this.seen=new Set([...this.seen].slice(-1000));
    this.queue=this.queue.filter(id=>this.items.some(e=>e.id===id)).slice(-200);
    return changed;
  }
  list(){return [...this.items].reverse();}
  get(id){return validId(id)?this.items.find(e=>e.id===id):undefined;}
  next(){return this.queue.map(id=>this.get(id)).find(Boolean);}
  delivered(id){this.queue=this.queue.filter(x=>x!==id);}
  serialize(){return {version:1,items:this.items,seen:[...this.seen]};}
  desktop(instance,snapshot){
    // Do not show a queued approval notification after it was answered elsewhere.
    // Keep its history so an already visible/clicked notice still resolves exactly.
    if(snapshot)this.queue=this.queue.filter(id=>{
      const n=this.get(id),p=snapshot.projects?.find(p=>p.key===n?.projectKey),s=snapshot.sessions?.find(s=>s.key===n?.sessionKey);
      return !!(n&&p?.notify&&p.connected&&s?.connected&&p.currentKeys?.includes(s.key)&&(n.signature.includes(':codex-hook:')?s.pending?.some(q=>String(q.id)===n.requestId):s.stateRevision===n.revision&&(!n.requestId||s.pending?.some(q=>String(q.id)===n.requestId))));
    });
    const n=this.next();
    if(!n)return `MCN1\n${instance}\nnone\n`;
    const line=s=>String(s).replace(/[\r\n\t\x00-\x1f\x7f]/g,' ').trim();
    // No command text, chat content or file paths on a lock-screen-adjacent popup.
    return `MCN1\n${instance}\n${n.id}\n${line(n.project).slice(0,140)}\n${line(stateLabels[n.state]||n.state)} — ${n.agent==='zoo'?'Zoo Code':'Codex'}. Kliknutím otevřete tuto událost.\n`;
  }
}
