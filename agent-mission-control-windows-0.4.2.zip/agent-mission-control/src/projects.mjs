import {createHash} from 'node:crypto';
import identity from '../bridge/src/identity.cjs';
const clip=(v,n=2000)=>typeof v==='string'?v.slice(0,n):'';
export function projectIdentity(p){
  const platform=identity.platformFor(p.environment,p.workspace);
  const root=identity.normalizeWorkspace(p.canonicalWorkspace||p.workspace,platform);
  if(!root)return null;
  return createHash('sha256').update(JSON.stringify([p.hostId||['legacy',String(p.host||'').toLowerCase(),platform],root])).digest('hex').slice(0,24);
}
export function projectMetadata(raw){
  const p={project:clip(raw.project||raw.name,160)||'Projekt',workspace:clip(raw.workspace),canonicalWorkspace:clip(raw.canonicalWorkspace),hostId:clip(raw.hostId,160),host:clip(raw.host,160),environment:clip(raw.environment,60),
    focusUri:/^vscode(?:-insiders)?:\/\//.test(raw.focusUri||'')?clip(raw.focusUri,8000):'',branch:clip(raw.branch,200),filesKnown:raw.filesKnown===true,filesAt:Number.isFinite(raw.filesAt)?raw.filesAt:0,
    files:(Array.isArray(raw.files)?raw.files:[]).slice(0,100).map(f=>({path:clip(f.path,1500),status:clip(f.status,10),scope:'workspace'}))};
  p.key=projectIdentity(p);if(!p.key)throw new Error('Project requires a workspace path');return p;
}
/** Per-root registry, independent from transport connections and individual chats.
 * Removed roots are durable tombstones. A new log or a late epoch cannot re-add one.
 */
export class Projects{
  constructor(store){this.store=store;this.items=new Map();this.removed=new Set();this.blocked=new Map();}
  isBlocked(key,id,epoch){return this.removed.has(key)||this.blocked.get(key)?.includes(JSON.stringify([id,epoch]));}
  accept(raw,id,epoch,{resume=false,at=this.store.now(),fromSession=false}={}){
    const meta=projectMetadata(raw),key=meta.key,tag=JSON.stringify([id,epoch]);
    // Even an explicit resume cannot reuse the old generation.
    if(this.blocked.get(key)?.includes(tag))return null;
    if(this.removed.has(key)){if(!resume)return null;this.removed.delete(key);}
    let old=this.items.get(key);
    // Upgrade a legacy identity only with an exact host/environment/root match.
    if(!old&&meta.hostId){const oldMeta={...meta,hostId:''};const legacy=this.items.get(projectIdentity(oldMeta));if(legacy&&!legacy.hostId){
      this.items.delete(legacy.key);for(const s of this.store.sessions.values())if(s.projectKey===legacy.key)s.projectKey=key;old=legacy;
    }}
    const members={...(old?.members||{})};members[id]={epoch,at};
    const p={...old,...meta,focusUri:fromSession?(old?.focusUri||''):(meta.focusUri||old?.focusUri||''),createdAt:old?.createdAt||at,members};
    if(old?.filesKnown&&(!meta.filesKnown||(old.filesAt||0)>(meta.filesAt||0)))Object.assign(p,{files:old.files,filesKnown:true,filesAt:old.filesAt,branch:old.branch});
    this.items.set(key,p);return key;
  }
  register(data,{resume=false}={}){
    if(data.projects===undefined)return;
    if(!Array.isArray(data.projects)||data.projects.length>40)throw new Error('Maximum 40 workspace roots');
    data.projects.map(projectMetadata); // Validate first.
    let accepted=0;
    for(const p of data.projects)if(this.accept(p,data.sourceId,data.epoch,{resume}))accepted++;
    if(data.projects.length&&!accepted)throw this.store.removedError('project-removed');
  }
  disconnect(key,expected){
    const p=this.items.get(key);if(!p)return {removed:true,count:0,projectKey:key};
    const current=this.owners(p);
    if(JSON.stringify(current)!==JSON.stringify(expected))throw Object.assign(new Error('Připojení projektu se změnilo. Obnovte dashboard a potvrďte odpojení znovu.'),{status:409,code:'NOT_OWNER'});
    this.removed.add(key);
    const blocked=new Set(this.blocked.get(key)||[]);for(const [id,m] of Object.entries(p.members))blocked.add(JSON.stringify([id,m.epoch]));this.blocked.set(key,[...blocked].slice(-256));
    this.items.delete(key);let count=0;
    for(const [k,s] of this.store.sessions)if(s.projectKey===key){this.store.sessions.delete(k);count++;}
    this.store.changed();return {removed:true,count,projectKey:key};
  }
  removeSource(id){
    for(const [key,p] of this.items){delete p.members[id];if(!Object.keys(p.members).length){this.items.delete(key);}}
  }
  owners(p){return Object.entries(p.members).map(([sourceId,m])=>({sourceId,epoch:m.epoch})).sort((a,b)=>a.sourceId.localeCompare(b.sourceId));}
  snapshot(){return [...this.items.values()].map(p=>{
    const sources=this.owners(p).map(x=>{const src=this.store.sources.get(x.sourceId);return {...x,connected:src?.epoch===x.epoch&&this.store.sourceAlive(src),label:src?.label||x.sourceId,lastSeen:src?.lastSeen||0};});
    return {...p,members:undefined,owners:this.owners(p),sources,connected:sources.some(x=>x.connected),lastSeen:Math.max(0,...sources.map(x=>x.lastSeen))};
  });}
  serialize(){return {version:1,items:[...this.items.values()].map(p=>({...p,focusUri:''})),removed:[...this.removed],blocked:[...this.blocked]};}
  restore(data){
    this.items.clear();this.removed.clear();this.blocked.clear();
    for(const key of (data?.removed||[]).slice(0,10000))if(/^[a-f0-9]{24}$/.test(key))this.removed.add(key);
    for(const entry of (Array.isArray(data?.blocked)?data.blocked:[]).slice(0,10000)){if(!Array.isArray(entry))continue;const [key,values]=entry;if(/^[a-f0-9]{24}$/.test(key)&&Array.isArray(values))this.blocked.set(key,values.filter(v=>typeof v==='string'&&v.length<500).slice(-256));}
    for(const p of (data?.items||[]).slice(0,1000))try{
      const meta=projectMetadata(p);if(this.removed.has(meta.key))continue;
      const members=Object.fromEntries(Object.entries(p.members||{}).filter(([id,m])=>typeof id==='string'&&typeof m?.epoch==='string').slice(0,100));
      this.items.set(meta.key,{...meta,members,createdAt:p.createdAt||0,acknowledgedSignature:clip(p.acknowledgedSignature,12000),snoozeUntil:Number(p.snoozeUntil)||0});
    }catch{/* Invalid saved root is not executed or guessed. */}
    for(const s of this.store.sessions.values()){
      const key=projectIdentity(s);if(!key||this.removed.has(key))continue;
      s.projectKey=key;
      if(!this.items.has(key))this.accept(s,s.sourceId,s.sourceEpoch||'restored');
    }
  }
}
