import {randomBytes, timingSafeEqual, createHash} from 'node:crypto';

/** Short-lived, single-use browser pairing; separate from the long-lived bridge token. */
export class DesktopAccess {
  constructor(secret, instanceId, {now=Date.now, ttl=30_000}={}) {
    if(!/^[a-f0-9]{64}$/.test(secret))throw new Error('Invalid desktop secret');
    if(!/^[a-f0-9]{32}$/.test(instanceId))throw new Error('Invalid desktop instance ID');
    this.secret=secret;this.instanceId=instanceId;this.now=now;this.ttl=ttl;this.tickets=new Map();
  }
  authorized(value) {
    const expected=`Bearer ${this.secret}`;
    return typeof value==='string'&&Buffer.byteLength(value)===Buffer.byteLength(expected)&&timingSafeEqual(Buffer.from(value),Buffer.from(expected));
  }
  issue() {
    const now=this.now();for(const [key,expiry] of this.tickets)if(expiry<=now)this.tickets.delete(key);
    if(this.tickets.size>=16)this.tickets.delete(this.tickets.keys().next().value);
    const ticket=randomBytes(32).toString('hex');this.tickets.set(ticket,now+this.ttl);return ticket;
  }
  consume(ticket) {
    if(typeof ticket!=='string'||!/^[a-f0-9]{64}$/.test(ticket))return false;
    const expiry=this.tickets.get(ticket);this.tickets.delete(ticket);return expiry>this.now();
  }
  status(snapshot) {
    const sessions=snapshot.projects||snapshot.sessions||[];
    const state=s=>s.effectiveState||s.state;
    const noticeState=s=>s.notificationState||state(s);
    const pending=sessions.filter(s=>s.connected!==false&&(s.notify===undefined?!s.acknowledged&&!s.snoozed:s.notify)&&['needs_input','needs_approval','error','review'].includes(noticeState(s)));
    // No source text or commands are sent to the system-tray status channel.
    const fingerprint=createHash('sha256').update(pending.map(s=>`${s.key}:${s.notificationSignature??s.stateRevision}:${state(s)}`).sort().join('\n')).digest('hex');
    const attention=pending.filter(s=>noticeState(s)!=='review').length;
    const working=sessions.filter(s=>s.workingCount===undefined?state(s)==='working':s.connected&&s.workingCount>0).length;
    const review=pending.length-attention;
    return `MC2\n${this.instanceId}\n${attention}\n${working}\n${review}\n${sessions.length}\n${fingerprint}\n`;
  }
}
