import {Projects,projectIdentity} from './projects.mjs';
import {projectProjection} from '../public/project-model.mjs';
import {createHash} from 'node:crypto';
import {EventEmitter} from 'node:events';
import normalizers from '../bridge/src/normalizers.cjs';
import identity from '../bridge/src/identity.cjs';
const {sessionIdentity,sameSession}=identity;
const {STATES} = normalizers;
export const keyFor = (source,id) => createHash('sha256').update(JSON.stringify([source,id])).digest('hex').slice(0,24);
const str=(v,max=500)=>typeof v==='string'?v.slice(0,max):'';
const time=(v,now)=>Number.isFinite(v)&&v>0?Math.min(v,now+5000):now;
const safeUri=(v)=>typeof v==='string' && /^vscode(?:-insiders)?:\/\//.test(v) ? v.slice(0,8000) : '';
function sanitizeSession(raw,now) {
  if(!raw || typeof raw.id!=='string' || !raw.id || raw.id.length>250) throw new Error('Invalid session id');
  if(!['codex','zoo'].includes(raw.agent)) throw new Error('Invalid agent');
  if(!STATES.has(raw.state)) throw new Error('Invalid state');
  if(!['api','observed','demo'].includes(raw.evidence)) throw new Error('Invalid evidence');
  const activity=(a)=>({id:str(a?.id,250),at:time(a?.at,now),kind:str(a?.kind,50),text:str(a?.text,12000)});
  const s={id:raw.id,agent:raw.agent,project:str(raw.project,160)||'Projekt',workspace:str(raw.workspace,2000),
    environment:str(raw.environment,60)||'Local',host:str(raw.host,160),hostId:str(raw.hostId,160),canonicalWorkspace:str(raw.canonicalWorkspace,2000),state:raw.state,evidence:raw.evidence,
    activity:str(raw.activity,600),activityAt:time(raw.activityAt,now),stateSince:time(raw.stateSince,now),
    controlNote:str(raw.controlNote,1200),branch:str(raw.branch,200),note:str(raw.note,1600),focusUri:safeUri(raw.focusUri),version:str(raw.version,80),
    capabilities:(Array.isArray(raw.capabilities)?raw.capabilities:[]).filter(x=>['open','prompt','approve','input','interrupt','zooDecision','codexDecision'].includes(x)),
    events:(Array.isArray(raw.events)?raw.events:[]).slice(-100).map(activity),
    messages:(Array.isArray(raw.messages)?raw.messages:[]).slice(-30).map(activity),
    diff:str(raw.diff,120000),files:(Array.isArray(raw.files)?raw.files:[]).slice(0,100).map(f=>({path:str(f.path,1500),status:str(f.status,10),scope:'workspace'})),
    observedCompletionAt:Number.isFinite(raw.observedCompletionAt)?raw.observedCompletionAt:0,role:['main','support','internal','unknown'].includes(raw.role)?raw.role:(raw.evidence==='observed'?'unknown':'main'),parentId:str(raw.parentId,250),sourceKind:str(raw.sourceKind,100),historical:raw.historical===true,current:raw.current!==false,runStartedAt:Number.isFinite(raw.runStartedAt)?raw.runStartedAt:0,filesKnown:raw.filesKnown===true,filesAt:Number.isFinite(raw.filesAt)?raw.filesAt:0,
    turnId:str(raw.turnId,250),pending:(Array.isArray(raw.pending)?raw.pending:[]).slice(0,20).map(p=>({
      id: typeof p.id==='number'?p.id:str(p.id,250),method:str(p.method,200),summary:str(p.summary,['zoo/ask/decision','codex/hook/permission'].includes(p.method)?24000:6000),command:str(p.command,['zoo/ask/decision','codex/hook/permission'].includes(p.method)?24000:6000),eventId:str(p.eventId,250),ask:str(p.ask,80),at:time(p.at,now),protected:p.protected===true,...(p.method==='codex/hook/permission'?{expiresAt:Number.isFinite(p.expiresAt)?p.expiresAt:0,turnId:str(p.turnId,250)}:{}),
      questions:(Array.isArray(p.questions)?p.questions:[]).slice(0,20).map(q=>({id:str(q.id,200),header:str(q.header,200),question:str(q.question,4000),options:(Array.isArray(q.options)?q.options:[]).slice(0,30).map(o=>({label:str(o.label,400),description:str(o.description,2000)}))}))
    }))};
  // Observed sessions cannot expose control actions, even if a producer claims otherwise.
  if(s.evidence==='observed') {s.capabilities=s.capabilities.filter(x=>x==='open');s.pending=[];}
  return s;
}
export class Store extends EventEmitter {
  constructor({now=()=>Date.now(),disconnectMs=30000,staleMs=600000,maxSessions=200}={}) {
    super(); Object.assign(this,{now,disconnectMs,staleMs,maxSessions});
    this.sessions=new Map();this.sources=new Map();this.revision=0;this.projects=new Projects(this);
    // Durable disconnect intent is independent of live leases. A restart or late
    // heartbeat cannot bring a deliberately removed connection back.
    this.detachedSources=new Map();this.retiredEpochs=new Map();
  }
  sourceAlive(source) {return !!source&&!source.released&&this.now()-source.lastSeen<this.disconnectMs;}
  sessionAlive(s) {const source=this.sources.get(s.sourceId);return this.sourceAlive(source)&&source.epoch===s.sourceEpoch&&this.now()-(s.lastReported||0)<this.disconnectMs;}
  validateSource(data) {
    if(data?.version!==1 || typeof data.sourceId!=='string' || !/^[a-zA-Z0-9_.:-]{1,160}$/.test(data.sourceId)) throw new Error('Invalid sourceId/version');
    if(typeof data.epoch!=='string'||data.epoch.length<8||data.epoch.length>160)throw new Error('Invalid epoch');
  }
  conflict(code,source,key) {
    return Object.assign(new Error(code==='SESSION_IN_USE'?'Tato relace agenta je již připojena v jiném okně. Druhé připojení nebylo vytvořeno.':'Tento workspace je již připojen jiným bridge. Použijte původní připojení.'),{
      status:409,code,ownerLabel:source?.label||'',existingKey:key||'',retryAfterMs:Math.max(0,this.disconnectMs-(this.now()-(source?.lastSeen||0)))
    });
  }
  removedError(reason='source-detached') {return Object.assign(new Error('Připojení bylo odpojeno a odebráno z dashboardu. Ve VS Code použijte Mission Control: Reconnect This Workspace (Bridge: Mission Control: Reconnect).'),{status:409,code:'CONNECTION_REMOVED',reason});}
  retire(id,epoch) {
    if(!epoch)return;
    const epochs=this.retiredEpochs.get(id)||[];
    if(!epochs.includes(epoch))epochs.push(epoch);
    this.retiredEpochs.set(id,epochs.slice(-64));
  }
  checkOwner(data,{resuming=false}={}) {
    if(this.detachedSources.has(data.sourceId)&&!resuming)throw this.removedError();
    if(this.retiredEpochs.get(data.sourceId)?.includes(data.epoch))throw this.removedError('epoch-retired');
    const old=this.sources.get(data.sourceId);
    if(old?.retired?.includes(data.epoch))throw Object.assign(new Error('Toto připojení již bylo nahrazeno. Obnovte bridge, nepřebírejte aktivní relaci.'),{status:409,code:'RETIRED_EPOCH'});
    if(this.sourceAlive(old)&&old.epoch!==data.epoch)throw this.conflict('CONNECTION_IN_USE',old);
    if(old?.released&&old.epoch===data.epoch)throw Object.assign(new Error('Připojení již bylo ukončeno.'),{status:409,code:'RELEASED_CONNECTION'});
    return old;
  }
  activeProjectRoots(data){return [...this.projects.items.values()].filter(p=>p.members[data.sourceId]?.epoch===data.epoch&&!this.projects.isBlocked(p.key,data.sourceId,data.epoch)).map(p=>p.canonicalWorkspace||p.workspace);}
  connectionStatus(data) {
    this.validateSource(data);
    const source=this.sources.get(data.sourceId);
    const tag=JSON.stringify([data.sourceId,data.epoch]);
    const removedProjectCount=[...this.projects.blocked.values()].filter(v=>v.includes(tag)).length;
    const common={sourceId:data.sourceId,epoch:data.epoch,protocol:1,removedProjectCount};
    if(this.detachedSources.has(data.sourceId)||this.retiredEpochs.get(data.sourceId)?.includes(data.epoch))
      return {...common,owned:false,state:'removed',code:'CONNECTION_REMOVED',message:this.removedError().message};
    if(this.sourceAlive(source)&&source.epoch!==data.epoch)
      return {...common,owned:false,state:'replaced',code:'CONNECTION_IN_USE',ownerLabel:source.label,message:'Workspace již vlastní jiné aktivní připojení.'};
    if(source?.epoch===data.epoch&&this.sourceAlive(source))
      return {...common,owned:true,state:'connected',message:'Připojeno'};
    return {...common,owned:false,state:source?.released?'released':source?'expired':'missing',code:'NOT_OWNER',message:'Původní připojení již není aktivní.'};
  }
  ensureCapacity(id) {
    if(this.sources.has(id)||this.sources.size<50)return;
    // Expired producers are not an unbounded persistent registry. Ownership is
    // still verified per session; current owners are never evicted for capacity.
    for(const [k,s] of this.sources)if(!this.sourceAlive(s)&&k!==id)this.sources.delete(k);
    if(this.sources.size>=50)throw new Error('Too many active sources');
  }
  claim(data) {
    this.validateSource(data);
    const resuming=data.resume===true;
    const old=this.checkOwner(data,{resuming});this.ensureCapacity(data.sourceId);
    this.projects.register(data,{resume:resuming});
    if(resuming)this.detachedSources.delete(data.sourceId);
    const retired=[...(old?.retired||[])];if(old&&old.epoch!==data.epoch)retired.push(old.epoch);
    this.sources.set(data.sourceId,{...old,id:data.sourceId,epoch:data.epoch,seq:old?.epoch===data.epoch?old.seq:-1,lastSeen:this.now(),released:false,
      label:str(data.label,180)||data.sourceId,health:old?.health||'',retired:retired.slice(-32),leaseRequired:true});
    this.changed();return {accepted:true,leaseMs:this.disconnectMs,sourceId:data.sourceId,epoch:data.epoch,disconnectVersion:1,activeProjectRoots:this.activeProjectRoots(data)};
  }
  release(data) {
    this.validateSource(data);const source=this.sources.get(data.sourceId);
    if(!source||source.epoch!==data.epoch)return {released:false};
    source.released=true;source.lastSeen=0;this.changed();return {released:true};
  }
  disconnectSource(id,{epoch=null,producer=false}={}) {
    if(typeof id!=='string'||!/^[a-zA-Z0-9_.:-]{1,160}$/.test(id))throw new Error('Invalid sourceId');
    if(epoch!==null&&(typeof epoch!=='string'||epoch.length<8||epoch.length>160))throw new Error('Invalid epoch');
    const source=this.sources.get(id);
    const detached=this.detachedSources.get(id);
    // An old window, retry or stale dashboard must never detach a newer owner.
    if(source?.epoch&&source.epoch!==epoch)throw Object.assign(new Error('Připojení se mezitím změnilo. Obnovte stav dashboardu; nové připojení nebylo odpojeno.'),{status:409,code:'NOT_OWNER'});
    if(producer&&this.retiredEpochs.get(id)?.includes(epoch)&&!detached)throw Object.assign(new Error('Starší odpojení už není aktuální; nové připojení zůstalo zachováno.'),{status:409,code:'NOT_OWNER'});
    if(!source&&!detached&&!producer&&![...this.sessions.values()].some(s=>s.sourceId===id))return {removed:true,count:0,alreadyRemoved:true};
    if(!detached&&this.detachedSources.size>=10000)throw new Error('Limit uložených odpojení byl dosažen; připojení nebylo odstraněno.');
    this.detachedSources.set(id,{id,label:source?.label||detached?.label||id,at:this.now()});
    this.retire(id,epoch);this.retire(id,source?.epoch);
    if(source){source.released=true;source.lastSeen=0;}
    let count=0;
    for(const [key,s] of this.sessions)if(s.sourceId===id){this.sessions.delete(key);count++;}
    this.projects.removeSource(id);
    this.changed();return {removed:true,count,sourceId:id};
  }
  authorizeSource(id,epoch) {
    if(this.detachedSources.has(id))throw this.removedError();
    if(this.retiredEpochs.get(id)?.includes(epoch))throw this.removedError('epoch-retired');
    const source=this.sources.get(id);
    if(!this.sourceAlive(source)||((source.leaseRequired||epoch)&&source.epoch!==epoch))throw Object.assign(new Error('Připojení již nevlastní tuto relaci.'),{status:409,code:'NOT_OWNER'});
    return source;
  }
  findSession(s) {return [...this.sessions.values()].find(x=>sameSession(x,s));}
  ingest(data) {
    const now=this.now();this.validateSource(data);
    if(!Number.isSafeInteger(data.seq)||data.seq<0)throw new Error('Invalid sequence');
    if(!Array.isArray(data.sessions)||data.sessions.length>100)throw new Error('Too many sessions (maximum 100 per batch)');
    const old=this.checkOwner(data);
    if(old?.epoch===data.epoch&&data.seq<=old.seq)return {accepted:false,reason:'duplicate'};
    const normalized=data.sessions.map(s=>sanitizeSession(s,now)).filter(s=>!this.projects.isBlocked(projectIdentity(s),data.sourceId,data.epoch));
    // Validate the WHOLE batch before mutation. A second reporter cannot create
    // a shadow record or overwrite the active owner's focus link/approval state.
    const seen=[];const records=[];
    for(const s of normalized){
      if(seen.some(x=>sameSession(x,s)))throw Object.assign(new Error('Jedna dávka obsahuje tutéž relaci vícekrát.'),{status:409,code:'DUPLICATE_SESSION'});
      seen.push(s);const prev=this.findSession(s);
      if(prev&&this.sessionAlive(prev)&&(prev.sourceId!==data.sourceId||prev.sourceEpoch!==data.epoch))throw this.conflict('SESSION_IN_USE',this.sources.get(prev.sourceId),prev.key);
      records.push({s,prev,key:prev?.key||sessionIdentity(s).key});
    }
    if(this.sessions.size+records.filter(r=>!r.prev).length>this.maxSessions)throw new Error('Session limit reached. Remove old sessions from the dashboard.');
    this.ensureCapacity(data.sourceId);
    this.projects.register(data);
    const retired=[...(old?.retired||[])];if(old&&old.epoch!==data.epoch)retired.push(old.epoch);
    this.sources.set(data.sourceId,{id:data.sourceId,epoch:data.epoch,seq:data.seq,lastSeen:now,released:false,label:str(data.label,180)||data.sourceId,
      health:str(data.health,1000),retired:retired.slice(-32),leaseRequired:old?.leaseRequired||data.leaseVersion===1});
    for(const {s,prev,key} of records){
      const signal=JSON.stringify([s.state,s.stateSince,s.pending.map(x=>x.id)]);
      const stateRevision=prev?prev.stateRevision+(prev.signal!==signal?1:0):1;
      // On reconnect keep collected history, but never restore old controls.
      const history=prev?mergeHistory(prev,s):s;
      const projectKey=projectIdentity(s)?this.projects.accept(s,data.sourceId,data.epoch,{fromSession:true}):null;
      this.sessions.set(key,{...history,key,projectKey,sourceId:data.sourceId,sourceEpoch:data.epoch,lastReported:now,signal,stateRevision,
        acknowledgedFor:prev?.acknowledgedFor||0,snoozeUntil:prev?.snoozeUntil||0});
    }
    this.changed();return {accepted:true,revision:this.revision,activeProjectRoots:this.activeProjectRoots(data)};
  }
  annotateProject(key,{acknowledge,snoozeMinutes}) {
    const p=this.projects.items.get(key);if(!p)throw new Error('Project not found');
    if(acknowledge===true)p.acknowledgedSignature=this.snapshot().projects.find(x=>x.key===key)?.notificationSignature||'';
    if(snoozeMinutes!==undefined){if(![0,5,15,60].includes(snoozeMinutes))throw new Error('Invalid snooze interval');p.snoozeUntil=this.now()+snoozeMinutes*60000;}
    this.changed();
  }
  changed() {this.revision++;this.emit('change');}
  annotate(key,{acknowledge,snoozeMinutes}) {
    const s=this.sessions.get(key);if(!s)throw new Error('Session not found');
    if(acknowledge===true)s.acknowledgedFor=s.stateRevision;
    if(snoozeMinutes!==undefined) {
      if(![0,5,15,60].includes(snoozeMinutes))throw new Error('Invalid snooze interval');
      s.snoozeUntil=this.now()+snoozeMinutes*60000;
    }
    this.changed();
  }
  forget(key) {const s=this.sessions.get(key);if(!s)return;const source=this.sources.get(s.sourceId);
    if(this.sessionAlive(s))throw new Error('Disconnect the producer before removing its session.');
    this.sessions.delete(key);this.changed();}
  snapshot() {
    const now=this.now();
    const result={version:1,revision:this.revision,serverTime:now,sessions:[...this.sessions.values()].map(s=>{
      const source=this.sources.get(s.sourceId);
      const connected=this.sessionAlive(s);
      const state=!connected?'disconnected':s.evidence==='observed'&&s.state==='working'&&now-s.activityAt>90000?'unknown':s.state;
      return {...s,effectiveState:state,connected,stale:connected&&s.evidence==='api'&&s.state==='working'&&now-s.activityAt>this.staleMs,
        acknowledged:s.acknowledgedFor===s.stateRevision,snoozed:s.snoozeUntil>now,signal:undefined};
    }),sources:[...this.sources.values()].filter(source=>!this.detachedSources.has(source.id)).map(source=>({id:source.id,label:source.label,health:source.health,lastSeen:source.lastSeen,connected:this.sourceAlive(source),connectionEpoch:source.epoch}))};
    result.projectModelVersion=1;result.projects=projectProjection(this.projects.snapshot(),result.sessions,now);return result;
  }
  serialize() {return {version:1,identityVersion:2,disconnectVersion:1,projectModelVersion:1,projects:this.projects.serialize(),detachedSources:[...this.detachedSources.values()],retiredEpochs:[...this.retiredEpochs],sessions:[...this.sessions.values()].map(s=>({...s,focusUri:''}))};}
  restore(data) {
    if(data?.version!==1||!Array.isArray(data.sessions))return;
    this.sessions.clear();this.sources.clear();this.detachedSources.clear();this.retiredEpochs.clear();
    for(const x of (Array.isArray(data.detachedSources)?data.detachedSources:[]).slice(0,10000)){
      if(x&&typeof x.id==='string'&&/^[a-zA-Z0-9_.:-]{1,160}$/.test(x.id))this.detachedSources.set(x.id,{id:x.id,label:str(x.label,180),at:time(x.at,this.now())});
    }
    for(const x of (Array.isArray(data.retiredEpochs)?data.retiredEpochs:[]).slice(0,20000)){
      if(Array.isArray(x)&&typeof x[0]==='string'&&/^[a-zA-Z0-9_.:-]{1,160}$/.test(x[0])&&Array.isArray(x[1])){
        this.retiredEpochs.set(x[0],x[1].filter(e=>typeof e==='string'&&e.length>=8&&e.length<=160).slice(-64));
      }
    }
    for(const raw of data.sessions.slice(0,1000))try{
      if(this.detachedSources.has(raw.sourceId))continue;
      const s=sanitizeSession(raw,this.now());const prev=this.findSession(s);
      const key=prev?.key||(/^[a-f0-9]{24}$/.test(raw.key||'')?raw.key:sessionIdentity(s).key);
      if(!prev&&this.sessions.size>=this.maxSessions)continue;
      const next={...s,key,sourceId:str(raw.sourceId,160),stateRevision:raw.stateRevision||1,acknowledgedFor:raw.acknowledgedFor||0,snoozeUntil:raw.snoozeUntil||0,
        signal:JSON.stringify([s.state,s.stateSince,s.pending.map(x=>x.id)])};
      if(prev){
        const winner=(next.activityAt>=prev.activityAt)?next:prev;
        const loser=winner===next?prev:next;
        this.sessions.set(key,{...mergeHistory(loser,winner),key,snoozeUntil:Math.max(prev.snoozeUntil,next.snoozeUntil)});
      }else if(!this.sessions.has(key))this.sessions.set(key,next);
    }catch{/* Malformed disk entries are skipped, never executed. */}
    this.projects.restore(data.projects);
    // Exact historical duplicates collapse to one offline record. No stored
    // source gets a lease and no approvals are sent during migration.
  }
}
function mergeHistory(older,newer){
  function merge(field,limit){
    const byId=new Map();
    for(const event of [...(older[field]||[]),...(newer[field]||[])])byId.set(event.id||JSON.stringify([event.at,event.kind,event.text]),event);
    return [...byId.values()].sort((a,b)=>a.at-b.at).slice(-limit);
  }
  return {...newer,events:merge('events',100),messages:merge('messages',30)};
}
