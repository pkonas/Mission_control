/** Wire contract v1. The executable implementation uses portable JavaScript. */
export type State = 'unknown' | 'idle' | 'working' | 'needs_input' | 'needs_approval' | 'error' | 'review' | 'paused';
export type Evidence = 'api' | 'observed' | 'demo';
export interface Activity { id: string; at: number; kind: string; text: string; }
export interface PendingRequest {
  id: string | number; method: string; summary: string;
  command?: string; questions?: {id: string; header?: string; question: string; options?: {label: string; description?: string}[]}[];
}
export interface Session {
  id: string; project: string; workspace: string; agent: 'zoo' | 'codex';
  environment: string; host: string; hostId?: string; canonicalWorkspace?: string; state: State; evidence: Evidence;
  activity: string; activityAt: number; stateSince: number;
  branch?: string; note?: string; focusUri?: string;
  capabilities: ('open' | 'prompt' | 'approve' | 'input' | 'interrupt')[];
  events: Activity[]; messages: Activity[]; diff?: string;
  files?: {path: string; status: string; scope?: 'workspace'}[];
  pending?: PendingRequest[]; turnId?: string; version?: string;
}
export interface Ingest {
  version: 1; sourceId: string; epoch: string; seq: number;
  label: string; health?: string; leaseVersion?: 1; sessions: Session[];
}

/** Claim before collection/thread creation. An active foreign epoch gets HTTP 409. */
export interface ConnectionClaim { version: 1; sourceId: string; epoch: string; label?: string; resume?: boolean; }
export interface ConnectionConflict { error: string; code: 'CONNECTION_IN_USE' | 'SESSION_IN_USE' | 'NOT_OWNER' | 'RETIRED_EPOCH' | 'RELEASED_CONNECTION' | 'CONNECTION_REMOVED'; ownerLabel?: string; existingKey?: string; retryAfterMs?: number; }

export interface DisconnectRequest { sourceId: string; epoch: string | null; }
export interface DisconnectResult { removed: boolean; sourceId?: string; count?: number; alreadyRemoved?: boolean; }
