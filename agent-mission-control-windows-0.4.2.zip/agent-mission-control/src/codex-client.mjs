import {spawn} from 'node:child_process';
import readline from 'node:readline';
import {readFile,stat} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import normalizers from '../bridge/src/normalizers.cjs';
import transport from '../bridge/src/producer.cjs';
import identityTools from '../bridge/src/identity.cjs';
const {Producer}=transport;const {codexNotification,publicSession,addEvent}=normalizers;
export class RpcClient {
  constructor(command,args,{cwd,onMessage=()=>{},onError=()=>{}}={}) {
    this.counter=0;this.requests=new Map();this.onMessage=onMessage;this.onError=onError;this.closed=false;
    // Never use a shell or interpolate a prompt into a command line.
    this.child=spawn(command,args,{cwd,stdio:['pipe','pipe','pipe'],windowsHide:true,shell:false});
    this.child.stdin.on('error',e=>this.fail(e));this.child.on('error',e=>this.fail(e));
    this.child.on('exit',(code,signal)=>this.fail(new Error(`Codex App Server skončil (${code??signal})`)));
    this.lines=readline.createInterface({input:this.child.stdout});
    this.lines.on('line',line=>{try{if(line.length>2*1024*1024)throw new Error('App Server line exceeds 2 MiB limit');const m=JSON.parse(line);
      if(m.id!==undefined&&!m.method){const req=this.requests.get(String(m.id));if(req){this.requests.delete(String(m.id));clearTimeout(req.timer);m.error?req.reject(new Error(m.error.message||'RPC error')):req.resolve(m.result);}return;}
      this.onMessage(m);
    }catch(e){this.onError(e);}});
    // Stderr may include paths but is not forwarded to the browser or persisted by the hub.
    this.child.stderr.on('data',buf=>process.stderr.write(buf));
  }
  send(m){if(this.closed||this.child.stdin.destroyed)throw new Error('App Server is disconnected');this.child.stdin.write(JSON.stringify(m)+'\n');}
  request(method,params={}){const id=`mc-${++this.counter}`;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{this.requests.delete(id);reject(new Error(`RPC timeout: ${method}`));},20000);this.requests.set(id,{resolve,reject,timer});try{this.send({id,method,params});}catch(e){clearTimeout(timer);this.requests.delete(id);reject(e);}});}
  notify(method,params={}){this.send({method,params});}
  respond(id,result){this.send({id,result});}
  fail(e){if(this.closed)return;this.closed=true;for(const r of this.requests.values()){clearTimeout(r.timer);r.reject(e);}this.requests.clear();this.onError(e);}
  close(){this.fail(new Error('Client closed'));this.lines.close();this.child.stdin.end();if(!this.child.killed)this.child.kill();}
}
export async function startCodexClient(config,{token,onStatus=()=>{}}={}) {
  if(!config||!path.isAbsolute(config.cwd||''))throw new Error('cwd must be an absolute existing directory');
  if(!(await stat(config.cwd)).isDirectory())throw new Error('cwd is not a directory');
  const command=config.command||['codex'];if(!Array.isArray(command)||!command.length||command.some(x=>typeof x!=='string'||!x))throw new Error('command must be a non-empty array of arguments');
  if(process.platform==='win32'&&/\.(cmd|bat)$/i.test(command[0]))throw new Error('Use the native Codex .exe, or ["node", ".../codex/bin/codex.js"]. Shell wrappers are intentionally disabled.');
  if(!['read-only','workspace-write'].includes(config.sandbox||'read-only'))throw new Error('Only read-only or workspace-write sandboxes are supported');
  token=token||process.env.MC_TOKEN;if(!token&&config.tokenFile)token=(await readFile(config.tokenFile,'utf8')).trim();
  if(!token||token.length<32)throw new Error('Set MC_TOKEN or tokenFile with the hub pairing token (not an OpenAI key).');
  const identity=await identityTools.workspaceIdentity([config.cwd]);
  const session={role:'main',historical:false,current:true,hostId:identity.hostId,canonicalWorkspace:identity.folders[0].canonical,id:'starting',project:config.project||path.basename(config.cwd),workspace:config.cwd,agent:'codex',environment:config.environment||(process.env.WSL_DISTRO_NAME?'WSL':process.platform==='win32'?'Windows':'Linux'),host:config.host||os.hostname(),state:'idle',stateSince:Date.now(),activityAt:Date.now(),activity:'App Server připraven · zadejte úkol v dashboardu',evidence:'api',capabilities:['prompt','approve','input','interrupt'],events:[],messages:[],pending:[],files:[],diff:'',note:'Tato relace patří samostatnému Mission Control klientovi, nikoli stávajícímu VS Code doplňku.'};
  let rpc,producer,stopped=false,health='Inicializace App Serveru';const pending=new Map();
  let closing;const close=()=>{if(closing)return closing;stopped=true;rpc?.close();closing=Promise.resolve(producer?.stop());return closing;};
  const onMessage=m=>{
    const p=m.params||{};
    const tid=p.threadId||p.thread?.id;
    if(session.id!=='starting'&&tid&&tid!==session.id)return;
    if(m.method==='thread/started'&&p.thread?.id&&session.id==='starting')session.id=p.thread.id;
    if(m.id!==undefined&&m.method){
      if(!tid||!['item/commandExecution/requestApproval','item/fileChange/requestApproval','item/tool/requestUserInput','tool/requestUserInput','item/permissions/requestApproval'].includes(m.method)){
        rpc.send({id:m.id,error:{code:-32601,message:'Mission Control does not implement this client request.'}});
        addEvent(session,'warning',`Nepodporovaný serverový požadavek: ${m.method}`);producer?.markDirty();return;
      }
      pending.set(String(m.id),{id:m.id,method:m.method,params:p});
    }
    if(m.method==='serverRequest/resolved')pending.delete(String(p.requestId));
    if(m.method==='turn/completed'||m.method==='turn/started')pending.clear();
    codexNotification(session,m.method,p,m.id);
    if(m.method==='item/permissions/requestApproval')session.note='Tento klient nezpracovává rozšířené žádosti o permissions. Přerušte běh; žádná oprávnění se automaticky neudělí.';
    producer?.markDirty();
  };
  async function onCommand(c){
    if(c.sessionId!==session.id)throw new Error('Session changed; command rejected');
    if(rpc.closed)throw new Error('App Server is disconnected');
    switch(c.action){
      case 'prompt':{
        if(session.state==='working'||pending.size)throw new Error('A turn or approval is already active');
        if(typeof c.text!=='string'||!c.text.trim()||c.text.length>24000)throw new Error('Invalid prompt');
        const msg={id:randomUUID(),at:Date.now(),kind:'user',text:c.text};session.messages.push(msg);session.messages=session.messages.slice(-30);
        const result=await rpc.request('turn/start',{threadId:session.id,input:[{type:'text',text:c.text}]});
        if(result.turn?.id)session.turnId=result.turn.id;producer.markDirty();return 'Codex přijal nové zadání.';
      }
      case 'interrupt':
        if(!session.turnId||c.turnId!==session.turnId)throw new Error('The active turn has changed');
        await rpc.request('turn/interrupt',{threadId:session.id,turnId:session.turnId});return 'Požadavek na přerušení byl přijat.';
      case 'approve':{
        const p=pending.get(String(c.requestId));if(!p)throw new Error('Approval already resolved or expired');
        if(!['item/commandExecution/requestApproval','item/fileChange/requestApproval'].includes(p.method))throw new Error('This approval type is not implemented. No permissions granted.');
        if(!['accept','decline','cancel'].includes(c.decision))throw new Error('Only explicit, single-action decisions are allowed');
        rpc.respond(p.id,{decision:c.decision});pending.delete(String(c.requestId));return 'Rozhodnutí odesláno App Serveru. Sledujte navazující stav.';
      }
      case 'input':{
        const p=pending.get(String(c.requestId));if(!p||!p.method.includes('requestUserInput'))throw new Error('Question is no longer pending');
        const answers={};for(const q of p.params.questions||[]){const a=c.answers?.[q.id]?.answers;if(!Array.isArray(a)||!a.length||a.length>10||a.some(x=>typeof x!=='string'||!x.trim()||x.length>8000))throw new Error('Answer all requested questions');answers[q.id]={answers:a};}
        rpc.respond(p.id,{answers});pending.delete(String(c.requestId));return 'Odpověď odeslána App Serveru.';
      }
      default:throw new Error('Unsupported action');
    }
  }
  try{
    // Reserve BEFORE spawning an App Server or creating a thread. Repeated
    // launches of the same connection cannot create a second agent session.
    const newProducer=(resume=false)=>new Producer({resume,hub:config.hub||'http://127.0.0.1:4317',token,
      sourceId:config.sourceId||`codex-${identityTools.hash([identity.hostId,identity.folders[0].canonical]).slice(0,40)}`,
      label:`${session.host} / ${session.project} / Codex App Server`,getProjects:()=>[session],getSessions:()=>session.id==='starting'?[]:[publicSession(session)],getHealth:()=>health,onCommand,
      onStatus:(ok,message,error)=>{onStatus(ok,message,error);if(error&&producer?.conflict&&!stopped)void close();}});
    producer=newProducer();
    await producer.connect();producer.start(); // Heartbeat the lease during initialization, with no session/actions yet.
    rpc=new RpcClient(command[0],[...command.slice(1),'app-server','--listen','stdio://'],{cwd:config.cwd,onMessage,onError:e=>{health=e.message;onStatus(false,e.message);if(rpc?.closed)producer?.stop();}});
    const init=await rpc.request('initialize',{clientInfo:{name:'local_mission_control',title:'Local Mission Control',version:'0.1.0'},capabilities:{experimentalApi:true}});
    rpc.notify('initialized');
    session.version=init?.userAgent||'';
    const params={cwd:config.cwd,approvalPolicy:'on-request',sandbox:config.sandbox||'read-only'};if(config.model)params.model=config.model;
    await producer.connect(); // Fence again before creating an agent thread.
    const result=await rpc.request('thread/start',params);
    if(!result.thread?.id)throw new Error('App Server did not return a thread id');session.id=result.thread.id;
    health=`Codex App Server · ${params.sandbox} · on-request`;
    await producer.connect(); // Revalidate ownership after potentially slow server startup.
    producer.markDirty();producer.start();
    const reconnect=async()=>{
      if(stopped||rpc.closed)throw new Error('Klient nebo App Server již skončil.');
      if(!producer.stopped)return {connected:true,threadId:session.id};
      const next=newProducer(true);await next.connect();producer=next;next.start();
      return {connected:true,threadId:session.id};
    };
    return {session,rpc,get producer(){return producer;},close,reconnect};
  }catch(e){await close();throw e;}
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const at=process.argv.indexOf('--config');if(at<0||!process.argv[at+1]){console.error('Usage: node src/codex-client.mjs --config codex.local.json');process.exitCode=1;}
  else try{
    const configFile=path.resolve(process.argv[at+1]);const config=JSON.parse(await readFile(configFile,'utf8'));
    if(config.tokenFile&&!path.isAbsolute(config.tokenFile))config.tokenFile=path.resolve(path.dirname(configFile),config.tokenFile);
    const client=await startCodexClient(config,{onStatus:(ok,msg)=>{if(!ok)console.error(msg);}});
    console.log(`Codex thread ${client.session.id}\nProject: ${client.session.project}\nNo model task has been started. Enter your prompt in Mission Control.\nCtrl+C stops this client and its App Server.`);
    // stdin is only a small monitor control, never an agent prompt or shell.
    const controls=createInterface({input:process.stdin,crlfDelay:Infinity});let reconnecting=false;
    controls.on('line',async line=>{
      if(line.trim()!=='connect'||reconnecting)return;reconnecting=true;
      try{await client.reconnect();console.log('Monitoring znovu připojen ke stejné Codex relaci '+client.session.id);}
      catch(e){console.error(e.message);}finally{reconnecting=false;}
    });
    console.log('Odpojení v dashboardu nezastavuje App Server. Pro návrat monitoringu napište connect a Enter v tomto terminálu.');
    const close=()=>{controls.close();void client.close().finally(()=>process.exit(0));};process.on('SIGINT',close);process.on('SIGTERM',close);
  }catch(e){console.error(`Codex client: ${e.message}`);process.exitCode=1;}
}
