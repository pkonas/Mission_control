import http from 'node:http';
import {readFile,writeFile,mkdir,rename,stat} from 'node:fs/promises';
import {randomBytes,timingSafeEqual,randomUUID} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Store} from './store.mjs';
import {NotificationCenter} from './notifications.mjs';
import {DesktopAccess} from './desktop-access.mjs';
import {createDemo,stepDemo} from '../public/demo.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
async function body(req,max=3*1024*1024) {
  let n=0;const parts=[];
  for await(const chunk of req){n+=chunk.length;if(n>max){const e=new Error('Request too large');e.status=413;throw e;}parts.push(chunk);}
  if(!parts.length)return {};
  try{return JSON.parse(Buffer.concat(parts).toString('utf8'));}catch{throw new Error('Invalid JSON');}
}
export async function createHub({port=4317,dataDir=path.join(ROOT,'.data'),demo=false,token:providedToken,host='127.0.0.1',persist=true,desktopSecret='',instanceId=''}={}) {
  if(!['127.0.0.1','::1'].includes(host))throw new Error('Hub must bind to loopback. Use SSH tunnels for remote machines.');
  if(!Number.isInteger(port)||port<0||port>65535)throw new Error('Invalid port');
  if(persist)await mkdir(dataDir,{recursive:true,mode:0o700});
  const tokenPath=path.join(dataDir,'token');let token=providedToken;
  if(!token&&persist){try{token=(await readFile(tokenPath,'utf8')).trim();}catch{}}
  if(!token){token=randomBytes(32).toString('hex');if(persist)await writeFile(tokenPath,token+'\n',{mode:0o600});}
  if(token.length<32)throw new Error('Pairing token must be at least 32 characters');
  const store=new Store();const stateFile=path.join(dataDir,'state.json');let restoredMigration=false;let savedNotifications;
  if(persist&&!demo){
    let previous;
    try{previous=await readFile(stateFile,'utf8');}catch(e){if(e.code!=='ENOENT')throw e;}
    if(previous){
      const saved=JSON.parse(previous);
      if(saved.projectModelVersion!==1&&Array.isArray(saved.sessions)&&saved.sessions.length){
        // Do not migrate/save on top of the only copy of the user's old state.
        try{await writeFile(path.join(dataDir,'state.before-0.4.0.json'),previous,{mode:0o600,flag:'wx'});}catch(e){if(e.code!=='EEXIST')throw e;}
      }
      savedNotifications=saved.notifications;store.restore(saved);restoredMigration=saved.projectModelVersion!==1||saved.identityVersion!==2||store.sessions.size!==(saved.sessions||[]).length;
    }
  }
  const desktop=desktopSecret?new DesktopAccess(desktopSecret,instanceId):null;
  const notifications=new NotificationCenter(savedNotifications);
  const hubId=randomUUID();const clients=new Set();const cookies=new Map();const commands=new Map();
  let broadcaster,tick,persisting=false,saveFlight,dirty=restoredMigration,closed=false;let boundPort=port;
  let demoSessions=demo?createDemo():[];let demoSeq=0;const demoEpoch=randomUUID();
  function demoIngest(){store.ingest({version:1,sourceId:'demo',epoch:demoEpoch,seq:++demoSeq,label:'Demo · pouze ukázková data',sessions:demoSessions.filter(s=>s.state!=='disconnected').map(s=>({...s,evidence:'demo'}))});}
  if(demo){demoIngest();for(const s of demoSessions.filter(s=>s.state==='disconnected')){const d={...s,state:'working',evidence:'demo'};store.ingest({version:1,sourceId:'demo-offline',epoch:randomUUID(),seq:1,label:'Demo · odpojený stroj',sessions:[d]});store.sources.get('demo-offline').lastSeen=0;}}
  const json=(res,code,obj)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(obj));};
  const allowedHosts=()=>new Set([`127.0.0.1:${boundPort}`,`localhost:${boundPort}`,`[::1]:${boundPort}`]);
  const validOrigin=(req)=>!req.headers.origin||[...allowedHosts()].some(h=>req.headers.origin===`http://${h}`);
  const hasBearer=req=>equal(req.headers.authorization,`Bearer ${token}`);
  const hasCookie=req=>{const c=req.headers.cookie?.match(/(?:^|;\s*)mc_session=([a-f0-9]{64})(?:;|$)/)?.[1];return c&&cookies.has(c)&&cookies.get(c)>Date.now();};
  function snap(){return {...store.snapshot(),hubId,demo,desktop:!!desktop,notificationIds:notifications.list().map(n=>n.id)};}
  function loginCookie(res){
    if(cookies.size>100)cookies.clear();const session=randomBytes(32).toString('hex');cookies.set(session,Date.now()+86400000);
    res.setHeader('Set-Cookie',`mc_session=${session}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400`);
  }
  const sendSnapshot=()=>{const text=`event: snapshot\ndata: ${JSON.stringify(snap())}\n\n`;for(const res of clients){if(res.writableLength>4*1024*1024){res.destroy();clients.delete(res);}else res.write(text);}};
  function change(){notifications.capture(store.snapshot());dirty=true;if(!broadcaster)broadcaster=setTimeout(()=>{broadcaster=undefined;sendSnapshot();},200);}
  store.on('change',change);
  function save(){
    if(!persist||demo)return Promise.resolve();
    if(saveFlight)return saveFlight;
    if(!dirty)return Promise.resolve();
    persisting=true;
    saveFlight=(async()=>{
      // Serialize writes, including any state change that arrived during an
      // earlier write. Explicit disconnect never acknowledges an unsaved intent.
      while(dirty){
        dirty=false;
        try{await writeFile(stateFile+'.tmp',JSON.stringify({...store.serialize(),notifications:notifications.serialize()}),{mode:0o600});await rename(stateFile+'.tmp',stateFile);}
        catch(e){dirty=true;throw new Error('Stav hubu se nepodařilo uložit. Případné odpojení je účinné jen v paměti; po restartu je může být potřeba zopakovat: '+e.message);}
      }
    })().finally(()=>{persisting=false;saveFlight=undefined;});
    return saveFlight;
  }
  function cancelSourceCommands(sourceId){
    for(const c of commands.values())if(c.sourceId===sourceId&&['queued','delivered'].includes(c.status)){
      if(c.status==='queued'){c.status='failed';c.message='Připojení bylo odebráno před předáním příkazu. Nic se automaticky neopakuje.';}
      else {c.status='unknown';c.message='Příkaz již byl předán před odpojením. Jeho výsledek ověřte u agenta; odpojení jej nemůže vzít zpět.';}
    }
  }
  const server=http.createServer(async(req,res)=>{
    let recoveryRequestId=null;
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; font-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    try{
      // Authenticated native producers can arrive through a different loopback tunnel port.
      const producerTunnel=hasBearer(req)&&!req.headers.origin&&/^(?:127\.0\.0\.1|localhost|\[::1\]):[0-9]{1,5}$/.test(req.headers.host||'');
      if(!allowedHosts().has(req.headers.host)&&!producerTunnel){json(res,403,{error:'Invalid Host header'});return;}
      if(!validOrigin(req)){json(res,403,{error:'Cross-origin requests are not allowed'});return;}
      const url=new URL(req.url,`http://${req.headers.host}`);
      if(req.method==='GET' && url.pathname==='/healthz'){json(res,200,{ok:true,version:'0.4.2',demo,instanceId});return;}
      if(req.method==='POST' && url.pathname==='/api/login'){
        const b=await body(req,4096);if(!equal(b.token,token)){json(res,401,{error:'Nesprávný párovací token'});return;}
        loginCookie(res);json(res,200,{ok:true});return;
      }
      if(url.pathname.startsWith('/api/desktop/')){
        if(!desktop){json(res,404,{error:'Desktop mode is not enabled'});return;}
        if(req.method==='POST'&&url.pathname==='/api/desktop/login'){
          const b=await body(req,4096);
          if(!desktop.consume(b.ticket)){json(res,401,{error:'Odkaz vypršel nebo již byl použit. Otevřete dashboard z ikony u hodin.'});return;}
          loginCookie(res);json(res,200,{ok:true});return;
        }
        // Separate per-launch secret: producer tokens and browser cookies cannot control the supervisor.
        if(req.headers.origin||!desktop.authorized(req.headers.authorization)){json(res,401,{error:'Desktop credentials required'});return;}
        if(req.method==='POST'&&url.pathname==='/api/desktop/ticket'){
          res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'});res.end(desktop.issue());return;
        }
        if(req.method==='GET'&&url.pathname==='/api/desktop/status'){
          res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'});res.end(desktop.status(store.snapshot()));return;
        }
        if(req.method==='GET'&&url.pathname==='/api/desktop/next-notification'){
          res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'});res.end(notifications.desktop(desktop.instanceId,store.snapshot()));return;
        }
        if(req.method==='POST'&&url.pathname==='/api/desktop/notification-delivered'){notifications.delivered(url.searchParams.get('id'));json(res,200,{ok:true});return;}
        if(req.method==='POST'&&url.pathname==='/api/desktop/shutdown'){
          json(res,200,{ok:true});setTimeout(()=>{void close();},25);return;
        }
        json(res,404,{error:'Unknown desktop endpoint'});return;
      }
      if(url.pathname.startsWith('/api/')){
        const producerPaths=['/api/ingest','/api/commands','/api/result','/api/claim','/api/release','/api/disconnect-source','/api/connection-status','/api/reconnect'];
        if(producerPaths.includes(url.pathname)){
          if(demo){json(res,403,{error:'Demo hub does not accept real producers'});return;}
          if(!hasBearer(req)){json(res,401,{error:'Producer token required'});return;}
        }else if(!hasCookie(req)&&!(demo&&req.method==='GET')&&!(demo&&url.pathname==='/api/demo-step')){json(res,401,{error:'Otevřete dashboard z ikony Mission Control u hodin, nebo použijte párovací token.'});return;}
        if(req.method==='GET' && url.pathname==='/api/state'){json(res,200,snap());return;}
        if(req.method==='GET' && url.pathname==='/api/events'){
          res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-store','Connection':'keep-alive','X-Accel-Buffering':'no'});
          clients.add(res);res.write(`event: snapshot\ndata: ${JSON.stringify(snap())}\n\n`);req.on('close',()=>clients.delete(res));return;
        }
        if(req.method==='GET' && url.pathname==='/api/connection-status'){
          json(res,200,{...store.connectionStatus({version:1,sourceId:url.searchParams.get('sourceId'),epoch:url.searchParams.get('epoch')}),hubVersion:'0.4.2',recoveryProtocol:1});return;
        }
        if(req.method==='POST' && url.pathname==='/api/reconnect'){
          const b=await body(req,256000);
          if(b.recoveryProtocol!==1||b.userInitiated!==true||typeof b.requestId!=='string'||!/^[a-zA-Z0-9-]{8,80}$/.test(b.requestId))
            throw Object.assign(new Error('Obnova vyžaduje explicitní příkaz a identifikátor požadavku.'),{status:400,code:'INVALID_RECOVERY_REQUEST'});
          recoveryRequestId=b.requestId;
          // Reuse the same ownership/fencing rules. No broad reset of tokens,
          // history, other sources, or retired epochs; no takeover of a live owner.
          const result=store.claim({...b,resume:true});
          try{await save();}catch(e){
            // A failed disk write must not leave an unacknowledged live lease.
            store.release(b);throw Object.assign(e,{code:'RECOVERY_SAVE_FAILED'});
          }
          // A concurrent dashboard disconnect must win, never a false success.
          store.authorizeSource(b.sourceId,b.epoch);
          json(res,200,{...result,recoveryProtocol:1,requestId:b.requestId,hubVersion:'0.4.2'});return;
        }
        if(req.method==='POST' && url.pathname==='/api/claim'){
          const b=await body(req,256000);const result=store.claim(b);
          // Reconnecting is a durable change of user intent, just like removal.
          // Do not acknowledge it while the old tombstone is still on disk.
          if(b.resume===true)await save();
          json(res,200,result);return;
        }
        if(req.method==='POST' && url.pathname==='/api/release'){json(res,200,store.release(await body(req,256000)));return;}
        if(req.method==='POST' && url.pathname==='/api/disconnect-source'){
          const b=await body(req,256000);store.validateSource(b);
          const result=store.disconnectSource(b.sourceId,{epoch:b.epoch,producer:true});
          cancelSourceCommands(b.sourceId);await save();json(res,200,result);return;
        }
        if(req.method==='POST' && url.pathname==='/api/disconnect'){
          if(demo){json(res,403,{error:'Použijte samostatné offline demo pro simulaci odpojení.'});return;}
          const b=await body(req,256000);
          const result=store.disconnectSource(b.sourceId,{epoch:b.epoch??null});
          cancelSourceCommands(b.sourceId);await save();json(res,200,result);return;
        }
        if(req.method==='POST' && url.pathname==='/api/disconnect-project'){
          const b=await body(req,32000);
          const result=store.projects.disconnect(b.key,b.owners);
          for(const c of commands.values())if(!store.sessions.has(c.key)&&['queued','delivered'].includes(c.status)){c.status='failed';c.message='Monitorování projektu bylo odpojeno.';}
          await save();json(res,200,result);return;
        }
        if(req.method==='POST' && url.pathname==='/api/annotate-project'){
          const b=await body(req,4096);store.annotateProject(b.key,b);await save();json(res,200,{ok:true});return;
        }
        if(req.method==='POST' && url.pathname==='/api/ingest'){json(res,200,store.ingest(await body(req)));return;}
        if(req.method==='POST' && url.pathname==='/api/annotate'){
          const b=await body(req,4096);store.annotate(b.key,b);json(res,200,{ok:true});return;
        }
        if(req.method==='POST' && url.pathname==='/api/forget'){
          const b=await body(req,4096);store.forget(b.key);json(res,200,{ok:true});return;
        }
        if(req.method==='POST' && url.pathname==='/api/demo-step' && demo){stepDemo(demoSessions);demoIngest();json(res,200,{ok:true});return;}
        if(req.method==='GET'&&url.pathname==='/api/notifications'){json(res,200,{items:notifications.list()});return;}
        if(req.method==='GET'&&url.pathname==='/api/notification'){const n=notifications.get(url.searchParams.get('id'));json(res,n?200:404,n||{error:'Událost již není v uložené historii. Nebyla nahrazena jiným požadavkem.'});return;}
        if(req.method==='POST' && url.pathname==='/api/action'){
          if(demo){json(res,403,{error:'Ukázka neovládá žádné agenty.'});return;}
          const b=await body(req,40000);const s=store.snapshot().sessions.find(x=>x.key===b.key);
          if(!s||!s.connected){json(res,409,{error:'Relace nebo bridge již nejsou připojené'});return;}
          if(b.action==='open') {if(!s.focusUri){json(res,409,{error:'Tato relace nemá zpětný odkaz do VS Code. Otevřete uvedenou cestu.'});return;}json(res,200,{uri:s.focusUri});return;}
          if(!['prompt','approve','input','interrupt','zooDecision','codexDecision'].includes(b.action)||!s.capabilities.includes(b.action)||s.evidence!=='api'){json(res,403,{error:'Tato akce není pro relaci dostupná'});return;}
          if(b.stateRevision!==s.stateRevision){json(res,409,{error:'Stav relace se změnil. Zkontrolujte aktuální požadavek.'});return;}
          if(['approve','input','zooDecision','codexDecision'].includes(b.action)){
            const p=s.pending.find(x=>String(x.id)===String(b.requestId));
            if(!p){json(res,409,{error:'Požadavek již není aktuální'});return;}
            if(b.action==='zooDecision'&&(s.agent!=='zoo'||s.state!=='needs_approval'||p.method!=='zoo/ask/decision'||!['run','deny'].includes(b.decision))){json(res,400,{error:'Neplatné rozhodnutí pro Zoo Code.'});return;}
            if(b.action==='codexDecision'&&(s.agent!=='codex'||s.state!=='needs_approval'||p.method!=='codex/hook/permission'||!['run','deny','delegate'].includes(b.decision)||!Number.isFinite(p.expiresAt)||p.expiresAt<=Date.now())){json(res,409,{error:'Živý dotaz Codexu vypršel nebo není ovladatelný.'});return;}
            if(b.action==='approve'&&(!['accept','decline','cancel'].includes(b.decision)||!['item/commandExecution/requestApproval','item/fileChange/requestApproval'].includes(p.method))){json(res,400,{error:'Nepodporovaný typ schválení'});return;}
            if(b.action==='input'&&!p.method.includes('requestUserInput')){json(res,400,{error:'Není to požadavek na textový vstup'});return;}
          }
          if(b.action==='prompt'&&(s.state==='working'||s.pending.length)){json(res,409,{error:'Nejdříve dokončete probíhající běh nebo jeho požadavek'});return;}
          if(b.action==='prompt'&&(typeof b.text!=='string'||!b.text.trim()||b.text.length>24000))throw new Error('Invalid prompt');
          // At-most-once dispatch. No automatic retries of side-effecting commands.
          if([...commands.values()].some(c=>c.key===s.key&&['queued','delivered'].includes(c.status)&&c.deadline>Date.now())){json(res,409,{error:'Předchozí příkaz ještě čeká na potvrzení'});return;}
          if(commands.size>200){for(const [id,c] of commands)if(c.deadline<Date.now())commands.delete(id);if(commands.size>200)throw new Error('Command queue is full');}
          const id=randomUUID();const command={id,key:s.key,sourceId:s.sourceId,sourceEpoch:s.sourceEpoch,sessionId:s.id,action:b.action,text:b.text,requestId:b.requestId,decision:b.decision,answers:b.answers,turnId:b.action==='codexDecision'?s.pending.find(p=>p.id===b.requestId)?.turnId:s.turnId,stateRevision:s.stateRevision,status:'queued',deadline:Date.now()+20000};
          commands.set(id,command);json(res,202,{id});return;
        }
        if(req.method==='GET' && url.pathname==='/api/commands'){
          const source=url.searchParams.get('sourceId');const owner=store.authorizeSource(source,url.searchParams.get('epoch'));const list=[];
          for(const c of commands.values())if(c.sourceId===source&&c.status==='queued'&&c.deadline>Date.now()){
            if(c.sourceEpoch!==owner.epoch||store.sessions.get(c.key)?.sourceId!==source||store.sessions.get(c.key)?.sourceEpoch!==owner.epoch){c.status='failed';c.message='Původní připojení skončilo; příkaz nebyl předán novému.';continue;}
            if(['zooDecision','codexDecision'].includes(c.action)){const current=store.sessions.get(c.key);if(current.stateRevision!==c.stateRevision||!current.pending.some(p=>p.id===c.requestId&&(c.action!=='codexDecision'||p.expiresAt>Date.now()))){c.status='failed';c.message='Dotaz agenta se změnil před předáním rozhodnutí. Nic nebylo odesláno.';continue;}}
            c.status='delivered';list.push(c);
          }
          json(res,200,{commands:list});return;
        }
        if(req.method==='POST' && url.pathname==='/api/result'){
          const b=await body(req,256000);const c=commands.get(b.id);
          if(!c||c.sourceId!==b.sourceId){json(res,404,{error:'Unknown command'});return;}
          const owner=store.authorizeSource(b.sourceId,b.epoch);
          if(c.sourceEpoch!==owner.epoch||c.status!=='delivered'){json(res,409,{error:'Příkaz nepatří tomuto aktivnímu připojení',code:'NOT_OWNER'});return;}
          c.status=b.ok===true?'completed':'failed';c.message=String(b.message||'').slice(0,6000);json(res,200,{ok:true});return;
        }
        if(req.method==='GET' && url.pathname.startsWith('/api/action/')){
          const c=commands.get(url.pathname.slice('/api/action/'.length));
          if(!c){json(res,404,{error:'Unknown command'});return;}
          json(res,200,{id:c.id,status:c.deadline<Date.now()&&['queued','delivered'].includes(c.status)?'unknown':c.status,message:c.message||''});return;
        }
        json(res,404,{error:'Unknown API endpoint'});return;
      }
      if(req.method!=='GET'&&req.method!=='HEAD'){json(res,405,{error:'Method not allowed'});return;}
      const files={'/':'index.html','/index.html':'index.html','/app.mjs':'app.mjs','/style.css':'style.css','/demo.mjs':'demo.mjs','/project-model.mjs':'project-model.mjs','/icon.svg':'icon.svg'};
      const name=files[url.pathname];if(!name){json(res,404,{error:'Not found'});return;}
      const data=await readFile(path.join(ROOT,'public',name));
      res.writeHead(200,{'Content-Type':name.endsWith('.mjs')?'text/javascript; charset=utf-8':name.endsWith('.css')?'text/css; charset=utf-8':name.endsWith('.svg')?'image/svg+xml':'text/html; charset=utf-8','Cache-Control':'no-cache'});res.end(req.method==='HEAD'?undefined:data);
    }catch(e){if(!res.headersSent)json(res,e.status||400,{error:e.message,...(recoveryRequestId?{requestId:recoveryRequestId,hubVersion:'0.4.2'}:{}),...(e.code?{code:e.code}:{}),...(e.reason?{reason:e.reason}:{}),...(e.ownerLabel?{ownerLabel:e.ownerLabel}:{}),...(e.existingKey?{existingKey:e.existingKey}:{}),...(Number.isFinite(e.retryAfterMs)?{retryAfterMs:e.retryAfterMs}:{})});else res.end();}
  });
  server.requestTimeout=15000;server.headersTimeout=10000;
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,resolve);});boundPort=server.address().port;
  tick=setInterval(()=>{if(demo)demoIngest();for(const [c,exp] of cookies)if(exp<Date.now())cookies.delete(c);sendSnapshot();void save().catch(e=>console.error(e.message));},5000);tick.unref();
  async function close(){if(closed)return;closed=true;clearInterval(tick);clearTimeout(broadcaster);store.off('change',change);for(const c of clients)c.end();while(persisting)await new Promise(r=>setTimeout(r,10));await save();server.closeAllConnections();await new Promise(r=>server.close(r));}
  return {server,store,token,port:boundPort,url:`http://127.0.0.1:${boundPort}`,close};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const demo=process.argv.includes('--demo');const port=Number(process.env.MC_PORT||4317);
  const hub=await createHub({port,demo,dataDir:process.env.MC_DATA_DIR||path.join(ROOT,'.data'),desktopSecret:process.env.MC_DESKTOP_SECRET||'',instanceId:process.env.MC_INSTANCE_ID||''});
  if(process.env.MC_DESKTOP_SECRET)await writeFile(path.join(process.env.MC_DATA_DIR||path.join(ROOT,'.data'),'connection.json'),JSON.stringify({version:1,instanceId:process.env.MC_INSTANCE_ID,hub:hub.url,node:process.execPath,relay:path.join(ROOT,'windows','wsl-relay.cjs')})+'\n',{mode:0o600});
  if(process.env.MC_DESKTOP_SECRET)console.log(`Mission Control 0.4.2: desktop hub on ${hub.url} (PID ${process.pid})`);
  else console.log(`Mission Control 0.4.2: ${hub.url}\nPárovací token: ${hub.token}\nUkončení: Ctrl+C`);
  const shutdown=async()=>{await hub.close();process.exit(0);};process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown);
}
