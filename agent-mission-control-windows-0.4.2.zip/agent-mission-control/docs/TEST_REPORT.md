> Archiv výsledků původní verze 0.1.0. Pro Windows sestavení 0.2.0 viz WINDOWS_TEST_REPORT.md.

# Ověření verze 0.1.0

Datum: 1. října 2026. Testovací prostředí: izolovaný Linux, Node.js 22.16.0, Python Playwright a systémový Chromium. Nebyl použit uživatelský účet Codexu ani skutečný workspace ve VS Code. Testy neprováděly skutečnou migraci databáze či jiné příkazy generované modelem.

## Výsledky

| Sada | Výsledek | Co skutečně ověřuje |
|---|---:|---|
| Node.js unit + integration | 38 / 38 prošlo | Normalizace, úložiště, lokální HTTP hub, bezpečnostní kontroly a vlastní Codex klient proti simulátoru |
| Prohlížečový smoke test | 13 / 13 prošlo | Samostatné HTML demo v Chromium, interakce, bezpečné vykreslení textu, desktop a mobil |
| VSIX archiv | Kontrola ZIP / XML / entrypoint prošla | Konzistence balíčku a přítomnost zdrojů, nikoliv skutečná instalace |

Příkazy:

```sh
node --test tests/*.test.mjs
node scripts/build-preview.mjs
python tests/browser_smoke.py
python scripts/package-vsix.py
```

Surové výstupy posledního běhu jsou v `tests-node.tap` a `tests-browser.json` vedle tohoto dokumentu.

## Co pokrývá 38 Node testů

Normalizace rozlišuje automaticky zpracovanou Zoo ask zprávu od skutečného zastavení na člověka, zachovává pořadí událostí, slučuje textové delty, neoznačí jednotlivý neúspěšný nástroj jako definitivní chybu celé úlohy a neodesílá raw reasoning. Codex testy zachovávají přesné request ID, ignorují otazníky jako důkaz čekání, oddělují retry od definitivní chyby a nepovažují obecný idle za dokončený úkol.

Úložiště má testy oddělené identity relací, deduplikace pořadí, vyřazené epochy, heartbeat odpojení, vlastní expirace relace i při živém zdroji, stárnutí pozorovaných záznamů, nečinnosti pracujícího agenta, uživatelských anotací, obnovení vždy jako offline, odebírání ovládacích oprávnění observeru, atomického odmítnutí neplatné dávky a limitů růstu.

HTTP testy pokrývají prázdný živý start, token/cookie přihlášení, Host/Origin kontrolu, odlišný loopback Host port pro autentizovaný reverse-tunnel producent, omezení akcí a staré revize, at-most-once vyzvedávání a ACK, SSE a oddělení dema od skutečného ingestu.

Integrační testy ověřují URL omezení, hranice cwd workspace, reálné tailování dočasného JSONL souboru včetně rozdělených UTF-8 bajtů a JSON-RPC round-trip. Poslední test spouští skutečný přiložený klient a hub, ale **místo Codexu používá `tests/fixtures/mock-codex.mjs`**. Projde initialize → thread → turn → explicitní approval request → odeslané rozhodnutí → diff a completion. Neprokazuje kompatibilitu s každou verzí skutečného App Serveru.

## Co pokrývá 13 kontrol prohlížeče

Osm viditelně označených ukázkových relací, filtr pozornosti, hledání projektu, filtr nástroje, filtr prostředí, záložky zpráv a diffu, „Viděno“ bez schválení, odložení, simulovaný přechod do fronty pozornosti, průvodce připojením, HTML escaping, šířky 1600/390 px bez horizontálního přetečení a absence nezachycených JS chyb.

Test načítá obsah samostatného HTML přes Playwright `set_content`. Síťová navigace prohlížeče byla v prostředí blokovaná politikou, takže **nejde o end-to-end browser test přihlášení/cookies/SSE přes reálnou navigaci**. Backendové HTTP cesty jsou samostatně testované přes skutečné localhost požadavky v Node testech. Systémová oznámení nebyla prakticky ověřena.

## Dosud neověřené integrační hranice

Instalace a aktivace VSIX ve skutečném VS Code; API právě uživatelem nainstalované verze Zoo Code; přihlášení k Codex účtu a konkrétní verze CLI; současné uložené formáty relací Codex extension; Windows notifikace a focus existujícího okna; lokální/remote URI routing; firewall a WSL localhost forwarding; SSH server dovolující reverse forwarding. VSIX je vlastní nepodepsaný lokální balíček, ne publikovaný ověřený Marketplace produkt.

Proto začněte na jednom neprodukčním projektu a s App Server sandboxem `read-only`. Zkontrolujte diagnostiku bridge, skutečný přechod do čekání, následnou odpověď v původním Zoo panelu, přechod zpět do práce a odpojení. Následně přidejte WSL a jeden Remote SSH host. Nedostupný stav nesmí být interpretován jako souhlas k pokračování.
