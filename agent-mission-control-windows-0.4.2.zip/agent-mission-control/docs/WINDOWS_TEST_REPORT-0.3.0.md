# Mission Control 0.3.0 — protokol ověření

## Skutečně provedeno

**75 automatických testů Node.js úspěšně dokončeno** příkazem `node --test tests/*.test.mjs` v Linuxu / Node.js 22.16.0. Jde o 54 existujících testů, 20 nových testů CLI a 1 integrační test skutečného desktop hubu. Surový výstup: `maintenance-node-tests.tap`.

Nové testy spouštějí skutečné procesy Node s explicitně simulovaným VS Code CLI. Testy ověřují: stderr s dodaným DEP0169 a exit 0; skutečný exit 7; falešný úspěch bez záznamu bridge; nesprávnou verzi; selhání následného výpisu; opakovanou opravu; přechod testovacího stavu 0.2.0 → 0.3.0; odstranění přesného ID a kontrolu jeho nepřítomnosti; opakované odstranění; neúspěšné odebrání; názvy s mezerami, českými znaky a shell metaznaky; profily; oddělení prostředí; BOM/CRLF; současný velký stdout/stderr; timeout; chybějící proces; omezení výstupu; JSON rozhraní pomocníka; odmítnutí neznámé akce.

Integrační test spustí skutečný `src/server.mjs`, ověří soulad instanceId descriptoru a /healthz, verzi 0.3.0 a zachování existujícího párovacího tokenu. To nejsou testy Windows instalace.

**Cross-kompilace Windows x64:** tray a bootstrap sestaveny pomocí clang a lld-link; `-Wall -Wextra -Werror`; PE32+ GUI, asInvoker, ASLR/NX. Neproběhlo jejich vykonání.

**Statická kontrola balíčku:** kontroluje x64 PE formát, manifest asInvoker, nepřítomnost Authenticode podpisu, bezpečné cesty vloženého ZIP, CRC, shodu všech vložených souborů se zdroji, přítomnost údržby, BOM všech PowerShell souborů a připnutý digest Node archivu. Skript `scripts/validate-windows-package.py` není runtime test.

## Neprovedeno — důležité omezení

Toto prostředí neposkytuje Windows ani PowerShell runtime. **Neproběhl běh průvodce, jeho parsování v PowerShell 5.1, práce s HKCU, registrace Windows Apps, zápis zástupců, instalace opravdového VSIX, tray notifikace, skutečný rollback souborů Windows, oprava/odinstalace na Windows, WSL interop ani RDP/SSH.** Automatické Node.js testy toto nenahrazují. Úprava .NET Process vrstvy byla posouzena ve zdroji, nikoli spuštěna ve Windows.

`windows/Test-InstallerLogic.ps1` je připravený nedestruktivní test pro Windows: AST parser všech PS1, rozhodování Install/Update/Repair/Uninstall, quoting a skutečné oddělené stdout/stderr. **Zde nebyl spuštěn a nepočítá se do 75 testů.** Ani jeho úspěch by sám nepotvrdil celý instalační životní cyklus.

Předchozí browserové testy verze 0.2.0 zůstávají historickým záznamem; pro tento instalační update nejsou uváděny jako nové testy.

Node.js runtime 24.21.0 a jeho oba SHA-256 jsou převzaty z předchozího balíčku, ve kterém uživateli ověření prošlo. Při aktualizaci se stále kontrolují. Windows runtime nebyl v této relaci znovu stažen ani spuštěn. Kontrolní součty distribuovaných souborů nejsou certifikát vydavatele.

## Doporučené akceptační scénáře v testovacím Windows účtu / Windows Sandbox

1. Instalace 0.3.0 na čistém účtu, restart přihlášení a otevření dashboardu z ikony.
2. Instalace 0.2.0, vytvoření testovacích dat, zaznamenání SHA-256 tokenu, portu a autostartu. Aktualizace novým EXE, ověření zachování hodnot a bridge 0.3.0.
3. Oprava 0.3.0 po odstranění jednoho aplikačního souboru; oprava z nabídky Start bez původního EXE. Test pouze v izolovaném účtu, ne za běhu produkčních úloh.
4. Stejný stderr DEP0169 v opravdovém VS Code: výsledek úspěšný jen při správném exit code a ověřené verzi.
5. Obsazený port nebo selhání startu: zachování původního instalačního stromu a metadata po obnovení. Samostatně zamčené soubory a jiné Windows/RDP relace.
6. Odinstalování s výchozími volbami: odstraněny app/autostart/registrace/cache; zachován token a historie. Opětovná instalace používá zachovaná data.
7. Odinstalování s explicitním odstraněním dat a bridge: žádný zásah do Codexu, Zoo Code, projektů ani vzdálených hostů.
8. Vlastní cesta Code.exe, Insiders, existující pojmenovaný profil a česká cesta s mezerami. Jiný profil či WSL se nemá změnit.

## Známé hranice návrhu

Nejde o MSI ani systémovou službu. Údržba pracuje pod aktuálním uživatelem. Cache nevyhledává nová internetová vydání. Rollback pokrývá zachycené chyby před potvrzením nové instance hubu, ne výpadek napájení. Zamčené soubory a zásady zabezpečení mohou opravu/odinstalování zablokovat; nejsou obcházeny. Změny bridge se nevracejí s transakcí souborů aplikace. Odstranění bridge pokrývá pouze zvolenou lokální instalaci/profil.

EXE i VSIX jsou nepodepsané lokální balíčky. Neexistuje zde SmartScreen reputace ani Windows certifikace tohoto vydání.
