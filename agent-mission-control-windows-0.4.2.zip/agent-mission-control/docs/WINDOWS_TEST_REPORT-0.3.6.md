# Mission Control 0.3.6 — protokol ověření

Datum sestavení: 2. října 2026. Prostředí ověření: Linux, Node.js 22.16.0, Chromium a nativní C kompilátor.

## Provedené testy

**192 / 192 automatických testů Node.js prošlo.** Oproti předchozí sadě přibylo 44 testů. Jeden dřívější test okamžitého nahrazení živé epochy byl změněn: nahrazení nyní smí nastat až po explicitním uvolnění nebo vypršení vlastnictví. Starou aktivní relaci již nelze přetlačit.

Nové scénáře zahrnují skutečný HTTP server, ne jen simulaci transportu:

- 20 současných požadavků různých vlastníků stejného bridge: jeden přijatý, 19 konfliktů 409.
- 15 souběžných pokusů reportovat stejnou úlohu s různými sourceId: jediný záznam, 14 konfliktů.
- opakovaný claim téhož vlastníka; atomické odmítnutí duplicitní dávky; samostatná identita Codexu, Zoo Code, odlišných úloh, hostů a worktrees;
- stabilní identita při souběžném vytvoření ID hostu, reloadu, změně pořadí kořenů a při přístupu přes symbolický odkaz (reálný Linux filesystem);
- uvolnění a opětovné připojení bez druhého řádku; vypršení časového limitu; odmítnutí starých epoch a opožděných heartbeatů;
- autentizace claim/release, odmítnutí převzetí fronty schválení a nedoručení starých příkazů nové instanci;
- zachování originálních bajtů zálohy state.json, migrace přesných duplicit, zachování dostupné historie a nenahlášení uložených relací jako připojených;
- idempotentní start skutečné třídy Producer, zastavení uprostřed claim, přenos strukturovaných konfliktů přes skutečný stdio relay běžící na Linuxu;
- odmítnutí duplicitního spravovaného klienta Codexu ještě před pokusem spustit jeho podproces;
- skutečný JavaScript bridge a Connection s dosazeným VS Code API: souběh přímých příkazů, připojená relace, opakované připojování, zrušený dialog, konflikt, deaktivace nebo odpojení během inicializace.

**31 / 31 nativních scénářů** řadiče zastavení prošlo s **náhradami Windows API**. Tyto testy vykonávají produkční C logiku na Linuxu, nikoli Windows procesy.

**13 / 13 kontrol demo rozhraní v Chromium** prošlo: filtry, detail, zprávy, diff, odložení, bezpečné zobrazení textu, rozložení a absence neodchycených JavaScript chyb.

## Testy, které nebyly úspěšně provedeny

Připravený nový test živého dashboardu (tests/duplicates_browser.py) se pokusil načíst místní hub. Chromium v tomto prostředí navigaci odmítlo chybou **ERR_BLOCKED_BY_ADMINISTRATOR**. Žádná politika prohlížeče nebyla vypnutá ani obejita. Šest plánovaných kontrol živého DOM/SSE se proto **nezapočítává mezi úspěšné testy**. HTTP integrační testy uvedené výše tento problém neměly.

Skutečný Windows instalátor, PowerShell 5.1 průvodce, tray, VS Code Extension Host, rozšíření Zoo Code, reálné přihlášení Codexu ani spojení Windows/WSL/SSH nebyly spuštěny. WSL relay test běží jako podproces Node.js na Linuxu, nikoli přes Windows interop. Codex end-to-end protokol používá testovací App Server a žádný model.

## Sestavení a statická kontrola distribuce

Instalátor se sestavuje z těchto zdrojů pomocí clang/lld-link pro Windows x64. Samostatná kontrola scripts/validate-windows-package.py ověřuje PE strukturu, nepodepsaný stav, embedded ZIP, shodu přiložených zdrojů, VSIX a vnořeného bridge. Konkrétní výstup je přiložen samostatně v JSON. To není náhrada spuštění ve Windows.

EXE ani VSIX nejsou digitálně podepsané. Ochranu Windows nevypínejte. Aktualizujte hub a oba doplňky; otevřená okna VS Code nechte znovu načíst až po doběhnutí práce agentů.

## Reprodukce

```sh
npm test
sh tests/native/run-tests.sh
python tests/browser_smoke.py
python tests/duplicates_browser.py   # potřebuje prohlížeč, který dovolí lokální navigaci
python scripts/build-windows.py
python scripts/validate-windows-package.py
```

U nového runtime protokolu jsou kontroly souběhu a vlastnictví v tests/duplicates.test.mjs a kontroly vstupních příkazů v tests/bridge-duplicates.test.mjs. Kompletní skutečně naměřené výsledky Node, nativních a demo kontrol jsou v docs/duplicates-*.tap/txt/json.
