# Mission Control 0.4.2 — protokol ověření

Datum: 3. 10. 2026. Prostředí: Linux, Node.js 22.16.0, Chromium přes Playwright,
clang/lld cross-build Windows x64. **Bez spuštění Windows, PowerShellu, skutečného
VS Code Extension Hostu a skutečného Codexu/Zoo Code.**

## Výsledky provedené na zdrojích tohoto vydání

| Sada | Výsledek | Co je skutečné a co nahrazené |
| --- | --- | --- |
| Node.js, všechny testy | **419 pass, 0 fail, 0 skip** | Skutečný hub/HTTP/store/bridge/relay; VS Code/Zoo callbacky jsou testovací náhrady. |
| Z toho nové Codex testy | **48 pass** | Skutečně spouštěný hook s JSON stdin/stdout, localhost endpoint, slučování souborů, Node runtime probe; události Codexu generuje test. |
| Chromium — nové Codex UI | **21 pass** | Produkční HTML/JS, skutečný hub/bridge/hook; browser fetch/SSE jsou zprostředkovány testovací transportní vrstvou. |
| Chromium — Zoo regrese | **24 pass** | Produkční UI, skutečný hub, simulovaný Zoo Task a transportní vrstva prohlížeče. |
| Chromium — projektový přehled | **30 pass** | Produkční UI a projektový model, testovací přenos, označená data. |
| Nativní kód řadiče zastavení | **31 scénářů pass** | Produkční C kód s náhradami Win32 API; navíc ASan/UBSan. |
| Nativní upozornění | **14 scénářů pass** | Produkční C kód s náhradami Win32 API, ASan/UBSan. |

Celkem browser **75 kontrol**, nativní **45 scénářů**. Sanitizer běhy nejsou
připočítány jako další nezávislé scénáře. Souhrn a surové výstupy jsou
v `test-results/0.4.2/`. Historické výsledky předchozích vydání jsou oddělené.

## Co nové testy ověřují

Skutečný samostatný hook vrací podporovaný JSON `allow` až po explicitním Run;
Deny vrací `deny`, předání/timeout/výpadek vrací bez verdiktu. Potvrzení obsahuje
úplný tool_input. Testují se jiné session/turn/root, odpojení projektu, jiné okno,
zneplatněný zdroj, starý požadavek, jednorázovost a 20 souběžných HTTP rozhodnutí
s jedním přijatým. Příjem více dotazů nezvyšuje počet projektů a druhý dotaz
znovu nenotifikuje první. Starý odkaz neudělí souhlas.

Slučování hooks.json zachovává ostatní handlery, zálohuje originál, odmítá
poškozený JSON, souběžnou změnu a pozměněný helper. Při odebrání hooku nebo projektu
se živé rozhodování ukončí. Vypnutí a odinstalace neodstraňují cizí hooky.
Nakonfigurování bez callbacku není falešně označené jako ověřené.

Browser test prochází Run, Deny, delegování, zavření dialogu, neplatné potvrzení,
obsah s HTML jako inertní text, několik čekajících dotazů v jednom projektu,
změnu filtru, kliknutí na konkrétní událost přes skutečný jednorázový přihlašovací
odkaz a mobilní šířku 390 px. Screenshoty jsou výslovně označené testovacími daty.

Unixový hook launcher byl skutečně proveden přes shell. Windows varianta
PowerShell EncodedCommand má statické testy uvozování a přenosu UTF-8, **ale zde
nebyla vykonána v PowerShellu 5.1**. Výběr Node odmítá Electron a příliš starý
runtime; stejné ověření běží i při skutečném nastavení uživatelem.

## Sestavení a distribuce

Windows EXE je skutečně cross-kompilovaný x64 GUI program, nikoli přejmenovaný
archiv. Obsahuje hub, tray, samostatný řadič, opravný/odinstalační průvodce,
oba VSIX a český návod. Instalátor je nepodepsaný. Soukromý runtime se případně
stáhne podle dosavadního mechanismu s připnutými SHA-256; stávající ověřený runtime
lze použít. Neprovádí se automatická důvěra hooků ani globální změna politiky.

`scripts/validate-windows-package.py` provádí statickou kontrolu PE, manifestu,
importů, vloženého ZIP/CRC, verzí a byte-identity zdrojů. Výsledek finálního
balíčku je dodán jako samostatný JSON. Statický test nikdy nenahrazuje test
Windows instalace. Binární výstup se po testech nemění kromě závěrečného sestavení.

## Co je nutné ověřit na cílovém stroji

Aktualizaci/opravu/odinstalování a GUI PowerShellu; důvěru hooků a jejich načtení
v konkrétní verzi Codexu; Windows start hooku s UTF-8 a mezerami v cestách; WSL/SSH
umístění Codex home, Bridge a Node; chování Windows notifikačního okna; skutečný
obsah callbacku a případný souběh dalších politik. Neexistuje zde tvrzení, že
proběhl modelový požadavek přes skutečný účet Codexu nebo schválení jeho nástroje.

Hook může předat rozhodnutí jen pro nový požadavek, který skutečně obdržel.
Nedostupnost/timeout znamenají původní schvalovací politiku, nikoli Deny. Není
podporované dálkové ovládání již otevřených starých promptů nebo cloudové
orchestrace. Neměňte ochrany Windows ani důvěru hooků kvůli spuštění balíčku.

## Reprodukce

```sh
node --test --test-concurrency=4 tests/*.test.mjs
node scripts/build-preview.mjs
python3 tests/codex_browser.py /tmp/mc-browser
python3 tests/zoo_browser.py /tmp/mc-browser
python3 tests/projects_browser.py /tmp/mc-browser
bash tests/native/run-tests.sh
cc -std=c11 -fshort-wchar -fno-builtin -ffunction-sections -fdata-sections \
  -Wl,--gc-sections -Wall -Wextra -Werror -Wno-unused-function \
  -fsanitize=address,undefined tests/native/notification-test.c -o /tmp/mc-notifications
/tmp/mc-notifications
python3 scripts/build-windows.py
python3 scripts/validate-windows-package.py
```
