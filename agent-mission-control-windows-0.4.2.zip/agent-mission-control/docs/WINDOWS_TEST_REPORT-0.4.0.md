# Mission Control 0.4.0 — protokol ověření

Datum: 2. října 2026. Prostředí: Linux x64, Node.js 22.16.0, Chromium,
Python + Playwright, clang/lld-link. Balíček je určený pro Windows x64,
ale zde se na Windows nespouštěl. Historické protokoly 0.3.x nejsou výsledky
aktuálního sestavení.

## Vykonané testy

**312/312 automatických testů Node.js**, bez selhání či přeskočení.
Původních 265 scénářů prošlo i s novým modelem; přidáno 47 projektových scénářů.
Použité příkazy: `npm test` / `node --test tests/*.test.mjs`.
Výpis je `docs/results-0.4.0/node-tests.tap`.

Nové scénáře ověřují čtyři Codex záznamy pod jedním projektem, společný projekt
pro Codex a Zoo Code, identitu hostitele a cesty, oddělení různých serverů,
registraci projektu bez úlohy, priority nevyřízených otázek, souběžnou práci,
vyloučení dokončených interních a pomocných běhů, zastaralou historii,
nově připsané explicitní dokončení hlavního Codex běhu, nedostupné spojení,
unikátní Git snapshot, projektové potvrzení a odložení upozornění.

Skutečný HTTP hub ověřuje omezené odpojení jednoho kořene vícesložkového
workspace, zachování druhého, blokaci opožděných zpráv, uložené odpojení,
explicitní obnovu s novou epochou, zachování stejné identity projektu,
a odmítnutí změny bez autentizace. Produkční Bridge + Producer + Connection
jsou také testované proti skutečnému HTTP hubu a stdio relay. VS Code API,
Zoo provider a Windows interop volání jsou v těchto testech náhrady.
Nejde o skutečný Extension Host, Code.exe nebo powershell.exe.

Test migrace spouští skutečný hub nad původním formátem uloženého stavu se
čtyřmi záznamy. Ověří přesnou zálohu, zachování tokenu, jeden offline projekt,
uchování historie a nový formát stavu po zápisu. Další test ověří, že existující
záloha není přepsána a čistá instalace nedostane ukázkové projekty.

**30/30 kontrol nového rozhraní v Chromium.** Ověřeno přihlášení, počty projektů,
převod 4 → 1, aktuální práce vs. interní dokončení, sbalená diagnostika,
filtry, připnutí, kompaktní zobrazení, potvrzení bez schvalování agentovi,
souběh obou nástrojů, neaktivní HTML z textu agenta, odpojení projektu,
odmítnutí starého snímku a pozdního reportu, zachování odebrání v novém
dokumentu dashboardu, šířka 390 px bez vodorovného přetečení a samostatné demo.
Výpis: `docs/results-0.4.0/browser-tests.json`.

Důležitý rozdíl: Chromium v kontejneru blokuje přímou navigaci na loopback
(`ERR_BLOCKED_BY_ADMINISTRATOR`). Proto browser test načítá skutečné UI inline
a používá testovací `fetch` přes Python na **skutečné HTTP routy hubu**,
s HTTP cookie jar. EventSource je nahrazené řízeným načítáním skutečných
snímků. Test tedy není přímým browser → SSE end-to-end testem. Systémové
bezpečnostní politiky se kvůli němu nevypínaly. Všechny úlohy jsou syntetické.
Screenshoty `projects-dashboard-0.4.0.png` a `projects-disconnect-0.4.0.png`
pocházejí ze skutečného distribuovaného demo UI, s viditelným označením DEMO.

**31/31 nativních scénářů C se simulovanými Win32 API**, zaměřených na bezpečné
zastavení a parser argumentů. `sh tests/native/run-tests.sh`;
výpis: `docs/results-0.4.0/native-tests.txt`. Nejde o skutečné procesy Windows.

## Sestavení a statická kontrola

Příkazy:

```sh
node scripts/build-preview.mjs
python3 scripts/build-project-guide.py
python3 scripts/build-windows.py
python3 scripts/validate-windows-package.py
```

Kontrola sestaveného balíčku ověřuje x64 GUI PE, `asInvoker`, prázdnou sekci
certifikátu (nepodepsané), CRC vloženého ZIP, shodu všech vložených souborů se
zdroji, aktuální oba VSIX, shodu vnořeného Bridge a jeho SHA-256, předchozí
opravy instalátoru, přítomnost projektového registru a migrace, odpojení,
obnovení i oddělených hostů doplňků. Její samostatný JSON protokol s hash
finálního EXE je součástí distribuovaných souborů vedle instalátoru.

Zdrojový ZIP je vytvořený ze stejného stromu jako vložený instalační balíček.
Soubor kontrolních součtů obsahuje SHA-256 distribuovaných souborů. Archiv
neobsahuje živé uživatelské přihlašovací údaje, workspace ani `state.json`.
Testovací tokeny ve fixture souborech jsou umělé, nikoli uživatelovy.

## Co nebylo ověřeno

Nebyl spuštěn Windows instalátor, jeho PowerShell 5.1 průvodce, skutečná
aktualizace/oprava/odinstalování na Windows, reálné Windows tray notifikace,
reálný VS Code Extension Host, skutečný Zoo Code ani Codex uživatele,
Windows ↔ WSL interop a uživatelovy SSH tunely. Cross-kompilace a API náhrady
tuto platformní validaci nenahrazují. Nelze tvrdit potvrzenou produkční
kompatibilitu. Instalační opravy zůstávají ve zdrojích a procházejí dosavadními
regresními testy; to není doklad vykonání průvodce na Windows.

## Přetrvávající věcná omezení

Pozorování původního Codex VS Code rozšíření je opt-in JSONL adaptér. Nedává
zaručené informace o čekajícím schválení. Načtená historie není živá aktivita;
při neznámých metadatech se stav nehádá. App Server klient zůstává samostatný
spravovaný režim, nepřebírá automaticky existující chaty rozšíření.

Zoo ve vícesložkovém workspace vyžaduje výslovný výběr jediného kořene pro dané
okno. Identické názvy na různých hostitelích se neslučují. Windows a WSL cesty
k téže fyzické složce se bez společné identity automaticky nesjednocují.
VS Code příkaz Disconnect This Workspace odpojuje všechny jeho kořeny;
v dashboardu lze odebrat jednotlivý projekt. Výslovné Reconnect obnovuje kořeny
příslušného workspace. Bezpečnostní ochrany Windows ani Workspace Trust
kvůli balíčku nevypínejte.
