# Mission Control 0.3.4 — zámek údržby: změna a rozsah ověření

## Co bylo zjištěno ze zdrojů 0.3.3

`windows/Install.ps1` získával `Local\AgentMissionControl-Setup-<SID>` před vytvořením formuláře a uvolňoval jej až po zavření celého průvodce. Zámek držel proces Windows PowerShell, do kterého nativní EXE předal bootstrap. Stejný průvodce mohl být spuštěn ze Start menu přímo přes PowerShell, zcela bez instalačního EXE. Z pouhé nepřítomnosti `MissionControl-Setup-0.3.3-x64.exe` nelze tedy usuzovat, že neběží údržba. Identitu konkrétního procesu na uživatelově PC neznáme; jde o vysvětlení a opravu diagnostiky/lifecycle, nikoli potvrzenou vzdálenou diagnózu.

## Změna

Vstup do `Invoke-MCOperation` získává stále tentýž mutex; při skutečném obsazení odmítne zapisovat aplikační soubory. `finally` uvolní mutex při úspěchu i chybě. Otevřený formulář 0.3.4 mimo operaci zámek nedrží. Všechny operace včetně odinstalace procházejí stejnou branou. Verze a stav instalace se po získání zámku přečtou znovu. Metadata v `setup-owner.json` jsou pouze diagnostika; neautorizují vstup a jejich stáří/absence neopravňuje přepsání.

Diagnostika vypisuje pouze PowerShell procesy aktuálního účtu a relace s rozpoznaným vstupním skriptem. PID záznamu nové verze porovnává s časem vzniku procesu, SID a relací. U všech nalezených procesů výslovně uvádí „možní“, protože CIM neposkytuje vlastnictví tohoto mutexu. Ani záznam novější verze s validním PID/časem procesu není sám o sobě důkazem aktuálního vlastnictví. Při nedostupné diagnostice zámek neobchází. Skript ani tlačítko nikoho neukončují. `Diagnose-Setup.ps1` pouze vypíše stav a kandidáty; při diagnostické sondě krátce získá volný mutex a hned jej uvolní.

Starší otevřený průvodce může stále oprávněně blokovat novou operaci. Je nutné jej běžně zavřít nebo dokončit; nová verze jej nesmí svévolně zabít při zápisu/rollbacku. Zámek je per-user a per-session jako ve starších verzích, ne distribuovaný zámek mezi různými relacemi Windows.

## Skutečně spuštěno v tomto prostředí

Prostředí: Debian Linux x64, Node.js 22.16.0, Clang/lld-link; Windows, Wine ani PowerShell runtime nejsou k dispozici.

- **112/112 Node testů prošlo.** 103 předchozích testů aplikace a 9 nových kontrol zdrojových kontraktů/diagnostických regulárních výrazů. Záznam: `docs/setup-lock-node-tests.tap`. Nové kontroly NEvykonávají PowerShell ani mutex Win32; nejsou vydávány za runtime testy.
- **31/31 scénářů nativního kódu se simulovanými Win32 API prošlo.** Záznam: `docs/setup-lock-native-tests.txt`. Pokrývají dřívější řadič zastavení; nemodelují PowerShell průvodce.
- Křížové sestavení Windows x64 EXE a kontrola vloženého ZIP se provádí přes `scripts/build-windows.py` a `scripts/validate-windows-package.py`. Výsledek statické kontroly je distribuován jako samostatný JSON. Ověřuje PE, manifest, nepodepsaný stav, shodu zabalených zdrojů, BOM a přítomnost změny zámku. Není to spuštění Windows.

## Automatická kontrola až na cílovém Windows

`windows/Test-SetupLock.ps1` obsahuje 12 kontrol skutečného produkčního zámku a syntaktickou kontrolu všech zabalených PS1. Vlastní procesy testu používají pouze jméno `Local\MCSetupLock-Test-<GUID>` a novou dočasnou složku, nikdy produkční mutex. Zkouší blokování druhého procesu, uvolnění, opakovaný Release, výjimku a opuštěný mutex s ponechaným handlem. Výsledek `MC_SETUP_LOCK_TEST_OK` vypisuje až po skutečném úspěchu. Při timeoutu může ukončit výhradně vlastního testovacího potomka reprezentovaného uchovaným procesním objektem; nevyhledává jiné procesy pro ukončení.

Instalátor tento test volá po získání skutečného instalačního zámku, ještě před zastavením, stahováním runtime či výměnou původní aplikace. Při selhání nepokračuje. Dále zůstává preflight atomického zápisu ze 0.3.3. Test zámku zde **nebyl spuštěn** a není započítán mezi provedené kontroly.

## Neověřeno

Celý průvodce ve Windows PowerShell 5.1, upgrade z 0.2.0 či 0.3.3, normální i havarijní konec legacy workeru, skutečné CIM/okna, VS Code/WSL/SSH, oprava a odinstalace na Windows. Nejde o podepsané nebo produkčně certifikované vydání. Zachování dat je implementovaný návrh; není zde podložené Windows end-to-end testem. Nativní EXE jsou nepodepsaná, ochranu Windows nevypínejte.

## Primární podklady

- Microsoft, Mutex a opuštění zámku: https://learn.microsoft.com/en-us/dotnet/api/system.threading.mutex?view=netframework-4.8.1
- Microsoft, Win32_Process a vlastnosti CommandLine / ProcessId / CreationDate: https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-process
