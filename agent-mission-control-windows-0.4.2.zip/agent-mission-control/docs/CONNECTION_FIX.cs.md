# Mission Control 0.3.5 — připojení ve VS Code

## Co opravuje tato verze

Ve 0.3.4 byl `local-mission-control.bridge` pouze workspace extension.
Příkazy v jeho manifestu existovaly, ale instalace do místního Windows profilu
nezajišťovala jeho dostupnost ve WSL/SSH okně. Navíc deklaroval nepodporovaný
Restricted Mode, takže mohl být z bezpečnostních důvodů zcela vypnutý.
Z pouhého hlášení uživatele nelze určit konkrétní příčinu na jeho počítači:
stále je nutné rozlišovat host, profil, vypnuté rozšíření a chybu aktivace.

Nově jsou v instalátoru dva malé doplňky:

| Doplněk | Identifikátor | Úloha |
|---|---|---|
| Mission Control Connection | local-mission-control.connector | Místní připojovací panel, příkaz Setup Connection a instalace bridge do aktuálního okna. |
| Mission Control Bridge | local-mission-control.bridge | Sběr událostí u projektu; ve vzdáleném okně běží ve WSL/SSH extension hostu. |

## Instalace / aktualizace

Spusťte MissionControl-Setup-0.3.5-x64.exe pod stejným účtem jako dosud.
Původní Mission Control neodinstalovávejte. Instalátor zachovává data, token,
port, autostart, opravu i odinstalování a dosavadní opravy zámku/zastavení/zápisu.

VS Code se dohledává automaticky. Ponechte volbu **Nainstalovat / opravit
Connection + Bridge ve zvoleném profilu VS Code**. Oba doplňky se instalují a
ověřují samostatně přes CLI do téže místní instalace a téhož profilu.
Prázdné pole profilu znamená výchozí profil, nikoli všechny profily. Profil
přepnutý až uvnitř editoru nemusí instalátor automaticky rozpoznat.

Při úspěchu se objeví MC_VSCODE_PACKAGES_VERIFIED. To potvrzuje instalaci obou
verzí na disk, nikoli jejich aktivaci ve všech oknech nebo připojení k hubu.
Při neúspěchu jednoho doplňku se uvádí částečný výsledek, ne plný úspěch.

## Připojení projektu

V okně s projektem klikněte dole na **Mission Control**, případně v Exploreru
na **Mission Control → Nastavit připojení**. Stejný postup spouští příkaz:

    Mission Control: Setup Connection

Panel ověří bridge v tomto konkrétním okně. Pokud chybí nebo je starý, nabídne
instalaci přiloženého VSIX. Jeho SHA-256 se kontroluje před předáním VS Code.
Místo instalace určuje VS Code podle aktuálního workspace: místní, WSL nebo
SSH. Nestahuje se neexistující balíček z Marketplace a nespouští se vlastní
příkazy na SSH serveru. Instalace se týká aktuálního prostředí, nikoli všech
vzdálených hostů nebo WSL distribucí.

Po instalaci se znovu ověřuje verze a host skutečně odpovídajícího bridge.
Pokud ještě není aktivní, panel nehlásí připojení a nevynucuje restart. Až
agenti dokončí práci, použijte Developer: Reload Window. Bezpečnostní výzvy
VS Code musí uživatel vyřešit sám; panel neobchází Workspace Trust ani zásady.

Ve Windows a WSL se následně použije dosavadní připojení k Windows aplikaci
s potvrzením souhlasu. Pro SSH zůstává zadání adresy dostupné přes tunel a
párovacího tokenu přes Mission Control: Connect. Instalace rozšíření na SSH
server sama síťový tunel k hubu nevytváří.

Codex JSONL pozorování je nadále samostatně volitelné; nepřidává záruku
zachycení všech schvalovacích dialogů původního Codex rozšíření.

## Když příkaz nebo panel chybí

V Extensions (Ctrl+Shift+X) vyhledejte přesný identifikátor:

    @id:local-mission-control.connector

Connection musí být nainstalovaný místně a povolený v právě používaném
profilu. Pro tento doplněk je správný místní/UI host i v okně SSH/WSL.
V profilu, kde chybí, jej lze nainstalovat z přiloženého
mission-control-connection-0.3.5.vsix přes Extensions: Install from VSIX.
Tento VSIX už obsahuje balíček bridge, hub kvůli tomu není nutné přeinstalovat.

V jiném profilu použijte vlastní instalaci nebo v nabídce rozšíření funkci
VS Code **Apply Extension to all Profiles**. Instalátor zásady profilů sám
potají nemění. Vypnutá rozšíření zůstávají vypnutá, dokud je nepovolíte.

U bridge vyhledávejte @id:local-mission-control.bridge. V okně WSL/SSH patří
bridge na vzdálenou stranu. Případné Enable / Install in WSL/SSH ukazuje
přímo VS Code. Původní příkazy Connect a Connect to Windows App zůstaly zachované.

Restricted Mode nyní dovoluje diagnostiku a zobrazení příkazů, nikoli sběr
projektových dat. Důvěru povolujte pouze projektu, který znáte; ochranu
pracovního prostoru nevypínejte globálně. Prohlížečové vscode.dev není cílem
tohoto Node.js doplňku. Manifest vyžaduje VS Code 1.100 nebo novější.

## Diagnostika bez kopírování tajných údajů

    Mission Control: Connection Diagnostics

Výpis obsahuje verzi panelu, verzi VS Code, remote typ, stav důvěry a odpověď
bridge: verzi, host, blokující důvod, dostupnost párování a skutečné spojení
s hubem. Panel nečte ani nevypisuje párovací token nebo obsah chatů.

Nejde o automatický sběr diagnostiky z ostatních profilů, neotevřených
vzdálených hostů nebo vypnutých doplňků. Pokud není dostupný ani Connection,
nejprve ověřte jeho instalaci/povolení v aktuálním profilu.

## Oprava a odinstalování

Správa ve Start menu a nový EXE zachovávají Update / Repair / Uninstall.
Při zaškrtnuté volbě odebrání doplňků se odstraní pouze dva naše identifikátory
ze zvoleného místního profilu. Codex, Zoo Code a vzdálené instalace se nemažou.
Úplné odinstalování dat zůstává oddělené a standardně nezaškrtnuté.

## Rozsah ověření

Balíčky jsou nepodepsané. Tato verze byla sestavena a otestována v Linuxu.
148 Node testů zahrnuje 36 nových scénářů připojovacího panelu/bridge/instalátoru;
VS Code API a CLI jsou v těchto integračních scénářích simulované. Dalších
31 nativních scénářů používá simulace Windows API.

Skutečný VS Code Extension Host, jeho Command Palette, Windows instalátor,
upgrade, odinstalování, WSL a SSH přenos zde spuštěny nebyly. Kontrola obsahu
balíčku není náhradou end-to-end testu na Windows. Ochranu Windows nevypínejte.

## Primární dokumentace

- VS Code CLI (VSIX instalace a profily): https://code.visualstudio.com/docs/configure/command-line
- Extension Hosts: https://code.visualstudio.com/api/advanced-topics/extension-host
- Remote extensions: https://code.visualstudio.com/api/advanced-topics/remote-extensions
- Vestavěný příkaz installExtension: https://code.visualstudio.com/api/references/commands
- Workspace Trust: https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
- Profily: https://code.visualstudio.com/docs/configure/profiles
