# Mission Control 0.3.7 — odpojení a odebrání z dashboardu

## Aktualizace bez odinstalace

Spusťte MissionControl-Setup-0.3.7-x64.exe pod stejným Windows účtem jako dosud.
Vyberte Aktualizovat a ponechte instalaci Connection + Bridge ve správném profilu
VS Code. Hub i oba doplňky musí mít verzi 0.3.7. Instalátor nadále podporuje opravu,
aktualizaci a odinstalování; automatické dohledání VS Code a dřívější opravy zůstávají.
Párovací token, port a nastavení při aktualizaci zůstávají zachované.

Až agenti dokončí rozpracované úlohy, načtěte příslušná okna VS Code znovu přes
Developer: Reload Window. Instalátor restart editoru nevynucuje. Ve WSL/SSH
aktualizujte i vzdálený Bridge přes Mission Control: Setup Connection nebo
Mission Control: Install / Repair Bridge Here. Obnovte také stránku dashboardu.

## Odpojení z VS Code

V Exploreru otevřete sekci Mission Control a vyberte Odpojit a odebrat z dashboardu.
Stejnou akci spouští místní příkaz Mission Control: Disconnect This Workspace.
Samotný Bridge poskytuje Mission Control: Disconnect and Remove from Dashboard
(interní identifikátor missionControl.disconnect zůstává zachovaný).

Potvrzení vypne monitoring tohoto workspace, počká na rozpracovaný přenos a požádá
hub o odebrání jeho záznamů. Nemaže sdílený hubToken: jiný workspace ve stejném
profilu nesmí přijít o připojení. Pauza je uložená pro daný workspace; prostředky
případného nedokončeného požadavku jsou oddělené i mezi více okny.

## Odpojení z dashboardu

Vyberte řádek a v detailu stiskněte Odpojit a odebrat. Potvrzovací dialog ukáže
všechny dotčené relace, i ty skryté aktuálním filtrem. Po potvrzení řádky i zdroj
zmizí z dashboardu. Odebrat lze i staré odpojené připojení.
V Nastavení připojení / Připojit nástroje je stejné tlačítko u jednotlivých zdrojů:
tím lze odstranit i připojení, které ještě neohlásilo žádnou úlohu.

Rozsah je CELÉ PŘIPOJENÍ BRIDGE, zpravidla jeden workspace. Má-li tento bridge více
úloh Zoo Code a Codexu nebo více kořenových složek, odeberou se všechny jím
reportované řádky. Nejde o mazání jednoho vybraného chatu. Jiná připojení zůstávají
nedotčená. Před potvrzením je rozsah výslovně zobrazen.

Hub uloží odpojení ještě před úspěšnou odpovědí. Další zprávy daného připojení
odmítá; starý heartbeat ani standardní restart hubu jej neoživí. Bridge 0.3.7 při
příštím kontaktu zastaví pouze vlastní monitoring a uloží místní pauzu. Nepřipojuje
se automaticky znovu. Nový vlastník stejného workspace je chráněný před opožděným
odpojovacím požadavkem starého okna.

## Co zůstává beze změny

Odpojení nevolá přerušení běhu, schválení, shell, restart editoru ani ukončení
agentů. Nemění soubory projektu ani původní historii chatů Codexu / Zoo Code.
Odebere kopii událostí a zpráv daného zdroje z aktivního stavu dashboardu; starší
zálohy souboru state.json neprohledává a nemaže. Není to funkce bezpečného vymazání
veškerých dříve uložených dat.

Dosud nepředané příkazy ve frontě daného zdroje se označí za neprovedené a dál se
neodesílají. Již předaný příkaz nelze vzít zpět: jeho výsledek je po odpojení
neověřený. Ověřte jej přímo u agenta; automatické opakování neprobíhá.

Běžné zavření VS Code, restart hubu nebo krátký výpadek není toto ruční odebrání.
Takové přerušení nadále zachovává historii a umožňuje obvyklé opětovné připojení.

## Nedostupný hub

Při odpojení ve VS Code bez dostupného hubu se místní monitoring vypne okamžitě,
ale odebrání řádku v dashboardu není falešně potvrzeno. Rozšíření zobrazí čekající
odebrání a uloží požadavek. Při otevřeném workspace jej zkouší znovu přibližně po
15 sekundách; po zavření editoru jej dokončí až při opětovném otevření tohoto
workspace. Záznam lze mezitím odebrat přímo v dostupném dashboardu.

Není-li možné uložit odpojení na disk hubu, zobrazí se chyba. Záznamy mohou být již
odstraněné z paměti, ale jejich potlačení po restartu nelze do opravy zápisu zaručit.
Úspěšné testy standardního restartu nejsou zárukou proti výpadku napájení,
poškození disku ani ručnímu smazání state.json.

## Opětovné připojení

Ve VS Code vědomě spusťte Mission Control: Setup Connection nebo příkaz Connect.
Použije se existující bezpečně uložený token a NOVÁ instance připojení. Staré
odpojovací požadavky i staré reporty se nepřenesou na nové připojení. Záznamy se
znovu objeví, jakmile je bridge nahlásí; odebraná kopie starší historie dashboardu
se nemusí doplnit. Pro jiné přihlašovací údaje použijte původní postup párování
po odpovídající změně uložené konfigurace; tato verze nezavádí správce více hubů.

Volitelný samostatný klient Codex App Serveru rovněž neukončuje RPC ani čekající
úlohu při odpojení monitoru. Ve STEJNÉM terminálu běžícího klienta napište connect
 a Enter: znovu připojí stejný thread, bez nového App Serveru. Ctrl+C nadále tento
samostatný klient i jeho App Server ukončuje. Původního Codex rozšíření ve VS Code
se tato terminálová funkce netýká.

## Ověření a bezpečnost balíčku

Podrobný rozsah je v docs/WINDOWS_TEST_REPORT-0.3.7.md. Testy skutečného hubu
v Linuxu jsou oddělené od testů nahrazeného VS Code API a od testů UI s ukázkovými
daty. Windows instalátor, PowerShell průvodce, reálný VS Code Extension Host a
skutečná WSL/SSH interoperabilita zde nebyly spuštěny. EXE i VSIX jsou nepodepsané.
Ochranu Windows ani Workspace Trust kvůli instalaci nevypínejte.
