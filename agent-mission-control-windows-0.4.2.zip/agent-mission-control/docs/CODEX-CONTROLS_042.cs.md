# Mission Control 0.4.2 — Codex Run / Deny

**Stejný původní Codex, stejný projekt, žádný druhý chat.** Dashboard nově umí
předat jednorázové rozhodnutí původnímu Codexu prostřednictvím jeho živého
`PermissionRequest` hooku. Pozorování JSONL samo o sobě zůstává pouze pro čtení.

## Důležité před zapnutím

Tato integrace vyžaduje Codex s podporou dokumentované události `PermissionRequest`
a povolenými místními command hooky. Nevztahuje se na cloudově řízené běhy.
Hooky musí uživatel v Codexu zkontrolovat a schválit; Mission Control jejich
registr důvěry, sandbox, schvalovací politiku ani omezení správce nemění.
Dokumentovaný prohlížeč hooků je `/hooks` **v Codex CLI**, ne Command Palette VS Code.

Mechanismus běží **před** běžným schvalováním Codexu. Není to dálkové mačkání již
zobrazených nativních tlačítek. Na nový dotaz nejprve čeká dashboard. Předání zpět
nebo uplynutí pěti minut vrátí řízení původní politice Codexu, která může rozhodnout
sama, nebo zobrazit dotaz. Nedostupný dashboard není automatické zamítnutí ani
automatické povolení. Není to náhrada bezpečnostní politiky.

## Aktualizace a první zapnutí

1. Spusťte `MissionControl-Setup-0.4.2-x64.exe` pod dosavadním Windows účtem.
   Aktualizujte hub, tray i Connection + Bridge v používaném profilu VS Code.
   Původní instalaci neodinstalovávejte, data a token nemažte. Zachovány jsou oprava,
   odinstalování, automatický start, dohledání editoru a projektový přehled.
2. Až agenti dokončí rozpracované úlohy, proveďte `Developer: Reload Window`.
   Ve WSL/SSH aktualizujte také Bridge v příslušném vzdáleném prostředí. Obnovte
   stránku dashboardu a ověřte běžné připojení projektu k hubu.
3. V okně projektu spusťte **Mission Control: Enable Codex Dashboard Controls**.
   Stejná položka je v Explorer → Mission Control → **Codex: zapnout Run / Deny
   v dashboardu**; místní panel má příkaz **Mission Control: Setup Codex Dashboard Controls**.
   Potvrzení ukáže konkrétní Codex home a rozsah úpravy. Záloha existujícího
   `hooks.json` vznikne před přepsáním; cizí hooky se zachovají.
4. Zkontrolujte a potvrďte nové hooky v Codexu. Dokumentovaná cesta je otevřít
   **Codex CLI ve stejném prostředí a se stejným CODEX_HOME** a použít `/hooks`.
   Pokud vaše vydání Codexu má vlastní rozhraní pro kontrolu hooků, lze použít je.
   Bez potvrzení důvěry nebude hook spuštěn. Nevypínejte ochranu a nepoužívejte
   obcházení důvěry. CLI není nutné používat k vlastnímu psaní kódu — původní chaty
   nadále zůstávají v rozšíření. Tento balíček CLI automaticky neinstaluje.
5. Po bezpečném opětovném načtení Codexu ověřte příští skutečný požadavek na
   povolení v neprodukčním projektu. Starý dotaz, který se objevil před zapnutím
   hooku, vyřiďte ještě ve VS Code. Nový chat ani destruktivní testovací příkaz
   nejsou k instalaci potřeba. Nenastavujte kvůli zkoušce slabší oprávnění.

**Nakonfigurováno není totéž jako ověřeno.** Do první přijaté události se zobrazuje
„připraveno, skutečný dotaz zatím neověřen“. Teprve skutečný callback vytvoří
`MC_CODEX_HOOK_VERIFIED` v Output → Mission Control. Běžící Bridge má identitu
`0.4.2-codex-hooks.1`. Pokud se žádná operace nemusí schvalovat, žádný dotaz
nevznikne a stav se tím automaticky neoznačí jako vadný.

## Jak rozhodnout v dashboardu

Vyberte projekt → **Teď**. Živý dotaz Codexu nabídne:

| Akce | Výsledek |
| --- | --- |
| **Run · povolit** | Odpověď `allow` pro právě zobrazené volání. Ne trvalé povolení. |
| **Deny · zamítnout** | Odpověď `deny` pro totéž volání. Ne zastavení celého agenta. |
| **Vyřídit v Codexu** | Bez vlastního verdiktu se vrátí běžný schvalovací postup Codexu. |

Před rozhodnutím se otevře potvrzení s úplným přijatým `tool_input`, názvem
nástroje, pracovní složkou a ID původního běhu/kroku. Nic v obsahu není spuštěno
jako HTML nebo příkaz. Zrušení potvrzení, otevření notifikace a označení „viděno“
nic neschválí. Příkaz může obsahovat citlivé údaje; celý požadavek posuzujte stejně
pečlivě jako v editoru. Žádost může pocházet i od pomocného agenta hlavní úlohy;
identifikátor je v úplném obsahu.

Run/Deny se váže na konkrétní živé spojení hooku, session, turn a náhodné ID
požadavku. Změněný, spotřebovaný, přerušený, odpojený či vypršelý požadavek se
odmítne. Současné stisky z více záložek nemají rozhodnutí zdvojit. Odpověď Run
potvrzuje předání verdiktu, **nikoli úspěšné vykonání nástroje**. Případné další
politiky/hooky mohou výsledek ovlivnit; zákaz jiného rozhodujícího hooku se neobchází.

Při více čekajících voláních dostane každé vlastní kartu uvnitř stejného projektu.
Hlavní seznam zůstává **jeden projekt = jeden řádek** i při současné práci Zoo Code.
Po odpovědi se může do dalšího pozorovaného záznamu ukázat stav neověřen. Samotný
PermissionRequest není proud všech tokenů a výsledků příkazů; původní JSONL
pozorování slouží dál pro dostupnou aktivitu a má dosavadní omezení.

## Upozornění a časové limity

Žádosti Codexu používají stejné aplikační okno u lišty jako Zoo Code: výchozí
**60 sekund**, volby 30 / 60 / 120 / 300 sekund nebo do zavření. Kliknutí otevře
právě původní událost, vybere správný projekt a odstraní filtr, který ho skrýval.
Novější dotaz nepřepíše cíl staršího upozornění. Vyřízený dotaz nelze schválit
ze staré notifikace. Historie je dostupná přes **Upozornění** v dashboardu.

**Délka upozornění a doba pro rozhodnutí jsou rozdílné:** popup standardně 60 s,
čekání jednoho hooku nejvýše 5 minut. Zavření popupu není Deny; požadavek zůstává
v projektu do rozhodnutí nebo vypršení času. Žádné okno ani upozornění samo
nepovoluje vykonání akce.

## Windows, WSL, Linux a SSH

Hook musí být zaregistrovaný **tam, kde běží Codex**, a Bridge ve stejném prostředí.
Windows instalátor nedokáže z místního Windows příkazu schvalovat nesouvisející
vzdálený proces bez této vazby. Vzdálený Bridge používá dosavadní bezpečné spojení
k hubu; žádný nový veřejný port ani pravidlo firewallu nepřibývá.

Na Windows se přednostně použije soukromý Node.js Mission Control. Ve WSL/SSH
samostatný Node z prostředí Bridge nebo PATH. Vlastní cesta se nastavuje přes
`missionControl.codexHookNode` (absolutní cesta, Node.js 22+). Rozpoznání běh
Node ověří; Code.exe/Electron se nepoužije jako domnělé Node CLI.

Pokud Codex běží ve WSL, ale projekt/Bridge místně ve Windows, otevřete projekt
přes Remote WSL a zapněte funkci tam. Při detekovaném nastavení této kombinace
Bridge zobrazí pokyn a hook ve špatném prostředí nenastaví. U vlastního Codex
home nastavte `missionControl.codexHome` na stejný adresář, který používá Codex;
výchozí je CODEX_HOME z prostředí, jinak `~/.codex`. Restartovaný hook se
nepřesměruje automaticky na jiný host nebo jiné připojení.

## Vypnutí, odstranění a data

**Mission Control: Disable Codex Dashboard Controls** vypne ovládání jen v daném
workspace. Nevyřízené dotazy pokračují původní politikou. Odpojení monitorování
projektu z dashboardu také přestane přijímat jeho rozhodnutí; pozdní požadavky
odpojený projekt znovu nevytvoří.

**Mission Control: Remove Codex Hooks from This Host** po potvrzení odstraní
pouze vlastní nezměněné skupiny hooků z daného Codex home. Dotýká se všech
projektů, které tento home sdílí; ostatní hooky ponechá. Změněná cizí definice se
nepovažuje za vlastnictví aplikace. Zálohy ani původní chaty se nemažou.

Windows odinstalace zkontroluje výchozí Codex home a CODEX_HOME z prostředí a
odstraní vlastní záznamy, jen když ukazují právě na odinstalovaný soukromý Node.
**Pro vlastní Codex home nastavený pouze v rozšíření nebo pro WSL/SSH použijte
před odinstalací uvedený příkaz v daném prostředí.** Tyto jiné hosty instalátor
sám neprohledává. Při selhání odstranění vypíše varování; bezpečně nemazat celý
`hooks.json` ani `config.toml`. Odinstalační oprava není zárukou rollbacku hooku
při neúspěšné odinstalaci ostatních souborů.

Lokální endpoint naslouchá pouze na 127.0.0.1 a má samostatný náhodný token.
Registrované kořeny, krátká platnost registrace, vlastník připojení a otevřený
socket omezují přijetí požadavku. To není izolace proti kompromitovanému účtu
na stejném počítači. Konfigurace a endpoint jsou v uživatelském Codex home;
na Unixu se nové soubory vytvářejí s režimem 600, složky 700. Hub zpracovává
obsah schvalovacího požadavku stejně jako ostatní monitorované události a může
ho mít v místní historii. Necitlivé označení v popupu neznamená, že příkaz neobsahuje
tajemství. Hook nečte soubor přihlášení, transcript_path ani celé chaty.

Při neznámém formátu, neúplném obsahu nad 24 000 znaků, nedostupném hubu nebo
nevyhovující konfiguraci se nepokouší obecně klikat ve VS Code. Nevydá souhlas;
vrátí se původní schvalování. Volné textové otázky Codexu a již probíhající
interaktivní terminál touto funkcí neovládáte.

## Diagnostika

Spusťte **Mission Control: Copy Connection Report**. Pole `codexControls`
odlišuje lokální zapnutí, naslouchání, počet obdržených hooků a skutečně ověřený
callback. Report neobsahuje token ani text příkazů. Problém s důvěrou hooku se
řeší v Codexu, problém „není runtime“ nastavením samostatného Node; pouhé
opakované připojování workspace tyto příčiny neopraví.

Stav „ověřeno“ dokládá callback, ne automaticky úspěšné dokončení budoucího Run.
Skutečné Windows/WSL/SSH/Codex prostředí nebylo v tomto sestavení spuštěné.
Ověření komponent a náhrady API jsou výslovně rozlišené v protokolu testů.

## Referenční kontrakt

OpenAI: [Hooks — PermissionRequest, konfigurace a důvěra](https://learn.chatgpt.com/docs/hooks).
Ověřeno 3. 10. 2026. Implementace nepoužívá přepis `chatgpt.cliExecutable`,
nezakládá paralelní App Server chat a nemění spustitelný soubor Codexu.
