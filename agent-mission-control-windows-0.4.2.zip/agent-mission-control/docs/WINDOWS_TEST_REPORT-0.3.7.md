# Mission Control 0.3.7 — protokol ověření

Datum sestavení: 2026-10-02. Prostředí: Linux, Node.js v22.16.0, Python 3,
Chromium headless přes Playwright, clang a lld-link (cross-compilation pro Windows x64).
Nejde o potvrzení kompatibility konkrétní instalace Windows/VS Code uživatele.

## Provedené testy

**224 automatických Node testů, všechny úspěšné.** Zahrnují dosavadní testy hubu,
adaptérů, správy instalace a duplicit a 32 nových testů odebrání. Plný výstup:
`docs/disconnect-node-tests.tap`. Příkaz: `node --test tests/*.test.mjs`.

Nové testy skutečného HTTP hubu a uloženého stavu v Linuxu ověřují odebrání celého
zdroje bez změny jiných projektů, blokování opožděných zpráv, uloženou pauzu po
restartu, explicitní obnovení novým vlastníkem, ochranu proti starému odebrání,
oddělení cookie/bearer oprávnění a origin kontrolu. Zápis na disk je ověřen ještě
před úspěšnou HTTP odpovědí; simulovaná chyba filesystemu vyvolá hlášení chyby.

Testy reálného Producer kódu a stdio relay v Linuxu ověřují bezpečné doběhnutí
in-flight přenosu, zastavení reportování bez odeslání agent action, jednorázovou
platnost explicitního resume a omezení relay endpointů. Nejde o skutečné WSL
spuštění přes Windows interop.

Samostatný Codex klient prošel integračním scénářem s PROTOKOLOVOU NÁHRADOU App
Serveru: zahájení testovací úlohy, čekající schválení, odebrání z dashboardu,
ponechání živého RPC se stejným PID/threadem, opětovné připojení a dokončení.
Nespouštěl se skutečný model ani uživatelův Codex účet.

Bridge a Connection testy spouštějí skutečný extension.cjs pod NAHRAZENÝM VS Code
API. Ověřují příkazy, potvrzení/zrušení, souběžné kliknutí, trvalou pauzu,
nedokončené offline odebrání po opětovné aktivaci, oddělené pending credentials
více workspace, zachování společného hubToken a blokování pozdní aktivace Zoo API.
Nejde o skutečný VS Code Extension Host ani reálný Command Palette test.

**28 kontrol rozhraní Chromium, všechny úspěšné.** Z toho 13 regresních kontrol
samostatného dema (`docs/disconnect-demo-browser.json`) a 15 kontrol odebrání
(`docs/disconnect-browser.json`). Nové testy kontrolují rozsah i přes aktivní
filtr, zrušení/úspěch, historická a prázdná připojení, bezpečné vykreslení textu,
mobilní šířku, zobrazení chyb, použití zachycené epochy a ignorování opožděného
snapshotu. Používají inline samostatné demo nebo skutečnou UI větev se SIMULOVANÝM
fetch/EventSource. Nejde o end-to-end prohlížeč připojený ke skutečnému hubu.

Pokus `tests/duplicates_browser.py` se skutečnou navigací na localhost byl
zablokován politikou Chromium: `net::ERR_BLOCKED_BY_ADMINISTRATOR`. Tato kontrola
není započítaná mezi úspěšné. Ochrana prohlížeče nebyla vypnuta ani obcházena.
Podrobnosti jsou v `docs/disconnect-live-browser-blocked.txt`.

**31 nativních scénářů s náhradami Win32 API, všechny úspěšné.** Příkaz
`sh tests/native/run-tests.sh`, výstup `docs/disconnect-native-tests.txt`. Jde o
regresi kódu zastavování; skutečné Windows procesy, tray a mutexy tu neběžely.

## Sestavení distribučních balíčků

`python3 scripts/build-windows.py` sestavuje x64 MissionControl.exe,
MissionControlStop.exe a samorozbalovací instalační EXE. Součástí jsou dva VSIX
0.3.7; Connection obsahuje kontrolním součtem ověřenou identickou kopii Bridge.
`python3 scripts/validate-windows-package.py` prověřuje PE strukturu, oprávnění
asInvoker, vložený ZIP/CRC, shodu všech vložených souborů se zdroji, manifesty,
verze a přítomnost původních i nových ochranných větví. Jde o STATICKOU kontrolu.
Samostatný výstup s hashem finálního EXE je distribuovaný vedle instalátoru, aby
nevznikla kruhová závislost hashů balíčku.

Instalátor je nadále per-user Windows x64, s vlastní stávající připnutou verzí
Node runtime. Rozšíření této verze mění odpojení, nikoliv mechanismus aktualizace,
opravy, odinstalace nebo nalezení VS Code. Nativní a instalační zdroje mění kromě
návodu jen verzi a testovací verze dat.

## Neprovedené ověření a hranice

Skutečná instalace/upgrade/oprava/odinstalace ve Windows, PowerShell 5.1 průvodce,
Windows tray, skutečný VS Code Extension Host, nainstalované Zoo Code API,
Windows WSL interop a uživatelova SSH síť nebyly v tomto prostředí spuštěny.
Úspěšné linuxové testy tyto situace nenahrazují. EXE i VSIX nejsou digitálně
podepsané; ochranu Windows ani Workspace Trust kvůli nim nevypínejte.

Odpojení se týká celého identifikovaného připojení v jednom hubu, nikoli jednoho
chatu ani všech nezávislých hubů. Nesmaže projekt ani původní historii agentů,
ale odstraní kopii záznamů zdroje z aktivního dashboardového stavu. Zálohy dat
neprohledává. Standardní restart je testovaný; výpadek napájení, ruční smazání
state.json, poškození disku a ochrana proti neautorizovaným místním administrátorům
nejsou tímto ověřením pokryty.
