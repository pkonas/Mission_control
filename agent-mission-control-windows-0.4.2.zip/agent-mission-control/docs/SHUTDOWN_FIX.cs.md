## 0.3.2 — oprava timeoutu při aktualizaci z 0.2.0

- Opraveno: `ConvertTo-MCArgument` správně uvozoval `--quit`, ale starý tray parser tyto uvozovky nesprávně ignoroval. Nativní spouštěč nyní používá Windows `CommandLineToArgvW`, odmítá neznámé/rozporné přepínače a jeho `--quit` nic nespouští ani nevytváří.
- Instalace, oprava i odinstalace používají samostatný `MissionControlStop.exe`. Nespouští GUI, hub, Node.js ani shell. Před použitím proběhne bezstavová kontrola `--check`.
- Řadič ověřuje úplnou cestu instalovaného EXE, SID a relaci Windows; uchovává ověřené procesní handly. Nejprve pošle WM_CLOSE původnímu oknu tray. Pokud nereaguje, po omezeném čekání ukončí pouze tento ověřený tray. Nikdy neukončuje node.exe podle názvu, portu ani samotného PID.
- Pozoruje ukončení soukromého hubu (ověřená cesta, rodič a čas vzniku); vlastní hub je už od 0.2.0 v Job Object s KILL_ON_JOB_CLOSE. Nesouvisející procesy neukončuje.
- Už neběžící tray znamená úspěšný no-op, ne spuštění kopie aplikace z Temp. Nelze-li bezpečně ověřit zastavení, soubory se nemění.
- Chyba před výměnou souborů se už nehlásí jako provedená obnova souborů.
- Zachována automatická detekce VS Code, lokální bridge, automatické spouštění, aktualizace, oprava, odinstalace a zachování dat/tokenu.


Viz `WINDOWS_TEST_REPORT.md` pro skutečně provedené a neprovedené testy.
