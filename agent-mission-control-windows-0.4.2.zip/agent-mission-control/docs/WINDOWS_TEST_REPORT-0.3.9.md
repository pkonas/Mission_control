# Mission Control 0.3.9 — protokol ověření

Datum sestavení: 2. října 2026. Prostředí: Linux x64, Node.js v22.16.0,
clang/lld-link pro křížové sestavení Windows x64.

## Reprodukce chyby na původním balíčku

Původní zdroje byly rozbaleny přímo z dodaného
`agent-mission-control-windows-0.3.8.zip`. Test spustil původní Bridge, Producer
a HTTP hub; VS Code API a Zoo poskytovatel jsou testovací náhrady. Po odstranění
připojení se při dokončování čtení tokenu vyvolá událost změny workspace. Tím se
automatický start dostane před ruční start s příznakem obnovy.

Výsledek 0.3.8: `connected: false`, `paused: true`, `liveSessions: 0`.
Výsledek 0.3.9: `connected: true`, `paused: false`, `liveSessions: 1`.
Nový producer má jinou instanci; starý je zastavený, neexistují dvě živá spojení.

Strojové záznamy jsou v `docs/reconnect-race-0.3.8.json` a
`docs/reconnect-race-0.3.9.json`. Opakovatelný skript je
`tests/reproduce-recovery-race.mjs`; jako argument přijímá kořen rozbaleného
původního projektu. Bez argumentu testuje aktuální zdroje.

Tento výsledek je důkaz konkrétní chyby v původním kódu, nikoli důkaz přesné
příčiny na počítači uživatele. Původní obecná zpráva neobsahovala takové údaje,
aby se tyto příčiny daly rozlišit. Nová diagnostika proto ukazuje běžící build,
endpoint, fázi, kód, ID požadavku a potvrzenou verzi hubu.

## Testy aplikace

`node --test tests/*.test.mjs`: **265 testů prošlo, 0 selhalo, 0 přeskočeno**.
Úplný výstup: `docs/recovery-node-tests.tap`; výstupní kód je v
`docs/recovery-node-tests.exit` (0). Provedený finální běh trval přibližně 37 s.

Nové testy v `tests/recovery.test.mjs` (16 scénářů) a doplněný test Connection
ověřují zejména zachování explicitního požadavku při souběhu, dvacet kliknutí,
selhání automatického startu, skutečný HTTP a stdio přenos, identitu odpovědi,
odmítnutí cookie autentizace na producer endpointu, ochranu živého vlastníka,
staré instance, zápis stavu a restart skutečného hubu, selhání zápisu,
ukončení neúspěšného explicitního pokusu a report bez tokenů/chatů.

Součástí je i statická kontrola deklarace runtime build; není označená za test
skutečného Extension Hostu. Test s novým manifestem a chybějícím runtime build
ověřuje, že Connection nepovažuje instalaci na disk za načtení nového kódu.

VS Code API a Zoo úlohy jsou nahrazené. Stdio relay běží přes skutečný podproces
Node.js v Linuxu, nikoli přes Windows interop. Nebylo použito `--test-force-exit`.

## Nativní kód

`sh tests/native/run-tests.sh`: **31 scénářů prošlo**. Testy kompilují aktuální
nativní kód s náhradami Win32 API. Výstup: `docs/recovery-native-tests.txt`.
Testují zastavovací řadič a parsování argumentů, nikoli skutečný Windows tray.

Křížové sestavení `scripts/build-windows.py` vytváří skutečné Windows x64 PE:
`MissionControl.exe`, `MissionControlStop.exe` a instalační EXE s vloženým ZIP.
Nejde o spuštění těchto souborů ve Windows. VSIX se generují ze stejných zdrojů.

Po sestavení se samostatně provádí `scripts/validate-windows-package.py`:
kontrola struktury PE, manifestu/asInvoker, absence certifikátu, bezpečných cest
ZIP, CRC a shody vložených souborů se zdroji, včetně vnořeného bridge VSIX.
Výstup této kontroly je distribuován samostatně jako
`Mission-Control-Windows-balicek-testy-0.3.9.json`, aby nebyl kruhovou součástí
vlastního balíčku. SHA-256 součty jsou v samostatném souboru distribuce.

## Co neproběhlo

Skutečný Windows instalátor (ani aktualizace, oprava či odinstalace), PowerShell
5.1, Windows tray, skutečný VS Code Extension Host a Windows/WSL interoperabilita
zde spuštěné nebyly. Pokus získat VS Code pro test reálného Linuxového Extension
Hostu selhal kvůli nedostupnému DNS (`update.code.visualstudio.com`). Reálný host
proto netvrdíme jako otestovaný. Nebyl proveden nový test dashboardu v prohlížeči;
UI se v tomto vydání funkčně nemění.

Nebylo použito skutečné přihlášení ke Codexu, uživatelovo Zoo Code API, jeho
projekty ani jeho WSL/SSH síť. Instalační EXE a oba VSIX jsou nepodepsané.
Úspěch simulovaných testů není potvrzením bezchybného provozu na jeho počítači.
Ochranu Windows ani Workspace Trust kvůli balíčku nevypínejte.
