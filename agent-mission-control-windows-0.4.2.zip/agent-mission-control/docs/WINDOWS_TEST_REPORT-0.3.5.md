# Mission Control 0.3.5 — test report

## Executed in this build environment (Linux)

- `npm test`: **148 passed, 0 failed**. The 112 retained regression scenarios
  passed, plus **36 new tests** in `tests/connection.test.mjs`.
- `bash tests/native/run-tests.sh`: **31 passed** with injected Win32 API test
  doubles. These execute the native shutdown source, not Windows itself.
- JavaScript syntax checks completed for both extension entrypoints, the UI
  controller and the installer CLI adapter.
- Windows x64 PE binaries compiled from source using clang/lld-link; embedded
  manifests request ordinary user privileges and binaries remain unsigned.
- `scripts/validate-windows-package.py` checks PE headers, payload byte identity,
  UTF-8 BOM in PowerShell, prior lifecycle fixes, both VSIX identities, UI versus
  workspace execution kinds, and the exact nested bridge VSIX/checksum.

Raw Node output: `docs/connection-node-tests.tap`.
Raw native simulation output: `docs/connection-native-tests.txt`.
The static package JSON is provided separately after compilation.

## New scenario coverage

The UI companion's commands, status item and Explorer tree activate under an
injected VS Code API even with no workspace bridge. The actual workspace
bridge activation function registers its contributed commands in Restricted
Mode while refusing secret reads, subprocesses, pairing and collection.

The controller handles missing commands, activation errors, wrong hosts, old
versions, rejected consent, corrupted VSIX bytes, failed installation, and
installed-but-not-yet-active versions. It never treats a successful install
command as a live hub connection, never automatically reloads the editor and
refuses to downgrade an active newer bridge.

The CLI suite installs/validates both fixed extension IDs in the selected
profile. Missing/failed packages produce partial failure, repeated repair is
idempotent in the fixture, and uninstall preserves unrelated Codex/Zoo IDs.

## NOT executed / not certified

No real Windows PowerShell 5.1 UI run; no Windows installation, update, repair,
autostart, tray, uninstall, WSL interoperability or SSH VSIX-transfer test.
No genuine VS Code Extension Host / command-palette UI test. A download of the
VS Code Linux test executable could not be obtained in this environment.
Node mocks and PE/source inspection do not substitute for those tests.

## Remaining scope boundaries

The exact cause of the user's missing command is not remotely established:
wrong host, inactive profile, disabled extension or activation failure remain
possible. 0.3.4's workspace-only manifest and CLI-local installation are proven
from the supplied source. 0.3.5 adds a local UI companion instead of pretending
that a workspace collector can safely run locally for remote projects.

CLI success verifies files in the selected local profile only. The companion
then checks actual bridge replies in the current window. It does not install
into unopened remote hosts or create a network tunnel. Disabled extensions,
enterprise policies, certificate warnings, trust decisions and user-selected
window reloads are not bypassed. Both new VSIX files require VS Code >=1.100.

## Source attribution

Implementation uses VS Code's documented `workbench.extensions.installExtension`
with a VSIX URI and the UI/workspace host model:
https://code.visualstudio.com/api/references/commands
https://code.visualstudio.com/api/advanced-topics/extension-host
https://code.visualstudio.com/docs/configure/command-line
