# Oprava 0.3.3

Nový instalátor opravuje `The path is not of a legal form.` při `File.Replace`.
Zachovává aktualizaci, opravu, odinstalování i detekci VS Code. Předchozí aplikaci neodinstalovávejte, její data nemažte.

Funkce `Write-MCAtomic` dostává místo `$null` platnou záložní cestu. Preflight zkouší opakované nahrazení souborů před zastavením původní aplikace.
Nové body logu: `MC_ATOMIC_WRITE_OK`, `MC_PORT_WRITE_OK`, `MC_MAINTENANCE_CACHE_OK`.
Podrobné ověření a omezení: `WINDOWS_TEST_REPORT.md`.
