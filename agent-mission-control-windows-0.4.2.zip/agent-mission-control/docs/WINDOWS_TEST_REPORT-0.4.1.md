# Mission Control 0.4.1 — protokol ověření

Sestavení: 2026-10-03, Linux x86_64. Nová funkcionalita: konkrétní Zoo Run/Deny,
aplikační okno upozornění s výchozí dobou 60 sekund a navigace na původní událost.
Nejde o záznam úspěšné instalace nebo provozu ve Windows.

## Skutečně provedené kontroly

| Oblast | Výsledek | Co se skutečně spustilo |
|---|---|---|
| Node.js | 371/371 | Produkční hub, úložiště, projektová projekce, migrace, přenos HTTP/stdio a kód doplňků s náhradami VS Code API. |
| Nové Zoo kontroly | 30 unit + 10 integračních (zahrnuto v 371) | Produkční ZooControl; skutečný HTTP hub a Producer; testovací Zoo Task, žádný shell příkaz. |
| Nová upozornění | 19 (zahrnuto v 371) | Identita událostí, historie, persistence, origin/autentizace, desktop fronta, odmítnutí zastaralých položek. |
| Chromium | 54/54 | 30 projektových a 24 nových Zoo/notifikačních kontrol skutečného HTML/CSS/JS. Hub a cookie autentizace jsou skutečné, fetch/SSE mají testovací přenosovou vrstvu. |
| C / simulované Win32 API | 45/45 | 31 dosavadních scénářů zastavení/parseru a 14 nových scénářů časovače a cíle upozornění. Ne Windows GUI. |
| Sanitizéry nového C kódu | 14/14 opakovaně | Nové nativní scénáře s AddressSanitizer a UndefinedBehaviorSanitizer. Nepočítají se znovu do 45. |
| Instalátor | 34 statických kontrol | PE x64, asInvoker, absence podpisu, vložený ZIP, shoda souborů, VSIX a jejich vnořeného hashe, nové Win32 importy a trasy akcí. |

Poslední úplný Node běh má 371 passed, 0 failed, 0 skipped, 0 cancelled.
Příkazy pro zopakování jsou níže. Reporty browseru jsou v test-results/0.4.1.
Statický report finálního EXE se distribuuje také samostatně s hashem tohoto EXE.

## Co nové testy ověřují

Run i Deny putují přes skutečnou frontu příkazů k produkčnímu adaptéru a končí
voláním metody konkrétního testovacího Task objektu. Obecné primary/secondary
API je v testech nastavené tak, aby při použití selhalo. Změna objektu úlohy,
objektu dotazu (i se shodným timestampem a textem), obsahu, času, příznaků,
odpovědi z VS Code a odpojení zabrání předání nesprávnému cíli.

20 souběžných HTTP pokusů o stejnou akci vytvoří jedno přijetí a 19 konfliktů.
Rozhodnutí se po výjimce nebo nejasném výsledku automaticky neopakuje. Po
potvrzení předání zmizí staré schvalovací tlačítko i pozornost k tomuto dotazu;
do nové události agenta se netvrdí, že příkaz úspěšně běží nebo skončil.

Browser kontroluje úplný text v potvrzení včetně chráněné operace, neaktivní
vložené HTML, Run, Deny, zrušení dialogu, zamítnutí zastaralého potvrzení, viditelnou
zpětnou vazbu, staré upozornění po novém dotazu, zrušení skrývajícího filtru,
přihlášení jednorázovým desktop odkazem se zachováním notice ID a odebraný
projekt bez automatického obnovení. Základní pravidlo jeden projekt/jeden řádek
zůstává otestované. Screenshoty jsou označené jako testovací data.

Nativní jednotkové testy kompilují skutečný notification.h s náhradami Win32.
Kontrolují výchozích 60 sekund, povolené intervaly, vypršení, režim do zavření,
ukazatel nad oknem, explicitní kliknutí/klávesové příkazy a neměnný cílový ID.
Neměří skutečné zobrazení/rozložení Win32 okna ani nastavení Soustředění.

## Co ověřené není

- Skutečný instalátor/upgrade/oprava/odinstalování ve Windows a Windows PowerShell 5.1.
- Skutečný VS Code Extension Host, nainstalované Zoo Code, jeho UI a skutečný příkaz po schválení.
- Nativní popup ve Windows, monitor/DPI/čtečka obrazovky, aktivace prohlížeče a všechna nastavení Soustředění.
- Skutečná WSL interoperabilita a konkrétní uživatelova konfigurace SSH.
- Přímé browser–SSE spojení v tomto prostředí. Chromium zde blokuje navigaci na loopback i testovací HTTP origin. Browser testy proto používají set_content, fetch proxy na skutečný HTTP hub a polling snímků místo EventSource. Jednorázové přihlášení a lookup události přesto provádí skutečný hub.

Testovací běhy se nepočítají jako důkaz produkční kompatibility. Výsledky
neznamenají, že byl opraven dříve hlášený prázdný dashboard v cizí instalaci.

## Kompatibilitní hranice Zoo

Veřejné API neumí v použitém zdroji podmínit primary/secondary rozhodnutí
identitou dotazu. Tato verze proto používá kontrolovaný vnitřní Task objekt.
Je to verzově citlivá integrace, nikoli stabilní veřejný kontrakt. Při chybějícím
rozhraní nebo neověřitelném dotazu zůstává pouze čtení, nikdy obecné klikání.
Ani strukturální kontrola není záruka sémantiky všech budoucích verzí. Podrobnosti
jsou v docs/ZOO_ACTIONS_041.cs.md. V běžném projektu se nic neschvaluje automaticky.

## Reprodukce

```sh
node --test --test-concurrency=6 tests/*.test.mjs
node scripts/build-preview.mjs
python tests/projects_browser.py /tmp/mc-project-browser
python tests/zoo_browser.py /tmp/mc-zoo-browser
bash tests/native/run-tests.sh
cc -std=c11 -fshort-wchar -fno-builtin -ffunction-sections -fdata-sections \
  -Wl,--gc-sections -Wall -Wextra -Werror -Wno-unused-function \
  tests/native/notification-test.c -o /tmp/mc-notification-test
/tmp/mc-notification-test
python scripts/build-windows.py
python scripts/validate-windows-package.py
```

Pro nový nativní test se používá také -fsanitize=address,undefined. Pro Chromium
je potřeba Python Playwright a /usr/bin/chromium. Cross-build vyžaduje clang a
lld-link, nikoli běžící Windows. EXE a VSIX jsou nepodepsané; systémové ochrany
kvůli instalaci nevypínejte.
