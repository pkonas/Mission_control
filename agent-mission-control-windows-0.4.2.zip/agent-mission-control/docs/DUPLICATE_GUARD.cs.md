# Mission Control 0.3.6 — ochrana proti duplicitním relacím

## Co tato verze mění

Jedna relace konkrétního agenta má v jednom hubu jeden záznam a jednoho aktivního zapisovatele. Opakované připojení už není způsob, jak vytvořit další kopii stejného chatu.

- **V jednom okně:** příkazy Connect, Connect to Windows App a Setup Connection neprovádějí nové párování, pokud je bridge připojený nebo právě obnovuje spojení. Souběžná volání používají jednu probíhající operaci. Panel místo připojování ukazuje stav připojení.
- **Ve druhém okně:** stejný host a stejná množina složek dostávají stabilní identitu bridge. Hub druhého aktivního vlastníka odmítne. Nezastaví původní bridge, VS Code ani agenty.
- **Na serveru:** záznamy rozlišuje host, kanonická cesta projektu, nástroj a skutečné ID jeho úlohy. Změna náhodného sourceId nevytvoří druhý záznam stejné úlohy. Kolizní dávka se odmítne celá, bez přepsání stavu, odkazu do okna nebo požadavků na schválení.
- **Po odpojení:** nové spojení převezme existující záznam. Zachová jeho klíč, odložení upozornění a dostupnou historii. U běžného ukončení se vlastnictví uvolňuje ihned po dokončení případného probíhajícího přenosu; při pádu vyprší po 30 sekundách od posledního potvrzeného kontaktu.

Odlišné úlohy Zoo Code a Codexu nejsou sloučeny jen proto, že sdílejí projekt nebo mají podobný název. Více chatů v již připojeném projektu může mít samostatné řádky. Jeden další bridge téhož workspace ale nesmí současně přebrat totožné napojení.

## Aktualizace

1. Spusťte MissionControl-Setup-0.3.6-x64.exe pod dosavadním Windows účtem. Vyberte aktualizaci a ponechte instalaci obou doplňků Connection + Bridge ve správném profilu VS Code. Původní aplikaci předem neodinstalovávejte.
2. Po doběhnutí práce agentů použijte v příslušných oknech Developer: Reload Window. Instalátor tento krok nevynucuje. Na vzdálené straně WSL/SSH ověřte také Bridge 0.3.6 přes místní Connection panel (Setup Connection / instalace bridge zde).
3. Připojený panel má ukázat Připojeno — zobrazit stav. Opakovaný Connect má sdělit, že spojení již existuje. Ve druhém okně se při konfliktu objeví informace o původním spojení; původní řádek zůstane jediný.

Je potřeba aktualizovat hub i doplňky. Bridge 0.3.6 vyžaduje ochranu hubu 0.3.6 nebo novější. Starší bridge může hubu posílat události kvůli kompatibilitě; hub však ani jemu nedovolí vytvořit další záznam stejné aktivní relace. Starý doplněk nemá nové stavové hlášky ani ochranu tlačítek, proto doporučujeme dokončit aktualizaci ve všech používaných profilech a hostech.

## Již existující duplicity

Při prvním načtení staršího state.json hub nejprve vytvoří kopii state.before-0.3.6.json ve stejné datové složce. Ve standardní Windows instalaci je to %LOCALAPPDATA%\AgentMissionControl. Bez možnosti vytvořit zálohu se převod neprovede (existující záloha se nepřepisuje).

Přesné shody úlohy se při načtení spojí do jednoho **odpojeného** záznamu. Zvolí se novější známý stav a spojí dostupné zprávy a události v dosavadních mezích: 30 zpráv a 100 událostí. Původní uložený snapshot zůstává v záloze. Žádná úloha se nespouští a žádné schválení se během převodu neodesílá. Záznam získá stav připojeno až po nové živé události oprávněného bridge.

Neshody identity se neslučují odhadem. U starých záznamů, které neobsahují nové ID hostu ani kanonickou cestu, závisí porovnání na uloženém hostiteli, cestě a ID úlohy. Historické záznamy pod různými nerozpoznatelnými aliasy tak mohou vyžadovat ruční odstranění odpojeného záznamu.

## Technické hranice a bezpečnost

Ochrana platí v rámci **jednoho hubu**, ne mezi několika nezávislými instalacemi hubu. Týká se připojení a evidence Mission Control, nikoli zákazu vytvářet nové skutečné chaty přímo v Codexu nebo Zoo Code.

Na extension hostu se po povoleném párování vytvoří náhodné místní ID v ~/.agent-mission-control/host-<hash>.id. Neobsahuje token a nesynchronizuje se přes VS Code profil. Záměrně zůstává u bridge i po odinstalaci Windows hubu. Cesty jsou řešeny přes realpath; pořadí a opakování kořenů workspace nemění jeho identitu. Windows cesty jsou porovnávány bez rozlišení velikosti písmen, POSIX cesty ji rozlišují. Windows složky s nestandardně zapnutou citlivostí na velikost písmen nejsou tímto porovnáním zvlášť podporované. Windows a WSL zůstávají oddělená prostředí; jiný host ani jiný worktree se nesloučí.

Aktivní spojení se identifikuje dvojicí sourceId + epoch. Claim, ingest a release ověřují aktuálního vlastníka. Release od staré instance neodpojí novou. Fronta příkazů je také svázaná s konkrétní epoch: staré schválení se po výměně bridge nedoručí novému vlastníkovi. Žádné automatické přehrávání příkazů ani automatické schvalování.

Spravovaný klient Codexu si rezervuje připojení před spuštěním App Serveru a před vytvořením threadu. Standardní identita klienta je stabilní pro host a pracovní složku, místo dřívější náhodné hodnoty. Více záměrně odlišných spravovaných klientů může mít explicitně odlišné sourceId; skutečná stejnost již známého threadu je stále hlídána hubem.

Komunikace WSL nadále používá soukromý stdio relay. Přibyly pouze ověřené endpointy claim a release; desktopové řízení ani libovolné adresy relay nepovoluje. Instalace, oprava, odinstalování, nalezení VS Code a předchozí opravy instalátoru zůstávají zachované.

## Ověření

Viz docs/WINDOWS_TEST_REPORT-0.3.6.md. EXE a VSIX nejsou podepsané. Ochranu Windows ani Workspace Trust kvůli instalaci nevypínejte. Skutečná instalace ve Windows a skutečný VS Code Extension Host nebyly v tomto prostředí spuštěny.
