# Windows automation 0.2.0 — validation report

## Executed successfully

**54 Node.js automated tests**, including the original hub/store/normalizer/client tests plus 12 desktop-auth/status tests and 4 stdio-relay tests. Command: `node --test tests/*.test.mjs`. All 54 passed. The runner was Linux with Node.js 22.16.0; the downloaded Windows Node.js 24.21.0 binary was not executed here.

Coverage added for this version: independent desktop credentials, bounded random ticket generation, single-use and expiring login tickets, protected cookies, anti-CSRF origin checks, rejection of producer credentials on desktop administration, unread/snoozed/disconnected attention handling, stable status fingerprints, no project text in tray summaries, restricted relay destinations/endpoints, relay authentication failure, and transport shutdown.

**13 Chromium UI smoke checks** passed against the rebuilt self-contained demo: filtering, search, messages/diffs, acknowledgements, snooze, simulated changes, setup help, HTML escaping, responsive layouts, and absence of uncaught JavaScript errors. Command: `python tests/browser_smoke.py`.

**Native cross-compilation:** the tray and self-extracting setup program were built for Windows x64 by clang/lld-link. C compilation used `-Wall -Wextra -Werror`. The executable format, Windows GUI subsystem, import tables, resources, and asInvoker manifest are inspected by the packaging validation script. Executables use only standard Windows DLL imports and have no .NET or VC redistributable dependency; the graphical installer itself uses the Windows PowerShell 5.1 / .NET Framework components already required by its script.

## Not executed / limitations

A live-navigation Chromium test was attempted, but this environment's managed `URLBlocklist` blocked navigation to the loopback URL with `ERR_BLOCKED_BY_ADMINISTRATOR`. No browser policy was modified. That attempted check is not counted among the 13 successful demo checks. The optional script `tests/desktop_browser.py` is included for running in a normal development environment.

There is **no Windows runtime available here**. Consequently the following were not executed: PowerShell wizard on Windows, download/extraction of the pinned Windows Node runtime, system-tray notification behavior, startup at Windows logon, Job Object shutdown, cross-process single-instance coordination, update/uninstall, native browser launch, VSIX installation, WSL Windows interop, or a real SSH connection. Cross-compilation is not proof of those behaviors on the user's system.

The Node relay tests execute the Windows-relay JavaScript using the Linux Node process; they validate its protocol, not WSL process interoperability.

The installer and tray EXE are **unsigned**. There is no SmartScreen reputation, Authenticode verification or Windows compatibility certification for this build. The pinned SHA-256 values for the Node ZIP and node.exe are from the official Node.js release listing and are enforced by the installer; the Windows download itself was not available to verify in this environment.

The exact final binaries and source archive have SHA-256 hashes in the accompanying SHA256SUMS.txt. Raw test output is included alongside this report.

## Suggested first Windows validation

Use a non-production Windows account: install; verify the icon and health check; pair one trusted test workspace; close the browser and trigger a synthetic attention event; terminate only the owned hub node.exe in Task Manager and check recovery; launch the shortcut twice and check a single tray instance; sign out/in; then uninstall and confirm that project files and default retained data remain. Close WSL bridge sessions before updating/uninstalling to avoid their relay holding the old runtime open. None of these Windows checks are claimed as completed here.
