# Mission Control 0.3.9 — obnovení odpojeného připojení

## Nasazení bez mazání dat

Spusťte `MissionControl-Setup-0.3.9-x64.exe` pod stejným Windows účtem jako
předchozí instalaci. Vyberte Aktualizovat a ponechte instalaci Connection + Bridge
v používaném profilu VS Code. Zachované jsou oprava, aktualizace, odinstalování,
autostart, hledání VS Code, historie, port a párovací token.

Hub i oba doplňky musí být aktualizované. Ve WSL/SSH patří Bridge do vzdáleného
extension hostu, Connection zůstává místně. Panel nabídne opravu chybějící nebo
staré verze. Instalátor ani doplněk automaticky nerestartují VS Code.
Po dokončení rozpracovaných úloh použijte `Developer: Reload Window`.

Ve stejném okně projektu potom spusťte:

```
Mission Control: Reconnect This Workspace
```

Samotný Bridge má příkaz `Mission Control: Reconnect`. Není potřeba mazat token,
`state.json`, záměr odpojení ani VS Code workspaceState. Obnova nic neschvaluje,
nevytváří nový chat a nepřebírá živé připojení jiného okna.

## Co bylo skutečně reprodukováno

Na původním kódu 0.3.8 byl reprodukován souběh automatického startu po události
změny workspace a ručního Reconnect. Pomocná funkce sdílela jednu rozpracovanou
operaci bez ohledu na její parametry. Ruční obnova tak mohla dostat výsledek
obyčejného automatického startu, který správně respektoval uložené odpojení,
ale sám neměl povolení je obnovit. Ruční požadavek se neprovedl.

Test používá původní kód Bridge a skutečný HTTP hub. VS Code API a událost změny
workspace jsou testovací náhrady. Ve stejném scénáři je 0.3.8 nepřipojená
(`connected: false`, 0 zobrazených relací), zatímco 0.3.9 má jedno živé připojení
a jednu úlohu. Původní i nový výsledek jsou v `docs/reconnect-race-0.3.8.json`
a `docs/reconnect-race-0.3.9.json`.

Samotná obecná hláška uživatele nedokazuje, že u něj nastal právě tento souběh.
Další možností je dosud načtený starší Bridge v jiném hostu nebo profilu. Verze
0.3.9 proto nepovažuje údaj z manifestu na disku za ověření běžícího kódu.

## Změny v 0.3.9

Ruční obnova se zařadí za rozpracovaný automatický start a nesmí se v něm ztratit.
Opakovaná kliknutí sdílí jednu obnovu; současně běží nanejvýš jeden kolektor.

Obnova má samostatný autentizovaný požadavek `POST /api/reconnect`. Hub ověří
vlastnictví, novou instanci a uloží změnu záměru. Bridge přijme úspěch jen pro
stejné ID workspace, stejnou instanci a stejné ID požadavku. Staré instance
zůstávají zakázané; jiná připojení se neresetují. Původní `/api/claim` zůstává
pro běžný start a kompatibilní starší klienty.

Při chybě nové explicitní obnovy se oprávnění k obnově neudržuje v nekonečné
smyčce automatických pokusů. Pro další obnovu je nutný nový vědomý příkaz.
Po neúspěšném zápisu stavu hub neponechá nepotvrzenou živou rezervaci.

Načtený Bridge hlásí pevné `runtimeBuild: 0.3.9-recovery.1` a vedle něj zvlášť
verzi manifestu. Connection vyžaduje potvrzení běžícího kódu. Instalace na disk
proto nadále neznamená automaticky aktivaci ve všech oknech.

## Jak poznat výsledek

Po úspěchu se zobrazí oznámení o potvrzeném připojení k hubu. V diagnostice je
`MC_RECOVERY_OK` a `hubVersion: 0.3.9`. Pokud už je stejné připojení živé,
obnova jej ponechá a diagnostika uvede `ALREADY_CONNECTED`.

Úloha v dashboardu se objeví až po načtení dostupných událostí agenta. Připojení
může být v nastavení dashboardu viditelné i bez rozpoznané aktivní úlohy.
Pozorování původních chatů Codexu zůstává experimentální a není zárukou zachycení
všech žádostí o schválení. Tato verze integrační omezení Codexu nemění.

Při neúspěchu explicitního požadavku se otevře výstup Mission Control s konkrétní
fází, kódem chyby, endpointem a identifikátorem požadavku. Například
`HUB_UPGRADE_REQUIRED` znamená chybějící nový endpoint; `CONNECTION_IN_USE`
znamená jiné živé okno; `RECOVERY_SAVE_FAILED` neúspěšný zápis stavu.
U `CONNECTION_REMOVED` je důvod rozlišen jako odpojený zdroj nebo stará instance.

Přehled bez tokenů a obsahu chatů získáte příkazem:

```
Mission Control: Copy Connection Report
```

Příkaz jej zkopíruje do schránky a zobrazí ve výstupu. Obsahuje verze, prostředí,
stav, hash identity workspace a metadata poslední obnovy. Nic nikam neodesílá.
Pokud tento příkaz chybí, nové zdroje Bridge v daném okně dosud nejsou načtené.

## Rozsah ověření

Aktuální výsledky jsou v `docs/WINDOWS_TEST_REPORT-0.3.9.md`. Přenos HTTP a
stdio relay byly testované v Linuxu; nejde o skutečnou Windows/WSL interoperabilitu.
Windows instalátor, PowerShell 5.1 a skutečný VS Code Extension Host zde nebyly
spuštěné. Pokus stáhnout VS Code pro test skutečného hostu selhal na DNS v tomto
prostředí. Tato mezera není nahrazena simulacemi ani velkým počtem testů.

EXE a VSIX nejsou digitálně podepsané. Ochranu Windows ani Workspace Trust
kvůli instalaci nevypínejte.

Oficiální popis rozdělení místních a vzdálených extension hostů:
`https://code.visualstudio.com/api/advanced-topics/extension-host`.
