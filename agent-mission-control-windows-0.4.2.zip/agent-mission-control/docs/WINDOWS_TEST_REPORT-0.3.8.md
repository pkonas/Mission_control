# Mission Control 0.3.8 — protokol ověření

Datum sestavení: 2026-10-02. Prostředí: Linux, Node.js v22.16.0, Python 3,
clang a lld-link (cross-compilation pro Windows x64).

## Výsledky skutečně provedených testů

**248 automatických testů Node.js: 248 úspěšných, 0 chyb, 0 přeskočených.**
Příkaz: `node --test tests/*.test.mjs`; plný výstup je
`docs/reconnect-node-tests.tap`. Zahrnují 224 dosavadních testů a 24 nových
regresních scénářů obnovy (`tests/reconnect.test.mjs`). Některé starší testy
byly upraveny pro nové pravidlo: panel nesmí zahodit explicitní příkaz pouze
podle cache; kontrolu vlastnictví provádí Bridge a hub. Testy ochrany proti
souběžnému párování a dvěma aktivním vlastníkům zůstávají zachované.

Nové integrační scénáře společně vykonávají produkční `extension.cjs`,
`Producer`, `controller.cjs`, normalizaci Zoo úloh a skutečný HTTP hub. Náhradou
je pouze VS Code API, úložiště VS Code a testovací Zoo poskytovatel. Nejde o
samostatný mock úspěšného Produceru jako u některých starších jednotkových testů.

Ověřeno: odstranění přes dashboard před doručením heartbeat odpovědi a obnovení
všemi původními/novými cestami, již zjištěná vzdálená pauza, odpojení příkazem
ve VS Code, obnovení po restartu rozšíření se stejným uloženým záměrem, opožděný
zápis místní pauzy a nedostupný hub bez falešného úspěchu. Dvacet souběžných
pokusů vytváří jedinou novou instanci připojení. Aktivní vlastník v jiném okně,
aktivní jiný projekt, staré epochy i staré odpojovací požadavky jsou chráněné.

Zvláštní test simuluje notifikace, které uživatel nezavřel. Příkazy Disconnect,
Reconnect a Connect se musí dokončit nezávisle na těchto neukončených Thenable;
čekání na skutečné potvrzení odpojení zůstává zachované.

Test stdio relay spouští reálný `windows/wsl-relay.cjs` jako podproces Node.js
v Linuxu, nikoli Windows interop. Prochází přes něj odebrání, ověření vlastnictví
a obnovení. Testy autentizace ověřují oddělení cookie/bearer přístupu.
Čtecí endpoint ověření vlastnictví neprodlužuje lease ani nespotřebuje čekající
schvalovací příkaz. Testovaný příkaz je pouze syntetická položka fronty, nikoli
skutečný agentní příkaz.

Explicitní resume je ověřené se skutečným zápisem na disk před HTTP odpovědí,
při následném restartu hubu a s vloženou chybou filesystemu. Opuštění blokace
není potvrzeno při chybě zápisu. Standardní restart není zárukou proti výpadku
napájení nebo poškození disku.

**31 nativních scénářů: všechny úspěšné.** Příkaz
`sh tests/native/run-tests.sh`, výstup `docs/reconnect-native-tests.txt`.
Jde o regresi zastavovacího kódu s náhradami Win32 API, nikoli test skutečných
Windows procesů, mutexů, instalace nebo tray.

## Reprodukce na původním kódu 0.3.7

`docs/reconnect-reproduced-0.3.7.json`: úspěšně odstraněný zdroj nemá v hubu žádné
řádky, ale původní panel má stále connected=true a příkaz Setup odmítne předat.

`docs/reconnect-toast-reproduced-0.3.7.json`: původní Disconnect dokončí odebrání
v hubu, ale do zavření běžné notifikace drží disconnecting=true. Následující
Connect je proto blokovaný. Obě reprodukce používají původní soubory z balíčku
0.3.7, skutečný HTTP hub a náhradu VS Code API. Nedokládají, který z těchto stavů
byl právě aktivní u uživatele.

Oficiální kontrakt notifikací uvádí dokončení Thenable až po volbě akce nebo
zavření oznámení. Zdroj: `https://code.visualstudio.com/api/references/vscode-api`
(sekce `window.showInformationMessage`).

## Sestavení a statická kontrola

`python3 scripts/build-windows.py` sestavuje `MissionControl.exe`,
`MissionControlStop.exe`, oba VSIX 0.3.8 a samorozbalovací instalátor x64.
`python3 scripts/validate-windows-package.py` kontroluje PE strukturu, manifest
0.3.8.0/asInvoker, nepřítomnost podpisu, bezpečné položky ZIP, CRC a byte-for-byte
shodu celého vloženého balíčku se zdroji. Kontroluje také shodnou vnořenou kopii
Bridge v Connection, příkazy Reconnect, nové ověřovací rozhraní a dřívější ochrany.

Finální výstup kontroly a SHA-256 instalátoru je distribuován samostatně jako
`Mission-Control-Windows-balicek-testy-0.3.8.json`; není vložen do vlastního EXE,
aby nevznikla kruhová závislost hashů. Kontrolní součty distribuovaných souborů
jsou v `SHA256SUMS-Mission-Control-0.3.8.txt`.

## Co nebylo spuštěno

Windows instalátor/upgrade/repair/uninstall, PowerShell 5.1, tray, skutečný
VS Code Extension Host, UI Command Palette, nainstalované Zoo Code, reálný
Codex účet, Windows WSL interop a uživatelova SSH síť nebyly ověřené. Pokus získat
VS Code pro další linuxový Extension Host test zablokovalo DNS tohoto prostředí;
žádný takový test není započítaný. Nový prohlížečový test dashboardu se v této
verzi nespouštěl; jeho ovládání nebylo měněné (jen zobrazené číslo verze).

EXE a VSIX nejsou podepsané. Ochranu Windows ani Workspace Trust kvůli nim
nevypínejte. Testy výše jsou přesně vymezené, nejsou potvrzením bezchybného
produkčního upgradu konkrétního Windows počítače.
