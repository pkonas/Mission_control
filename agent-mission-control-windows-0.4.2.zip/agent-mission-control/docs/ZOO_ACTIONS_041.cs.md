# Mission Control 0.4.1 — Zoo Run/Deny a upozornění na konkrétní událost

## Použití

V seznamu stále platí **jeden projekt, jeden řádek**. Vyberte projekt → **Teď**.
Pokud má aktuální úloha postranního panelu Zoo Code ověřený nezodpovězený
požadavek na povolení příkazu, nástroje nebo MCP, její karta nabídne:

**Run · povolit** předá souhlas právě tomuto dotazu. **Deny · zamítnout** předá
zamítnutí téhož dotazu. Následuje dialog s projektem, pracovní složkou a celým
textem příkazu nebo strukturovaným obsahem požadavku. Zrušení dialogu nic
neodesílá. Příznak chráněné operace se zobrazí výslovně. Rozhodnutí nepotvrzuje
úspěšné dokončení příkazu; výsledek sledujte v aktivitě agenta.

Není tu „vždy povolit“, automatické schvalování ani globální zastavení agenta.
Každý dotaz má vlastní identitu. Změněný dotaz, jiná úloha, odpověď z VS Code,
vypršelý příkaz, jiné připojení nebo druhý souběžný pokus se odmítnou. Při
nejasném výsledku se rozhodnutí automaticky neopakuje. Ověřte stav ve VS Code.
Otevření upozornění ani označení projektu jako viděného nic neschvaluje.

## Kompatibilita Zoo Code — důležité

Veřejné Zoo API `pressPrimaryButton` / `pressSecondaryButton` cílí obecně na
aktuální panel a nemá parametr očekávané identity dotazu. Proto ho pro tuto
funkci nepoužíváme. Nestačilo by ověřit stav před asynchronním kliknutím: mezitím
by se mohl zobrazit jiný dotaz.

Adaptér `bridge/src/zoo-control.cjs` používá kompatibilitní vrstvu nad skutečným
Task objektem: `api.sidebarProvider.getCurrentTask()` a synchronní
`Task.handleWebviewAskResponse()`. V aktuálním zdroji jde o TypeScript-private
vlastnosti dostupné v JavaScriptu, **nikoli stabilní veřejný integrační kontrakt**.
Kontrolují se dostupné členy, reference objektu, ID úlohy, timestamp/typ/úplný
obsah dotazu, příznaky a nezodpovězený stav. Kontrola a předání odpovědi nejsou
oddělené `await` ani obecnou zprávou do webview.

Pokud se vnitřní API změnilo, dotaz není aktuální nebo ho nelze úplně zobrazit,
Run/Deny se nenabídne. Karta vysvětlí důvod a odkáže na VS Code. Nikdy se
nepřechází na neověřené obecné klikání. Skutečnou kompatibilitu s nainstalovanou
verzí Zoo Code je potřeba ověřit v cílovém prostředí; zde byl použit testovací
Zoo objekt odpovídající ověřenému zdroji. Samotná kontrola členů není důkazem
sémantické kompatibility všech budoucích verzí.

Podporované ask typy: `command`, `tool`, `use_mcp_server`. Nepodporované jsou
volný text (`followup`), pokračování již běžícího terminálu (`command_output`),
obnovení úlohy, dokončení a neznámé typy. Není podporováno ovládání libovolného
neaktivního nebo samostatného editorového panelu Zoo. Požadavky s obrázky,
automatickým rozhodnutím nebo textem delším než 24 000 znaků se řeší ve VS Code.
UI je nikdy nezkrátí na akční souhlas bez úplného obsahu.

V nastavení VS Code lze ovládání vypnout:

```json
{"missionControl.zooDashboardControls": false}
```

Výchozí hodnota je true, ale monitorování i ovládání stále vyžadují trusted
workspace, aktivní vlastnictví připojení, Zoo adaptér a potvrzení v dashboardu.
Ovládání původních chatů Codexu přes čtení JSONL se touto změnou nepřidává.

## Upozornění u lišty

Nové **aplikační okno Mission Control** pro události projektu zůstává standardně
**60 sekund**. Nastavení: pravým tlačítkem na ikonu Mission Control u hodin →
**Doba upozornění: 30 sekund / 60 sekund / 2 minuty / 5 minut / do zavření**.
Volba se uloží pro aktuální Windows účet. Nad oknem podržený ukazatel oddálí
jeho zavření. Zobrazení nežádá aktivaci editoru ani nepřebírá jeho klávesnici.

Jde o vlastní Win32 okno, nikoli položku systémového Centra oznámení Windows.
Doba běžného balloon upozornění je v nových Windows řízena systémem; nepřepisujeme
kvůli tomu globální přístupnost ani nastavení ostatních aplikací. Servisní hlášky
tray (například kopírování tokenu nebo chyba hubu) nadále používají původní
balónek; delší interval je určený pro **události projektů**.

Zobrazuje se jeden neměnný cíl upozornění najednou. Další události jsou dostupné
v dashboardu přes **Upozornění**; nevyřízená fronta pokračuje po zavření okna.
Při volbě „do zavření“ tedy zavřete staré okno pro zobrazení dalšího. Neaktuální
požadavek čekající ve frontě se přeskočí. Windows režimy oznámené přes
`SHQueryUserNotificationState` jako zaneprázdnění/fullscreen/prezentace zobrazení
odloží. To není ověření všech režimů Soustředění ve Windows 10/11.

Kliknutí na tělo nebo **Otevřít událost** otevře přihlášený dashboard, vybere
správný projekt, zruší filtr, který by ho skrýval, a zvýrazní původní událost.
Cíl se nemění příchodem nového dotazu. Je-li původní požadavek vyřízený nebo
změněný, stránka to sdělí; nesmí jej zaměnit za jiný požadavek na schválení.
Odebraný projekt se automaticky nepřipojí. Zobrazí se pouze původní událost.

Historie posledních 200 upozornění je součástí místního stavu hubu; obsahuje
omezený výňatek zprávy (max. 2 000 znaků), identifikátory a čas. Neobsahuje
párovací token. Přehled v dialogu zobrazuje posledních 50. Dřívější vytlačený
odkaz ohlásí nedostupnou událost a nevybere náhradní cíl. Po restartu hubu se
historie zachová, ale stará fronta popupů se znovu nepřehrává.

Samotné okno u lišty ukazuje jen projekt/nástroj/druh události, ne celý příkaz
či obsah chatu. Webový přehled je dostupný až po přihlášení. Při běhu bez
Windows tray používá prohlížeč `requireInteraction`; skutečnou dobu tam
určuje prohlížeč a operační systém. Zavřený prohlížeč nemá vlastní službu.

## Aktualizace

Spusťte `MissionControl-Setup-0.4.1-x64.exe` pod stejným účtem a vyberte
**Aktualizovat**, včetně **Connection + Bridge** v používaném profilu. Data,
port, token, projektový model a nastavení připojení zůstávají zachované.
Zachovány jsou oprava, odinstalování, autostart, soukromý Node runtime a detekce
VS Code. Nemažte stav ani neodinstalovávejte předchozí verzi.

Po dokončení rozpracovaných úloh použijte `Developer: Reload Window` a obnovte
stránku dashboardu. Ve WSL/SSH aktualizujte i vzdálený Bridge přes Connection.
Spuštěný runtime Bridge se hlásí jako **0.4.1-zoo-actions.1**. Pro změny jsou
potřeba hub, tray a doplňky 0.4.1; samotný VSIX neopraví starý tray/hub.
Instalátor nevynucuje restart VS Code ani neukončuje jeho agenty.

Dříve odebraný projekt připojte vědomě přes `Mission Control: Reconnect This
Workspace`. Více kořenů v jednom okně: `Mission Control: Select Zoo Project Root`.
Tato aktualizace není potvrzením odstranění dříve nahlášeného prázdného dashboardu;
při takovém problému použijte existující diagnostiku spojení a Copy Connection Report.

## Ověření a zdroje

Podrobnosti: `docs/WINDOWS_TEST_REPORT-0.4.1.md`. Testy běží v Linuxu se skutečným
hubem a kódem bridge; VS Code API, Zoo Task a Win32 API jsou tam, kde je potřeba,
explicitně nahrazené. Skutečný Windows instalátor, reálná UI tlačítka Zoo,
VS Code Extension Host, nativní popup a WSL interop nebyly v tomto prostředí
spuštěné. EXE a VSIX nejsou podepsané. Bezpečnostní ochrany kvůli nim nevypínejte.

Primární zdroje ověřené při implementaci 2026-10-03:
- Zoo API: https://github.com/Zoo-Code-Org/Zoo-Code/blob/main/src/extension/api.ts
- Zoo Task: https://github.com/Zoo-Code-Org/Zoo-Code/blob/main/src/core/task/Task.ts
- Win32 balloon: https://learn.microsoft.com/en-us/windows/win32/api/shellapi/ns-shellapi-notifyicondataw
