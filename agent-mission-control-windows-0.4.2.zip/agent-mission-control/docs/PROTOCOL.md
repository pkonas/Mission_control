## 0.3.9 explicit recovery endpoint

`POST /api/reconnect` requires a producer bearer token, `version: 1`, `sourceId`,
a fresh `epoch`, `recoveryProtocol: 1`, `userInitiated: true`, and a bounded
alphanumeric/hyphen `requestId`. It reuses claim ownership rules with explicit
resume, waits for persistence, rechecks ownership and returns `accepted`, the
same source/epoch/request ID, `recoveryProtocol: 1` and `hubVersion`.
No browser-cookie access, no active-owner takeover, no global reset, no agent action.
A legacy claim route is retained; 0.3.9 explicit recovery never silently falls back
to it. A missing endpoint is an upgrade error. The WSL relay allows this exact
producer endpoint and forwards structured errors. `CONNECTION_REMOVED` now also
identifies `source-detached` vs `epoch-retired` in producer errors.

## 0.3.8 reconnect extension

`GET /api/connection-status?sourceId=<id>&epoch=<epoch>` requires the producer
Bearer token. Returns `protocol:1`, `sourceId`, `epoch`, `owned:boolean`, `state`
and an explanatory `code`/`message` when not owned. It does not create a source,
renew a lease, consume commands or clear a tombstone. Browser cookies do not
have access. The WSL relay permits only GET on this endpoint.

`POST /api/claim` with explicit `resume:true` now persists the cleared removal
intent before success. Source and epoch identity checks still apply, including
retired epochs and the live owner. The existing disconnectVersion remains 1;
the payload format is otherwise compatible. On persistence failure the request
fails even if in-memory state changed. No durability claim covers power loss.

# Protokol lokálního hubu v1

Tento dokument popisuje vlastní protokol Mission Control, nikoliv záruku upstream API. Typový kontrakt je v `src/protocol.ts`. Runtime nemá závislost na TypeScript compileru.

## Připojení

Hub naslouchá na loopbacku, standardně `127.0.0.1:4317`. Producent používá `Authorization: Bearer <hub-token>`. Token není klíč poskytovatele modelu. Z vzdáleného extension hostu se připojuje přes loopback konec SSH reverse tunelu.

Prohlížeč používá `POST /api/login` s JSON `{ "token": "..." }`. Hub vydá HttpOnly SameSite=Strict cookie. Browser Origin/Host musí odpovídat skutečnému hubu. Jiný loopback Host port je povolen pouze producentovi s platným Bearer tokenem bez browser Origin.

## Ingest

`POST /api/ingest` přijímá následující strukturu (hodnoty jsou příklad):

```json
{
  "version": 1,
  "sourceId": "vscode-window-instance",
  "epoch": "random-connection-uuid",
  "seq": 1,
  "label": "dev02 / backend",
  "health": "Zoo API připojeno",
  "sessions": [{
    "id": "native-agent-task-id",
    "project": "backend",
    "workspace": "/home/me/projects/backend",
    "agent": "zoo",
    "environment": "Remote SSH",
    "host": "dev02",
    "state": "needs_input",
    "evidence": "api",
    "activity": "Agent žádá odpověď",
    "activityAt": 1790880000000,
    "stateSince": 1790880000000,
    "capabilities": ["open"],
    "events": [],
    "messages": [],
    "files": [],
    "pending": []
  }]
}
```

`sourceId` identifikuje instanci producenta, `epoch` každé nové připojení a `seq` striktně rostoucí pořadí v dané epoše. Staré pořadí se ignoruje. Nahrazená epocha už nesmí převzít zdroj zpět. Identita relace v hubu je hash dvojice sourceId/native session ID, nikoliv samotný název projektu.

Dávky jsou **upsert**, ne smazání celého inventáře. Každá relace má vlastní `lastReported`; opomenutá relace po 30 sekundách nebude vypadat připojená ani při pokračujícím heartbeat zdroje. Dávky producenta zůstávají pod 2,5 MB, hub odmítá těla nad 3 MiB. V jednom požadavku lze přijmout nejvýše 100 relací, celkem nejvýše 200 relací a 50 zdrojů. Limity chrání MVP, nejsou plánem horizontálního škálování.

`evidence=api` znamená zprávu adaptéru z agent API, ne kryptografické ověření pravdivosti. Všichni držitelé společného tokenu jsou důvěryhodní. `observed` označuje experimentální čtení historie: hub takové relaci odebere ovládací oprávnění, kromě otevření původního panelu. `demo` je výhradně výslovná ukázka.

## Stav

Agentové stavy jsou `unknown`, `idle`, `working`, `needs_input`, `needs_approval`, `error`, `review`, `paused`. `disconnected` vzniká až při výpočtu snapshotu hubem. Stav z uloženého snapshotu se po restartu neoznačí za připojený bez nového reportu.

Chybějící heartbeat >30 s znamená odpojení. U pozorovaného Codexu se `working` bez aktivity >90 s změní na neověřený stav. Ověřený pracující agent bez aktivity >10 min dostane upozornění na nečinnost, nikoliv automatickou chybu či approval.

`stateRevision` chrání ovládání před zastaralým kliknutím. `acknowledgedFor` a `snoozeUntil` jsou lidské anotace oddělené od stavu agenta. Ovládací tlačítko nikdy není odvozené jen z textu poslední zprávy.

## UI a anotace

`GET /api/state` vrací snapshot. `GET /api/events` posílá totéž přes Server-Sent Events při změně a periodicky. UI při ztrátě SSE přestane prezentovat relace jako živé.

`POST /api/annotate` přijímá `key` a `acknowledge: true` nebo `snoozeMinutes` (0 nebo 15 z UI). `POST /api/forget` smaže jen odpojenou relaci. Žádná z těchto akcí neodešle příkaz agentovi.

## Explicitní příkazy

`POST /api/action` s cookie přijímá `key`, `stateRevision`, `action` a příslušná data. Zoo/observed bridge mají pouze `open`, který vrací validované callback URI od bridge. Vlastní klient Codexu může mít `prompt`, `approve`, `input`, `interrupt`. Oprávnění a živost se ověřují znovu v hubu i klientovi.

`approve` se váže na konkrétní pending request ID; podporovány jsou pouze `accept`, `decline`, `cancel` pro jednotlivou akci, ne pro celou relaci. Žádosti o rozšířené permissions tento klient automaticky nepovoluje. `input` používá mapu question ID na pole odpovědí. `interrupt` se váže na současný turn ID.

Producent vyzvedává příkazy přes `GET /api/commands?sourceId=...`. Po předání jsou odstraněny z fronty a **nepřehrávají se** při opakovaném pollu. `POST /api/result` potvrzuje korelaci `{sourceId, id, ok, message}`. Browser sleduje `GET /api/action/:id`. Fronta má omezenou TTL; chybějící potvrzení po předání vede k výsledku `unknown`, nikoliv k tvrzení o neprovedení. Výpadek těsně po předání může znamenat ztracený příkaz nebo ztracené ACK. Jde o at-most-once doručení, nikoliv přesně-jednou provedení.

## Persistování a soukromí

Snapshot `.data/state.json` se ukládá přes dočasný soubor a rename. Nejde o databázi, transakční log ani úplnou auditní historii. Ukládají se omezené zprávy, události a diff v otevřeném textu; callback URI se do persistovaného snapshotu nezahrnuje. Hub token je zvlášť v `.data/token`. Browser sessions a příkazová fronta nepřežívají restart.


## Connection ownership and identity (0.3.6)

`POST /api/claim` and `/api/release` use producer Bearer authentication and `{version:1, sourceId, epoch, label}`. Claim renewals by the same epoch are idempotent. A different live owner returns HTTP 409 `CONNECTION_IN_USE`; no implicit takeover. A normal release is conditional on both source and epoch. An absent/crashed owner expires after 30 seconds without a heartbeat.

Ingest from the new producer includes `leaseVersion:1`. Sessions may include `hostId` and `canonicalWorkspace`. Canonical identity excludes the producer's random process identity and includes the actual agent task ID and agent namespace. Conflicts return HTTP 409 `SESSION_IN_USE` with the existing key and owner label. No row is silently hidden and no winning state is overwritten. The entire batch is validated synchronously before writes.

`GET /api/commands` must include `epoch` for lease-enabled producers; `POST /api/result` includes `epoch` too. Each queued command binds to `sourceEpoch`, not just a source name. Commands from an earlier incarnation fail rather than being replayed.

Legacy ingestion is supported, with server-side exact-task uniqueness. A new client requires the claim endpoint and reports an upgrade requirement on an old hub; it does not silently fall back to unprotected registration. The compatibility flow is not a permission system between mutually untrusted holders of the same producer token.

Identity is scoped to one hub. Trusted producers must provide correct host and task identities. Remote filesystem canonicalization occurs on the bridge host, not by probing remote folders from the hub. Legacy aliases without sufficient metadata are not guessed. Stable host markers do not contain pairing credentials.


## Explicit removal (0.3.7)

`POST /api/disconnect` requires an authenticated dashboard cookie and the same
origin/host checks as other UI writes. Body: `{sourceId, epoch}` where epoch is
the captured source `connectionEpoch`, or null for offline restored sources.
`POST /api/disconnect-source` is the bearer-only producer equivalent. It requires
the usual `{version:1,sourceId,epoch}` envelope and is allowed through the bounded
WSL stdio relay. Neither route is an agent action or a desktop shutdown route.

A matching disconnect records the opt-out, retires the owner epoch, removes all
of the source's session snapshots, removes it from visible sources and saves the
state before returning `{removed:true,count,sourceId}`. A later source claim or
report without explicit resume returns 409 CONNECTION_REMOVED. A stale disconnect
cannot affect a different current epoch (409 NOT_OWNER). Paused source records
and retired epochs are serialized separately from leases; no lease is restored
from disk. Normal `/api/release` semantics are unchanged.

An explicit user connect sends `resume:true` on exactly its first successful claim
with a NEW epoch. It clears the source opt-out but never resurrects an old owner.
Queued commands for a removed source become failed; delivered ones become unknown.
An old delivered command cannot be confirmed by a replacement owner.

Snapshots now contain `hubId`, regenerated per hub process. UI ignores an older
revision within the same hubId to prevent delayed snapshots from reintroducing
removed rows, while accepting a new hub's lower initial revision.

VS Code stores an explicit pause/pending envelope in workspaceState and a
pending-removal token in SecretStorage under a source+epoch key. No token enters
the snapshot, workspace settings, URLs, command palette arguments or logs.
