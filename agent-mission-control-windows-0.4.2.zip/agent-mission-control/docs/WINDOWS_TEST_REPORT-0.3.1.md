# Mission Control 0.3.1 — protokol ověření

## Skutečně spuštěné testy

Prostředí sestavení: Linux x64, Node.js v22.16.0, clang a lld-link.

`node --test tests/*.test.mjs`: **103 / 103 prošlo**. Výstup aktuálního běhu je v `docs/vscode-discovery-node-tests.tap`.

28 nových testů v `tests/vscode-layout.test.mjs` kontroluje zejména:
- oficiální strukturu starého a verzovaného code.cmd, bez kořenového resources;
- výběr aktivní verze i při přítomnosti další/staged verze;
- oddělení Stable/Insiders, portable metadata a vlastní datové adresáře;
- zachování mezer, diakritiky a znaků %, &, ! v cestách;
- odmítnutí chybějícího, nejednoznačného, přesměrovaného nebo poškozeného CLI;
- odstranění zděděných IPC/portable/debug proměnných;
- preflight, instalaci a ověření ve stejném cíli a profilu;
- nezaměňování DEP0169 za návratový kód;
- pokračující běh nesouvisejícího testovacího procesu během instalace bridge proti simulovanému CLI.

Předchozí regresní testy CLI, hubu, identity instalace, tokenu a bridge byly znovu spuštěny. Simulované CLI **není opravdové VS Code**. Soubory Code.exe v testech layoutu jsou pouze dočasné testovací zástupné soubory a nikdy se nespouštějí.

## Binární balíček

Instalátor a tray aplikace jsou sestaveny jako x64 Windows GUI PE pomocí clang/lld-link. `scripts/validate-windows-package.py` kontroluje PE hlavičky, nepřítomnost podpisu, manifest asInvoker, CRC vloženého ZIP, shodu vložených souborů se zdroji a bezpečné relativní cesty. Výsledek aktuální kontroly je přiložen samostatně jako `Mission-Control-Windows-balicek-0.3.1.json`.

## Neprovedené testy / omezení

V tomto prostředí není Windows, Windows PowerShell 5.1 ani spustitelný PowerShell. **Nebyl spuštěn Windows instalátor, formulář, CIM/WMI, registry ani COM čtení zástupců.** Nebyla reálně ověřena instalace do otevřeného VS Code, Windows tray, autostart, oprava, odinstalování ani WSL/SSH. Statické kontroly a Linux mock testy toto nenahrazují.

K dispozici jsou kontrolní skripty pro Windows, které zde nebyly spuštěny:

```powershell
powershell.exe -NoProfile -File .\windows\Test-InstallerLogic.ps1
powershell.exe -NoProfile -File .\windows\Test-CodeDiscovery.ps1 -Live
```

Druhý skript čte lokální cesty procesů/registrů/zástupců, nic neinstaluje ani neukončuje. Pracuje pouze s dočasnou testovací složkou, kterou po testu odstraní. Nepřekračujte kvůli spuštění firemní pravidla pro skripty.

## Doporučený akceptační test na Windows

Ponechat VS Code otevřené na neprodukčním projektu. Spustit Setup 0.3.1, zkontrolovat automaticky vyplněné Code.exe a případný profil/datové složky. Aktualizovat z 0.3.0 bez odinstalace. Potvrdit v protokolu zdroj cesty, přesné CLI, úspěšný preflight a bridge 0.3.1. Ověřit, že původní okno i jeho práce zůstaly otevřené. Teprve po dokončení úloh agentů provést Developer: Reload Window. Potom vyzkoušet Opravit a na testovacím účtu Odinstalovat s ponecháním dat.

Při potížích protokol rozlišuje nenalezené EXE, neplatný launcher, nefunkční CLI a neúspěšné ověření bridge. Chyba není zakryta hlášením o úspěchu bridge; běh samotného hubu se hodnotí zvlášť.
