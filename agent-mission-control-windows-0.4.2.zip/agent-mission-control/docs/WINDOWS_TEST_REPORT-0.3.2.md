# Mission Control 0.3.2 — protokol opravy a ověření

## Co bylo nalezeno v dodaných zdrojích

`windows/Common.ps1` předává argument přes `ConvertTo-MCArgument` jako `"--quit"`. Staré `windows/native/tray.c` používalo ruční `hasArg`, které tento tvar nerozpozná. Pokud proces v daném kontextu nenašel původní mutex, mohl místo vypnutí spustit normální smyčku nové tray aplikace z dočasného instalačního adresáře; vnější `Invoke-MCProcess` pak vypršel po 25 sekundách. To odpovídá chybové větvi v dodaném logu. Samotný log nedokazuje, zda v tu chvíli běžela původní tray ve stejné Windows relaci. Tato oprava pokrývá obě varianty.

Změněný `--quit` používá Windows parser a nemá cestu, která by při vypínání vytvářela okno/hub. Instalátor navíc už tray EXE k zastavení vůbec nespouští: nový řadič nemá startovací režim.

## Skutečně spuštěné testy

Prostředí: Linux x64, Node.js v22.16.0, GCC/Clang a lld-link. Windows runtime zde nebyl k dispozici.

**103/103 testů Node.js prošlo** (`node --test tests/*.test.mjs`). Záznam: `docs/shutdown-node-tests.tap`. Patří sem hub, desktop autentizace/identita, relay, bridge normalizace, VS Code layout a simulované CLI. Testy s falešným Code.exe nejsou testy opravdového VS Code.

**31/31 scénářů nativních zdrojů prošlo** (`sh tests/native/run-tests.sh`). Testy přímo kompilují aktuální `shutdown.h` a `arguments.h`, ale nahrazují Win32 API testovacími funkcemi. Záznam: `docs/shutdown-native-tests.txt`. Znovu prošly i pod AddressSanitizer + UndefinedBehaviorSanitizer; záznam: `docs/shutdown-native-sanitizer-tests.txt`.

Scénáře zahrnují zejména již zastavenou aplikaci, běžné ukončení, nereagující tray, odepřená oprávnění, vypršení čekání, zbylý hub, ochranu jiného Code.exe/node.exe, shodný název v jiné cestě, jiného uživatele, jinou Windows relaci, neověřitelnou cestu/uživatele, opětovné použití rodičovského PID, chybu enumerace a přepínač v uvozovkách z původní chyby. Parsování uvozovek ve skutečném Windows API je v těchto Linux testech simulované, nikoli provedené.

**Binární balíček:** sestaveny tři Windows x64 GUI PE (`MissionControl.exe`, `MissionControlStop.exe`, Setup). Kontrolovány PE hlavičky, asInvoker manifest, nepřítomnost podpisu, CRC a úplná shoda souborů vloženého ZIP se zdroji. Samostatný stop řadič nesmí importovat CreateProcess/ShellExecute/CreateWindow; tray a řadič musejí importovat CommandLineToArgvW. Výsledky statické kontroly jsou distribuovány samostatně.

## Neprovedené testy — důležité

**Nebylo provedeno skutečné spuštění Windows instalátoru, Windows PowerShell 5.1, skutečné WM_CLOSE/Job Object ukončení, tray GUI, upgrade 0.2.0 → 0.3.2, oprava, odinstalace ani provoz s opravdovým VS Code/WSL/SSH.** Statické kontroly a Linux simulace je nenahrazují. Instalátor je opravený sestavený prototyp, nikoli certifikované produkční vydání. EXE není podepsaný. Ochranu Windows ani firemní pravidla kvůli němu nevypínejte.

## Přibalené Windows kontroly (zde nespouštěné)

`windows/Test-Shutdown.ps1` spouští nové binární soubory se samostatným dočasným LOCALAPPDATA. Ověří skutečné Windows parsování `"--quit"`, neexistující instanci a no-op řadič. Tím nesmí cílit na skutečnou uživatelskou instalaci. Další existující skripty: `Test-InstallerLogic.ps1`, `Test-CodeDiscovery.ps1`.

Instalátor automaticky ověří `MissionControlStop.exe --check` dříve, než cokoli ukončí. Kontrola neslouží jako náhrada testů celého Windows instalačního průvodce.

## Přijímací scénář pro Windows

Spustit nový EXE pod stejným účtem jako 0.2.0, ponechat neprodukční VS Code projekty otevřené. Zvolit Aktualizovat. Protokol musí potvrdit `MCSTOP_VERIFIED_STOPPED` nebo `MCSTOP_ALREADY_STOPPED`, teprve poté přejít k výměně souborů, spuštění/ověření nového hubu a instalaci bridge. Následně ověřit opakovanou opravu a odinstalaci s výchozím ponecháním dat.

Pokud běžné ukončení nereaguje, fallback ukončí pouze ověřenou tray. Neuložené poslední události monitoru se přitom mohou ztratit, nikoli kód z projektů; agenti nejsou součástí tohoto hub Job Object. Úlohy, projekty, systémový Node.js a bezpečnostní nastavení řadič nemění. Pokud při procesu nelze ověřit identitu, narazí na jinou Windows relaci nebo vlastní hub nezanikne, aktualizace bezpečně skončí s diagnostikou místo plošného zabíjení procesů.
