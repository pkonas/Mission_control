# Mission Control — Codex + Zoo Code

**Verze 0.1.0 · lokální MVP · 1. října 2026**

Jeden přehled napříč projekty: kdo pracuje, kdo potřebuje odpověď nebo schválení a co se právě děje. Původní rozšíření mohou zůstat nainstalovaná a používaná. Součástí je skutečný lokální hub, prohlížečové rozhraní, instalovatelný VS Code bridge a samostatný klient Codex App Serveru.

**Nejde o univerzální napojení na všechny již otevřené chaty.** Zoo Code používá extension API. Pozorování existujících Codex relací čte pouze uložené JSONL události a je experimentální. Přesný živý protokol Codexu je dostupný pro samostatné relace spuštěné přiloženým klientem, nikoli automaticky pro chaty původního VS Code doplňku.

## 1. Nejdřív si prohlédněte UI

Otevřete `dashboard-demo.html` přímo v prohlížeči. Je to samostatný soubor bez CDN, bez síťových požadavků a bez skutečných agentů. Fungují filtry, hledání, detail aktivity, zprávy, diff, označení „Viděno“, odložení a simulace změny stavu tlačítkem ↻.

Pro testování UI přes lokální server:

```sh
node src/server.mjs --demo
```

Otevřete `http://127.0.0.1:4317`. Demo hub záměrně odmítá skutečné bridge. Do živého režimu přejdete ukončením demo procesu pomocí Ctrl+C a spuštěním bez `--demo`.

## 2. Spusťte skutečný dashboard

Potřebujete Node.js 22 nebo novější na stroji, kde poběží hub. Aplikace nemá runtime npm závislosti: není potřeba `npm install`, sestavení frontendu ani databázový server.

```sh
node --version
node src/server.mjs
```

Ve Windows lze také otevřít `start.cmd`. V Linuxu/WSL lze použít `./start.sh`.

Otevřete `http://127.0.0.1:4317`. První spuštění vygeneruje token, vypíše jej do terminálu a uloží do `.data/token`. Vložte jej do přihlašovacího dialogu dashboardu. **Není to OpenAI API klíč ani Zoo Code klíč.** Prohlížeč token vymění za HttpOnly cookie; token se nedává do URL ani do localStorage. Přihlášení platí 24 hodin a po restartu hubu je potřeba nové.

Živý režim začíná prázdný. Žádná ukázková čísla se nevydávají za vaše projekty.

Výchozí port je 4317. Jiný port lze nastavit pomocí `MC_PORT`. Úložiště lze změnit pomocí `MC_DATA_DIR`; nastavení platí pro proces hubu:

```powershell
$env:MC_PORT = "4317"
$env:MC_DATA_DIR = "$env:LOCALAPPDATA\MissionControl"
node src/server.mjs
```

```sh
MC_DATA_DIR="$HOME/.local/share/mission-control" node src/server.mjs
```

Při změně datového adresáře se změní umístění tokenu; upravte také `tokenFile` v případné konfiguraci klienta Codexu. V nastavení jednotlivých bridge musí port odpovídat skutečnému endpointu nebo SSH tunelu.

## 3. Zoo Code: připojte původní rozšíření

Balíček VSIX je lokálně sestavený, nepodepsaný a není publikovaný ve VS Code Marketplace. Zdroj je v `bridge/`; k opětovnému sestavení slouží `python scripts/package-vsix.py`.

V každém prostředí s projektem nainstalujte `dist/mission-control-bridge-0.1.0.vsix` příkazem VS Code **Extensions: Install from VSIX…**. U Remote SSH/WSL zkontrolujte, že je bridge nainstalovaný v příslušném vzdáleném extension hostu, ne jen v lokálním seznamu rozšíření. Nepotřebuje vlastní instalaci Node.js na vzdáleném stroji, používá runtime extension hostu.

Pro lokální VS Code lze použít také:

```sh
code --install-extension dist/mission-control-bridge-0.1.0.vsix
```

V požadovaném okně VS Code otevřete důvěryhodný projekt. Spusťte **Mission Control: Connect**, vložte URL hubu a jeho token. Token se ukládá do VS Code SecretStorage. Stav najdete vlevo dole jako `MC: live` / `MC: offline`. Podrobnou diagnostiku otevře **Mission Control: Show Diagnostics**.

Bridge vyhledává rozšíření `ZooCodeOrganization.zoo-code`. U odlišné distribuce lze změnit `missionControl.zooExtensionId`. Ověřte, že skutečně poskytuje stejné API. Bridge není oficiální produkt Zoo Code ani OpenAI.

Bridge odebírá task lifecycle a message události. Do hubu posílá průběh, poslední zprávy, dotazy a změny stavu. Neparsuje webview, nečte pixely a neautomatizuje klikání na tlačítka. **Zoo bridge je pouze pro sledování a otevření původního panelu: neodesílá zprávy ani nic neschvaluje.**

Připojte bridge ideálně před novým úkolem. K existující úloze přidá záznam, ale do první události ji označí jako „Stav neověřen“. API současného task stacku nedává úplný, bezpečně rekonstruovatelný živý stav všech již otevřených záložek. Historie před připojením se automaticky nedoplňuje.

Vícesložkový workspace: Zoo událost neobsahuje jednoznačný kořen projektu. V této verzi se použije první složka a zobrazí se poznámka. Pro nejjasnější rozdělení použijte jeden projekt na workspace.

## 4. Stávající Codex ve VS Code: experimentální pozorování

Spusťte **Mission Control: Enable Codex Observation** a potvrďte informaci o čtených datech. Vypnutí provede **Mission Control: Disable Codex Observation**.

Observer čte pouze nedávné `.jsonl` soubory pod `$CODEX_HOME/sessions`, případně `~/.codex/sessions`. Vlastní cestu nastavíte přes `missionControl.codexHome` — musí to být cesta na stroji extension hostu. Na Windows tedy jiná než uvnitř WSL. Nečte `auth.json`, tokeny ani API klíče. Filtruje relace podle `cwd` odpovídajícího otevřenému workspace a jeho podsložkám.

Je implementováno průběžné čtení po bajtech, zpracování neúplných řádků a UTF-8, základní události běhu, textové zprávy a názvy nástrojů. První čtení zahrnuje nejvýše posledních 256 KiB souboru; čtou se soubory změněné v posledních 48 hodinách, nejvýše 50 souborů. Proto nemusí být historie kompletní.

**Zásadní omezení: uložený záznam není živý kanál.** Codex nemusí zapsat čekající schválení, některé výstupy se ukládají zpožděně a nové formáty/paginovaná historie mohou být nekompatibilní. Observer se nepřipojuje na interní proces VS Code rozšíření. Relace má štítek `LOG` a vlastní vysvětlení. Po 90 sekundách bez nového záznamu se dříve pozorovaný běžící stav změní na „Stav neověřen“, ne na falešné „Čeká na odpověď“.

Pokud se nic neobjeví, ověřte skutečné umístění `CODEX_HOME` a obsah `sessions` na příslušném stroji. Prázdný výsledek není důkazem, že Codex nepracuje. Pro bezchybné upozornění na všechny vstupy stávajícího doplňku tato cesta nestačí.

## 5. Přesné Codex události: samostatný App Server klient

Tato volitelná cesta vytváří **novou vlastní relaci Codexu**. Nemění instalaci původního rozšíření, ale ani z něj automaticky nepřebírá běžící chat. Relaci ovládáte z dashboardu, kód zůstává ve vašem workspace otevřeném ve VS Code.

Na stroji projektu musí být funkční Codex CLI s vaším obvyklým přihlášením. Ověřte `codex --version` a přihlaste CLI standardním způsobem. Přiložený klient neshání ani nesdílí přihlašovací údaje; App Server použije své prostředí a běžnou konfiguraci Codexu.

Zkopírujte `codex.example.json` do `codex.local.json` a upravte zejména `cwd`, `hub`, `tokenFile` a případně `command`:

```json
{
  "hub": "http://127.0.0.1:4317",
  "tokenFile": ".data/token",
  "cwd": "/home/jan/projects/backend",
  "project": "Backend",
  "environment": "WSL",
  "command": ["codex"],
  "sandbox": "workspace-write"
}
```

`cwd` musí být absolutní cesta na stroji klienta. Relativní `tokenFile` se vyhodnotí vůči konfiguračnímu souboru. Na vzdáleném stroji vytvořte lokální soubor obsahující párovací token a omezte jeho práva; neposílejte token v argumentu příkazového řádku. Alternativou je proměnná prostředí `MC_TOKEN`.

```sh
node src/codex-client.mjs --config codex.local.json
```

Klient spustí `codex app-server --listen stdio://`, provede handshake a založí thread. **Samotné spuštění klienta neodešle žádný úkol modelu.** Nové zadání odešlete až tlačítkem v dashboardu. Model může podle své konfigurace používat placené prostředky stejně jako obvyklý Codex; dashboard nemá vlastní účetní limit.

Podporovány jsou textové prompty, průběžné texty, výstup příkazů, turn diff, přerušení, jednorázové schválení/odmítnutí příkazu nebo změny souborů a textové odpovědi na `requestUserInput`. Odpověď se vždy páruje s konkrétním request ID. Neimplementované žádosti o rozšířená oprávnění se nikdy automaticky neschválí; lze přerušit běh. UI nevydává samotné odeslání schválení za dokončení operace.

Používá se `approvalPolicy: on-request`. Bez nastavení `sandbox` je výchozí `read-only`; příklad výše výslovně používá `workspace-write`, aby agent mohl psát do projektu. Ani `on-request` neznamená dotaz před každým příkazem — rozhoduje sandbox a politika Codexu. Režim `danger-full-access` tento klient nenabízí.

Na Windows nemusí Node.js spustit npm wrapper `codex.cmd` bez shellu. Shell je záměrně vypnutý. Použijte nativní `codex.exe`, nebo zadejte pole `command` s `node` a skutečnou cestou k nainstalovanému `codex/bin/codex.js`. Snazší je tuto komponentu provozovat uvnitř WSL. Pole argumentů se předává bez shellové interpolace.

Jedna instance klienta = jeden projekt / thread. Pro více projektů spusťte více klientů s vlastními konfiguracemi. Ctrl+C ukončí klienta i jím spuštěný App Server. Tato verze vlastní relace po restartu automaticky neobnovuje. Nepoužívejte současně dva agenty pro konfliktní změny ve stejných souborech bez koordinace; samostatné Git worktrees mohou oddělit jejich práci.

## 6. Windows + WSL + Remote SSH

### Doporučený začátek: jeden hub uvnitř WSL

Spusťte hub ve WSL, otevřete jeho URL ve Windows prohlížeči. WSL dokumentuje přístup z Windows k linuxovým aplikacím přes localhost; u konkrétní konfigurace ověřte dostupnost. Bridge ve WSL používá `http://127.0.0.1:4317`. Windows bridge může při funkčním WSL localhost forwarding použít stejnou adresu.

Výhodou je, že nemusíte zpřístupnit Windows loopback službu do NAT sítě WSL. Pro tento postup potřebujete Node.js uvnitř WSL, ne pouze ve Windows. Není potřeba měnit nastavení sítě automatickým skriptem.

### Hub běžící nativně ve Windows

Lokální Windows bridge připojte přímo. Přístup WSL → Windows `127.0.0.1` závisí na síťovém režimu. V již zapnutém mirrored režimu může fungovat stejná loopback adresa. V NAT režimu prosté použití IP Windows nestačí: hub naslouchá výhradně na loopbacku. **Nepřepínejte hub na `0.0.0.0`.** Využijte zabezpečený SSH tunel přes už existující SSH server, nebo přesuňte hub do WSL. Tento balíček nezapíná SSH server, firewall ani mirrored networking za vás.

### Vzdálený Linux přes SSH

Z hostitele hubu (například z WSL) spusťte samostatný tunel:

```sh
ssh -N \
  -o ExitOnForwardFailure=yes \
  -o ServerAliveInterval=30 \
  -o ServerAliveCountMax=3 \
  -R 127.0.0.1:4318:127.0.0.1:4317 user@server
```

Vzdálený bridge / Codex klient pak použije `http://127.0.0.1:4318`. Tunel znamená: port 4318 na vzdáleném loopbacku se přepošle do portu 4317 na počítači, odkud běží `ssh`. Hub akceptuje jiný loopback Host port pouze u autentizovaného producenta bez browser Origin, takže tento tunel funguje bez oslabení kontroly browser požadavků.

Tunel nechte spuštěný. Každý nezávislý vzdálený server může mít vlastní loopback port 4318. Pokud SSH server zakazuje remote forwarding, musí to vyřešit jeho správce. Nepoužívejte veřejný reverse forward ani sdílený neověřený proxy server.

Prohlížeč dashboardu přistupuje k hubu na jeho vlastním lokálním portu. Libovolný odlišný port pro browser forward není automaticky povolen kvůli kontrole Host/Origin. SSH reverse forwarding v tomto návodu je určen producentům.

## 7. Co znamenají stavy a tlačítka

- **Pracuje:** agent API oznámilo práci, případně je jasně označen nedávný pozorovaný záznam Codexu.
- **Čeká na odpověď / schválení:** skutečná interaktivní událost/API žádost, nikoliv odhad z délky pauzy nebo otazníku v textu.
- **Ke kontrole:** dokončený běh / dokončovací výstup k revizi. Není to garance správnosti kódu nebo úspěchu všech testů.
- **Odpojeno / Stav neověřen:** spojení nebo důkaz aktuálního stavu chybí; agent může nadále pracovat.

„Viděno“ označuje pouze upozornění jako přečtené. Čekající stav zůstane viditelný. Odložení ztiší notifikace na 15 minut, ale agenta nepřeruší ani mu neodpoví. Nový stav má vlastní revizi, takže staré potvrzení nezakryje nový požadavek.

„Otevřít VS Code“ používá callback registrovaného bridge přes `asExternalUri`. Prohlížeč může vyžadovat souhlas s otevřením aplikace. Správné směrování a přesunutí okna do popředí závisí také na VS Code, operačním systému a remote konfiguraci; není zaručeno univerzálně. Historická Zoo úloha se sama neobnoví, aby obnovení nepřerušilo jinou práci. U Codexu se otevírá původní panel, ne garantovaně konkrétní chat. Samostatné App Server relace takový bridge callback nemají a tlačítko je vypnuté.

Git přehled uvádí změny **celého workspace**, včetně vašich ručních úprav a jiných agentů. Počty souborů se nepřisuzují jednomu agentovi. Zoo bridge neposílá celé Git diffy; u Codex App Serveru lze zobrazit diff aktuálního běhu z jeho události.

Klávesnice: `/` zaměří hledání, `j`/`k` přechází mezi relacemi, Escape zavře dialog. Seznam relací i detail mají nezávislé posouvání.

## 8. Notifikace a přerušení spojení

Klikněte na „Upozornění“ a povolte prohlížeči systémové notifikace. Notifikace odcházejí při relevantní změně stavu, ne s každým tokenem. Kliknutí na notifikaci vybere relaci v dashboardu. Do titulku záložky se přidává počet nepřečtených položek.

**Stránka musí zůstat otevřená.** Nejde o nativní tray aplikaci, service worker ani systémovou službu. Režim Nerušit, oprávnění systému, uspávání prohlížeče nebo stroje mohou doručení ovlivnit. Po zavření stránky nejsou notifikace zajištěny. Spuštění po přihlášení a Tauri/Electron obal nejsou součástí této verze.

Producer se pokouší posílat změny zhruba po sekundě a heartbeat nejméně po pěti sekundách při funkčním spojení. UI přenáší snapshots přes Server-Sent Events; producer používá autentizované HTTP dávky. Exponenciální reconnect backoff omezuje opakované chyby. Po zhruba 30 sekundách bez potvrzené zprávy je relace odpojena. Dlouhá nečinnost ověřeného pracujícího agenta se po 10 minutách označí k prověření — ne jako jistá chyba.

Příkazy k agentům se nepřehrávají automaticky. Po vypršení čekání na ACK zobrazí UI nejistý výsledek; může být nutné zkontrolovat původní relaci, ne kliknout znovu. Běžné události jsou verzované a deduplikované podle source/epoch/sequence.

## 9. Data a bezpečnost

Hub se váže pouze na `127.0.0.1` (programaticky lze i `::1`) a odmítá cizí browser Origin a Host. Producenti používají Bearer token, prohlížeč HttpOnly SameSite cookie. Cesty k souborům ani obsah zpráv se nespouštějí jako příkazy; renderují se s HTML escapingem. Odpovědi na serverové approval requests se validují podle ID, typu a živého stavu. Neexistuje hromadné automatické schvalování.

To je ochrana **jednouživatelského lokálního MVP**, ne bezpečnostní audit ani multi-tenant oprávnění. Všechny připojené stroje a procesy s párovacím tokenem musí být důvěryhodné. Jeden sdílený token nemá oddělená oprávnění per host. Nezveřejňujte hub na internetu.

`.data/state.json` obsahuje omezené snapshots, poslední zprávy a případný kód v otevřeném textu. Adresář nevkládejte do Git repozitáře ani veřejného synchronizovaného úložiště. Na POSIX vznikají soubory s režimem 0600, ale na Windows ochranu určují také NTFS ACL. Data nejsou aplikačně šifrovaná. Pro vymazání historie hub zastavte a odstraňte `state.json`. Pro rotaci tokenu hub zastavte, odstraňte token a znovu spárujte všechny bridge.

Počet relací je omezen na 200 v hubu, 80 v jednom VS Code bridge. Uloženo je nejvýše 100 posledních událostí a 30 zpráv na relaci a oříznutý diff; nejde o kompletní auditní historii. Staré odpojené relace lze odstranit přes nabídku detailu. Odpojený zdroj může být v diagnostice viditelný až do restartu hubu.

Hub nemá vlastní cloudovou službu ani telemetrii. **To nemění síťové chování Codexu ani Zoo Code**: jejich modely, autentizace a poskytovatelé nadále fungují podle jejich konfigurace. Prompty/terminálové výstupy mohou samy obsahovat citlivé údaje; automatická spolehlivá redakce všech tajemství zde není.

## 10. Testy a známá hranice ověření

```sh
npm test
# nebo přímo
node --test tests/*.test.mjs
```

Přiložené testy používají jen vestavěný Node.js runner. Pokrývají normalizaci stavů, neúplné UTF-8 záznamy, deduplikaci, odpojení, autentizaci, Host/Origin kontrolu, reverse-forward Host port, SSE a round-trip klient → hub → approval → completion přes simulátor protokolu App Serveru.

`tests/browser_smoke.py` je volitelný test samostatného HTML dema. Vyžaduje Python Playwright a Chromium, které nejsou runtime závislostmi aplikace. Cestu k prohlížeči lze nastavit proměnnou `CHROMIUM`.

**Ověřeno zde:** 38 Node testů a 13 browser kontrol; desktop a mobilní rozvržení. **Neověřeno zde:** skutečné přihlášení k vašemu Codex účtu, instalace VSIX ve vašem VS Code, exportované Zoo API v konkrétní nainstalované verzi, Windows systémové notifikace, směrování oken ani vaše WSL/SSH síť. Výstup není tvrzením o produkční kompatibilitě.

První akceptační zkouška: jeden důvěryhodný neprodukční projekt, jedna Zoo úloha s ručním dotazem, jeden testovací Codex thread. Zkontrolujte přechod do čekání, odpověď v původním Zoo panelu, změnu zpět na práci a odpojení při ukončení bridge. Teprve pak přidávejte další hosty. U vlastního Codex klienta nejprve zkuste sandbox `read-only`.

## 11. Struktura a zdroje

```
public/           Prohlížečové UI, bez sestavení a bez CDN
src/              Lokální hub, úložiště, Codex App Server klient, TypeScript kontrakt
bridge/           Zdroj doprovodného VS Code rozšíření
scripts/          Generování samostatného dema a VSIX balíčku
tests/            Node a volitelné browser testy, falešný App Server
docs/             Protokol a zpráva o ověření
dist/             Hotový VSIX
```

Implementace je JavaScript s malými moduly; `src/protocol.ts` popisuje wire kontrakt. Tím není potřeba kompilátor ani npm instalace pro běh. SQLite/React/WebSocket runtime z původního návrhu nejsou pro toto MVP potřebné: persistuje se atomicky přejmenovaný JSON snapshot, producer posílá HTTP a UI přijímá SSE.

Primární podklady, ověřované 1. října 2026 (upstream `main` není automaticky vaší instalovanou verzí):

- Zoo extension API: https://raw.githubusercontent.com/Zoo-Code-Org/Zoo-Code/main/packages/types/src/api.ts
- Zoo events: https://raw.githubusercontent.com/Zoo-Code-Org/Zoo-Code/main/packages/types/src/events.ts
- Zoo ask/message typy: https://raw.githubusercontent.com/Zoo-Code-Org/Zoo-Code/main/packages/types/src/message.ts
- Zoo package / publisher / příkazy: https://raw.githubusercontent.com/Zoo-Code-Org/Zoo-Code/main/src/package.json
- Codex App Server: https://developers.openai.com/codex/app-server
- Codex uložený protokol: https://raw.githubusercontent.com/openai/codex/main/codex-rs/protocol/src/protocol.rs
- VS Code remote extension host a callbacky: https://code.visualstudio.com/api/advanced-topics/remote-extensions
- VS Code API `env.asExternalUri`: https://code.visualstudio.com/api/references/vscode-api
- WSL networking: https://learn.microsoft.com/en-us/windows/wsl/networking

Externí rozhraní se vyvíjejí. U nekompatibilní verze použijte diagnostiku a upravte adaptér proti skutečně nainstalovanému API; nepřidávejte odhady schválení založené na textu či času.
