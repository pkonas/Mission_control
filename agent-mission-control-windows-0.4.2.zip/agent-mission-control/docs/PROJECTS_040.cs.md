# Mission Control 0.4.0 — jeden projekt, jeden řádek

Tato verze převádí schválený projektový návrh do skutečného hubu, webového rozhraní,
Windows upozornění a VS Code Bridge. Není to pouze HTML seskupení starých relací.
Samostatný soubor `dashboard-demo.html` je nadále výslovně označená ukázka se
syntetickými daty. Živá aplikace nezačíná s ukázkovými projekty.

## Aktualizace stávající instalace Windows

Spusťte `MissionControl-Setup-0.4.0-x64.exe` pod stejným Windows účtem jako dosud.
Vyberte **Aktualizovat** a ponechte instalaci **Connection + Bridge** v profilu
VS Code, který skutečně používáte. Předchozí aplikaci neodinstalovávejte a nemažte
párovací token. Automatické dohledání VS Code, oprava, odinstalování, soukromý
runtime, automatické spuštění po přihlášení a ikona u hodin zůstávají zachované.

Aktualizuje se hub i oba doplňky. **Až dokončí rozpracované úlohy agenti**, použijte
v příslušném okně `Developer: Reload Window`, a obnovte stránku dashboardu.
Instalátor okna VS Code sám nerestartuje. Místní Connection zůstává ve Windows;
u WSL/SSH musí být Bridge 0.4.0 také v prostředí projektu. Panel Connection
nabídne instalaci/opravu přiloženého Bridge do aktuálního hostu.

Stávající připojení se pokusí obnovit běžným způsobem. Projekt, který jste vědomě
odebrali, zůstane odebraný. Pro jeho návrat použijte:

```
Mission Control: Reconnect This Workspace
```

Bridge poskytuje také `Mission Control: Reconnect`. Běžící kód se hlásí jako
`0.4.0-projects.1`; samotný manifest na disku nenahrazuje načtení nového kódu.
`Mission Control: Copy Connection Report` zůstává pro diagnostiku (bez tokenu
nebo obsahu chatů). Při zapnutém Codex pozorování se dosavadní volba zachová;
tato aktualizace sama dodatečný přístup k jeho souborům nezapíná.

Windows balíček je určený pro x64. Instalátor a VSIX jsou nepodepsané. Systémové
bezpečnostní ochrany ani Workspace Trust kvůli instalaci nevypínejte. Novou
instalaci a dosud neověřenou kombinaci prostředí nejprve ověřte na neprodukčním
projektu. Reálné spuštění instalátoru ve Windows v tomto sestavení testované nebylo.

## Co znamená projekt

Základní jednotkou je **sledovaná pracovní složka na konkrétním hostiteli**.
Stabilní identita vychází z hostitele a normalizované cesty, nikoli z názvu,
chatového ID, instance Bridge nebo počtu úloh.

Čtyři Codex záznamy v `monografie` tvoří jeden řádek. Codex i Zoo Code v téže složce
jsou pod stejným projektem. Dvě různá místa nazvaná `backend` se naopak nesloučí
jen podle názvu. Windows, WSL a vzdálený stroj nejsou automaticky považované za
totéž prostředí; například `C:\repo` a `/mnt/c/repo` se bez ověřené společné identity
neslučují. Změna názvu či větve nevytváří nový projekt. Přesun složky na jinou
cestu není automaticky rozpoznaný jako přejmenování stejného projektu.

Bridge registruje kořeny již při připojení. Projekt se proto zobrazí i bez
nového chatu; chybějící aktuální událost má stav **Stav neověřen**, ne vymyšlenou
práci nebo dokončení. Bez spojení má **Výpadek spojení**. Úmyslným odpojením
monitorování se řádek odstraní, běžný výpadek spojení jej pouze označí.

## Hlavní obrazovka a detail

Počítadla a filtry pracují s projekty. Kategorie se mohou překrývat: projekt
může potřebovat odpověď Zoo Code a současně v něm může pracovat Codex. V seznamu
přesto zůstává jednou. Nejdůležitější stav má přednost, druhá činnost je uvedená
pod ním. Počet „Pracují“ znamená alespoň jeden aktuální pracující běh v projektu;
„Ke kontrole“ alespoň jeden aktuální hlavní výsledek.

Seznam nabízí hledání názvu/cesty/hostitele/větve, filtrování prostředí a
nástroje, řazení, připnutí projektu a kompaktní zobrazení. Nečinné/pozastavené
projekty lze sbalit. Klávesa `/` přejde do hledání, `j` a `k` přepínají výběr.
Výběr je stabilní při příchodu událostí. Řádky se nemění mezi stiskem a uvolněním
ukazatele, aby se pod kurzorem nezaměnil cíl.

**Teď** ukazuje konkrétní práci nástrojů, nevyřízenou otázku, dostupné zadání,
poslední odpověď a několik důležitých událostí. Pomocná úloha vyžadující člověka
se neztratí jen proto, že není hlavním chatem. Její samostatné dokončení však
není dokončením celého hlavního úkolu.

**Změny** ukazují poslední dostupný Git stav projektu. Jeden soubor se nesčítá
podle chatů. Je to stav workspace včetně ručních změn; není automaticky připisován
agentovi. Seznam je omezený na 100 položek. Chybějící Git snapshot není „0 změn“.
Diff jednotlivého aktuálního běhu se ukáže pouze tehdy, když ho adaptér poskytuje.

**Historie** odděluje starší hlavní úkoly. Interní, pomocné a nezařazené záznamy
mají sbalenou diagnostiku pouze s metadaty. Interní posudky a pomocné odpovědi
nesoutěží o místo v hlavním seznamu. Původní chaty a soubory Codexu/Zoo se nemění.

Odkaz „Otevřít VS Code“ používá ověřený odkaz registrovaného Bridge. Nezakládá
nový chat. Je nedostupný, pokud platný odkaz chybí. Otevření konkrétního nástroje
je v detailu jeho běhu, podle možností původního rozšíření. Přepnutí na přesný
historický chat není u všech nástrojů zaručené.

## Jak vzniká stav a oznámení

Pořadí důležitosti je požadavek člověku, problém, probíhající práce, aktuální
výsledek, neověřený/nečinný stav. Interní záznam není zdrojem hlavního stavu.
Novější hlavní úkol nahrazuje starý hotový úkol stejného nástroje; skutečně
souběžné aktivní běhy API zůstávají dostupné v detailu.

Zoo Code má průběžné události. Rozlišení delegovaného dokončení využívá metadata
`isSubtask` a vazby rodič/potomek, nikoli odhad podle obsahu věty. Selhání jednoho
nástroje se samo o sobě nepřevádí na selhání celého úkolu. Bridge připojený k již
běžící Zoo úloze čeká na první skutečnou událost; nepředstírá její stav.

Pozorování původního Codex rozšíření zůstává **omezené, volitelné čtení JSONL**.
Role se určuje podle metadat `source` (`vscode`/`cli`, `internal`, `subagent`),
ne podle výskytu slov `risk_level` v textu. Neznámá metadata se raději označí
jako nezařazená. Úvodní načtení již existujících souborů je historie a nevyvolá
nové oznámení „hotovo“. Až nově připsaná událost může doložit aktuální činnost.
U známého hlavního běhu může nově připsaný explicitní `task_complete` /
`turn_complete` vytvořit výsledek a oznámení označené jako pozorovaný záznam.
Pouhá stará zpráva, ukončení pomocného agenta nebo tokenový heartbeat nestačí.

**Čekající schválení v původním Codex rozšíření stále nelze tímto pozorováním
spolehlivě detekovat.** Spolehlivější události poskytují relace spravované
přiloženým App Server klientem, ale klient automaticky nepřebírá současné chaty
rozšíření. Redesign tento integrační rozdíl nezakrývá. Pozorovaný pracující
Codex bez nové aktivity po 90 sekundách přechází na „Stav neověřen“, ne na chybu.

Oznámení i Windows tray počítají projekty. Viděno a odložení se vztahují na
projektový požadavek a nic agentovi neschvalují. Nový požadavek vytvoří nový
signál. Při spuštění dashboardu se nespustí série prohlížečových oznámení ze
starého stavu. Systémový tray může upozornit na dosud nevyřízený aktuální API
požadavek po opětovném připojení. V desktopovém režimu prohlížeč nepřidává druhou
kopii Windows oznámení.

## Odpojení a více kořenů v jednom okně

V dashboardu vyberte **Odpojit monitorování projektu**. Dialog zachytí konkrétní
vlastníky připojení; kdyby se mezitím změnili, operaci je nutné potvrdit znovu.
Zmizí právě vybraný kořen včetně jeho kopií chatových záznamů. Další kořeny
stejného VS Code workspace zůstanou sledované. Staré zprávy odebraný projekt
nevrátí. Zákaz obnovení zůstává uložený i po restartu hubu.

Ve VS Code dosavadní **Disconnect This Workspace** nadále znamená **všechny
kořeny daného okna**. U běžného jednosložkového projektu jde o stejný rozsah.
Pro odpojení pouze jednoho kořene vícesložkového workspace použijte dashboard.
Explicitní **Reconnect This Workspace** obnoví připojení kořenů tohoto okna;
může obnovit i více kořenů, které jste dříve jednotlivě odebrali. Automatický
heartbeat to nedělá a jiné projekty se nepřebírají.

Codex JSONL obsahuje pracovní adresář, takže adaptér přiřazuje záznam podle
nejkonkrétnějšího odpovídajícího kořene. Zoo API neposkytuje v používaných
událostech spolehlivou cestu projektu. V okně s více složkami proto Bridge Zoo
**nepřiřazuje automaticky první složce**. Vyberte kořen pomocí:

```
Mission Control: Select Zoo Project Root
```

Volba se uloží do konfigurace workspace. Změna kolektoru neukončuje agenta.
Tato integrace připisuje Zoo úlohy daného okna jednomu výslovně zvolenému kořeni;
více nezávislých Zoo projektů je vhodné vést v samostatných oknech. V dashboardu
je pořád uvidíte společně. Při přejmenování/odebrání zvoleného kořene ho vyberte
znovu; neplatná konfigurace se nehádá.

## Migrace a bezpečnost

Při prvním načtení starého stavu se před přepisem vytvoří přesná záloha:

```
%LOCALAPPDATA%\AgentMissionControl\state.before-0.4.0.json
```

Existující záloha se nepřepíše. U čisté instalace bez uložených relací není co
zálohovat. Migrace seskupí staré záznamy podle identity kořene a neodstraňuje
původní agentové chaty. Předchozí záměr odpojení a token se zachovají. Už uložené
záznamy s nerozpoznatelně různými hostiteli/cestami se úmyslně neslučují odhadem.
Zálohy obsahují lokální kopie historie; zacházejte s nimi jako s pracovními daty.

Hub naslouchá na loopbacku, nezřizuje veřejný port a nepřidává firewallové výjimky.
WSL relay a SSH tunely fungují jako dříve. UI kontroluje verzi snímku, takže
opožděná stará odpověď nezobrazí znovu již odebraný projekt. Texty agentů se
vykreslují jako text, ne spustitelné HTML. Odpojení nic nezastaví, schválení
vyžaduje konkrétní výslovnou akci v detailu skutečně spravovaného běhu.

## Ověření a hranice této dodávky

Aktuální protokol je `docs/WINDOWS_TEST_REPORT-0.4.0.md`. Automatické testy
provádějí skutečný hub, úložiště, migraci a přenos HTTP/stdio. VS Code API a Zoo
provider jsou v integračních testech nahrazené. Browser test používá skutečné
UI a skutečný HTTP hub, ale testovací mezivrstvu prohlížečového přenosu, protože
místní Chromium blokuje přímou loopback navigaci. Události SSE v tomto testu
nahrazuje řízené načítání stejných serverových snímků.

Windows instalátor, Windows PowerShell 5.1, reálný VS Code Extension Host,
Windows notifikace a WSL/SSH připojení konkrétního uživatele zde spuštěné nebyly.
Statická kontrola EXE nepředstavuje test jeho běhu ve Windows.

## Vývoj

Node.js 22+, bez npm runtime závislostí. Ve složce projektu:

```sh
npm test
sh tests/native/run-tests.sh
node scripts/build-preview.mjs
python3 tests/projects_browser.py /tmp/mc-browser-results
python3 scripts/build-windows.py
python3 scripts/validate-windows-package.py
node src/server.mjs
```

Pro browser test je potřeba Playwright a Chromium. Pro Windows cross-build
clang + lld-link; kompilace je bez stahování Windows SDK. Původní browser skripty
v `tests/` dokumentují staré rozhraní 0.3.x; pro 0.4.0 použijte `projects_browser.py`.

Technické zdroje ověřené při implementaci: Codex App Server
(https://developers.openai.com/codex/app-server), Codex protokol
(https://github.com/openai/codex/blob/main/codex-rs/protocol/src/protocol.rs),
Zoo API (https://github.com/Zoo-Code-Org/Zoo-Code/blob/main/src/extension/api.ts)
a VS Code extension hosts (https://code.visualstudio.com/api/advanced-topics/extension-host).
Metadata těchto nástrojů mohou změnit formát; neznámý záznam má diagnostický stav,
ne automaticky důvěryhodný výsledek.
