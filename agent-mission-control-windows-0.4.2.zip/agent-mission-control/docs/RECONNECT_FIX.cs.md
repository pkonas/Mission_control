# Mission Control 0.3.8 — oprava opětovného připojení

## Aktualizace bez mazání dat

Spusťte `MissionControl-Setup-0.3.8-x64.exe` pod stejným Windows účtem jako
předchozí instalaci. Vyberte Aktualizovat a ponechte instalaci Connection + Bridge
ve správném místním profilu VS Code. Oprava, aktualizace, odinstalování, dohledání
VS Code, token, historie a port zůstávají podporované. Tato verze nemění princip
Windows instalace; mění hub a příkazy připojení.

Pouhý restart hubu nestačí, pokud ve VS Code stále běží starý kód rozšíření.
Až agenti dokončí rozpracované úlohy, použijte `Developer: Reload Window`.
Instalátor restart editoru nevynucuje. Ve WSL/SSH aktualizujte také Bridge ve
vzdáleném extension hostu přes `Mission Control: Install / Repair Bridge Here`.
Místní Connection a vzdálený Bridge mají být načtené ve verzi 0.3.8.

## Obnovení připojení

V okně daného projektu spusťte:

```
Mission Control: Reconnect This Workspace
```

Stejná akce je v Exploreru → Mission Control → **Znovu připojit tento workspace**.
Samotný Bridge poskytuje `Mission Control: Reconnect`. Opravené zůstávají také
původní příkazy Connect, Connect to Windows App a Setup Connection.

Výslovné obnovení použije dříve uložený token a stejnou identitu projektu. Pokud
hub původní připojení už odstranil, bridge vytvoří novou instanci připojení a
požádá o jednorázové obnovení reportování. Nezakládá nový chat Codexu/Zoo Code.
Nemažte kvůli této chybě token, state.json ani workspaceState.

Při úspěchu se zobrazí:

> Mission Control: připojení k hubu bylo potvrzeno. Relace se zobrazí po načtení
> událostí agentů.

V diagnostice Bridge bude `MC_RECONNECTED`. Úspěch zde znamená skutečnou
komunikaci s hubem, nikoli pouze spuštění časovače. Pokud agent nemá žádnou
rozpoznanou úlohu, řádek úlohy ještě nemusí existovat: připojení je samostatně
viditelné v nastavení připojení dashboardu.

Pokud je stejná instance již živá, zůstane zachovaná. Pokud workspace vlastní
jiné okno, hub nové připojení odmítne. Obnovení není vynucené převzetí relace.
Opakované rychlé klikání sdílí jednu operaci; nikdy nespouští paralelní párování.
Nedostupný hub vyvolá konkrétní zprávu, nikoli falešné potvrzení připojení.

## Co bylo opraveno

**Čekání na zavření obyčejné notifikace.** Původní Disconnect čekal i na návrat
informační zprávy o úspěchu. VS Code tento příslib dokončuje až výběrem akce nebo
zavřením zprávy. Přestože hub už řádky odstranil, interní operace zůstávala
rozpracovaná a blokovala Connect. Nyní se na běžná oznámení nečeká. Na skutečné
potvrzovací dialogy (instalace, souhlas s párováním, odpojení) se čeká nadále.

**Zastaralý stav připojení.** Po odstranění z dashboardu mohlo okno do příštího
kontaktu stále hlásit connected/connecting. Panel i Bridge tento místní údaj
považovaly za důvod Connect přeskočit. Nyní panel akci předá Bridge a ten ověří
skutečného vlastníka v hubu čtecím požadavkem. Tento požadavek nevybírá příkazy
ze schvalovací fronty, nic nepovoluje a neprodlužuje dobu vlastnictví.

**Dostupnost příkazů.** Connect a Reconnect nejsou deaktivované zastaralou
kontextovou proměnnou connected/connecting. Ochrana proti duplicitám zůstává
uvnitř příkazu a především v hubu, nikoli pouze v nabídce.

**Trvalý záměr a diagnostika.** Lokální zápisy pauzy a obnovení se provádějí v
pořadí; opožděný zápis odpojení nesmí přepsat nové obnovení. Hub před potvrzením
výslovného obnovení uloží zrušení blokace na disk. Staré instance zůstávají
odmítnuté. Konflikt HTTP 409 bez strojového kódu chyby nevyvolá nekonečné
připojování: monitor se zastaví a ponechá dostupnou ruční obnovu.

## Co zůstává chráněné

Odpojení se nadále týká celého připojení workspace a všech jeho monitorovaných
úloh. Záznamy z dashboardu odstraní; staré události je nesmějí automaticky vrátit.
Výslovný Reconnect znovu načte dostupný aktuální stav. Dříve odebraná kopie
historie v dashboardu se nemusí kompletně doplnit. Původní chaty a projektové
soubory se nemění.

Jiná připojení, tokeny dalších workspace, agenti, čekající schválení a skutečné
úlohy zůstávají nedotčené. Starý požadavek na odstranění nesmí odpojit nového
vlastníka. Běžný restart nebo krátký výpadek není souhlasem s obnovením relace,
kterou uživatel výslovně odstranil.

Pro vzdálený Linux je nadále nutný fungující tunel k hubu. WSL používá existující
stdio relay přes Windows aplikaci. Nové ověření vlastnictví má v tomto relay
vlastní omezený endpoint; nenabízí obecné HTTP proxy ani příkazy shellu.

## Diagnostika

`Mission Control: Connection Diagnostics` vypíše verze doplňků a stav hostu.
`Mission Control: Show Diagnostics` otevře log Bridge. V něm je možné rozlišit
`MC_RECONNECT_CHECK`, `MC_RECONNECT_CHECK_FAILED` a `MC_RECONNECTED`.
Při neúspěchu sledujte konkrétní následující chybu; nepřepínejte naslepo token ani
neodstraňujte ochranu proti duplicitám. Tokeny se do těchto nových hlášení nevypisují.

## Ověření a omezení

Rozsah provedených testů je v `docs/WINDOWS_TEST_REPORT-0.3.8.md`. Reprodukce
původních problémů používá skutečný kód 0.3.7 a skutečný HTTP hub, ale nahrazené
VS Code API. Nové integrační testy používají produkční kód Bridge, Producer,
Connection a hubu společně. Nejde o běh v reálném VS Code Extension Hostu.

Skutečný Windows instalátor, PowerShell 5.1, Windows tray, reálné Zoo Code/Codex
rozšíření ani Windows WSL interoperability nebyly v tomto prostředí spuštěny.
EXE a VSIX nejsou digitálně podepsané. Ochranu Windows ani Workspace Trust kvůli
nim nevypínejte.

Podklad pro chování notifikací: oficiální VS Code API, metoda
`window.showInformationMessage`, návratová hodnota Thenable:
`https://code.visualstudio.com/api/references/vscode-api#window`.
