# Mission Control 0.3.3 — oprava File.Replace a rozsah ověření

## Nalezená chyba

V původním `windows/Common.ps1` bylo jediné volání tohoto přetížení:

```powershell
[IO.File]::Replace($temporary, $Path, $null)
```

Windows PowerShell při předání do parametru typu string může převést `$null` na prázdný řetězec. Prázdná záložní cesta není pro .NET `File.Replace` platná. Nový soubor se původně vytvářel metodou `Move`, a proto prvotní instalace mohla projít; problém se objevil až ve větvi pro již existující soubor. V aktualizaci je první takový zápis po přepnutí souborů typicky `port.txt`. Dodaný log potvrzuje již úspěšné zastavení a chybu přetížení `Replace` se třemi argumenty; neobsahuje stack trace konkrétního souboru.

Nová verze používá skutečnou jedinečnou absolutní cestu zálohy ve stejné složce jako zdroj i cíl. Nepoužívá přímé mazání cíle, potlačení výjimky ani přeskočení uložení nastavení. Při chybě zůstanou případné pomocné soubory pro obnovu; instalační transakce zachovává vlastní rollback.

## Automatický test v instalátoru

`Test-MCAtomicWrite` volá skutečný `Write-MCAtomic` na disku a v PowerShell/.NET uživatele. Před zastavením aplikace provede 12 zápisů (vytvoření a dvě nahrazení čtyř souborů) a porovnání UTF-8 bytů. Testovací složka je nová, uvnitř datové složky, a od skutečných konfigurací oddělená. Po úspěchu nebo chybě se odstraní. Při selhání se nesmí zastavit ani vyměnit původní aplikace. Výsledek se neloguje předem; `MC_ATOMIC_WRITE_OK` vznikne až po návratu z testu.

Tato kontrola testuje konkrétní chybu zápisu, ne celý budoucí průběh instalace, registry, VS Code ani funkci bezpečnostního softwaru.

## Skutečně spuštěné ověření tohoto balíčku

Prostředí: Debian Linux x64, Node.js v22.16.0, Clang/lld-link. PowerShell ani Windows runtime nebyl v tomto prostředí dostupný; pokusy získat samostatný testovací PowerShell selhaly při stažení. Nejsou zahrnuté jako provedené testy.

- **103/103 existujících Node.js testů prošlo.** `node --test tests/*.test.mjs`; záznam `docs/atomic-node-tests.tap`. Pokrývají hub, desktop autentizaci/identitu, relay, integrace a simulované VS Code CLI. Nevykonávají PowerShell a nejsou důkazem opravy `File.Replace`.
- **31/31 nativních scénářů s náhradami Win32 API prošlo.** `sh tests/native/run-tests.sh`; záznam `docs/atomic-native-tests.txt`. Týkají se dřívějšího řadiče zastavení a parsování argumentů. Nejde o skutečné Windows procesy.
- **Sestavení Windows x64 EXE a vloženého ZIP** bylo provedeno z přiložených zdrojů. Samostatná statická kontrola ověřuje x64 PE, nepodepsaný asInvoker manifest, obsah ZIP, shodu souborů, UTF-8 BOM PowerShell skriptů, opravené volání `File.Replace`, pořadí preflight před Stop a zachované příkazy údržby. Strojový výsledek se distribuuje samostatně vedle balíčku; nejde o runtime test.

## Co zde neproběhlo

**Nebylo provedeno spuštění Windows PowerShell 5.1, celého instalačního průvodce, aktualizace 0.2.0 → 0.3.3, opravy/odinstalování na Windows, opravdového VS Code, WSL ani SSH.** Není tvrzena produkční certifikace. Binární soubory nejsou podepsané. Ochranu Windows ani firemní pravidla neměňte.

Přiložený `windows/Test-AtomicWrite.ps1` je samostatný test pro skutečné PowerShell/.NET souborové operace v izolované složce. Volitelný `-ReproduceLegacy` spustí staré chybné volání pouze na testovacích souborech. Neprovádí instalaci, změny registrů ani práci s uživatelskými projekty. Zde nebyl spuštěn; instalátor sám používá kratší automatický preflight a nevyžaduje jeho ruční spuštění.

## Přijímací scénář na Windows

Spustit 0.3.3 pod stejným účtem jako 0.2.0, zvolit Aktualizovat, očekávat `MC_ATOMIC_WRITE_OK` ještě před řadičem zastavení, poté `MC_PORT_WRITE_OK` a `MC_MAINTENANCE_CACHE_OK`, ověření nové verze hubu a samostatný výsledek bridge. Následně lze zopakovat Opravit bez mazání dat a Odinstalovat s výchozím ponecháním dat. Nejde o seznam zde úspěšně provedených kroků.

## Primární technické podklady

- Microsoft File.Replace (.NET Framework 4.8.1), pravidla parametrů a záloh: https://learn.microsoft.com/en-us/dotnet/api/system.io.file.replace?view=netframework-4.8.1
- PowerShell projekt, převod `$null` do string parametrů: https://github.com/PowerShell/PowerShell/issues/4616
- PowerShell projekt, historické chování metod .NET a NullString: https://github.com/PowerShell/PowerShell/issues/26725
