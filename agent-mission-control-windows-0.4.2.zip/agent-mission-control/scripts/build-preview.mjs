import {readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let html=await readFile(path.join(root,'public/index.html'),'utf8');
const css=await readFile(path.join(root,'public/style.css'),'utf8');
const demo=(await readFile(path.join(root,'public/demo.mjs'),'utf8')).replace(/^export /gm,'');
const model=(await readFile(path.join(root,'public/project-model.mjs'),'utf8')).replace(/^export /gm,'');
const app=(await readFile(path.join(root,'public/app.mjs'),'utf8')).replace(/^import .*;\n/gm,'');
const icon=await readFile(path.join(root,'public/icon.svg'),'utf8');
html=html.replace('<link rel="stylesheet" href="./style.css">',`<style>${css}</style>`)
 .replace('href="./icon.svg"',`href="data:image/svg+xml,${encodeURIComponent(icon)}"`)
 .replace('<script type="module" src="./app.mjs"></script>',`<script>window.MC_OFFLINE=true;\n${model}\n${demo}\n${app.replaceAll('</script','<\\/script')}</script>`);
const out=path.join(root,'dashboard-demo.html');await writeFile(out,html);console.log(out);
