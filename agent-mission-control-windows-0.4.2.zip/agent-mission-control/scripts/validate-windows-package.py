#!/usr/bin/env python3
"""Static verification of native binaries and self-extracting payload. Not a Windows runtime test."""
import io,json,struct,subprocess,sys,zipfile,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[1]
setup=Path(sys.argv[1]) if len(sys.argv)>1 else root/'dist/MissionControl-Setup-0.4.2-x64.exe'
checks=[]
for p in [root/'windows/bin/MissionControl.exe',root/'windows/bin/MissionControlStop.exe',setup]:
    b=p.read_bytes();assert b[:2]==b'MZ'
    off=struct.unpack_from('<I',b,0x3c)[0];assert b[off:off+4]==b'PE\0\0'
    assert struct.unpack_from('<H',b,off+4)[0]==0x8664
    optional=off+24;assert struct.unpack_from('<H',b,optional)[0]==0x20b
    assert struct.unpack_from('<H',b,optional+68)[0]==2
    # The certificate directory is empty: do not misrepresent the binaries as signed.
    certificate=struct.unpack_from('<II',b,optional+112+4*8);assert certificate==(0,0)
    assert b'assemblyIdentity version="0.4.2.0"' in b
    assert b'requestedExecutionLevel level="asInvoker"' in b
    checks.append(p.name+': valid x64 GUI PE, asInvoker, explicitly unsigned')
b=setup.read_bytes();start=b.find(b'PK\x03\x04');end=b.rfind(b'PK\x05\x06');assert start>0 and end>start
comment=struct.unpack_from('<H',b,end+20)[0]
with zipfile.ZipFile(io.BytesIO(b[start:end+22+comment])) as z:
    assert z.testzip() is None
    names=z.namelist()
    assert all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
    for n in ['windows/Install.ps1','windows/Setup-Lock.ps1','windows/Test-SetupLock.ps1','windows/Diagnose-Setup.ps1','windows/Uninstall.ps1','windows/Common.ps1','windows/Launch-Maintenance.ps1','windows/vscode-cli.cjs','windows/vscode-layout.cjs','windows/Code-Discovery.ps1','windows/bin/MissionControl.exe','windows/bin/MissionControlStop.exe','src/server.mjs','src/desktop-access.mjs','public/app.mjs','dist/mission-control-bridge-0.4.2.vsix','dist/mission-control-connection-0.4.2.vsix','connector/src/controller.cjs','connector/src/extension.cjs','bridge/src/readiness.cjs']:
        assert z.read(n)==(root/n).read_bytes(),n
    assert not any(n.startswith('.data/') or n.endswith('/token') for n in names)
    for n in names:
        assert z.read(n)==(root/n).read_bytes(), 'Source mismatch: '+n
    checks.append(f'Embedded ZIP: {len(names)} safe entries, CRC checked, required files byte-identical, no live credentials')
    ps=z.read('windows/Install.ps1');assert ps.startswith(b'\xef\xbb\xbf')
    assert b'158f7685b44de51f6c0df1d153526cbcd3e1bc739a8dfc607721cef75de9e541' in ps
    for n in names:
        if n.endswith('.ps1'): assert z.read(n).startswith(b'\xef\xbb\xbf'), n
    text=ps.decode('utf-8-sig')
    assert '& $code --install-extension' not in text
    assert "Resolve-MCMode" in text and "ModifyPath=" in text and "QuietUninstallString=" in text
    assert "ReadToEndAsync" in z.read('windows/Common.ps1').decode('utf-8-sig')
    checks.append('Maintenance entrypoints and isolated native stream capture are packaged')
    checks.append('PowerShell UTF-8 BOM and pinned Node archive digest are present')
assert (root/'windows/Code-Discovery.ps1').read_bytes().startswith(b'\xef\xbb\xbf')
checks.append('Read-only VS Code discovery and active-launcher CLI resolver included')
install=(root/'windows/Install.ps1').read_text(encoding='utf-8-sig')
stop=install[install.index('function Stop-MCApplication'):install.index('function Resolve-MCCode')]
assert 'MissionControlStop.exe' in stop and "@('--stop')" in stop and "@('--quit')" not in stop
checks.append('Installer stops through a separate no-start controller and validates acknowledgement')
imports=subprocess.check_output(['objdump','-p',str(root/'windows/bin/MissionControlStop.exe')],text=True)
for forbidden in ['CreateProcessW','ShellExecuteW','CreateWindowExW','CreateMutexW','WinHttpOpen']:
    assert forbidden not in imports, 'Controller must not start GUI/processes or access network: '+forbidden
for required in ['CommandLineToArgvW','QueryFullProcessImageNameW','OpenProcessToken','GetProcessTimes','EnumWindows']:
    assert required in imports, required
trayImports=subprocess.check_output(['objdump','-p',str(root/'windows/bin/MissionControl.exe')],text=True)
assert 'CommandLineToArgvW' in trayImports
checks.append('Headless controller imports no process/window startup or HTTP API; native argument decoder is linked')
common=(root/'windows/Common.ps1').read_text(encoding='utf-8-sig')
writer=common[common.index('function Write-MCAtomic'):common.index('function Test-MCAtomicWrite')]
assert '[IO.File]::Replace($temporary, $fullPath, $backup)' in writer
assert '[IO.File]::Replace($temporary, $Path, $null)' not in writer
assert '$backup = "$fullPath.bak-$suffix"' in writer
assert '[IO.FileMode]::CreateNew' in writer and '$stream.Flush($true)' in writer
assert '[IO.File]::Delete($fullPath)' not in writer
checks.append('Atomic writer uses non-null absolute sibling backup paths and no delete-first fallback (static)')
transaction=install[install.index('function Install-MissionControl'):install.index('function Uninstall-MissionControl')]
assert transaction.index('Test-MCAtomicWrite $script:DataDir') < transaction.index('$wasRunning = Stop-MCApplication')
assert transaction.index('Test-MCAtomicWrite $script:DataDir') < transaction.index('Move-Item -LiteralPath $stage')
assert 'MC_ATOMIC_WRITE_OK' in transaction and 'MC_PORT_WRITE_OK' in transaction and 'MC_MAINTENANCE_CACHE_OK' in transaction
checks.append('Actual writer preflight is wired before stop/swap; phase diagnostics are present (static)')
assert (root/'windows/Test-AtomicWrite.ps1').read_bytes().startswith(b'\xef\xbb\xbf')
checks.append('Isolated real-PowerShell regression script included, not executed in this Linux validation')
lock=(root/'windows/Setup-Lock.ps1').read_text(encoding='utf-8-sig')
operation=install[install.index('function Invoke-MCOperation('):install.index('# Environment validation is read-only.')]
startup=install[install.index('# Environment validation is read-only.'):install.index('$form = New-Object')]
assert 'Enter-MCSetupMutex' not in startup and '$ownsMutex' not in install
assert '$lease = Enter-MCSetupMutex $lockName' in operation
assert "'Local\\AgentMissionControl-Setup-' + $sid" in lock
assert 'finally {\n            Exit-MCSetupMutex $lease' in operation
assert 'MC_SETUP_LOCK_RELEASED' in operation and 'Diagnostika zámku' in install
assert operation.index("'Test-SetupLock.ps1'") < operation.index('Install-MissionControl $action')
checks.append('Operation-scoped compatible mutex, finally release, diagnostic button and real-host preflight are wired (static only)')
assert 'jejich vlastnictví zámku nelze potvrdit' in lock
assert '$candidate.StartTicks -ceq [string]$record.startTicks' in lock
for forbidden in ['Stop-Process', '.Kill(', 'taskkill']:
    assert forbidden not in lock
checks.append('Lock diagnostics identifies PowerShell candidates without forceful process termination or lock-file bypass (static only)')
# Packaging checks are distinct from a real VS Code Extension Host test.
with zipfile.ZipFile(root/'dist/mission-control-connection-0.4.2.vsix') as ui:
    cm=json.loads(ui.read('extension/package.json'))
    assert cm['extensionKind']==['ui'] and not cm.get('extensionDependencies')
    assert cm['version']=='0.4.2'
    assert any(c['command']=='missionControl.setup' for c in cm['contributes']['commands'])
    nested=ui.read('extension/resources/bridge.vsix')
    nested_meta=json.loads(ui.read('extension/resources/bridge-package.json'))
    assert hashlib.sha256(nested).hexdigest()==nested_meta['sha256']
    assert nested==(root/'dist/mission-control-bridge-0.4.2.vsix').read_bytes()
    assert b'Value="ui"' in ui.read('extension.vsixmanifest')
    with zipfile.ZipFile(io.BytesIO(nested)) as bridge:
        bm=json.loads(bridge.read('extension/package.json'))
        assert bm['extensionKind']==['workspace'] and bm['version']=='0.4.2'
        assert bm['capabilities']['untrustedWorkspaces']['supported']=='limited'
        assert b'Value="workspace"' in bridge.read('extension.vsixmanifest')
        assert 'extension/src/readiness.cjs' in bridge.namelist()
checks.append('UI companion and workspace bridge VSIX have distinct roles, valid embedded checksum and identical versions (static)')
assert 'suite=$true' in install and 'connectorVsix=' in install
assert "'connector'" in install
assert 'Nainstalovat / opravit Connection + Bridge' in install
checks.append('Installer/repair stages and verifies both packages in the selected local profile (static)')
# Explicitly verify the newly required ownership/identity implementation.
for name in ['bridge/src/identity.cjs','bridge/src/single-flight.cjs','tests/duplicates.test.mjs','tests/bridge-duplicates.test.mjs']:
    assert name in names, 'Missing uniqueness dependency: '+name
bridge_source=(root/'bridge/src/extension.cjs').read_text()
assert 'sourceId:identity.sourceId' in bridge_source and 'sourceId:`vscode-${instance}`' not in bridge_source
server=(root/'src/server.mjs').read_text()
for endpoint in ['/api/claim','/api/release']:
    assert endpoint in server and endpoint in (root/'windows/wsl-relay.cjs').read_text()
assert 'sourceEpoch:s.sourceEpoch' in server and 'store.authorizeSource' in server
checks.append('Stable source identity, server ownership routes and command epoch fencing are included (static)')
with zipfile.ZipFile(root/'dist/mission-control-bridge-0.4.2.vsix') as bridge:
    for name in ['identity.cjs','single-flight.cjs','producer.cjs','extension.cjs']:
        assert bridge.read('extension/src/'+name)==(root/'bridge/src'/name).read_bytes()
    meta=json.loads(bridge.read('extension/package.json'))
    for command in meta['contributes']['commands']:
        if command['command'] in ['missionControl.connect','missionControl.connectDesktop']:
            assert not command.get('enablement')
checks.append('VSIX contains the same guarded bridge sources; recovery commands are not disabled by cached status (static)')
# Explicit removal is bundled in all layers, not just a client-side button.
store=(root/'src/store.mjs').read_text()
assert 'detachedSources' in store and 'retiredEpochs' in store and 'CONNECTION_REMOVED' in store
assert "data.resume===true" in store and "this.detachedSources.delete(data.sourceId)" in store
assert "'/api/disconnect-source'" in server and "'/api/disconnect'" in server
assert "'/api/disconnect-source':'POST'" in (root/'windows/wsl-relay.cjs').read_text()
assert 'cancelSourceCommands(b.sourceId);await save();json' in server
checks.append('Removal routes, persisted opt-out, retired-epoch fences and save-before-success are included (static)')
assert "disconnectToken:${p.sourceId}:${p.epoch}" in bridge_source
assert "context.workspaceState.update(intentKey" in bridge_source
assert "context.secrets.delete('hubToken')" not in bridge_source
assert "missionControl.disconnectHere" in (root/'connector/src/extension.cjs').read_text()
assert "Odpojit a odebrat z dashboardu" in (root/'connector/src/extension.cjs').read_text()
checks.append('VS Code commands, persistent per-workspace pause and per-owner secret keys are packaged (static)')
app=(root/'public/app.mjs').read_text()
assert "data-disconnect=" in app and "id=\"confirmDisconnect\"" in app
assert "api('/api/disconnect-project','POST',{key,owners})" in app
assert "snapshot.hubId===data.hubId" in app and "data.revision<snapshot.revision" in app
assert (root/'tests/disconnect.test.mjs').is_file() and (root/'tests/disconnect_browser.py').is_file()
checks.append('UI scope confirmation, removal POST and stale-snapshot guard are present with regression tests (static)')
assert 'missionControl.reconnect' in bridge_source and 'current.inspect()' in bridge_source
assert 'MC_RECONNECTED' in bridge_source and 'intentWrites' in bridge_source
assert 'await vscode.window.showInformationMessage(' not in bridge_source.replace('const consent=await vscode.window.showInformationMessage(', '')
assert '/api/connection-status' in server and 'if(b.resume===true)await save();' in server
checks.append('Reconnect route, ownership verification, non-blocking notices and durable resume are packaged (static)')
assert "const start=recoveryFlight" in bridge_source
assert "version:RUNTIME_VERSION,runtimeBuild:RUNTIME_BUILD" in bridge_source
assert 'missionControl.copyConnectionReport' in bridge_source
assert 'tests/recovery.test.mjs' in names
checks.append('Priority recovery, executing-code identity and safe diagnostic command are packaged (static)')
assert "url.pathname==='/api/reconnect'" in server and 'store.authorizeSource(b.sourceId,b.epoch)' in server
assert "'/api/reconnect':'POST'" in (root/'windows/wsl-relay.cjs').read_text()
assert 'INVALID_RECOVERY_ACK' in (root/'bridge/src/producer.cjs').read_text()
checks.append('Dedicated recovery endpoint, exact request acknowledgement and relay support are packaged (static)')
for name in ['src/projects.mjs','public/project-model.mjs','tests/projects.test.mjs','tests/project-bridge.test.mjs','tests/projects_browser.py']:
    assert name in names
assert 'projectProjection(this.projects.snapshot()' in store
assert '/api/disconnect-project' in server and '/api/annotate-project' in server
assert 'state.before-0.4.0.json' in server
checks.append('Independent project registry, project projection, guarded removal and migration backup are packaged (static)')
assert 'projectProjection' in (root/'public/project-model.mjs').read_text()
assert 'snapshot.projects||snapshot.sessions' in (root/'src/desktop-access.mjs').read_text()
assert 'project-model.mjs' in server
assert 'data-tab=' in app and 'diagnosticKeys' in app and 'currentKeys' in app
checks.append('Browser and desktop use project counts; current/history/diagnostic layers are separate (static)')
assert 'getProjects:()=>projectRoots' in bridge_source
assert 'missionControl.selectZooProject' in bridge_source and 'codexSource' in (root/'bridge/src/normalizers.cjs').read_text()
assert 'session.historical=true' in (root/'bridge/src/codex-observer.cjs').read_text()
checks.append('Root registration without tasks, explicit multi-root Zoo mapping and historical observation are packaged (static)')
# 0.4.2: approvals and event-addressed app-owned notices.
for name in ['bridge/src/zoo-control.cjs','src/notifications.mjs','windows/native/notification.h','tests/zoo-actions-http.test.mjs','tests/notifications.test.mjs','tests/zoo_browser.py','docs/ZOO_ACTIONS_041.cs.md']:
    assert name in names, name
with zipfile.ZipFile(root/'dist/mission-control-bridge-0.4.2.vsix') as z:
    assert z.read('extension/src/zoo-control.cjs')==(root/'bridge/src/zoo-control.cjs').read_bytes()
checks.append('Task-specific Zoo adapter and event notification history are present in actual VSIX and installer')
control=(root/'bridge/src/zoo-control.cjs').read_text()
assert 'x.task.handleWebviewAskResponse(response)' in control
assert 'x.task!==guard.task' in control and 'x.fingerprint!==guard.fingerprint' in control
assert 'this.consumed.add(signature)' in control
assert '.pressPrimaryButton(' not in control and '.pressSecondaryButton(' not in control
checks.append('Zoo control validates captured Task and request content; no generic primary/secondary fallback (static)')
assert "'zooDecision'" in server and 'current.stateRevision!==c.stateRevision' in server
assert 'zooDashboardControls' in (root/'bridge/package.json').read_text()
assert 'confirmZooDecision' in app and 'structuredClone(current)' in app
checks.append('Explicit approval dialog, opt-out setting and server queue revalidation are bundled (static)')
notice=(root/'windows/native/notification.h').read_text()
for symbol in ['GetDpiForSystem','SystemParametersInfoW','GetWindowRect','GetStockObject','MultiByteToWideChar','SHQueryUserNotificationState','IsDialogMessageW']:
    assert symbol in trayImports, symbol
assert 'noticeSeconds=60' in notice and 'v==300' in notice and 'v==0' in notice
assert 'NotificationSeconds' in notice and 'MC_POP_OPEN' in notice
checks.append('Native popup timing, persisted per-app choices and required Win32 imports are linked (static)')
tray=(root/'windows/native/tray.c').read_text()
assert '&notice=' in tray and 'pendingOpenNotice' in tray
assert '/api/desktop/next-notification' in server and '/api/notification' in server
assert "params.delete('desktop-ticket')" in app and 'navigateNotice' in app
checks.append('Tray event identifier survives one-use login and selects exact browser event (static)')
assert 'No command text' in (root/'src/notifications.mjs').read_text()
assert 's.stateRevision===n.revision' in (root/'src/notifications.mjs').read_text()
assert 'req.headers.origin||!desktop.authorized' in server
checks.append('Desktop notices use a separate credential and omit raw commands; stale queue entries are revalidated (static)')
assert '#notice:not([hidden]) {display:block;}' in (root/'public/style.css').read_text()
checks.append('Live action feedback is not suppressed by legacy demo CSS (static)')
# 0.4.2 original-Codex hook control: package checks do not execute Windows/Codex.
for n in ['bridge/src/codex-permission-hook.cjs','bridge/src/codex-hook-config.cjs','bridge/src/codex-hook-server.cjs','bridge/src/codex-hook-runtime.cjs','windows/remove-codex-hooks.cjs','docs/CODEX-CONTROLS_042.cs.md','tests/codex-hooks.test.mjs','tests/codex_browser.py']:
    assert n in names,n
checks.append('Codex standalone hook, conservative config, private adapter, runtime resolver and regressions are in installer (static)')
with zipfile.ZipFile(root/'dist/mission-control-bridge-0.4.2.vsix') as z:
    for n in ['codex-permission-hook.cjs','codex-hook-config.cjs','codex-hook-server.cjs','codex-hook-runtime.cjs']:
        assert z.read('extension/src/'+n)==(root/'bridge/src'/n).read_bytes()
    bm=json.loads(z.read('extension/package.json'))
    ids=[c['command'] for c in bm['contributes']['commands']]
    for c in ['enableCodexDashboardControls','disableCodexDashboardControls','removeCodexHooks']:
        assert 'missionControl.'+c in ids
checks.append('Actual bridge VSIX includes Codex implementation and opt-in/off/remove commands byte-for-byte (static)')
cfg=(root/'bridge/src/codex-hook-config.cjs').read_text()
assert 'removeOwned' in cfg and 'before-mission-control-' in cfg and 'before-mc-remove-' in cfg
assert '--dangerously-bypass-hook-trust' not in cfg and 'ExecutionPolicy' not in cfg
assert "event==='PermissionRequest'?330:3" in cfg
checks.append('Hook installer preserves other handlers, backs up existing config, uses synchronous deadlines and no trust bypass (static)')
assert 'codexControlsEnabled' in bridge_source or 'codexDashboardControlsEnabled' in bridge_source or 'controlsKey' in bridge_source
assert 'showWarningMessage' in bridge_source and 'MC_CODEX_HOOK_CONFIGURED' in bridge_source and 'meta.permissionEvent' in bridge_source
assert 'MC_CODEX_HOOK_VERIFIED' in bridge_source
checks.append('User consent, configured/verified separation and event-only verification marker are bundled (static)')
adapter=(root/'bridge/src/codex-hook-server.cjs').read_text()
for text in ['127.0.0.1','timingSafeEqual','g.turnId!==c.turnId','g.res.destroyed','rootAvailable','verifyConfig','this.pending.delete(g.id)']:
    assert text in adapter,text
assert 'spawn(' not in adapter and 'execFile(' not in adapter and 'exec(' not in adapter
checks.append('Private hook adapter authenticates local requests, validates live scope/socket and cannot launch tool commands (static)')
assert 'codexDecision' in server and 'codex/hook/permission' in server
assert 'confirmCodexDecision' in app and 'Vyřídit v Codexu' in app
assert 'structuredClone(s)' in app or 'structuredClone(current)' in app
checks.append('Codex exact-request queue revalidation and full-content confirmation/fallback UI are packaged (static)')
assert 'remove-codex-hooks.cjs' in install and 'Get-FileHash -LiteralPath $cleanupNode' in install
cleanup=(root/'windows/remove-codex-hooks.cjs').read_text()
assert 'uninstallHook' in cleanup and 'receipt.node' in cleanup
checks.append('Uninstaller only invokes verified private runtime and removes own matching hook entries (static)')
assert 'activeProjectRoots' in (root/'bridge/src/producer.cjs').read_text() and 'activeProjectRoots' in store
assert 'codexHookNode' in (root/'bridge/package.json').read_text()
checks.append('Project-removal fencing and explicit standalone Node selection are included (static)')
print(json.dumps({'passed':len(checks),'checks':checks,'setupSHA256':hashlib.sha256(b).hexdigest()},indent=2))
