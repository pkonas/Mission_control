#!/usr/bin/env python3
"""Small, dependency-free renderer for the release guide's Markdown subset."""
from pathlib import Path
import html,re
root=Path(__file__).resolve().parents[1]
def inline(s):
    s=html.escape(s)
    s=re.sub(r'`([^`]+)`',r'<code>\1</code>',s)
    return re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',s)
blocks=[];para=[];code=[];fenced=False
def flush():
    if para:blocks.append('<p>'+inline(' '.join(para))+'</p>');para.clear()
for line in (root/'docs/PROJECTS_040.cs.md').read_text().splitlines():
    if line.startswith('```'):
        flush()
        if fenced:blocks.append('<pre><code>'+html.escape('\n'.join(code))+'</code></pre>');code=[]
        fenced=not fenced
    elif fenced:code.append(line)
    elif not line.strip():flush()
    elif line.startswith('#'):
        flush();level=len(line)-len(line.lstrip('#'));blocks.append(f'<h{level}>'+inline(line[level:].strip())+f'</h{level}>')
    else:para.append(line)
flush()
style='body{font:16px/1.65 system-ui,sans-serif;max-width:1000px;margin:40px auto;padding:0 24px;color:#1d2939;background:#f7fafc}h1{font-size:34px;line-height:1.2}h2{margin-top:36px}pre{padding:18px;background:#e9eff4;white-space:pre-wrap;overflow-wrap:anywhere}code{font-family:ui-monospace,monospace;font-size:.93em}p,li{overflow-wrap:anywhere}a{color:#174f99}strong{color:#111827}'
(root/'windows/Navod.html').write_text('<!doctype html><html lang="cs"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mission Control 0.4.2 — projektový dashboard</title><style>'+style+'</style><body>'+'\n'.join(blocks)+'</body></html>')
