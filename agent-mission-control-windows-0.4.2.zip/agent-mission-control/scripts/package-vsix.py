#!/usr/bin/env python3
"""Build unsigned sideload VSIX packages. No Marketplace dependency or secret payload."""
from pathlib import Path
import json,zipfile,hashlib
from xml.sax.saxutils import escape,quoteattr
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
def build(folder,label):
    base=ROOT/folder;meta=json.loads((base/'package.json').read_text())
    kind=','.join(meta['extensionKind'])
    manifest=f'''<?xml version="1.0" encoding="utf-8"?>
<PackageManifest Version="2.0.0" xmlns="http://schemas.microsoft.com/developer/vsx-schema/2011">
 <Metadata><Identity Language="en-US" Id={quoteattr(meta['name'])} Version={quoteattr(meta['version'])} Publisher={quoteattr(meta['publisher'])}/>
 <DisplayName>{escape(meta['displayName'])}</DisplayName><Description xml:space="preserve">{escape(meta['description'])}</Description>
 <Tags>local,agents,codex,zoo</Tags><Categories>Other</Categories><GalleryFlags>Preview</GalleryFlags><Properties>
 <Property Id="Microsoft.VisualStudio.Code.Engine" Value={quoteattr(meta['engines']['vscode'])}/>
 <Property Id="Microsoft.VisualStudio.Code.ExtensionKind" Value={quoteattr(kind)}/>
 <Property Id="Microsoft.VisualStudio.Code.ExecutesCode" Value="true"/>
 <Property Id="Microsoft.VisualStudio.Services.GitHubFlavoredMarkdown" Value="true"/>
 </Properties><License>extension/LICENSE</License></Metadata>
 <Installation><InstallationTarget Id="Microsoft.VisualStudio.Code"/></Installation><Dependencies/>
 <Assets><Asset Type="Microsoft.VisualStudio.Code.Manifest" Path="extension/package.json" Addressable="true"/>
 <Asset Type="Microsoft.VisualStudio.Services.Content.Details" Path="extension/README.md" Addressable="true"/>
 <Asset Type="Microsoft.VisualStudio.Services.Content.License" Path="extension/LICENSE" Addressable="true"/></Assets>
</PackageManifest>'''
    types='''<?xml version="1.0" encoding="utf-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
 <Default Extension="json" ContentType="application/json"/><Default Extension="cjs" ContentType="application/javascript"/>
 <Default Extension="md" ContentType="text/markdown"/><Default Extension="vsix" ContentType="application/octet-stream"/>
 <Default Extension="vsixmanifest" ContentType="text/xml"/><Override PartName="/extension/LICENSE" ContentType="text/plain"/>
</Types>'''
    ET.fromstring(manifest);ET.fromstring(types)
    files={'extension.vsixmanifest':manifest.encode(),'[Content_Types].xml':types.encode()}
    for p in sorted(base.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(base)
        if p.is_symlink():raise ValueError(f'Symlink not allowed: {p}')
        if rel.parts[0] not in {'package.json','README.md','LICENSE','src','resources'}:continue
        files['extension/'+rel.as_posix()]=p.read_bytes()
    output=ROOT/'dist'/f'mission-control-{label}-{meta["version"]}.vsix';output.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in sorted(files.items()):
            i=zipfile.ZipInfo(name,date_time=(2026,10,2,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,data)
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        assert 'extension/'+meta['main'].removeprefix('./') in z.namelist()
    print(f'{output.name}: {output.stat().st_size} bytes; {len(files)} entries; kind={kind}')
    return output
bridge=build('bridge','bridge')
assets=ROOT/'connector/resources';assets.mkdir(parents=True,exist_ok=True)
(assets/'bridge.vsix').write_bytes(bridge.read_bytes())
version=json.loads((ROOT/'bridge/package.json').read_text())['version']
(assets/'bridge-package.json').write_text(json.dumps({'id':'local-mission-control.bridge','version':version,'sha256':hashlib.sha256(bridge.read_bytes()).hexdigest()},indent=2)+'\n')
build('connector','connection')
