#!/usr/bin/env python3
"""Rebuild the CRT-free Windows x64 tray and self-extracting online installer.
Requires Python 3, clang with the Windows MSVC target, and lld-link. No Windows
SDK download is needed: minimal declarations and import definitions are in-tree.
This builds binaries; it does NOT execute or certify them on Windows.
"""
from pathlib import Path
import argparse, subprocess, tempfile, zipfile, hashlib
ROOT=Path(__file__).resolve().parents[1]
NATIVE=ROOT/'windows/native'
def run(*args):subprocess.run([str(a) for a in args],check=True)
def include(p):
    rel=p.relative_to(ROOT)
    if any(x in {'.git','.data','node_modules','__pycache__','runtime','cache'} for x in rel.parts):return False
    if rel.parts[0]=='dist':return p.name in {'mission-control-bridge-0.4.2.vsix','mission-control-connection-0.4.2.vsix'}
    if p.suffix in {'.obj','.lib','.zip'} or p.name=='payload.h':return False
    if p.suffix=='.exe':return rel.as_posix() in {'windows/bin/MissionControl.exe','windows/bin/MissionControlStop.exe'}
    return p.is_file() and not p.is_symlink()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',default=str(ROOT/'dist/MissionControl-Setup-0.4.2-x64.exe'));args=parser.parse_args()
    out=Path(args.out).resolve();out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='mc-win-') as temporary:
        build=Path(temporary);libs=[]
        for definition in sorted(NATIVE.glob('*.def')):
            lib=build/(definition.stem+'.lib');run('lld-link','/lib','/machine:x64',f'/def:{definition}',f'/out:{lib}');libs.append(lib)
        flags=['--target=x86_64-pc-windows-msvc','-Oz','-ffreestanding','-fno-builtin','-fno-stack-protector','-funwind-tables','-Wall','-Wextra','-Werror','-Wno-unused-function']
        run('clang','--target=x86_64-pc-windows-msvc','-c',NATIVE/'chkstk.s','-o',build/'chkstk.obj')
        def compile_file(name):run('clang',*flags,'-I',build,'-c',NATIVE/(name+'.c'),'-o',build/(name+'.obj'))
        def link(name,destination):run('lld-link',f'/out:{destination}','/entry:mainCRTStartup','/subsystem:windows','/machine:x64','/nodefaultlib','/dynamicbase','/nxcompat','/highentropyva','/opt:ref','/opt:icf',build/(name+'.obj'),build/'chkstk.obj',NATIVE/'app.res',*libs)
        tray=ROOT/'windows/bin/MissionControl.exe';tray.parent.mkdir(parents=True,exist_ok=True)
        compile_file('tray');link('tray',tray)
        compile_file('stop');link('stop',ROOT/'windows/bin/MissionControlStop.exe')
        run('python3',ROOT/'scripts/package-vsix.py')
        payload=build/'payload.zip'
        with zipfile.ZipFile(payload,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for p in sorted(ROOT.rglob('*')):
                if include(p):z.write(p,p.relative_to(ROOT).as_posix())
        blob=payload.read_bytes()
        with (build/'payload.h').open('w') as f:
            f.write('static const unsigned char payload[] = {\n')
            for i in range(0,len(blob),24):f.write(','.join(str(x) for x in blob[i:i+24])+',\n')
            f.write('};\n')
        compile_file('setup');link('setup',out)
        print(f'Installer: {out} ({out.stat().st_size} bytes)')
        print('SHA256:',hashlib.sha256(out.read_bytes()).hexdigest())
if __name__=='__main__':main()
