/** Pure, shared projection. Both the hub/tray and browser demo use this model.
 * A project is registered independently of its task history. Never count runs as projects.
 */
export const stateLabels={needs_input:'Čeká na tebe',needs_approval:'Čeká na schválení',error:'Potřebuje zásah',working:'Pracuje',review:'Výsledek ke kontrole',unknown:'Stav neověřen',idle:'Bez aktivní úlohy',paused:'Pozastaveno',disconnected:'Výpadek spojení'};
const waits=new Set(['needs_input','needs_approval']);
const active=new Set(['working','needs_input','needs_approval','error']);
const state=s=>s.effectiveState||s.state;
const start=s=>s.runStartedAt||s.stateSince||s.activityAt||0;
const main=s=>s.role==='main'||(!s.role&&s.evidence!=='observed');
const support=s=>s.role==='support';
const usable=s=>s.connected&&s.historical!==true&&s.current!==false;
const rank={needs_input:0,needs_approval:0,error:1,working:2,review:3,unknown:4,paused:5,idle:6,disconnected:7};
const text=(s)=>String(s.activity||'').slice(0,600);
export function projectProjection(registry,sessions,now=Date.now()){
  return registry.map(p=>{
    const all=sessions.filter(s=>s.projectKey===p.key);
    const roots=all.filter(main);
    const latest=new Map();
    for(const s of roots)if(!latest.has(s.agent)||start(s)>start(latest.get(s.agent)))latest.set(s.agent,s);
    const current=all.filter(s=>{
      if(!usable(s))return false;
      // True pending requests from a delegated task belong to the project too.
      if((main(s)||support(s))&&waits.has(state(s))&&s.evidence!=='observed')return true;
      if(support(s)&&state(s)==='working')return true;
      if(!main(s))return false;
      if(latest.get(s.agent)===s)return true;
      return s.evidence!=='observed'&&active.has(state(s));
    }).sort((a,b)=>(rank[state(a)]??9)-(rank[state(b)]??9)||start(b)-start(a));
    const primary=current[0];
    const connected=p.connected===true;
    const status=!connected?'disconnected':primary?state(primary):'unknown';
    const waiting=current.filter(s=>waits.has(state(s))),working=current.filter(s=>state(s)==='working'),reviews=current.filter(s=>state(s)==='review');
    const safeHistory=roots.filter(s=>!current.includes(s)).sort((a,b)=>start(b)-start(a));
    const diagnostic=all.filter(s=>!main(s));
    const activityAt=Math.max(0,...current.map(s=>s.activityAt||0));
    const secondary=[waiting.length>1?`${waiting.length} požadavky na tebe`:'',working.length&&(waiting.length||status!=='working')?`${working.length} další běh pracuje`:'',reviews.length&&status!=='review'?`${reviews.length} výsledek ke kontrole`:''].filter(Boolean).join(' · ');
    let summary=primary?text(primary):connected?'Připojeno. Čekám na aktuální událost hlavního agenta.':'Bridge nyní neodpovídá; poslední stav není ověřený.';
    if(primary?.evidence==='observed')summary=(summary||'Aktivita hlavního agenta')+' · podle záznamu';
    const files=new Map();let filesKnown=false,filesAt=0;
    // Prefer the workspace Git snapshot, not the sum of snapshots on every task.
    if(p.filesKnown){filesKnown=true;filesAt=p.filesAt||0;for(const f of p.files||[])files.set(f.path,f);}
    else for(const s of [...all].sort((a,b)=>(b.filesAt||0)-(a.filesAt||0))){
      if(s.filesKnown){filesKnown=true;filesAt=s.filesAt||0;for(const f of s.files||[])files.set(f.path,f);break;}
    }
    const actionable=connected?current.filter(s=>(s.evidence!=='observed'||main(s)&&s.state==='review'&&s.observedCompletionAt>0&&s.observedCompletionAt>=start(s))&&!s.acknowledged&&!s.snoozed&&['needs_input','needs_approval','error','review'].includes(state(s))):[];
    const signals=actionable.map(s=>`${s.key}:${s.stateRevision}:${state(s)}`).sort();
    const silenced=p.snoozeUntil>now;
    const fingerprint=signals.join('|');
    return {...p,project:p.project||p.name||'Projekt',state:status,effectiveState:status,activity:summary,secondary,activityAt,
      connected,agentNames:[...new Set(all.map(s=>s.agent))],currentKeys:current.map(s=>s.key),historyKeys:safeHistory.map(s=>s.key),diagnosticKeys:diagnostic.map(s=>s.key),sessionKeys:all.map(s=>s.key),
      primaryKey:primary?.key||null,focusUri:p.focusUri||primary?.focusUri||'',pendingCount:waiting.length,workingCount:working.length,reviewCount:reviews.length,
      files:[...files.values()],filesKnown,filesAt,branch:p.branch||primary?.branch||'',
      notificationState:actionable[0]?state(actionable[0]):null,notificationActivity:actionable[0]?text(actionable[0])+(actionable[0].evidence==='observed'?' · podle záznamu':''):'',notificationSignature:fingerprint,notify:signals.length>0&&!silenced&&p.acknowledgedSignature!==fingerprint,
      acknowledged:p.acknowledgedSignature===fingerprint,snoozed:silenced,
      evidence:primary?.evidence||'unknown',partialConnection:connected&&p.sources?.some(s=>!s.connected),
      lastKnownState:!connected?(roots.sort((a,b)=>start(b)-start(a))[0]?.state||'unknown'):null};
  });
}
