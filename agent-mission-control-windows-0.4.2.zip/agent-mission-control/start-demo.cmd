@echo off
cd /d "%~dp0"
node src\server.mjs --demo
pause
